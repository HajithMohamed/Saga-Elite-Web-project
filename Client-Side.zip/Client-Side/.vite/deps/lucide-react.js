import {
  require_react
} from "./chunk-JUSR5GC5.js";
import {
  __export,
  __toESM
} from "./chunk-G3PMV62Z.js";

// ../node_modules/lucide-react/dist/esm/icons/index.js
var icons_exports = {};
__export(icons_exports, {
  AArrowDown: () => AArrowDown,
  AArrowUp: () => AArrowUp,
  ALargeSmall: () => ALargeSmall,
  Accessibility: () => Accessibility,
  Activity: () => Activity,
  AirVent: () => AirVent,
  Airplay: () => Airplay,
  AlarmClock: () => AlarmClock,
  AlarmClockCheck: () => AlarmClockCheck,
  AlarmClockMinus: () => AlarmClockMinus,
  AlarmClockOff: () => AlarmClockOff,
  AlarmClockPlus: () => AlarmClockPlus,
  AlarmSmoke: () => AlarmSmoke,
  Album: () => Album,
  AlignCenterHorizontal: () => AlignCenterHorizontal,
  AlignCenterVertical: () => AlignCenterVertical,
  AlignEndHorizontal: () => AlignEndHorizontal,
  AlignEndVertical: () => AlignEndVertical,
  AlignHorizontalDistributeCenter: () => AlignHorizontalDistributeCenter,
  AlignHorizontalDistributeEnd: () => AlignHorizontalDistributeEnd,
  AlignHorizontalDistributeStart: () => AlignHorizontalDistributeStart,
  AlignHorizontalJustifyCenter: () => AlignHorizontalJustifyCenter,
  AlignHorizontalJustifyEnd: () => AlignHorizontalJustifyEnd,
  AlignHorizontalJustifyStart: () => AlignHorizontalJustifyStart,
  AlignHorizontalSpaceAround: () => AlignHorizontalSpaceAround,
  AlignHorizontalSpaceBetween: () => AlignHorizontalSpaceBetween,
  AlignStartHorizontal: () => AlignStartHorizontal,
  AlignStartVertical: () => AlignStartVertical,
  AlignVerticalDistributeCenter: () => AlignVerticalDistributeCenter,
  AlignVerticalDistributeEnd: () => AlignVerticalDistributeEnd,
  AlignVerticalDistributeStart: () => AlignVerticalDistributeStart,
  AlignVerticalJustifyCenter: () => AlignVerticalJustifyCenter,
  AlignVerticalJustifyEnd: () => AlignVerticalJustifyEnd,
  AlignVerticalJustifyStart: () => AlignVerticalJustifyStart,
  AlignVerticalSpaceAround: () => AlignVerticalSpaceAround,
  AlignVerticalSpaceBetween: () => AlignVerticalSpaceBetween,
  Ambulance: () => Ambulance,
  Ampersand: () => Ampersand,
  Ampersands: () => Ampersands,
  Amphora: () => Amphora,
  Anchor: () => Anchor,
  Angry: () => Angry,
  Annoyed: () => Annoyed,
  Antenna: () => Antenna,
  Anvil: () => Anvil,
  Aperture: () => Aperture,
  AppWindow: () => AppWindow,
  AppWindowMac: () => AppWindowMac,
  Apple: () => Apple,
  Archive: () => Archive,
  ArchiveRestore: () => ArchiveRestore,
  ArchiveX: () => ArchiveX,
  Armchair: () => Armchair,
  ArrowBigDown: () => ArrowBigDown,
  ArrowBigDownDash: () => ArrowBigDownDash,
  ArrowBigLeft: () => ArrowBigLeft,
  ArrowBigLeftDash: () => ArrowBigLeftDash,
  ArrowBigRight: () => ArrowBigRight,
  ArrowBigRightDash: () => ArrowBigRightDash,
  ArrowBigUp: () => ArrowBigUp,
  ArrowBigUpDash: () => ArrowBigUpDash,
  ArrowDown: () => ArrowDown,
  ArrowDown01: () => ArrowDown01,
  ArrowDown10: () => ArrowDown10,
  ArrowDownAZ: () => ArrowDownAZ,
  ArrowDownFromLine: () => ArrowDownFromLine,
  ArrowDownLeft: () => ArrowDownLeft,
  ArrowDownNarrowWide: () => ArrowDownNarrowWide,
  ArrowDownRight: () => ArrowDownRight,
  ArrowDownToDot: () => ArrowDownToDot,
  ArrowDownToLine: () => ArrowDownToLine,
  ArrowDownUp: () => ArrowDownUp,
  ArrowDownWideNarrow: () => ArrowDownWideNarrow,
  ArrowDownZA: () => ArrowDownZA,
  ArrowLeft: () => ArrowLeft,
  ArrowLeftFromLine: () => ArrowLeftFromLine,
  ArrowLeftRight: () => ArrowLeftRight,
  ArrowLeftToLine: () => ArrowLeftToLine,
  ArrowRight: () => ArrowRight,
  ArrowRightFromLine: () => ArrowRightFromLine,
  ArrowRightLeft: () => ArrowRightLeft,
  ArrowRightToLine: () => ArrowRightToLine,
  ArrowUp: () => ArrowUp,
  ArrowUp01: () => ArrowUp01,
  ArrowUp10: () => ArrowUp10,
  ArrowUpAZ: () => ArrowUpAZ,
  ArrowUpDown: () => ArrowUpDown,
  ArrowUpFromDot: () => ArrowUpFromDot,
  ArrowUpFromLine: () => ArrowUpFromLine,
  ArrowUpLeft: () => ArrowUpLeft,
  ArrowUpNarrowWide: () => ArrowUpNarrowWide,
  ArrowUpRight: () => ArrowUpRight,
  ArrowUpToLine: () => ArrowUpToLine,
  ArrowUpWideNarrow: () => ArrowUpWideNarrow,
  ArrowUpZA: () => ArrowUpZA,
  ArrowsUpFromLine: () => ArrowsUpFromLine,
  Asterisk: () => Asterisk,
  AtSign: () => AtSign,
  Atom: () => Atom,
  AudioLines: () => AudioLines,
  AudioWaveform: () => AudioWaveform,
  Award: () => Award,
  Axe: () => Axe,
  Axis3d: () => Axis3d,
  Baby: () => Baby,
  Backpack: () => Backpack,
  Badge: () => Badge,
  BadgeAlert: () => BadgeAlert,
  BadgeCent: () => BadgeCent,
  BadgeCheck: () => BadgeCheck,
  BadgeDollarSign: () => BadgeDollarSign,
  BadgeEuro: () => BadgeEuro,
  BadgeIndianRupee: () => BadgeIndianRupee,
  BadgeInfo: () => BadgeInfo,
  BadgeJapaneseYen: () => BadgeJapaneseYen,
  BadgeMinus: () => BadgeMinus,
  BadgePercent: () => BadgePercent,
  BadgePlus: () => BadgePlus,
  BadgePoundSterling: () => BadgePoundSterling,
  BadgeQuestionMark: () => BadgeQuestionMark,
  BadgeRussianRuble: () => BadgeRussianRuble,
  BadgeSwissFranc: () => BadgeSwissFranc,
  BadgeTurkishLira: () => BadgeTurkishLira,
  BadgeX: () => BadgeX,
  BaggageClaim: () => BaggageClaim,
  Balloon: () => Balloon,
  Ban: () => Ban,
  Banana: () => Banana,
  Bandage: () => Bandage,
  Banknote: () => Banknote,
  BanknoteArrowDown: () => BanknoteArrowDown,
  BanknoteArrowUp: () => BanknoteArrowUp,
  BanknoteX: () => BanknoteX,
  Barcode: () => Barcode,
  Barrel: () => Barrel,
  Baseline: () => Baseline,
  Bath: () => Bath,
  Battery: () => Battery,
  BatteryCharging: () => BatteryCharging,
  BatteryFull: () => BatteryFull,
  BatteryLow: () => BatteryLow,
  BatteryMedium: () => BatteryMedium,
  BatteryPlus: () => BatteryPlus,
  BatteryWarning: () => BatteryWarning,
  Beaker: () => Beaker,
  Bean: () => Bean,
  BeanOff: () => BeanOff,
  Bed: () => Bed,
  BedDouble: () => BedDouble,
  BedSingle: () => BedSingle,
  Beef: () => Beef,
  Beer: () => Beer,
  BeerOff: () => BeerOff,
  Bell: () => Bell,
  BellDot: () => BellDot,
  BellElectric: () => BellElectric,
  BellMinus: () => BellMinus,
  BellOff: () => BellOff,
  BellPlus: () => BellPlus,
  BellRing: () => BellRing,
  BetweenHorizontalEnd: () => BetweenHorizontalEnd,
  BetweenHorizontalStart: () => BetweenHorizontalStart,
  BetweenVerticalEnd: () => BetweenVerticalEnd,
  BetweenVerticalStart: () => BetweenVerticalStart,
  BicepsFlexed: () => BicepsFlexed,
  Bike: () => Bike,
  Binary: () => Binary,
  Binoculars: () => Binoculars,
  Biohazard: () => Biohazard,
  Bird: () => Bird,
  Birdhouse: () => Birdhouse,
  Bitcoin: () => Bitcoin,
  Blend: () => Blend,
  Blinds: () => Blinds,
  Blocks: () => Blocks,
  Bluetooth: () => Bluetooth,
  BluetoothConnected: () => BluetoothConnected,
  BluetoothOff: () => BluetoothOff,
  BluetoothSearching: () => BluetoothSearching,
  Bold: () => Bold,
  Bolt: () => Bolt,
  Bomb: () => Bomb,
  Bone: () => Bone,
  Book: () => Book,
  BookA: () => BookA,
  BookAlert: () => BookAlert,
  BookAudio: () => BookAudio,
  BookCheck: () => BookCheck,
  BookCopy: () => BookCopy,
  BookDashed: () => BookDashed,
  BookDown: () => BookDown,
  BookHeadphones: () => BookHeadphones,
  BookHeart: () => BookHeart,
  BookImage: () => BookImage,
  BookKey: () => BookKey,
  BookLock: () => BookLock,
  BookMarked: () => BookMarked,
  BookMinus: () => BookMinus,
  BookOpen: () => BookOpen,
  BookOpenCheck: () => BookOpenCheck,
  BookOpenText: () => BookOpenText,
  BookPlus: () => BookPlus,
  BookSearch: () => BookSearch,
  BookText: () => BookText,
  BookType: () => BookType,
  BookUp: () => BookUp,
  BookUp2: () => BookUp2,
  BookUser: () => BookUser,
  BookX: () => BookX,
  Bookmark: () => Bookmark,
  BookmarkCheck: () => BookmarkCheck,
  BookmarkMinus: () => BookmarkMinus,
  BookmarkPlus: () => BookmarkPlus,
  BookmarkX: () => BookmarkX,
  BoomBox: () => BoomBox,
  Bot: () => Bot,
  BotMessageSquare: () => BotMessageSquare,
  BotOff: () => BotOff,
  BottleWine: () => BottleWine,
  BowArrow: () => BowArrow,
  Box: () => Box,
  Boxes: () => Boxes,
  Braces: () => Braces,
  Brackets: () => Brackets,
  Brain: () => Brain,
  BrainCircuit: () => BrainCircuit,
  BrainCog: () => BrainCog,
  BrickWall: () => BrickWall,
  BrickWallFire: () => BrickWallFire,
  BrickWallShield: () => BrickWallShield,
  Briefcase: () => Briefcase,
  BriefcaseBusiness: () => BriefcaseBusiness,
  BriefcaseConveyorBelt: () => BriefcaseConveyorBelt,
  BriefcaseMedical: () => BriefcaseMedical,
  BringToFront: () => BringToFront,
  Brush: () => Brush,
  BrushCleaning: () => BrushCleaning,
  Bubbles: () => Bubbles,
  Bug: () => Bug,
  BugOff: () => BugOff,
  BugPlay: () => BugPlay,
  Building: () => Building,
  Building2: () => Building2,
  Bus: () => Bus,
  BusFront: () => BusFront,
  Cable: () => Cable,
  CableCar: () => CableCar,
  Cake: () => Cake,
  CakeSlice: () => CakeSlice,
  Calculator: () => Calculator,
  Calendar: () => Calendar,
  Calendar1: () => Calendar1,
  CalendarArrowDown: () => CalendarArrowDown,
  CalendarArrowUp: () => CalendarArrowUp,
  CalendarCheck: () => CalendarCheck,
  CalendarCheck2: () => CalendarCheck2,
  CalendarClock: () => CalendarClock,
  CalendarCog: () => CalendarCog,
  CalendarDays: () => CalendarDays,
  CalendarFold: () => CalendarFold,
  CalendarHeart: () => CalendarHeart,
  CalendarMinus: () => CalendarMinus,
  CalendarMinus2: () => CalendarMinus2,
  CalendarOff: () => CalendarOff,
  CalendarPlus: () => CalendarPlus,
  CalendarPlus2: () => CalendarPlus2,
  CalendarRange: () => CalendarRange,
  CalendarSearch: () => CalendarSearch,
  CalendarSync: () => CalendarSync,
  CalendarX: () => CalendarX,
  CalendarX2: () => CalendarX2,
  Calendars: () => Calendars,
  Camera: () => Camera,
  CameraOff: () => CameraOff,
  Candy: () => Candy,
  CandyCane: () => CandyCane,
  CandyOff: () => CandyOff,
  Cannabis: () => Cannabis,
  CannabisOff: () => CannabisOff,
  Captions: () => Captions,
  CaptionsOff: () => CaptionsOff,
  Car: () => Car,
  CarFront: () => CarFront,
  CarTaxiFront: () => CarTaxiFront,
  Caravan: () => Caravan,
  CardSim: () => CardSim,
  Carrot: () => Carrot,
  CaseLower: () => CaseLower,
  CaseSensitive: () => CaseSensitive,
  CaseUpper: () => CaseUpper,
  CassetteTape: () => CassetteTape,
  Cast: () => Cast,
  Castle: () => Castle,
  Cat: () => Cat,
  Cctv: () => Cctv,
  ChartArea: () => ChartArea,
  ChartBar: () => ChartBar,
  ChartBarBig: () => ChartBarBig,
  ChartBarDecreasing: () => ChartBarDecreasing,
  ChartBarIncreasing: () => ChartBarIncreasing,
  ChartBarStacked: () => ChartBarStacked,
  ChartCandlestick: () => ChartCandlestick,
  ChartColumn: () => ChartColumn,
  ChartColumnBig: () => ChartColumnBig,
  ChartColumnDecreasing: () => ChartColumnDecreasing,
  ChartColumnIncreasing: () => ChartColumnIncreasing,
  ChartColumnStacked: () => ChartColumnStacked,
  ChartGantt: () => ChartGantt,
  ChartLine: () => ChartLine,
  ChartNetwork: () => ChartNetwork,
  ChartNoAxesColumn: () => ChartNoAxesColumn,
  ChartNoAxesColumnDecreasing: () => ChartNoAxesColumnDecreasing,
  ChartNoAxesColumnIncreasing: () => ChartNoAxesColumnIncreasing,
  ChartNoAxesCombined: () => ChartNoAxesCombined,
  ChartNoAxesGantt: () => ChartNoAxesGantt,
  ChartPie: () => ChartPie,
  ChartScatter: () => ChartScatter,
  ChartSpline: () => ChartSpline,
  Check: () => Check,
  CheckCheck: () => CheckCheck,
  CheckLine: () => CheckLine,
  ChefHat: () => ChefHat,
  Cherry: () => Cherry,
  ChessBishop: () => ChessBishop,
  ChessKing: () => ChessKing,
  ChessKnight: () => ChessKnight,
  ChessPawn: () => ChessPawn,
  ChessQueen: () => ChessQueen,
  ChessRook: () => ChessRook,
  ChevronDown: () => ChevronDown,
  ChevronFirst: () => ChevronFirst,
  ChevronLast: () => ChevronLast,
  ChevronLeft: () => ChevronLeft,
  ChevronRight: () => ChevronRight,
  ChevronUp: () => ChevronUp,
  ChevronsDown: () => ChevronsDown,
  ChevronsDownUp: () => ChevronsDownUp,
  ChevronsLeft: () => ChevronsLeft,
  ChevronsLeftRight: () => ChevronsLeftRight,
  ChevronsLeftRightEllipsis: () => ChevronsLeftRightEllipsis,
  ChevronsRight: () => ChevronsRight,
  ChevronsRightLeft: () => ChevronsRightLeft,
  ChevronsUp: () => ChevronsUp,
  ChevronsUpDown: () => ChevronsUpDown,
  Chromium: () => Chromium,
  Church: () => Church,
  Cigarette: () => Cigarette,
  CigaretteOff: () => CigaretteOff,
  Circle: () => Circle,
  CircleAlert: () => CircleAlert,
  CircleArrowDown: () => CircleArrowDown,
  CircleArrowLeft: () => CircleArrowLeft,
  CircleArrowOutDownLeft: () => CircleArrowOutDownLeft,
  CircleArrowOutDownRight: () => CircleArrowOutDownRight,
  CircleArrowOutUpLeft: () => CircleArrowOutUpLeft,
  CircleArrowOutUpRight: () => CircleArrowOutUpRight,
  CircleArrowRight: () => CircleArrowRight,
  CircleArrowUp: () => CircleArrowUp,
  CircleCheck: () => CircleCheck,
  CircleCheckBig: () => CircleCheckBig,
  CircleChevronDown: () => CircleChevronDown,
  CircleChevronLeft: () => CircleChevronLeft,
  CircleChevronRight: () => CircleChevronRight,
  CircleChevronUp: () => CircleChevronUp,
  CircleDashed: () => CircleDashed,
  CircleDivide: () => CircleDivide,
  CircleDollarSign: () => CircleDollarSign,
  CircleDot: () => CircleDot,
  CircleDotDashed: () => CircleDotDashed,
  CircleEllipsis: () => CircleEllipsis,
  CircleEqual: () => CircleEqual,
  CircleFadingArrowUp: () => CircleFadingArrowUp,
  CircleFadingPlus: () => CircleFadingPlus,
  CircleGauge: () => CircleGauge,
  CircleMinus: () => CircleMinus,
  CircleOff: () => CircleOff,
  CircleParking: () => CircleParking,
  CircleParkingOff: () => CircleParkingOff,
  CirclePause: () => CirclePause,
  CirclePercent: () => CirclePercent,
  CirclePile: () => CirclePile,
  CirclePlay: () => CirclePlay,
  CirclePlus: () => CirclePlus,
  CirclePoundSterling: () => CirclePoundSterling,
  CirclePower: () => CirclePower,
  CircleQuestionMark: () => CircleQuestionMark,
  CircleSlash: () => CircleSlash,
  CircleSlash2: () => CircleSlash2,
  CircleSmall: () => CircleSmall,
  CircleStar: () => CircleStar,
  CircleStop: () => CircleStop,
  CircleUser: () => CircleUser,
  CircleUserRound: () => CircleUserRound,
  CircleX: () => CircleX,
  CircuitBoard: () => CircuitBoard,
  Citrus: () => Citrus,
  Clapperboard: () => Clapperboard,
  Clipboard: () => Clipboard,
  ClipboardCheck: () => ClipboardCheck,
  ClipboardClock: () => ClipboardClock,
  ClipboardCopy: () => ClipboardCopy,
  ClipboardList: () => ClipboardList,
  ClipboardMinus: () => ClipboardMinus,
  ClipboardPaste: () => ClipboardPaste,
  ClipboardPen: () => ClipboardPen,
  ClipboardPenLine: () => ClipboardPenLine,
  ClipboardPlus: () => ClipboardPlus,
  ClipboardType: () => ClipboardType,
  ClipboardX: () => ClipboardX,
  Clock: () => Clock,
  Clock1: () => Clock1,
  Clock10: () => Clock10,
  Clock11: () => Clock11,
  Clock12: () => Clock12,
  Clock2: () => Clock2,
  Clock3: () => Clock3,
  Clock4: () => Clock4,
  Clock5: () => Clock5,
  Clock6: () => Clock6,
  Clock7: () => Clock7,
  Clock8: () => Clock8,
  Clock9: () => Clock9,
  ClockAlert: () => ClockAlert,
  ClockArrowDown: () => ClockArrowDown,
  ClockArrowUp: () => ClockArrowUp,
  ClockCheck: () => ClockCheck,
  ClockFading: () => ClockFading,
  ClockPlus: () => ClockPlus,
  ClosedCaption: () => ClosedCaption,
  Cloud: () => Cloud,
  CloudAlert: () => CloudAlert,
  CloudBackup: () => CloudBackup,
  CloudCheck: () => CloudCheck,
  CloudCog: () => CloudCog,
  CloudDownload: () => CloudDownload,
  CloudDrizzle: () => CloudDrizzle,
  CloudFog: () => CloudFog,
  CloudHail: () => CloudHail,
  CloudLightning: () => CloudLightning,
  CloudMoon: () => CloudMoon,
  CloudMoonRain: () => CloudMoonRain,
  CloudOff: () => CloudOff,
  CloudRain: () => CloudRain,
  CloudRainWind: () => CloudRainWind,
  CloudSnow: () => CloudSnow,
  CloudSun: () => CloudSun,
  CloudSunRain: () => CloudSunRain,
  CloudSync: () => CloudSync,
  CloudUpload: () => CloudUpload,
  Cloudy: () => Cloudy,
  Clover: () => Clover,
  Club: () => Club,
  Code: () => Code,
  CodeXml: () => CodeXml,
  Codepen: () => Codepen,
  Codesandbox: () => Codesandbox,
  Coffee: () => Coffee,
  Cog: () => Cog,
  Coins: () => Coins,
  Columns2: () => Columns2,
  Columns3: () => Columns3,
  Columns3Cog: () => Columns3Cog,
  Columns4: () => Columns4,
  Combine: () => Combine,
  Command: () => Command,
  Compass: () => Compass,
  Component: () => Component,
  Computer: () => Computer,
  ConciergeBell: () => ConciergeBell,
  Cone: () => Cone,
  Construction: () => Construction,
  Contact: () => Contact,
  ContactRound: () => ContactRound,
  Container: () => Container,
  Contrast: () => Contrast,
  Cookie: () => Cookie,
  CookingPot: () => CookingPot,
  Copy: () => Copy,
  CopyCheck: () => CopyCheck,
  CopyMinus: () => CopyMinus,
  CopyPlus: () => CopyPlus,
  CopySlash: () => CopySlash,
  CopyX: () => CopyX,
  Copyleft: () => Copyleft,
  Copyright: () => Copyright,
  CornerDownLeft: () => CornerDownLeft,
  CornerDownRight: () => CornerDownRight,
  CornerLeftDown: () => CornerLeftDown,
  CornerLeftUp: () => CornerLeftUp,
  CornerRightDown: () => CornerRightDown,
  CornerRightUp: () => CornerRightUp,
  CornerUpLeft: () => CornerUpLeft,
  CornerUpRight: () => CornerUpRight,
  Cpu: () => Cpu,
  CreativeCommons: () => CreativeCommons,
  CreditCard: () => CreditCard,
  Croissant: () => Croissant,
  Crop: () => Crop,
  Cross: () => Cross,
  Crosshair: () => Crosshair,
  Crown: () => Crown,
  Cuboid: () => Cuboid,
  CupSoda: () => CupSoda,
  Currency: () => Currency,
  Cylinder: () => Cylinder,
  Dam: () => Dam,
  Database: () => Database,
  DatabaseBackup: () => DatabaseBackup,
  DatabaseSearch: () => DatabaseSearch,
  DatabaseZap: () => DatabaseZap,
  DecimalsArrowLeft: () => DecimalsArrowLeft,
  DecimalsArrowRight: () => DecimalsArrowRight,
  Delete: () => Delete,
  Dessert: () => Dessert,
  Diameter: () => Diameter,
  Diamond: () => Diamond,
  DiamondMinus: () => DiamondMinus,
  DiamondPercent: () => DiamondPercent,
  DiamondPlus: () => DiamondPlus,
  Dice1: () => Dice1,
  Dice2: () => Dice2,
  Dice3: () => Dice3,
  Dice4: () => Dice4,
  Dice5: () => Dice5,
  Dice6: () => Dice6,
  Dices: () => Dices,
  Diff: () => Diff,
  Disc: () => Disc,
  Disc2: () => Disc2,
  Disc3: () => Disc3,
  DiscAlbum: () => DiscAlbum,
  Divide: () => Divide,
  Dna: () => Dna,
  DnaOff: () => DnaOff,
  Dock: () => Dock,
  Dog: () => Dog,
  DollarSign: () => DollarSign,
  Donut: () => Donut,
  DoorClosed: () => DoorClosed,
  DoorClosedLocked: () => DoorClosedLocked,
  DoorOpen: () => DoorOpen,
  Dot: () => Dot,
  Download: () => Download,
  DraftingCompass: () => DraftingCompass,
  Drama: () => Drama,
  Dribbble: () => Dribbble,
  Drill: () => Drill,
  Drone: () => Drone,
  Droplet: () => Droplet,
  DropletOff: () => DropletOff,
  Droplets: () => Droplets,
  Drum: () => Drum,
  Drumstick: () => Drumstick,
  Dumbbell: () => Dumbbell,
  Ear: () => Ear,
  EarOff: () => EarOff,
  Earth: () => Earth,
  EarthLock: () => EarthLock,
  Eclipse: () => Eclipse,
  Egg: () => Egg,
  EggFried: () => EggFried,
  EggOff: () => EggOff,
  Ellipsis: () => Ellipsis,
  EllipsisVertical: () => EllipsisVertical,
  Equal: () => Equal,
  EqualApproximately: () => EqualApproximately,
  EqualNot: () => EqualNot,
  Eraser: () => Eraser,
  EthernetPort: () => EthernetPort,
  Euro: () => Euro,
  EvCharger: () => EvCharger,
  Expand: () => Expand,
  ExternalLink: () => ExternalLink,
  Eye: () => Eye,
  EyeClosed: () => EyeClosed,
  EyeOff: () => EyeOff,
  Facebook: () => Facebook,
  Factory: () => Factory,
  Fan: () => Fan,
  FastForward: () => FastForward,
  Feather: () => Feather,
  Fence: () => Fence,
  FerrisWheel: () => FerrisWheel,
  Figma: () => Figma,
  File: () => File,
  FileArchive: () => FileArchive,
  FileAxis3d: () => FileAxis3d,
  FileBadge: () => FileBadge,
  FileBox: () => FileBox,
  FileBraces: () => FileBraces,
  FileBracesCorner: () => FileBracesCorner,
  FileChartColumn: () => FileChartColumn,
  FileChartColumnIncreasing: () => FileChartColumnIncreasing,
  FileChartLine: () => FileChartLine,
  FileChartPie: () => FileChartPie,
  FileCheck: () => FileCheck,
  FileCheckCorner: () => FileCheckCorner,
  FileClock: () => FileClock,
  FileCode: () => FileCode,
  FileCodeCorner: () => FileCodeCorner,
  FileCog: () => FileCog,
  FileDiff: () => FileDiff,
  FileDigit: () => FileDigit,
  FileDown: () => FileDown,
  FileExclamationPoint: () => FileExclamationPoint,
  FileHeadphone: () => FileHeadphone,
  FileHeart: () => FileHeart,
  FileImage: () => FileImage,
  FileInput: () => FileInput,
  FileKey: () => FileKey,
  FileLock: () => FileLock,
  FileMinus: () => FileMinus,
  FileMinusCorner: () => FileMinusCorner,
  FileMusic: () => FileMusic,
  FileOutput: () => FileOutput,
  FilePen: () => FilePen,
  FilePenLine: () => FilePenLine,
  FilePlay: () => FilePlay,
  FilePlus: () => FilePlus,
  FilePlusCorner: () => FilePlusCorner,
  FileQuestionMark: () => FileQuestionMark,
  FileScan: () => FileScan,
  FileSearch: () => FileSearch,
  FileSearchCorner: () => FileSearchCorner,
  FileSignal: () => FileSignal,
  FileSliders: () => FileSliders,
  FileSpreadsheet: () => FileSpreadsheet,
  FileStack: () => FileStack,
  FileSymlink: () => FileSymlink,
  FileTerminal: () => FileTerminal,
  FileText: () => FileText,
  FileType: () => FileType,
  FileTypeCorner: () => FileTypeCorner,
  FileUp: () => FileUp,
  FileUser: () => FileUser,
  FileVideoCamera: () => FileVideoCamera,
  FileVolume: () => FileVolume,
  FileX: () => FileX,
  FileXCorner: () => FileXCorner,
  Files: () => Files,
  Film: () => Film,
  FingerprintPattern: () => FingerprintPattern,
  FireExtinguisher: () => FireExtinguisher,
  Fish: () => Fish,
  FishOff: () => FishOff,
  FishSymbol: () => FishSymbol,
  FishingHook: () => FishingHook,
  Flag: () => Flag,
  FlagOff: () => FlagOff,
  FlagTriangleLeft: () => FlagTriangleLeft,
  FlagTriangleRight: () => FlagTriangleRight,
  Flame: () => Flame,
  FlameKindling: () => FlameKindling,
  Flashlight: () => Flashlight,
  FlashlightOff: () => FlashlightOff,
  FlaskConical: () => FlaskConical,
  FlaskConicalOff: () => FlaskConicalOff,
  FlaskRound: () => FlaskRound,
  FlipHorizontal2: () => FlipHorizontal2,
  FlipVertical2: () => FlipVertical2,
  Flower: () => Flower,
  Flower2: () => Flower2,
  Focus: () => Focus,
  FoldHorizontal: () => FoldHorizontal,
  FoldVertical: () => FoldVertical,
  Folder: () => Folder,
  FolderArchive: () => FolderArchive,
  FolderCheck: () => FolderCheck,
  FolderClock: () => FolderClock,
  FolderClosed: () => FolderClosed,
  FolderCode: () => FolderCode,
  FolderCog: () => FolderCog,
  FolderDot: () => FolderDot,
  FolderDown: () => FolderDown,
  FolderGit: () => FolderGit,
  FolderGit2: () => FolderGit2,
  FolderHeart: () => FolderHeart,
  FolderInput: () => FolderInput,
  FolderKanban: () => FolderKanban,
  FolderKey: () => FolderKey,
  FolderLock: () => FolderLock,
  FolderMinus: () => FolderMinus,
  FolderOpen: () => FolderOpen,
  FolderOpenDot: () => FolderOpenDot,
  FolderOutput: () => FolderOutput,
  FolderPen: () => FolderPen,
  FolderPlus: () => FolderPlus,
  FolderRoot: () => FolderRoot,
  FolderSearch: () => FolderSearch,
  FolderSearch2: () => FolderSearch2,
  FolderSymlink: () => FolderSymlink,
  FolderSync: () => FolderSync,
  FolderTree: () => FolderTree,
  FolderUp: () => FolderUp,
  FolderX: () => FolderX,
  Folders: () => Folders,
  Footprints: () => Footprints,
  Forklift: () => Forklift,
  Form: () => Form,
  Forward: () => Forward,
  Frame: () => Frame,
  Framer: () => Framer,
  Frown: () => Frown,
  Fuel: () => Fuel,
  Fullscreen: () => Fullscreen,
  Funnel: () => Funnel,
  FunnelPlus: () => FunnelPlus,
  FunnelX: () => FunnelX,
  GalleryHorizontal: () => GalleryHorizontal,
  GalleryHorizontalEnd: () => GalleryHorizontalEnd,
  GalleryThumbnails: () => GalleryThumbnails,
  GalleryVertical: () => GalleryVertical,
  GalleryVerticalEnd: () => GalleryVerticalEnd,
  Gamepad: () => Gamepad,
  Gamepad2: () => Gamepad2,
  GamepadDirectional: () => GamepadDirectional,
  Gauge: () => Gauge,
  Gavel: () => Gavel,
  Gem: () => Gem,
  GeorgianLari: () => GeorgianLari,
  Ghost: () => Ghost,
  Gift: () => Gift,
  GitBranch: () => GitBranch,
  GitBranchMinus: () => GitBranchMinus,
  GitBranchPlus: () => GitBranchPlus,
  GitCommitHorizontal: () => GitCommitHorizontal,
  GitCommitVertical: () => GitCommitVertical,
  GitCompare: () => GitCompare,
  GitCompareArrows: () => GitCompareArrows,
  GitFork: () => GitFork,
  GitGraph: () => GitGraph,
  GitMerge: () => GitMerge,
  GitMergeConflict: () => GitMergeConflict,
  GitPullRequest: () => GitPullRequest,
  GitPullRequestArrow: () => GitPullRequestArrow,
  GitPullRequestClosed: () => GitPullRequestClosed,
  GitPullRequestCreate: () => GitPullRequestCreate,
  GitPullRequestCreateArrow: () => GitPullRequestCreateArrow,
  GitPullRequestDraft: () => GitPullRequestDraft,
  Github: () => Github,
  Gitlab: () => Gitlab,
  GlassWater: () => GlassWater,
  Glasses: () => Glasses,
  Globe: () => Globe,
  GlobeLock: () => GlobeLock,
  GlobeOff: () => GlobeOff,
  GlobeX: () => GlobeX,
  Goal: () => Goal,
  Gpu: () => Gpu,
  GraduationCap: () => GraduationCap,
  Grape: () => Grape,
  Grid2x2: () => Grid2x2,
  Grid2x2Check: () => Grid2x2Check,
  Grid2x2Plus: () => Grid2x2Plus,
  Grid2x2X: () => Grid2x2X,
  Grid3x2: () => Grid3x2,
  Grid3x3: () => Grid3x3,
  Grip: () => Grip,
  GripHorizontal: () => GripHorizontal,
  GripVertical: () => GripVertical,
  Group: () => Group,
  Guitar: () => Guitar,
  Ham: () => Ham,
  Hamburger: () => Hamburger,
  Hammer: () => Hammer,
  Hand: () => Hand,
  HandCoins: () => HandCoins,
  HandFist: () => HandFist,
  HandGrab: () => HandGrab,
  HandHeart: () => HandHeart,
  HandHelping: () => HandHelping,
  HandMetal: () => HandMetal,
  HandPlatter: () => HandPlatter,
  Handbag: () => Handbag,
  Handshake: () => Handshake,
  HardDrive: () => HardDrive,
  HardDriveDownload: () => HardDriveDownload,
  HardDriveUpload: () => HardDriveUpload,
  HardHat: () => HardHat,
  Hash: () => Hash,
  HatGlasses: () => HatGlasses,
  Haze: () => Haze,
  Hd: () => Hd,
  HdmiPort: () => HdmiPort,
  Heading: () => Heading,
  Heading1: () => Heading1,
  Heading2: () => Heading2,
  Heading3: () => Heading3,
  Heading4: () => Heading4,
  Heading5: () => Heading5,
  Heading6: () => Heading6,
  HeadphoneOff: () => HeadphoneOff,
  Headphones: () => Headphones,
  Headset: () => Headset,
  Heart: () => Heart,
  HeartCrack: () => HeartCrack,
  HeartHandshake: () => HeartHandshake,
  HeartMinus: () => HeartMinus,
  HeartOff: () => HeartOff,
  HeartPlus: () => HeartPlus,
  HeartPulse: () => HeartPulse,
  Heater: () => Heater,
  Helicopter: () => Helicopter,
  Hexagon: () => Hexagon,
  Highlighter: () => Highlighter,
  History: () => History,
  Hop: () => Hop,
  HopOff: () => HopOff,
  Hospital: () => Hospital,
  Hotel: () => Hotel,
  Hourglass: () => Hourglass,
  House: () => House,
  HouseHeart: () => HouseHeart,
  HousePlug: () => HousePlug,
  HousePlus: () => HousePlus,
  HouseWifi: () => HouseWifi,
  IceCreamBowl: () => IceCreamBowl,
  IceCreamCone: () => IceCreamCone,
  IdCard: () => IdCard,
  IdCardLanyard: () => IdCardLanyard,
  Image: () => Image,
  ImageDown: () => ImageDown,
  ImageMinus: () => ImageMinus,
  ImageOff: () => ImageOff,
  ImagePlay: () => ImagePlay,
  ImagePlus: () => ImagePlus,
  ImageUp: () => ImageUp,
  ImageUpscale: () => ImageUpscale,
  Images: () => Images,
  Import: () => Import,
  Inbox: () => Inbox,
  IndianRupee: () => IndianRupee,
  Infinity: () => Infinity,
  Info: () => Info,
  InspectionPanel: () => InspectionPanel,
  Instagram: () => Instagram,
  Italic: () => Italic,
  IterationCcw: () => IterationCcw,
  IterationCw: () => IterationCw,
  JapaneseYen: () => JapaneseYen,
  Joystick: () => Joystick,
  Kanban: () => Kanban,
  Kayak: () => Kayak,
  Key: () => Key,
  KeyRound: () => KeyRound,
  KeySquare: () => KeySquare,
  Keyboard: () => Keyboard,
  KeyboardMusic: () => KeyboardMusic,
  KeyboardOff: () => KeyboardOff,
  Lamp: () => Lamp,
  LampCeiling: () => LampCeiling,
  LampDesk: () => LampDesk,
  LampFloor: () => LampFloor,
  LampWallDown: () => LampWallDown,
  LampWallUp: () => LampWallUp,
  LandPlot: () => LandPlot,
  Landmark: () => Landmark,
  Languages: () => Languages,
  Laptop: () => Laptop,
  LaptopMinimal: () => LaptopMinimal,
  LaptopMinimalCheck: () => LaptopMinimalCheck,
  Lasso: () => Lasso,
  LassoSelect: () => LassoSelect,
  Laugh: () => Laugh,
  Layers: () => Layers,
  Layers2: () => Layers2,
  LayersPlus: () => LayersPlus,
  LayoutDashboard: () => LayoutDashboard,
  LayoutGrid: () => LayoutGrid,
  LayoutList: () => LayoutList,
  LayoutPanelLeft: () => LayoutPanelLeft,
  LayoutPanelTop: () => LayoutPanelTop,
  LayoutTemplate: () => LayoutTemplate,
  Leaf: () => Leaf,
  LeafyGreen: () => LeafyGreen,
  Lectern: () => Lectern,
  LensConcave: () => LensConcave,
  LensConvex: () => LensConvex,
  Library: () => Library,
  LibraryBig: () => LibraryBig,
  LifeBuoy: () => LifeBuoy,
  Ligature: () => Ligature,
  Lightbulb: () => Lightbulb,
  LightbulbOff: () => LightbulbOff,
  LineDotRightHorizontal: () => LineDotRightHorizontal,
  LineSquiggle: () => LineSquiggle,
  Link: () => Link,
  Link2: () => Link2,
  Link2Off: () => Link2Off,
  Linkedin: () => Linkedin,
  List: () => List,
  ListCheck: () => ListCheck,
  ListChecks: () => ListChecks,
  ListChevronsDownUp: () => ListChevronsDownUp,
  ListChevronsUpDown: () => ListChevronsUpDown,
  ListCollapse: () => ListCollapse,
  ListEnd: () => ListEnd,
  ListFilter: () => ListFilter,
  ListFilterPlus: () => ListFilterPlus,
  ListIndentDecrease: () => ListIndentDecrease,
  ListIndentIncrease: () => ListIndentIncrease,
  ListMinus: () => ListMinus,
  ListMusic: () => ListMusic,
  ListOrdered: () => ListOrdered,
  ListPlus: () => ListPlus,
  ListRestart: () => ListRestart,
  ListStart: () => ListStart,
  ListTodo: () => ListTodo,
  ListTree: () => ListTree,
  ListVideo: () => ListVideo,
  ListX: () => ListX,
  Loader: () => Loader,
  LoaderCircle: () => LoaderCircle,
  LoaderPinwheel: () => LoaderPinwheel,
  Locate: () => Locate,
  LocateFixed: () => LocateFixed,
  LocateOff: () => LocateOff,
  Lock: () => Lock,
  LockKeyhole: () => LockKeyhole,
  LockKeyholeOpen: () => LockKeyholeOpen,
  LockOpen: () => LockOpen,
  LogIn: () => LogIn,
  LogOut: () => LogOut,
  Logs: () => Logs,
  Lollipop: () => Lollipop,
  Luggage: () => Luggage,
  Magnet: () => Magnet,
  Mail: () => Mail,
  MailCheck: () => MailCheck,
  MailMinus: () => MailMinus,
  MailOpen: () => MailOpen,
  MailPlus: () => MailPlus,
  MailQuestionMark: () => MailQuestionMark,
  MailSearch: () => MailSearch,
  MailWarning: () => MailWarning,
  MailX: () => MailX,
  Mailbox: () => Mailbox,
  Mails: () => Mails,
  Map: () => Map,
  MapMinus: () => MapMinus,
  MapPin: () => MapPin,
  MapPinCheck: () => MapPinCheck,
  MapPinCheckInside: () => MapPinCheckInside,
  MapPinHouse: () => MapPinHouse,
  MapPinMinus: () => MapPinMinus,
  MapPinMinusInside: () => MapPinMinusInside,
  MapPinOff: () => MapPinOff,
  MapPinPen: () => MapPinPen,
  MapPinPlus: () => MapPinPlus,
  MapPinPlusInside: () => MapPinPlusInside,
  MapPinX: () => MapPinX,
  MapPinXInside: () => MapPinXInside,
  MapPinned: () => MapPinned,
  MapPlus: () => MapPlus,
  Mars: () => Mars,
  MarsStroke: () => MarsStroke,
  Martini: () => Martini,
  Maximize: () => Maximize,
  Maximize2: () => Maximize2,
  Medal: () => Medal,
  Megaphone: () => Megaphone,
  MegaphoneOff: () => MegaphoneOff,
  Meh: () => Meh,
  MemoryStick: () => MemoryStick,
  Menu: () => Menu,
  Merge: () => Merge,
  MessageCircle: () => MessageCircle,
  MessageCircleCheck: () => MessageCircleCheck,
  MessageCircleCode: () => MessageCircleCode,
  MessageCircleDashed: () => MessageCircleDashed,
  MessageCircleHeart: () => MessageCircleHeart,
  MessageCircleMore: () => MessageCircleMore,
  MessageCircleOff: () => MessageCircleOff,
  MessageCirclePlus: () => MessageCirclePlus,
  MessageCircleQuestionMark: () => MessageCircleQuestionMark,
  MessageCircleReply: () => MessageCircleReply,
  MessageCircleWarning: () => MessageCircleWarning,
  MessageCircleX: () => MessageCircleX,
  MessageSquare: () => MessageSquare,
  MessageSquareCheck: () => MessageSquareCheck,
  MessageSquareCode: () => MessageSquareCode,
  MessageSquareDashed: () => MessageSquareDashed,
  MessageSquareDiff: () => MessageSquareDiff,
  MessageSquareDot: () => MessageSquareDot,
  MessageSquareHeart: () => MessageSquareHeart,
  MessageSquareLock: () => MessageSquareLock,
  MessageSquareMore: () => MessageSquareMore,
  MessageSquareOff: () => MessageSquareOff,
  MessageSquarePlus: () => MessageSquarePlus,
  MessageSquareQuote: () => MessageSquareQuote,
  MessageSquareReply: () => MessageSquareReply,
  MessageSquareShare: () => MessageSquareShare,
  MessageSquareText: () => MessageSquareText,
  MessageSquareWarning: () => MessageSquareWarning,
  MessageSquareX: () => MessageSquareX,
  MessagesSquare: () => MessagesSquare,
  Metronome: () => Metronome,
  Mic: () => Mic,
  MicOff: () => MicOff,
  MicVocal: () => MicVocal,
  Microchip: () => Microchip,
  Microscope: () => Microscope,
  Microwave: () => Microwave,
  Milestone: () => Milestone,
  Milk: () => Milk,
  MilkOff: () => MilkOff,
  Minimize: () => Minimize,
  Minimize2: () => Minimize2,
  Minus: () => Minus,
  MirrorRectangular: () => MirrorRectangular,
  MirrorRound: () => MirrorRound,
  Monitor: () => Monitor,
  MonitorCheck: () => MonitorCheck,
  MonitorCloud: () => MonitorCloud,
  MonitorCog: () => MonitorCog,
  MonitorDot: () => MonitorDot,
  MonitorDown: () => MonitorDown,
  MonitorOff: () => MonitorOff,
  MonitorPause: () => MonitorPause,
  MonitorPlay: () => MonitorPlay,
  MonitorSmartphone: () => MonitorSmartphone,
  MonitorSpeaker: () => MonitorSpeaker,
  MonitorStop: () => MonitorStop,
  MonitorUp: () => MonitorUp,
  MonitorX: () => MonitorX,
  Moon: () => Moon,
  MoonStar: () => MoonStar,
  Motorbike: () => Motorbike,
  Mountain: () => Mountain,
  MountainSnow: () => MountainSnow,
  Mouse: () => Mouse,
  MouseLeft: () => MouseLeft,
  MouseOff: () => MouseOff,
  MousePointer: () => MousePointer,
  MousePointer2: () => MousePointer2,
  MousePointer2Off: () => MousePointer2Off,
  MousePointerBan: () => MousePointerBan,
  MousePointerClick: () => MousePointerClick,
  MouseRight: () => MouseRight,
  Move: () => Move,
  Move3d: () => Move3d,
  MoveDiagonal: () => MoveDiagonal,
  MoveDiagonal2: () => MoveDiagonal2,
  MoveDown: () => MoveDown,
  MoveDownLeft: () => MoveDownLeft,
  MoveDownRight: () => MoveDownRight,
  MoveHorizontal: () => MoveHorizontal,
  MoveLeft: () => MoveLeft,
  MoveRight: () => MoveRight,
  MoveUp: () => MoveUp,
  MoveUpLeft: () => MoveUpLeft,
  MoveUpRight: () => MoveUpRight,
  MoveVertical: () => MoveVertical,
  Music: () => Music,
  Music2: () => Music2,
  Music3: () => Music3,
  Music4: () => Music4,
  Navigation: () => Navigation,
  Navigation2: () => Navigation2,
  Navigation2Off: () => Navigation2Off,
  NavigationOff: () => NavigationOff,
  Network: () => Network,
  Newspaper: () => Newspaper,
  Nfc: () => Nfc,
  NonBinary: () => NonBinary,
  Notebook: () => Notebook,
  NotebookPen: () => NotebookPen,
  NotebookTabs: () => NotebookTabs,
  NotebookText: () => NotebookText,
  NotepadText: () => NotepadText,
  NotepadTextDashed: () => NotepadTextDashed,
  Nut: () => Nut,
  NutOff: () => NutOff,
  Octagon: () => Octagon,
  OctagonAlert: () => OctagonAlert,
  OctagonMinus: () => OctagonMinus,
  OctagonPause: () => OctagonPause,
  OctagonX: () => OctagonX,
  Omega: () => Omega,
  Option: () => Option,
  Orbit: () => Orbit,
  Origami: () => Origami,
  Package: () => Package,
  Package2: () => Package2,
  PackageCheck: () => PackageCheck,
  PackageMinus: () => PackageMinus,
  PackageOpen: () => PackageOpen,
  PackagePlus: () => PackagePlus,
  PackageSearch: () => PackageSearch,
  PackageX: () => PackageX,
  PaintBucket: () => PaintBucket,
  PaintRoller: () => PaintRoller,
  Paintbrush: () => Paintbrush,
  PaintbrushVertical: () => PaintbrushVertical,
  Palette: () => Palette,
  Panda: () => Panda,
  PanelBottom: () => PanelBottom,
  PanelBottomClose: () => PanelBottomClose,
  PanelBottomDashed: () => PanelBottomDashed,
  PanelBottomOpen: () => PanelBottomOpen,
  PanelLeft: () => PanelLeft,
  PanelLeftClose: () => PanelLeftClose,
  PanelLeftDashed: () => PanelLeftDashed,
  PanelLeftOpen: () => PanelLeftOpen,
  PanelLeftRightDashed: () => PanelLeftRightDashed,
  PanelRight: () => PanelRight,
  PanelRightClose: () => PanelRightClose,
  PanelRightDashed: () => PanelRightDashed,
  PanelRightOpen: () => PanelRightOpen,
  PanelTop: () => PanelTop,
  PanelTopBottomDashed: () => PanelTopBottomDashed,
  PanelTopClose: () => PanelTopClose,
  PanelTopDashed: () => PanelTopDashed,
  PanelTopOpen: () => PanelTopOpen,
  PanelsLeftBottom: () => PanelsLeftBottom,
  PanelsRightBottom: () => PanelsRightBottom,
  PanelsTopLeft: () => PanelsTopLeft,
  Paperclip: () => Paperclip,
  Parentheses: () => Parentheses,
  ParkingMeter: () => ParkingMeter,
  PartyPopper: () => PartyPopper,
  Pause: () => Pause,
  PawPrint: () => PawPrint,
  PcCase: () => PcCase,
  Pen: () => Pen,
  PenLine: () => PenLine,
  PenOff: () => PenOff,
  PenTool: () => PenTool,
  Pencil: () => Pencil,
  PencilLine: () => PencilLine,
  PencilOff: () => PencilOff,
  PencilRuler: () => PencilRuler,
  Pentagon: () => Pentagon,
  Percent: () => Percent,
  PersonStanding: () => PersonStanding,
  PhilippinePeso: () => PhilippinePeso,
  Phone: () => Phone,
  PhoneCall: () => PhoneCall,
  PhoneForwarded: () => PhoneForwarded,
  PhoneIncoming: () => PhoneIncoming,
  PhoneMissed: () => PhoneMissed,
  PhoneOff: () => PhoneOff,
  PhoneOutgoing: () => PhoneOutgoing,
  Pi: () => Pi,
  Piano: () => Piano,
  Pickaxe: () => Pickaxe,
  PictureInPicture: () => PictureInPicture,
  PictureInPicture2: () => PictureInPicture2,
  PiggyBank: () => PiggyBank,
  Pilcrow: () => Pilcrow,
  PilcrowLeft: () => PilcrowLeft,
  PilcrowRight: () => PilcrowRight,
  Pill: () => Pill,
  PillBottle: () => PillBottle,
  Pin: () => Pin,
  PinOff: () => PinOff,
  Pipette: () => Pipette,
  Pizza: () => Pizza,
  Plane: () => Plane,
  PlaneLanding: () => PlaneLanding,
  PlaneTakeoff: () => PlaneTakeoff,
  Play: () => Play,
  Plug: () => Plug,
  Plug2: () => Plug2,
  PlugZap: () => PlugZap,
  Plus: () => Plus,
  Pocket: () => Pocket,
  PocketKnife: () => PocketKnife,
  Podcast: () => Podcast,
  Pointer: () => Pointer,
  PointerOff: () => PointerOff,
  Popcorn: () => Popcorn,
  Popsicle: () => Popsicle,
  PoundSterling: () => PoundSterling,
  Power: () => Power,
  PowerOff: () => PowerOff,
  Presentation: () => Presentation,
  Printer: () => Printer,
  PrinterCheck: () => PrinterCheck,
  PrinterX: () => PrinterX,
  Projector: () => Projector,
  Proportions: () => Proportions,
  Puzzle: () => Puzzle,
  Pyramid: () => Pyramid,
  QrCode: () => QrCode,
  Quote: () => Quote,
  Rabbit: () => Rabbit,
  Radar: () => Radar,
  Radiation: () => Radiation,
  Radical: () => Radical,
  Radio: () => Radio,
  RadioReceiver: () => RadioReceiver,
  RadioTower: () => RadioTower,
  Radius: () => Radius,
  RailSymbol: () => RailSymbol,
  Rainbow: () => Rainbow,
  Rat: () => Rat,
  Ratio: () => Ratio,
  Receipt: () => Receipt,
  ReceiptCent: () => ReceiptCent,
  ReceiptEuro: () => ReceiptEuro,
  ReceiptIndianRupee: () => ReceiptIndianRupee,
  ReceiptJapaneseYen: () => ReceiptJapaneseYen,
  ReceiptPoundSterling: () => ReceiptPoundSterling,
  ReceiptRussianRuble: () => ReceiptRussianRuble,
  ReceiptSwissFranc: () => ReceiptSwissFranc,
  ReceiptText: () => ReceiptText,
  ReceiptTurkishLira: () => ReceiptTurkishLira,
  RectangleCircle: () => RectangleCircle,
  RectangleEllipsis: () => RectangleEllipsis,
  RectangleGoggles: () => RectangleGoggles,
  RectangleHorizontal: () => RectangleHorizontal,
  RectangleVertical: () => RectangleVertical,
  Recycle: () => Recycle,
  Redo: () => Redo,
  Redo2: () => Redo2,
  RedoDot: () => RedoDot,
  RefreshCcw: () => RefreshCcw,
  RefreshCcwDot: () => RefreshCcwDot,
  RefreshCw: () => RefreshCw,
  RefreshCwOff: () => RefreshCwOff,
  Refrigerator: () => Refrigerator,
  Regex: () => Regex,
  RemoveFormatting: () => RemoveFormatting,
  Repeat: () => Repeat,
  Repeat1: () => Repeat1,
  Repeat2: () => Repeat2,
  Replace: () => Replace,
  ReplaceAll: () => ReplaceAll,
  Reply: () => Reply,
  ReplyAll: () => ReplyAll,
  Rewind: () => Rewind,
  Ribbon: () => Ribbon,
  Rocket: () => Rocket,
  RockingChair: () => RockingChair,
  RollerCoaster: () => RollerCoaster,
  Rose: () => Rose,
  Rotate3d: () => Rotate3d,
  RotateCcw: () => RotateCcw,
  RotateCcwKey: () => RotateCcwKey,
  RotateCcwSquare: () => RotateCcwSquare,
  RotateCw: () => RotateCw,
  RotateCwSquare: () => RotateCwSquare,
  Route: () => Route,
  RouteOff: () => RouteOff,
  Router: () => Router,
  Rows2: () => Rows2,
  Rows3: () => Rows3,
  Rows4: () => Rows4,
  Rss: () => Rss,
  Ruler: () => Ruler,
  RulerDimensionLine: () => RulerDimensionLine,
  RussianRuble: () => RussianRuble,
  Sailboat: () => Sailboat,
  Salad: () => Salad,
  Sandwich: () => Sandwich,
  Satellite: () => Satellite,
  SatelliteDish: () => SatelliteDish,
  SaudiRiyal: () => SaudiRiyal,
  Save: () => Save,
  SaveAll: () => SaveAll,
  SaveOff: () => SaveOff,
  Scale: () => Scale,
  Scale3d: () => Scale3d,
  Scaling: () => Scaling,
  Scan: () => Scan,
  ScanBarcode: () => ScanBarcode,
  ScanEye: () => ScanEye,
  ScanFace: () => ScanFace,
  ScanHeart: () => ScanHeart,
  ScanLine: () => ScanLine,
  ScanQrCode: () => ScanQrCode,
  ScanSearch: () => ScanSearch,
  ScanText: () => ScanText,
  School: () => School,
  Scissors: () => Scissors,
  ScissorsLineDashed: () => ScissorsLineDashed,
  Scooter: () => Scooter,
  ScreenShare: () => ScreenShare,
  ScreenShareOff: () => ScreenShareOff,
  Scroll: () => Scroll,
  ScrollText: () => ScrollText,
  Search: () => Search,
  SearchAlert: () => SearchAlert,
  SearchCheck: () => SearchCheck,
  SearchCode: () => SearchCode,
  SearchSlash: () => SearchSlash,
  SearchX: () => SearchX,
  Section: () => Section,
  Send: () => Send,
  SendHorizontal: () => SendHorizontal,
  SendToBack: () => SendToBack,
  SeparatorHorizontal: () => SeparatorHorizontal,
  SeparatorVertical: () => SeparatorVertical,
  Server: () => Server,
  ServerCog: () => ServerCog,
  ServerCrash: () => ServerCrash,
  ServerOff: () => ServerOff,
  Settings: () => Settings,
  Settings2: () => Settings2,
  Shapes: () => Shapes,
  Share: () => Share,
  Share2: () => Share2,
  Sheet: () => Sheet,
  Shell: () => Shell,
  ShelvingUnit: () => ShelvingUnit,
  Shield: () => Shield,
  ShieldAlert: () => ShieldAlert,
  ShieldBan: () => ShieldBan,
  ShieldCheck: () => ShieldCheck,
  ShieldEllipsis: () => ShieldEllipsis,
  ShieldHalf: () => ShieldHalf,
  ShieldMinus: () => ShieldMinus,
  ShieldOff: () => ShieldOff,
  ShieldPlus: () => ShieldPlus,
  ShieldQuestionMark: () => ShieldQuestionMark,
  ShieldUser: () => ShieldUser,
  ShieldX: () => ShieldX,
  Ship: () => Ship,
  ShipWheel: () => ShipWheel,
  Shirt: () => Shirt,
  ShoppingBag: () => ShoppingBag,
  ShoppingBasket: () => ShoppingBasket,
  ShoppingCart: () => ShoppingCart,
  Shovel: () => Shovel,
  ShowerHead: () => ShowerHead,
  Shredder: () => Shredder,
  Shrimp: () => Shrimp,
  Shrink: () => Shrink,
  Shrub: () => Shrub,
  Shuffle: () => Shuffle,
  Sigma: () => Sigma,
  Signal: () => Signal,
  SignalHigh: () => SignalHigh,
  SignalLow: () => SignalLow,
  SignalMedium: () => SignalMedium,
  SignalZero: () => SignalZero,
  Signature: () => Signature,
  Signpost: () => Signpost,
  SignpostBig: () => SignpostBig,
  Siren: () => Siren,
  SkipBack: () => SkipBack,
  SkipForward: () => SkipForward,
  Skull: () => Skull,
  Slack: () => Slack,
  Slash: () => Slash,
  Slice: () => Slice,
  SlidersHorizontal: () => SlidersHorizontal,
  SlidersVertical: () => SlidersVertical,
  Smartphone: () => Smartphone,
  SmartphoneCharging: () => SmartphoneCharging,
  SmartphoneNfc: () => SmartphoneNfc,
  Smile: () => Smile,
  SmilePlus: () => SmilePlus,
  Snail: () => Snail,
  Snowflake: () => Snowflake,
  SoapDispenserDroplet: () => SoapDispenserDroplet,
  Sofa: () => Sofa,
  SolarPanel: () => SolarPanel,
  Soup: () => Soup,
  Space: () => Space,
  Spade: () => Spade,
  Sparkle: () => Sparkle,
  Sparkles: () => Sparkles,
  Speaker: () => Speaker,
  Speech: () => Speech,
  SpellCheck: () => SpellCheck,
  SpellCheck2: () => SpellCheck2,
  Spline: () => Spline,
  SplinePointer: () => SplinePointer,
  Split: () => Split,
  Spool: () => Spool,
  Spotlight: () => Spotlight,
  SprayCan: () => SprayCan,
  Sprout: () => Sprout,
  Square: () => Square,
  SquareActivity: () => SquareActivity,
  SquareArrowDown: () => SquareArrowDown,
  SquareArrowDownLeft: () => SquareArrowDownLeft,
  SquareArrowDownRight: () => SquareArrowDownRight,
  SquareArrowLeft: () => SquareArrowLeft,
  SquareArrowOutDownLeft: () => SquareArrowOutDownLeft,
  SquareArrowOutDownRight: () => SquareArrowOutDownRight,
  SquareArrowOutUpLeft: () => SquareArrowOutUpLeft,
  SquareArrowOutUpRight: () => SquareArrowOutUpRight,
  SquareArrowRight: () => SquareArrowRight,
  SquareArrowRightEnter: () => SquareArrowRightEnter,
  SquareArrowRightExit: () => SquareArrowRightExit,
  SquareArrowUp: () => SquareArrowUp,
  SquareArrowUpLeft: () => SquareArrowUpLeft,
  SquareArrowUpRight: () => SquareArrowUpRight,
  SquareAsterisk: () => SquareAsterisk,
  SquareBottomDashedScissors: () => SquareBottomDashedScissors,
  SquareCenterlineDashedHorizontal: () => SquareCenterlineDashedHorizontal,
  SquareCenterlineDashedVertical: () => SquareCenterlineDashedVertical,
  SquareChartGantt: () => SquareChartGantt,
  SquareCheck: () => SquareCheck,
  SquareCheckBig: () => SquareCheckBig,
  SquareChevronDown: () => SquareChevronDown,
  SquareChevronLeft: () => SquareChevronLeft,
  SquareChevronRight: () => SquareChevronRight,
  SquareChevronUp: () => SquareChevronUp,
  SquareCode: () => SquareCode,
  SquareDashed: () => SquareDashed,
  SquareDashedBottom: () => SquareDashedBottom,
  SquareDashedBottomCode: () => SquareDashedBottomCode,
  SquareDashedKanban: () => SquareDashedKanban,
  SquareDashedMousePointer: () => SquareDashedMousePointer,
  SquareDashedTopSolid: () => SquareDashedTopSolid,
  SquareDivide: () => SquareDivide,
  SquareDot: () => SquareDot,
  SquareEqual: () => SquareEqual,
  SquareFunction: () => SquareFunction,
  SquareKanban: () => SquareKanban,
  SquareLibrary: () => SquareLibrary,
  SquareM: () => SquareM,
  SquareMenu: () => SquareMenu,
  SquareMinus: () => SquareMinus,
  SquareMousePointer: () => SquareMousePointer,
  SquareParking: () => SquareParking,
  SquareParkingOff: () => SquareParkingOff,
  SquarePause: () => SquarePause,
  SquarePen: () => SquarePen,
  SquarePercent: () => SquarePercent,
  SquarePi: () => SquarePi,
  SquarePilcrow: () => SquarePilcrow,
  SquarePlay: () => SquarePlay,
  SquarePlus: () => SquarePlus,
  SquarePower: () => SquarePower,
  SquareRadical: () => SquareRadical,
  SquareRoundCorner: () => SquareRoundCorner,
  SquareScissors: () => SquareScissors,
  SquareSigma: () => SquareSigma,
  SquareSlash: () => SquareSlash,
  SquareSplitHorizontal: () => SquareSplitHorizontal,
  SquareSplitVertical: () => SquareSplitVertical,
  SquareSquare: () => SquareSquare,
  SquareStack: () => SquareStack,
  SquareStar: () => SquareStar,
  SquareStop: () => SquareStop,
  SquareTerminal: () => SquareTerminal,
  SquareUser: () => SquareUser,
  SquareUserRound: () => SquareUserRound,
  SquareX: () => SquareX,
  SquaresExclude: () => SquaresExclude,
  SquaresIntersect: () => SquaresIntersect,
  SquaresSubtract: () => SquaresSubtract,
  SquaresUnite: () => SquaresUnite,
  Squircle: () => Squircle,
  SquircleDashed: () => SquircleDashed,
  Squirrel: () => Squirrel,
  Stamp: () => Stamp,
  Star: () => Star,
  StarHalf: () => StarHalf,
  StarOff: () => StarOff,
  StepBack: () => StepBack,
  StepForward: () => StepForward,
  Stethoscope: () => Stethoscope,
  Sticker: () => Sticker,
  StickyNote: () => StickyNote,
  Stone: () => Stone,
  Store: () => Store,
  StretchHorizontal: () => StretchHorizontal,
  StretchVertical: () => StretchVertical,
  Strikethrough: () => Strikethrough,
  Subscript: () => Subscript,
  Sun: () => Sun,
  SunDim: () => SunDim,
  SunMedium: () => SunMedium,
  SunMoon: () => SunMoon,
  SunSnow: () => SunSnow,
  Sunrise: () => Sunrise,
  Sunset: () => Sunset,
  Superscript: () => Superscript,
  SwatchBook: () => SwatchBook,
  SwissFranc: () => SwissFranc,
  SwitchCamera: () => SwitchCamera,
  Sword: () => Sword,
  Swords: () => Swords,
  Syringe: () => Syringe,
  Table: () => Table,
  Table2: () => Table2,
  TableCellsMerge: () => TableCellsMerge,
  TableCellsSplit: () => TableCellsSplit,
  TableColumnsSplit: () => TableColumnsSplit,
  TableOfContents: () => TableOfContents,
  TableProperties: () => TableProperties,
  TableRowsSplit: () => TableRowsSplit,
  Tablet: () => Tablet,
  TabletSmartphone: () => TabletSmartphone,
  Tablets: () => Tablets,
  Tag: () => Tag,
  Tags: () => Tags,
  Tally1: () => Tally1,
  Tally2: () => Tally2,
  Tally3: () => Tally3,
  Tally4: () => Tally4,
  Tally5: () => Tally5,
  Tangent: () => Tangent,
  Target: () => Target,
  Telescope: () => Telescope,
  Tent: () => Tent,
  TentTree: () => TentTree,
  Terminal: () => Terminal,
  TestTube: () => TestTube,
  TestTubeDiagonal: () => TestTubeDiagonal,
  TestTubes: () => TestTubes,
  TextAlignCenter: () => TextAlignCenter,
  TextAlignEnd: () => TextAlignEnd,
  TextAlignJustify: () => TextAlignJustify,
  TextAlignStart: () => TextAlignStart,
  TextCursor: () => TextCursor,
  TextCursorInput: () => TextCursorInput,
  TextInitial: () => TextInitial,
  TextQuote: () => TextQuote,
  TextSearch: () => TextSearch,
  TextSelect: () => TextSelect,
  TextWrap: () => TextWrap,
  Theater: () => Theater,
  Thermometer: () => Thermometer,
  ThermometerSnowflake: () => ThermometerSnowflake,
  ThermometerSun: () => ThermometerSun,
  ThumbsDown: () => ThumbsDown,
  ThumbsUp: () => ThumbsUp,
  Ticket: () => Ticket,
  TicketCheck: () => TicketCheck,
  TicketMinus: () => TicketMinus,
  TicketPercent: () => TicketPercent,
  TicketPlus: () => TicketPlus,
  TicketSlash: () => TicketSlash,
  TicketX: () => TicketX,
  Tickets: () => Tickets,
  TicketsPlane: () => TicketsPlane,
  Timer: () => Timer,
  TimerOff: () => TimerOff,
  TimerReset: () => TimerReset,
  ToggleLeft: () => ToggleLeft,
  ToggleRight: () => ToggleRight,
  Toilet: () => Toilet,
  ToolCase: () => ToolCase,
  Toolbox: () => Toolbox,
  Tornado: () => Tornado,
  Torus: () => Torus,
  Touchpad: () => Touchpad,
  TouchpadOff: () => TouchpadOff,
  TowelRack: () => TowelRack,
  TowerControl: () => TowerControl,
  ToyBrick: () => ToyBrick,
  Tractor: () => Tractor,
  TrafficCone: () => TrafficCone,
  TrainFront: () => TrainFront,
  TrainFrontTunnel: () => TrainFrontTunnel,
  TrainTrack: () => TrainTrack,
  TramFront: () => TramFront,
  Transgender: () => Transgender,
  Trash: () => Trash,
  Trash2: () => Trash2,
  TreeDeciduous: () => TreeDeciduous,
  TreePalm: () => TreePalm,
  TreePine: () => TreePine,
  Trees: () => Trees,
  Trello: () => Trello,
  TrendingDown: () => TrendingDown,
  TrendingUp: () => TrendingUp,
  TrendingUpDown: () => TrendingUpDown,
  Triangle: () => Triangle,
  TriangleAlert: () => TriangleAlert,
  TriangleDashed: () => TriangleDashed,
  TriangleRight: () => TriangleRight,
  Trophy: () => Trophy,
  Truck: () => Truck,
  TruckElectric: () => TruckElectric,
  TurkishLira: () => TurkishLira,
  Turntable: () => Turntable,
  Turtle: () => Turtle,
  Tv: () => Tv,
  TvMinimal: () => TvMinimal,
  TvMinimalPlay: () => TvMinimalPlay,
  Twitch: () => Twitch,
  Twitter: () => Twitter,
  Type: () => Type,
  TypeOutline: () => TypeOutline,
  Umbrella: () => Umbrella,
  UmbrellaOff: () => UmbrellaOff,
  Underline: () => Underline,
  Undo: () => Undo,
  Undo2: () => Undo2,
  UndoDot: () => UndoDot,
  UnfoldHorizontal: () => UnfoldHorizontal,
  UnfoldVertical: () => UnfoldVertical,
  Ungroup: () => Ungroup,
  University: () => University,
  Unlink: () => Unlink,
  Unlink2: () => Unlink2,
  Unplug: () => Unplug,
  Upload: () => Upload,
  Usb: () => Usb,
  User: () => User,
  UserCheck: () => UserCheck,
  UserCog: () => UserCog,
  UserKey: () => UserKey,
  UserLock: () => UserLock,
  UserMinus: () => UserMinus,
  UserPen: () => UserPen,
  UserPlus: () => UserPlus,
  UserRound: () => UserRound,
  UserRoundCheck: () => UserRoundCheck,
  UserRoundCog: () => UserRoundCog,
  UserRoundKey: () => UserRoundKey,
  UserRoundMinus: () => UserRoundMinus,
  UserRoundPen: () => UserRoundPen,
  UserRoundPlus: () => UserRoundPlus,
  UserRoundSearch: () => UserRoundSearch,
  UserRoundX: () => UserRoundX,
  UserSearch: () => UserSearch,
  UserStar: () => UserStar,
  UserX: () => UserX,
  Users: () => Users,
  UsersRound: () => UsersRound,
  Utensils: () => Utensils,
  UtensilsCrossed: () => UtensilsCrossed,
  UtilityPole: () => UtilityPole,
  Van: () => Van,
  Variable: () => Variable,
  Vault: () => Vault,
  VectorSquare: () => VectorSquare,
  Vegan: () => Vegan,
  VenetianMask: () => VenetianMask,
  Venus: () => Venus,
  VenusAndMars: () => VenusAndMars,
  Vibrate: () => Vibrate,
  VibrateOff: () => VibrateOff,
  Video: () => Video,
  VideoOff: () => VideoOff,
  Videotape: () => Videotape,
  View: () => View,
  Voicemail: () => Voicemail,
  Volleyball: () => Volleyball,
  Volume: () => Volume,
  Volume1: () => Volume1,
  Volume2: () => Volume2,
  VolumeOff: () => VolumeOff,
  VolumeX: () => VolumeX,
  Vote: () => Vote,
  Wallet: () => Wallet,
  WalletCards: () => WalletCards,
  WalletMinimal: () => WalletMinimal,
  Wallpaper: () => Wallpaper,
  Wand: () => Wand,
  WandSparkles: () => WandSparkles,
  Warehouse: () => Warehouse,
  WashingMachine: () => WashingMachine,
  Watch: () => Watch,
  Waves: () => Waves,
  WavesArrowDown: () => WavesArrowDown,
  WavesArrowUp: () => WavesArrowUp,
  WavesLadder: () => WavesLadder,
  Waypoints: () => Waypoints,
  Webcam: () => Webcam,
  Webhook: () => Webhook,
  WebhookOff: () => WebhookOff,
  Weight: () => Weight,
  WeightTilde: () => WeightTilde,
  Wheat: () => Wheat,
  WheatOff: () => WheatOff,
  WholeWord: () => WholeWord,
  Wifi: () => Wifi,
  WifiCog: () => WifiCog,
  WifiHigh: () => WifiHigh,
  WifiLow: () => WifiLow,
  WifiOff: () => WifiOff,
  WifiPen: () => WifiPen,
  WifiSync: () => WifiSync,
  WifiZero: () => WifiZero,
  Wind: () => Wind,
  WindArrowDown: () => WindArrowDown,
  Wine: () => Wine,
  WineOff: () => WineOff,
  Workflow: () => Workflow,
  Worm: () => Worm,
  Wrench: () => Wrench,
  X: () => X,
  XLineTop: () => XLineTop,
  Youtube: () => Youtube,
  Zap: () => Zap,
  ZapOff: () => ZapOff,
  ZoomIn: () => ZoomIn,
  ZoomOut: () => ZoomOut
});

// ../node_modules/lucide-react/dist/esm/createLucideIcon.js
var import_react2 = __toESM(require_react());

// ../node_modules/lucide-react/dist/esm/shared/src/utils/mergeClasses.js
var mergeClasses = (...classes) => classes.filter((className, index, array) => {
  return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
}).join(" ").trim();

// ../node_modules/lucide-react/dist/esm/shared/src/utils/toKebabCase.js
var toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();

// ../node_modules/lucide-react/dist/esm/shared/src/utils/toCamelCase.js
var toCamelCase = (string) => string.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase()
);

// ../node_modules/lucide-react/dist/esm/shared/src/utils/toPascalCase.js
var toPascalCase = (string) => {
  const camelCase = toCamelCase(string);
  return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
};

// ../node_modules/lucide-react/dist/esm/Icon.js
var import_react = __toESM(require_react());

// ../node_modules/lucide-react/dist/esm/defaultAttributes.js
var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};

// ../node_modules/lucide-react/dist/esm/shared/src/utils/hasA11yProp.js
var hasA11yProp = (props) => {
  for (const prop in props) {
    if (prop.startsWith("aria-") || prop === "role" || prop === "title") {
      return true;
    }
  }
  return false;
};

// ../node_modules/lucide-react/dist/esm/Icon.js
var Icon = (0, import_react.forwardRef)(
  ({
    color = "currentColor",
    size = 24,
    strokeWidth = 2,
    absoluteStrokeWidth,
    className = "",
    children,
    iconNode,
    ...rest
  }, ref) => (0, import_react.createElement)(
    "svg",
    {
      ref,
      ...defaultAttributes,
      width: size,
      height: size,
      stroke: color,
      strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
      className: mergeClasses("lucide", className),
      ...!children && !hasA11yProp(rest) && { "aria-hidden": "true" },
      ...rest
    },
    [
      ...iconNode.map(([tag, attrs]) => (0, import_react.createElement)(tag, attrs)),
      ...Array.isArray(children) ? children : [children]
    ]
  )
);

// ../node_modules/lucide-react/dist/esm/createLucideIcon.js
var createLucideIcon = (iconName, iconNode) => {
  const Component2 = (0, import_react2.forwardRef)(
    ({ className, ...props }, ref) => (0, import_react2.createElement)(Icon, {
      ref,
      iconNode,
      className: mergeClasses(
        `lucide-${toKebabCase(toPascalCase(iconName))}`,
        `lucide-${iconName}`,
        className
      ),
      ...props
    })
  );
  Component2.displayName = toPascalCase(iconName);
  return Component2;
};

// ../node_modules/lucide-react/dist/esm/icons/a-arrow-down.js
var __iconNode = [
  ["path", { d: "m14 12 4 4 4-4", key: "buelq4" }],
  ["path", { d: "M18 16V7", key: "ty0viw" }],
  ["path", { d: "m2 16 4.039-9.69a.5.5 0 0 1 .923 0L11 16", key: "d5nyq2" }],
  ["path", { d: "M3.304 13h6.392", key: "1q3zxz" }]
];
var AArrowDown = createLucideIcon("a-arrow-down", __iconNode);

// ../node_modules/lucide-react/dist/esm/icons/a-arrow-up.js
var __iconNode2 = [
  ["path", { d: "m14 11 4-4 4 4", key: "1pu57t" }],
  ["path", { d: "M18 16V7", key: "ty0viw" }],
  ["path", { d: "m2 16 4.039-9.69a.5.5 0 0 1 .923 0L11 16", key: "d5nyq2" }],
  ["path", { d: "M3.304 13h6.392", key: "1q3zxz" }]
];
var AArrowUp = createLucideIcon("a-arrow-up", __iconNode2);

// ../node_modules/lucide-react/dist/esm/icons/a-large-small.js
var __iconNode3 = [
  ["path", { d: "m15 16 2.536-7.328a1.02 1.02 1 0 1 1.928 0L22 16", key: "xik6mr" }],
  ["path", { d: "M15.697 14h5.606", key: "1stdlc" }],
  ["path", { d: "m2 16 4.039-9.69a.5.5 0 0 1 .923 0L11 16", key: "d5nyq2" }],
  ["path", { d: "M3.304 13h6.392", key: "1q3zxz" }]
];
var ALargeSmall = createLucideIcon("a-large-small", __iconNode3);

// ../node_modules/lucide-react/dist/esm/icons/accessibility.js
var __iconNode4 = [
  ["circle", { cx: "16", cy: "4", r: "1", key: "1grugj" }],
  ["path", { d: "m18 19 1-7-6 1", key: "r0i19z" }],
  ["path", { d: "m5 8 3-3 5.5 3-2.36 3.5", key: "9ptxx2" }],
  ["path", { d: "M4.24 14.5a5 5 0 0 0 6.88 6", key: "10kmtu" }],
  ["path", { d: "M13.76 17.5a5 5 0 0 0-6.88-6", key: "2qq6rc" }]
];
var Accessibility = createLucideIcon("accessibility", __iconNode4);

// ../node_modules/lucide-react/dist/esm/icons/activity.js
var __iconNode5 = [
  [
    "path",
    {
      d: "M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",
      key: "169zse"
    }
  ]
];
var Activity = createLucideIcon("activity", __iconNode5);

// ../node_modules/lucide-react/dist/esm/icons/airplay.js
var __iconNode6 = [
  [
    "path",
    {
      d: "M5 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-1",
      key: "ns4c3b"
    }
  ],
  ["path", { d: "m12 15 5 6H7Z", key: "14qnn2" }]
];
var Airplay = createLucideIcon("airplay", __iconNode6);

// ../node_modules/lucide-react/dist/esm/icons/air-vent.js
var __iconNode7 = [
  ["path", { d: "M18 17.5a2.5 2.5 0 1 1-4 2.03V12", key: "yd12zl" }],
  [
    "path",
    {
      d: "M6 12H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",
      key: "larmp2"
    }
  ],
  ["path", { d: "M6 8h12", key: "6g4wlu" }],
  ["path", { d: "M6.6 15.572A2 2 0 1 0 10 17v-5", key: "1x1kqn" }]
];
var AirVent = createLucideIcon("air-vent", __iconNode7);

// ../node_modules/lucide-react/dist/esm/icons/alarm-clock-check.js
var __iconNode8 = [
  ["circle", { cx: "12", cy: "13", r: "8", key: "3y4lt7" }],
  ["path", { d: "M5 3 2 6", key: "18tl5t" }],
  ["path", { d: "m22 6-3-3", key: "1opdir" }],
  ["path", { d: "M6.38 18.7 4 21", key: "17xu3x" }],
  ["path", { d: "M17.64 18.67 20 21", key: "kv2oe2" }],
  ["path", { d: "m9 13 2 2 4-4", key: "6343dt" }]
];
var AlarmClockCheck = createLucideIcon("alarm-clock-check", __iconNode8);

// ../node_modules/lucide-react/dist/esm/icons/alarm-clock-minus.js
var __iconNode9 = [
  ["circle", { cx: "12", cy: "13", r: "8", key: "3y4lt7" }],
  ["path", { d: "M5 3 2 6", key: "18tl5t" }],
  ["path", { d: "m22 6-3-3", key: "1opdir" }],
  ["path", { d: "M6.38 18.7 4 21", key: "17xu3x" }],
  ["path", { d: "M17.64 18.67 20 21", key: "kv2oe2" }],
  ["path", { d: "M9 13h6", key: "1uhe8q" }]
];
var AlarmClockMinus = createLucideIcon("alarm-clock-minus", __iconNode9);

// ../node_modules/lucide-react/dist/esm/icons/alarm-clock-plus.js
var __iconNode10 = [
  ["circle", { cx: "12", cy: "13", r: "8", key: "3y4lt7" }],
  ["path", { d: "M5 3 2 6", key: "18tl5t" }],
  ["path", { d: "m22 6-3-3", key: "1opdir" }],
  ["path", { d: "M6.38 18.7 4 21", key: "17xu3x" }],
  ["path", { d: "M17.64 18.67 20 21", key: "kv2oe2" }],
  ["path", { d: "M12 10v6", key: "1bos4e" }],
  ["path", { d: "M9 13h6", key: "1uhe8q" }]
];
var AlarmClockPlus = createLucideIcon("alarm-clock-plus", __iconNode10);

// ../node_modules/lucide-react/dist/esm/icons/alarm-clock-off.js
var __iconNode11 = [
  ["path", { d: "M6.87 6.87a8 8 0 1 0 11.26 11.26", key: "3on8tj" }],
  ["path", { d: "M19.9 14.25a8 8 0 0 0-9.15-9.15", key: "15ghsc" }],
  ["path", { d: "m22 6-3-3", key: "1opdir" }],
  ["path", { d: "M6.26 18.67 4 21", key: "yzmioq" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M4 4 2 6", key: "1ycko6" }]
];
var AlarmClockOff = createLucideIcon("alarm-clock-off", __iconNode11);

// ../node_modules/lucide-react/dist/esm/icons/alarm-clock.js
var __iconNode12 = [
  ["circle", { cx: "12", cy: "13", r: "8", key: "3y4lt7" }],
  ["path", { d: "M12 9v4l2 2", key: "1c63tq" }],
  ["path", { d: "M5 3 2 6", key: "18tl5t" }],
  ["path", { d: "m22 6-3-3", key: "1opdir" }],
  ["path", { d: "M6.38 18.7 4 21", key: "17xu3x" }],
  ["path", { d: "M17.64 18.67 20 21", key: "kv2oe2" }]
];
var AlarmClock = createLucideIcon("alarm-clock", __iconNode12);

// ../node_modules/lucide-react/dist/esm/icons/alarm-smoke.js
var __iconNode13 = [
  ["path", { d: "M11 21c0-2.5 2-2.5 2-5", key: "1sicvv" }],
  ["path", { d: "M16 21c0-2.5 2-2.5 2-5", key: "1o3eny" }],
  ["path", { d: "m19 8-.8 3a1.25 1.25 0 0 1-1.2 1H7a1.25 1.25 0 0 1-1.2-1L5 8", key: "1bvca4" }],
  [
    "path",
    { d: "M21 3a1 1 0 0 1 1 1v2a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V4a1 1 0 0 1 1-1z", key: "x3qr1j" }
  ],
  ["path", { d: "M6 21c0-2.5 2-2.5 2-5", key: "i3w1gp" }]
];
var AlarmSmoke = createLucideIcon("alarm-smoke", __iconNode13);

// ../node_modules/lucide-react/dist/esm/icons/album.js
var __iconNode14 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["polyline", { points: "11 3 11 11 14 8 17 11 17 3", key: "1wcwz3" }]
];
var Album = createLucideIcon("album", __iconNode14);

// ../node_modules/lucide-react/dist/esm/icons/align-center-horizontal.js
var __iconNode15 = [
  ["path", { d: "M2 12h20", key: "9i4pu4" }],
  ["path", { d: "M10 16v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-4", key: "11f1s0" }],
  ["path", { d: "M10 8V4a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v4", key: "t14dx9" }],
  ["path", { d: "M20 16v1a2 2 0 0 1-2 2h-2a2 2 0 0 1-2-2v-1", key: "1w07xs" }],
  ["path", { d: "M14 8V7c0-1.1.9-2 2-2h2a2 2 0 0 1 2 2v1", key: "1apec2" }]
];
var AlignCenterHorizontal = createLucideIcon("align-center-horizontal", __iconNode15);

// ../node_modules/lucide-react/dist/esm/icons/align-center-vertical.js
var __iconNode16 = [
  ["path", { d: "M12 2v20", key: "t6zp3m" }],
  ["path", { d: "M8 10H4a2 2 0 0 1-2-2V6c0-1.1.9-2 2-2h4", key: "14d6g8" }],
  ["path", { d: "M16 10h4a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-4", key: "1e2lrw" }],
  ["path", { d: "M8 20H7a2 2 0 0 1-2-2v-2c0-1.1.9-2 2-2h1", key: "1fkdwx" }],
  ["path", { d: "M16 14h1a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-1", key: "1euafb" }]
];
var AlignCenterVertical = createLucideIcon("align-center-vertical", __iconNode16);

// ../node_modules/lucide-react/dist/esm/icons/align-end-horizontal.js
var __iconNode17 = [
  ["rect", { width: "6", height: "16", x: "4", y: "2", rx: "2", key: "z5wdxg" }],
  ["rect", { width: "6", height: "9", x: "14", y: "9", rx: "2", key: "um7a8w" }],
  ["path", { d: "M22 22H2", key: "19qnx5" }]
];
var AlignEndHorizontal = createLucideIcon("align-end-horizontal", __iconNode17);

// ../node_modules/lucide-react/dist/esm/icons/align-end-vertical.js
var __iconNode18 = [
  ["rect", { width: "16", height: "6", x: "2", y: "4", rx: "2", key: "10wcwx" }],
  ["rect", { width: "9", height: "6", x: "9", y: "14", rx: "2", key: "4p5bwg" }],
  ["path", { d: "M22 22V2", key: "12ipfv" }]
];
var AlignEndVertical = createLucideIcon("align-end-vertical", __iconNode18);

// ../node_modules/lucide-react/dist/esm/icons/align-horizontal-distribute-center.js
var __iconNode19 = [
  ["rect", { width: "6", height: "14", x: "4", y: "5", rx: "2", key: "1wwnby" }],
  ["rect", { width: "6", height: "10", x: "14", y: "7", rx: "2", key: "1fe6j6" }],
  ["path", { d: "M17 22v-5", key: "4b6g73" }],
  ["path", { d: "M17 7V2", key: "hnrr36" }],
  ["path", { d: "M7 22v-3", key: "1r4jpn" }],
  ["path", { d: "M7 5V2", key: "liy1u9" }]
];
var AlignHorizontalDistributeCenter = createLucideIcon(
  "align-horizontal-distribute-center",
  __iconNode19
);

// ../node_modules/lucide-react/dist/esm/icons/align-horizontal-distribute-end.js
var __iconNode20 = [
  ["rect", { width: "6", height: "14", x: "4", y: "5", rx: "2", key: "1wwnby" }],
  ["rect", { width: "6", height: "10", x: "14", y: "7", rx: "2", key: "1fe6j6" }],
  ["path", { d: "M10 2v20", key: "uyc634" }],
  ["path", { d: "M20 2v20", key: "1tx262" }]
];
var AlignHorizontalDistributeEnd = createLucideIcon(
  "align-horizontal-distribute-end",
  __iconNode20
);

// ../node_modules/lucide-react/dist/esm/icons/align-horizontal-distribute-start.js
var __iconNode21 = [
  ["rect", { width: "6", height: "14", x: "4", y: "5", rx: "2", key: "1wwnby" }],
  ["rect", { width: "6", height: "10", x: "14", y: "7", rx: "2", key: "1fe6j6" }],
  ["path", { d: "M4 2v20", key: "gtpd5x" }],
  ["path", { d: "M14 2v20", key: "tg6bpw" }]
];
var AlignHorizontalDistributeStart = createLucideIcon(
  "align-horizontal-distribute-start",
  __iconNode21
);

// ../node_modules/lucide-react/dist/esm/icons/align-horizontal-justify-center.js
var __iconNode22 = [
  ["rect", { width: "6", height: "14", x: "2", y: "5", rx: "2", key: "dy24zr" }],
  ["rect", { width: "6", height: "10", x: "16", y: "7", rx: "2", key: "13zkjt" }],
  ["path", { d: "M12 2v20", key: "t6zp3m" }]
];
var AlignHorizontalJustifyCenter = createLucideIcon(
  "align-horizontal-justify-center",
  __iconNode22
);

// ../node_modules/lucide-react/dist/esm/icons/align-horizontal-justify-end.js
var __iconNode23 = [
  ["rect", { width: "6", height: "14", x: "2", y: "5", rx: "2", key: "dy24zr" }],
  ["rect", { width: "6", height: "10", x: "12", y: "7", rx: "2", key: "1ht384" }],
  ["path", { d: "M22 2v20", key: "40qfg1" }]
];
var AlignHorizontalJustifyEnd = createLucideIcon("align-horizontal-justify-end", __iconNode23);

// ../node_modules/lucide-react/dist/esm/icons/align-horizontal-justify-start.js
var __iconNode24 = [
  ["rect", { width: "6", height: "14", x: "6", y: "5", rx: "2", key: "hsirpf" }],
  ["rect", { width: "6", height: "10", x: "16", y: "7", rx: "2", key: "13zkjt" }],
  ["path", { d: "M2 2v20", key: "1ivd8o" }]
];
var AlignHorizontalJustifyStart = createLucideIcon("align-horizontal-justify-start", __iconNode24);

// ../node_modules/lucide-react/dist/esm/icons/align-horizontal-space-around.js
var __iconNode25 = [
  ["rect", { width: "6", height: "10", x: "9", y: "7", rx: "2", key: "yn7j0q" }],
  ["path", { d: "M4 22V2", key: "tsjzd3" }],
  ["path", { d: "M20 22V2", key: "1bnhr8" }]
];
var AlignHorizontalSpaceAround = createLucideIcon("align-horizontal-space-around", __iconNode25);

// ../node_modules/lucide-react/dist/esm/icons/align-horizontal-space-between.js
var __iconNode26 = [
  ["rect", { width: "6", height: "14", x: "3", y: "5", rx: "2", key: "j77dae" }],
  ["rect", { width: "6", height: "10", x: "15", y: "7", rx: "2", key: "bq30hj" }],
  ["path", { d: "M3 2v20", key: "1d2pfg" }],
  ["path", { d: "M21 2v20", key: "p059bm" }]
];
var AlignHorizontalSpaceBetween = createLucideIcon("align-horizontal-space-between", __iconNode26);

// ../node_modules/lucide-react/dist/esm/icons/align-start-horizontal.js
var __iconNode27 = [
  ["rect", { width: "6", height: "16", x: "4", y: "6", rx: "2", key: "1n4dg1" }],
  ["rect", { width: "6", height: "9", x: "14", y: "6", rx: "2", key: "17khns" }],
  ["path", { d: "M22 2H2", key: "fhrpnj" }]
];
var AlignStartHorizontal = createLucideIcon("align-start-horizontal", __iconNode27);

// ../node_modules/lucide-react/dist/esm/icons/align-start-vertical.js
var __iconNode28 = [
  ["rect", { width: "9", height: "6", x: "6", y: "14", rx: "2", key: "lpm2y7" }],
  ["rect", { width: "16", height: "6", x: "6", y: "4", rx: "2", key: "rdj6ps" }],
  ["path", { d: "M2 2v20", key: "1ivd8o" }]
];
var AlignStartVertical = createLucideIcon("align-start-vertical", __iconNode28);

// ../node_modules/lucide-react/dist/esm/icons/align-vertical-distribute-center.js
var __iconNode29 = [
  ["path", { d: "M22 17h-3", key: "1lwga1" }],
  ["path", { d: "M22 7h-5", key: "o2endc" }],
  ["path", { d: "M5 17H2", key: "1gx9xc" }],
  ["path", { d: "M7 7H2", key: "6bq26l" }],
  ["rect", { x: "5", y: "14", width: "14", height: "6", rx: "2", key: "1qrzuf" }],
  ["rect", { x: "7", y: "4", width: "10", height: "6", rx: "2", key: "we8e9z" }]
];
var AlignVerticalDistributeCenter = createLucideIcon(
  "align-vertical-distribute-center",
  __iconNode29
);

// ../node_modules/lucide-react/dist/esm/icons/align-vertical-distribute-end.js
var __iconNode30 = [
  ["rect", { width: "14", height: "6", x: "5", y: "14", rx: "2", key: "jmoj9s" }],
  ["rect", { width: "10", height: "6", x: "7", y: "4", rx: "2", key: "aza5on" }],
  ["path", { d: "M2 20h20", key: "owomy5" }],
  ["path", { d: "M2 10h20", key: "1ir3d8" }]
];
var AlignVerticalDistributeEnd = createLucideIcon("align-vertical-distribute-end", __iconNode30);

// ../node_modules/lucide-react/dist/esm/icons/align-vertical-distribute-start.js
var __iconNode31 = [
  ["rect", { width: "14", height: "6", x: "5", y: "14", rx: "2", key: "jmoj9s" }],
  ["rect", { width: "10", height: "6", x: "7", y: "4", rx: "2", key: "aza5on" }],
  ["path", { d: "M2 14h20", key: "myj16y" }],
  ["path", { d: "M2 4h20", key: "mda7wb" }]
];
var AlignVerticalDistributeStart = createLucideIcon(
  "align-vertical-distribute-start",
  __iconNode31
);

// ../node_modules/lucide-react/dist/esm/icons/align-vertical-justify-center.js
var __iconNode32 = [
  ["rect", { width: "14", height: "6", x: "5", y: "16", rx: "2", key: "1i8z2d" }],
  ["rect", { width: "10", height: "6", x: "7", y: "2", rx: "2", key: "ypihtt" }],
  ["path", { d: "M2 12h20", key: "9i4pu4" }]
];
var AlignVerticalJustifyCenter = createLucideIcon("align-vertical-justify-center", __iconNode32);

// ../node_modules/lucide-react/dist/esm/icons/align-vertical-justify-start.js
var __iconNode33 = [
  ["rect", { width: "14", height: "6", x: "5", y: "16", rx: "2", key: "1i8z2d" }],
  ["rect", { width: "10", height: "6", x: "7", y: "6", rx: "2", key: "13squh" }],
  ["path", { d: "M2 2h20", key: "1ennik" }]
];
var AlignVerticalJustifyStart = createLucideIcon("align-vertical-justify-start", __iconNode33);

// ../node_modules/lucide-react/dist/esm/icons/align-vertical-justify-end.js
var __iconNode34 = [
  ["rect", { width: "14", height: "6", x: "5", y: "12", rx: "2", key: "4l4tp2" }],
  ["rect", { width: "10", height: "6", x: "7", y: "2", rx: "2", key: "ypihtt" }],
  ["path", { d: "M2 22h20", key: "272qi7" }]
];
var AlignVerticalJustifyEnd = createLucideIcon("align-vertical-justify-end", __iconNode34);

// ../node_modules/lucide-react/dist/esm/icons/align-vertical-space-around.js
var __iconNode35 = [
  ["rect", { width: "10", height: "6", x: "7", y: "9", rx: "2", key: "b1zbii" }],
  ["path", { d: "M22 20H2", key: "1p1f7z" }],
  ["path", { d: "M22 4H2", key: "1b7qnq" }]
];
var AlignVerticalSpaceAround = createLucideIcon("align-vertical-space-around", __iconNode35);

// ../node_modules/lucide-react/dist/esm/icons/align-vertical-space-between.js
var __iconNode36 = [
  ["rect", { width: "14", height: "6", x: "5", y: "15", rx: "2", key: "1w91an" }],
  ["rect", { width: "10", height: "6", x: "7", y: "3", rx: "2", key: "17wqzy" }],
  ["path", { d: "M2 21h20", key: "1nyx9w" }],
  ["path", { d: "M2 3h20", key: "91anmk" }]
];
var AlignVerticalSpaceBetween = createLucideIcon("align-vertical-space-between", __iconNode36);

// ../node_modules/lucide-react/dist/esm/icons/ambulance.js
var __iconNode37 = [
  ["path", { d: "M10 10H6", key: "1bsnug" }],
  ["path", { d: "M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2", key: "wrbu53" }],
  [
    "path",
    {
      d: "M19 18h2a1 1 0 0 0 1-1v-3.28a1 1 0 0 0-.684-.948l-1.923-.641a1 1 0 0 1-.578-.502l-1.539-3.076A1 1 0 0 0 16.382 8H14",
      key: "lrkjwd"
    }
  ],
  ["path", { d: "M8 8v4", key: "1fwk8c" }],
  ["path", { d: "M9 18h6", key: "x1upvd" }],
  ["circle", { cx: "17", cy: "18", r: "2", key: "332jqn" }],
  ["circle", { cx: "7", cy: "18", r: "2", key: "19iecd" }]
];
var Ambulance = createLucideIcon("ambulance", __iconNode37);

// ../node_modules/lucide-react/dist/esm/icons/ampersand.js
var __iconNode38 = [
  ["path", { d: "M16 12h3", key: "4uvgyw" }],
  [
    "path",
    {
      d: "M17.5 12a8 8 0 0 1-8 8A4.5 4.5 0 0 1 5 15.5c0-6 8-4 8-8.5a3 3 0 1 0-6 0c0 3 2.5 8.5 12 13",
      key: "nfoe1t"
    }
  ]
];
var Ampersand = createLucideIcon("ampersand", __iconNode38);

// ../node_modules/lucide-react/dist/esm/icons/ampersands.js
var __iconNode39 = [
  [
    "path",
    {
      d: "M10 17c-5-3-7-7-7-9a2 2 0 0 1 4 0c0 2.5-5 2.5-5 6 0 1.7 1.3 3 3 3 2.8 0 5-2.2 5-5",
      key: "12lh1k"
    }
  ],
  [
    "path",
    {
      d: "M22 17c-5-3-7-7-7-9a2 2 0 0 1 4 0c0 2.5-5 2.5-5 6 0 1.7 1.3 3 3 3 2.8 0 5-2.2 5-5",
      key: "173c68"
    }
  ]
];
var Ampersands = createLucideIcon("ampersands", __iconNode39);

// ../node_modules/lucide-react/dist/esm/icons/anchor.js
var __iconNode40 = [
  ["path", { d: "M12 6v16", key: "nqf5sj" }],
  ["path", { d: "m19 13 2-1a9 9 0 0 1-18 0l2 1", key: "y7qv08" }],
  ["path", { d: "M9 11h6", key: "1fldmi" }],
  ["circle", { cx: "12", cy: "4", r: "2", key: "muu5ef" }]
];
var Anchor = createLucideIcon("anchor", __iconNode40);

// ../node_modules/lucide-react/dist/esm/icons/angry.js
var __iconNode41 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M16 16s-1.5-2-4-2-4 2-4 2", key: "epbg0q" }],
  ["path", { d: "M7.5 8 10 9", key: "olxxln" }],
  ["path", { d: "m14 9 2.5-1", key: "1j6cij" }],
  ["path", { d: "M9 10h.01", key: "qbtxuw" }],
  ["path", { d: "M15 10h.01", key: "1qmjsl" }]
];
var Angry = createLucideIcon("angry", __iconNode41);

// ../node_modules/lucide-react/dist/esm/icons/amphora.js
var __iconNode42 = [
  [
    "path",
    { d: "M10 2v5.632c0 .424-.272.795-.653.982A6 6 0 0 0 6 14c.006 4 3 7 5 8", key: "1h8rid" }
  ],
  ["path", { d: "M10 5H8a2 2 0 0 0 0 4h.68", key: "3ezsi6" }],
  ["path", { d: "M14 2v5.632c0 .424.272.795.652.982A6 6 0 0 1 18 14c0 4-3 7-5 8", key: "yt6q09" }],
  ["path", { d: "M14 5h2a2 2 0 0 1 0 4h-.68", key: "8f95yk" }],
  ["path", { d: "M18 22H6", key: "mg6kv4" }],
  ["path", { d: "M9 2h6", key: "1jrp98" }]
];
var Amphora = createLucideIcon("amphora", __iconNode42);

// ../node_modules/lucide-react/dist/esm/icons/annoyed.js
var __iconNode43 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M8 15h8", key: "45n4r" }],
  ["path", { d: "M8 9h2", key: "1g203m" }],
  ["path", { d: "M14 9h2", key: "116p9w" }]
];
var Annoyed = createLucideIcon("annoyed", __iconNode43);

// ../node_modules/lucide-react/dist/esm/icons/antenna.js
var __iconNode44 = [
  ["path", { d: "M2 12 7 2", key: "117k30" }],
  ["path", { d: "m7 12 5-10", key: "1tvx22" }],
  ["path", { d: "m12 12 5-10", key: "ev1o1a" }],
  ["path", { d: "m17 12 5-10", key: "1e4ti3" }],
  ["path", { d: "M4.5 7h15", key: "vlsxkz" }],
  ["path", { d: "M12 16v6", key: "c8a4gj" }]
];
var Antenna = createLucideIcon("antenna", __iconNode44);

// ../node_modules/lucide-react/dist/esm/icons/anvil.js
var __iconNode45 = [
  ["path", { d: "M7 10H6a4 4 0 0 1-4-4 1 1 0 0 1 1-1h4", key: "1hjpb6" }],
  [
    "path",
    { d: "M7 5a1 1 0 0 1 1-1h13a1 1 0 0 1 1 1 7 7 0 0 1-7 7H8a1 1 0 0 1-1-1z", key: "1qn45f" }
  ],
  ["path", { d: "M9 12v5", key: "3anwtq" }],
  ["path", { d: "M15 12v5", key: "5xh3zn" }],
  [
    "path",
    { d: "M5 20a3 3 0 0 1 3-3h8a3 3 0 0 1 3 3 1 1 0 0 1-1 1H6a1 1 0 0 1-1-1", key: "1fi4x8" }
  ]
];
var Anvil = createLucideIcon("anvil", __iconNode45);

// ../node_modules/lucide-react/dist/esm/icons/aperture.js
var __iconNode46 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m14.31 8 5.74 9.94", key: "1y6ab4" }],
  ["path", { d: "M9.69 8h11.48", key: "1wxppr" }],
  ["path", { d: "m7.38 12 5.74-9.94", key: "1grp0k" }],
  ["path", { d: "M9.69 16 3.95 6.06", key: "libnyf" }],
  ["path", { d: "M14.31 16H2.83", key: "x5fava" }],
  ["path", { d: "m16.62 12-5.74 9.94", key: "1vwawt" }]
];
var Aperture = createLucideIcon("aperture", __iconNode46);

// ../node_modules/lucide-react/dist/esm/icons/app-window-mac.js
var __iconNode47 = [
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }],
  ["path", { d: "M6 8h.01", key: "x9i8wu" }],
  ["path", { d: "M10 8h.01", key: "1r9ogq" }],
  ["path", { d: "M14 8h.01", key: "1primd" }]
];
var AppWindowMac = createLucideIcon("app-window-mac", __iconNode47);

// ../node_modules/lucide-react/dist/esm/icons/apple.js
var __iconNode48 = [
  ["path", { d: "M12 6.528V3a1 1 0 0 1 1-1h0", key: "11qiee" }],
  [
    "path",
    {
      d: "M18.237 21A15 15 0 0 0 22 11a6 6 0 0 0-10-4.472A6 6 0 0 0 2 11a15.1 15.1 0 0 0 3.763 10 3 3 0 0 0 3.648.648 5.5 5.5 0 0 1 5.178 0A3 3 0 0 0 18.237 21",
      key: "110c12"
    }
  ]
];
var Apple = createLucideIcon("apple", __iconNode48);

// ../node_modules/lucide-react/dist/esm/icons/app-window.js
var __iconNode49 = [
  ["rect", { x: "2", y: "4", width: "20", height: "16", rx: "2", key: "izxlao" }],
  ["path", { d: "M10 4v4", key: "pp8u80" }],
  ["path", { d: "M2 8h20", key: "d11cs7" }],
  ["path", { d: "M6 4v4", key: "1svtjw" }]
];
var AppWindow = createLucideIcon("app-window", __iconNode49);

// ../node_modules/lucide-react/dist/esm/icons/archive-restore.js
var __iconNode50 = [
  ["rect", { width: "20", height: "5", x: "2", y: "3", rx: "1", key: "1wp1u1" }],
  ["path", { d: "M4 8v11a2 2 0 0 0 2 2h2", key: "tvwodi" }],
  ["path", { d: "M20 8v11a2 2 0 0 1-2 2h-2", key: "1gkqxj" }],
  ["path", { d: "m9 15 3-3 3 3", key: "1pd0qc" }],
  ["path", { d: "M12 12v9", key: "192myk" }]
];
var ArchiveRestore = createLucideIcon("archive-restore", __iconNode50);

// ../node_modules/lucide-react/dist/esm/icons/archive-x.js
var __iconNode51 = [
  ["rect", { width: "20", height: "5", x: "2", y: "3", rx: "1", key: "1wp1u1" }],
  ["path", { d: "M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8", key: "1s80jp" }],
  ["path", { d: "m9.5 17 5-5", key: "nakeu6" }],
  ["path", { d: "m9.5 12 5 5", key: "1hccrj" }]
];
var ArchiveX = createLucideIcon("archive-x", __iconNode51);

// ../node_modules/lucide-react/dist/esm/icons/archive.js
var __iconNode52 = [
  ["rect", { width: "20", height: "5", x: "2", y: "3", rx: "1", key: "1wp1u1" }],
  ["path", { d: "M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8", key: "1s80jp" }],
  ["path", { d: "M10 12h4", key: "a56b0p" }]
];
var Archive = createLucideIcon("archive", __iconNode52);

// ../node_modules/lucide-react/dist/esm/icons/armchair.js
var __iconNode53 = [
  ["path", { d: "M19 9V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v3", key: "irtipd" }],
  [
    "path",
    {
      d: "M3 16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v1.5a.5.5 0 0 1-.5.5h-9a.5.5 0 0 1-.5-.5V11a2 2 0 0 0-4 0z",
      key: "1qyhux"
    }
  ],
  ["path", { d: "M5 18v2", key: "ppbyun" }],
  ["path", { d: "M19 18v2", key: "gy7782" }]
];
var Armchair = createLucideIcon("armchair", __iconNode53);

// ../node_modules/lucide-react/dist/esm/icons/arrow-big-down-dash.js
var __iconNode54 = [
  [
    "path",
    {
      d: "M15 11a1 1 0 0 0 1 1h2.939a1 1 0 0 1 .75 1.811l-6.835 6.836a1.207 1.207 0 0 1-1.707 0L4.31 13.81a1 1 0 0 1 .75-1.811H8a1 1 0 0 0 1-1V9a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1z",
      key: "1hy3w3"
    }
  ],
  ["path", { d: "M9 4h6", key: "10am2s" }]
];
var ArrowBigDownDash = createLucideIcon("arrow-big-down-dash", __iconNode54);

// ../node_modules/lucide-react/dist/esm/icons/arrow-big-down.js
var __iconNode55 = [
  [
    "path",
    {
      d: "M15 11a1 1 0 0 0 1 1h2.939a1 1 0 0 1 .75 1.811l-6.835 6.836a1.207 1.207 0 0 1-1.707 0L4.31 13.81a1 1 0 0 1 .75-1.811H8a1 1 0 0 0 1-1V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1z",
      key: "1eaqc3"
    }
  ]
];
var ArrowBigDown = createLucideIcon("arrow-big-down", __iconNode55);

// ../node_modules/lucide-react/dist/esm/icons/arrow-big-left-dash.js
var __iconNode56 = [
  [
    "path",
    {
      d: "M13 9a1 1 0 0 1-1-1V5.061a1 1 0 0 0-1.811-.75l-6.835 6.836a1.207 1.207 0 0 0 0 1.707l6.835 6.835a1 1 0 0 0 1.811-.75V16a1 1 0 0 1 1-1h2a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1z",
      key: "p8w4w5"
    }
  ],
  ["path", { d: "M20 9v6", key: "14roy0" }]
];
var ArrowBigLeftDash = createLucideIcon("arrow-big-left-dash", __iconNode56);

// ../node_modules/lucide-react/dist/esm/icons/arrow-big-left.js
var __iconNode57 = [
  [
    "path",
    {
      d: "M13 9a1 1 0 0 1-1-1V5.061a1 1 0 0 0-1.811-.75l-6.835 6.836a1.207 1.207 0 0 0 0 1.707l6.835 6.835a1 1 0 0 0 1.811-.75V16a1 1 0 0 1 1-1h6a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1z",
      key: "aztept"
    }
  ]
];
var ArrowBigLeft = createLucideIcon("arrow-big-left", __iconNode57);

// ../node_modules/lucide-react/dist/esm/icons/arrow-big-right-dash.js
var __iconNode58 = [
  [
    "path",
    {
      d: "M11 9a1 1 0 0 0 1-1V5.061a1 1 0 0 1 1.811-.75l6.836 6.836a1.207 1.207 0 0 1 0 1.707l-6.836 6.835a1 1 0 0 1-1.811-.75V16a1 1 0 0 0-1-1H9a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1z",
      key: "67vhrh"
    }
  ],
  ["path", { d: "M4 9v6", key: "bns7oa" }]
];
var ArrowBigRightDash = createLucideIcon("arrow-big-right-dash", __iconNode58);

// ../node_modules/lucide-react/dist/esm/icons/arrow-big-right.js
var __iconNode59 = [
  [
    "path",
    {
      d: "M11 9a1 1 0 0 0 1-1V5.061a1 1 0 0 1 1.811-.75l6.836 6.836a1.207 1.207 0 0 1 0 1.707l-6.836 6.835a1 1 0 0 1-1.811-.75V16a1 1 0 0 0-1-1H5a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1z",
      key: "1232du"
    }
  ]
];
var ArrowBigRight = createLucideIcon("arrow-big-right", __iconNode59);

// ../node_modules/lucide-react/dist/esm/icons/arrow-big-up-dash.js
var __iconNode60 = [
  [
    "path",
    {
      d: "M9 13a1 1 0 0 0-1-1H5.061a1 1 0 0 1-.75-1.811l6.836-6.835a1.207 1.207 0 0 1 1.707 0l6.835 6.835a1 1 0 0 1-.75 1.811H16a1 1 0 0 0-1 1v2a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1z",
      key: "pnzqmc"
    }
  ],
  ["path", { d: "M9 20h6", key: "s66wpe" }]
];
var ArrowBigUpDash = createLucideIcon("arrow-big-up-dash", __iconNode60);

// ../node_modules/lucide-react/dist/esm/icons/arrow-big-up.js
var __iconNode61 = [
  [
    "path",
    {
      d: "M9 13a1 1 0 0 0-1-1H5.061a1 1 0 0 1-.75-1.811l6.836-6.835a1.207 1.207 0 0 1 1.707 0l6.835 6.835a1 1 0 0 1-.75 1.811H16a1 1 0 0 0-1 1v6a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1z",
      key: "lh0v7k"
    }
  ]
];
var ArrowBigUp = createLucideIcon("arrow-big-up", __iconNode61);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down-0-1.js
var __iconNode62 = [
  ["path", { d: "m3 16 4 4 4-4", key: "1co6wj" }],
  ["path", { d: "M7 20V4", key: "1yoxec" }],
  ["rect", { x: "15", y: "4", width: "4", height: "6", ry: "2", key: "1bwicg" }],
  ["path", { d: "M17 20v-6h-2", key: "1qp1so" }],
  ["path", { d: "M15 20h4", key: "1j968p" }]
];
var ArrowDown01 = createLucideIcon("arrow-down-0-1", __iconNode62);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down-1-0.js
var __iconNode63 = [
  ["path", { d: "m3 16 4 4 4-4", key: "1co6wj" }],
  ["path", { d: "M7 20V4", key: "1yoxec" }],
  ["path", { d: "M17 10V4h-2", key: "zcsr5x" }],
  ["path", { d: "M15 10h4", key: "id2lce" }],
  ["rect", { x: "15", y: "14", width: "4", height: "6", ry: "2", key: "33xykx" }]
];
var ArrowDown10 = createLucideIcon("arrow-down-1-0", __iconNode63);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down-a-z.js
var __iconNode64 = [
  ["path", { d: "m3 16 4 4 4-4", key: "1co6wj" }],
  ["path", { d: "M7 20V4", key: "1yoxec" }],
  ["path", { d: "M20 8h-5", key: "1vsyxs" }],
  ["path", { d: "M15 10V6.5a2.5 2.5 0 0 1 5 0V10", key: "ag13bf" }],
  ["path", { d: "M15 14h5l-5 6h5", key: "ur5jdg" }]
];
var ArrowDownAZ = createLucideIcon("arrow-down-a-z", __iconNode64);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down-from-line.js
var __iconNode65 = [
  ["path", { d: "M19 3H5", key: "1236rx" }],
  ["path", { d: "M12 21V7", key: "gj6g52" }],
  ["path", { d: "m6 15 6 6 6-6", key: "h15q88" }]
];
var ArrowDownFromLine = createLucideIcon("arrow-down-from-line", __iconNode65);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down-left.js
var __iconNode66 = [
  ["path", { d: "M17 7 7 17", key: "15tmo1" }],
  ["path", { d: "M17 17H7V7", key: "1org7z" }]
];
var ArrowDownLeft = createLucideIcon("arrow-down-left", __iconNode66);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down-narrow-wide.js
var __iconNode67 = [
  ["path", { d: "m3 16 4 4 4-4", key: "1co6wj" }],
  ["path", { d: "M7 20V4", key: "1yoxec" }],
  ["path", { d: "M11 4h4", key: "6d7r33" }],
  ["path", { d: "M11 8h7", key: "djye34" }],
  ["path", { d: "M11 12h10", key: "1438ji" }]
];
var ArrowDownNarrowWide = createLucideIcon("arrow-down-narrow-wide", __iconNode67);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down-right.js
var __iconNode68 = [
  ["path", { d: "m7 7 10 10", key: "1fmybs" }],
  ["path", { d: "M17 7v10H7", key: "6fjiku" }]
];
var ArrowDownRight = createLucideIcon("arrow-down-right", __iconNode68);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down-to-dot.js
var __iconNode69 = [
  ["path", { d: "M12 2v14", key: "jyx4ut" }],
  ["path", { d: "m19 9-7 7-7-7", key: "1oe3oy" }],
  ["circle", { cx: "12", cy: "21", r: "1", key: "o0uj5v" }]
];
var ArrowDownToDot = createLucideIcon("arrow-down-to-dot", __iconNode69);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down-to-line.js
var __iconNode70 = [
  ["path", { d: "M12 17V3", key: "1cwfxf" }],
  ["path", { d: "m6 11 6 6 6-6", key: "12ii2o" }],
  ["path", { d: "M19 21H5", key: "150jfl" }]
];
var ArrowDownToLine = createLucideIcon("arrow-down-to-line", __iconNode70);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down-up.js
var __iconNode71 = [
  ["path", { d: "m3 16 4 4 4-4", key: "1co6wj" }],
  ["path", { d: "M7 20V4", key: "1yoxec" }],
  ["path", { d: "m21 8-4-4-4 4", key: "1c9v7m" }],
  ["path", { d: "M17 4v16", key: "7dpous" }]
];
var ArrowDownUp = createLucideIcon("arrow-down-up", __iconNode71);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down-wide-narrow.js
var __iconNode72 = [
  ["path", { d: "m3 16 4 4 4-4", key: "1co6wj" }],
  ["path", { d: "M7 20V4", key: "1yoxec" }],
  ["path", { d: "M11 4h10", key: "1w87gc" }],
  ["path", { d: "M11 8h7", key: "djye34" }],
  ["path", { d: "M11 12h4", key: "q8tih4" }]
];
var ArrowDownWideNarrow = createLucideIcon("arrow-down-wide-narrow", __iconNode72);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down-z-a.js
var __iconNode73 = [
  ["path", { d: "m3 16 4 4 4-4", key: "1co6wj" }],
  ["path", { d: "M7 4v16", key: "1glfcx" }],
  ["path", { d: "M15 4h5l-5 6h5", key: "8asdl1" }],
  ["path", { d: "M15 20v-3.5a2.5 2.5 0 0 1 5 0V20", key: "r6l5cz" }],
  ["path", { d: "M20 18h-5", key: "18j1r2" }]
];
var ArrowDownZA = createLucideIcon("arrow-down-z-a", __iconNode73);

// ../node_modules/lucide-react/dist/esm/icons/arrow-down.js
var __iconNode74 = [
  ["path", { d: "M12 5v14", key: "s699le" }],
  ["path", { d: "m19 12-7 7-7-7", key: "1idqje" }]
];
var ArrowDown = createLucideIcon("arrow-down", __iconNode74);

// ../node_modules/lucide-react/dist/esm/icons/arrow-left-from-line.js
var __iconNode75 = [
  ["path", { d: "m9 6-6 6 6 6", key: "7v63n9" }],
  ["path", { d: "M3 12h14", key: "13k4hi" }],
  ["path", { d: "M21 19V5", key: "b4bplr" }]
];
var ArrowLeftFromLine = createLucideIcon("arrow-left-from-line", __iconNode75);

// ../node_modules/lucide-react/dist/esm/icons/arrow-left-to-line.js
var __iconNode76 = [
  ["path", { d: "M3 19V5", key: "rwsyhb" }],
  ["path", { d: "m13 6-6 6 6 6", key: "1yhaz7" }],
  ["path", { d: "M7 12h14", key: "uoisry" }]
];
var ArrowLeftToLine = createLucideIcon("arrow-left-to-line", __iconNode76);

// ../node_modules/lucide-react/dist/esm/icons/arrow-left-right.js
var __iconNode77 = [
  ["path", { d: "M8 3 4 7l4 4", key: "9rb6wj" }],
  ["path", { d: "M4 7h16", key: "6tx8e3" }],
  ["path", { d: "m16 21 4-4-4-4", key: "siv7j2" }],
  ["path", { d: "M20 17H4", key: "h6l3hr" }]
];
var ArrowLeftRight = createLucideIcon("arrow-left-right", __iconNode77);

// ../node_modules/lucide-react/dist/esm/icons/arrow-right-from-line.js
var __iconNode78 = [
  ["path", { d: "M3 5v14", key: "1nt18q" }],
  ["path", { d: "M21 12H7", key: "13ipq5" }],
  ["path", { d: "m15 18 6-6-6-6", key: "6tx3qv" }]
];
var ArrowRightFromLine = createLucideIcon("arrow-right-from-line", __iconNode78);

// ../node_modules/lucide-react/dist/esm/icons/arrow-left.js
var __iconNode79 = [
  ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
  ["path", { d: "M19 12H5", key: "x3x0zl" }]
];
var ArrowLeft = createLucideIcon("arrow-left", __iconNode79);

// ../node_modules/lucide-react/dist/esm/icons/arrow-right-left.js
var __iconNode80 = [
  ["path", { d: "m16 3 4 4-4 4", key: "1x1c3m" }],
  ["path", { d: "M20 7H4", key: "zbl0bi" }],
  ["path", { d: "m8 21-4-4 4-4", key: "h9nckh" }],
  ["path", { d: "M4 17h16", key: "g4d7ey" }]
];
var ArrowRightLeft = createLucideIcon("arrow-right-left", __iconNode80);

// ../node_modules/lucide-react/dist/esm/icons/arrow-right-to-line.js
var __iconNode81 = [
  ["path", { d: "M17 12H3", key: "8awo09" }],
  ["path", { d: "m11 18 6-6-6-6", key: "8c2y43" }],
  ["path", { d: "M21 5v14", key: "nzette" }]
];
var ArrowRightToLine = createLucideIcon("arrow-right-to-line", __iconNode81);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up-0-1.js
var __iconNode82 = [
  ["path", { d: "m3 8 4-4 4 4", key: "11wl7u" }],
  ["path", { d: "M7 4v16", key: "1glfcx" }],
  ["rect", { x: "15", y: "4", width: "4", height: "6", ry: "2", key: "1bwicg" }],
  ["path", { d: "M17 20v-6h-2", key: "1qp1so" }],
  ["path", { d: "M15 20h4", key: "1j968p" }]
];
var ArrowUp01 = createLucideIcon("arrow-up-0-1", __iconNode82);

// ../node_modules/lucide-react/dist/esm/icons/arrow-right.js
var __iconNode83 = [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "m12 5 7 7-7 7", key: "xquz4c" }]
];
var ArrowRight = createLucideIcon("arrow-right", __iconNode83);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up-1-0.js
var __iconNode84 = [
  ["path", { d: "m3 8 4-4 4 4", key: "11wl7u" }],
  ["path", { d: "M7 4v16", key: "1glfcx" }],
  ["path", { d: "M17 10V4h-2", key: "zcsr5x" }],
  ["path", { d: "M15 10h4", key: "id2lce" }],
  ["rect", { x: "15", y: "14", width: "4", height: "6", ry: "2", key: "33xykx" }]
];
var ArrowUp10 = createLucideIcon("arrow-up-1-0", __iconNode84);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up-a-z.js
var __iconNode85 = [
  ["path", { d: "m3 8 4-4 4 4", key: "11wl7u" }],
  ["path", { d: "M7 4v16", key: "1glfcx" }],
  ["path", { d: "M20 8h-5", key: "1vsyxs" }],
  ["path", { d: "M15 10V6.5a2.5 2.5 0 0 1 5 0V10", key: "ag13bf" }],
  ["path", { d: "M15 14h5l-5 6h5", key: "ur5jdg" }]
];
var ArrowUpAZ = createLucideIcon("arrow-up-a-z", __iconNode85);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up-down.js
var __iconNode86 = [
  ["path", { d: "m21 16-4 4-4-4", key: "f6ql7i" }],
  ["path", { d: "M17 20V4", key: "1ejh1v" }],
  ["path", { d: "m3 8 4-4 4 4", key: "11wl7u" }],
  ["path", { d: "M7 4v16", key: "1glfcx" }]
];
var ArrowUpDown = createLucideIcon("arrow-up-down", __iconNode86);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up-from-dot.js
var __iconNode87 = [
  ["path", { d: "m5 9 7-7 7 7", key: "1hw5ic" }],
  ["path", { d: "M12 16V2", key: "ywoabb" }],
  ["circle", { cx: "12", cy: "21", r: "1", key: "o0uj5v" }]
];
var ArrowUpFromDot = createLucideIcon("arrow-up-from-dot", __iconNode87);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up-from-line.js
var __iconNode88 = [
  ["path", { d: "m18 9-6-6-6 6", key: "kcunyi" }],
  ["path", { d: "M12 3v14", key: "7cf3v8" }],
  ["path", { d: "M5 21h14", key: "11awu3" }]
];
var ArrowUpFromLine = createLucideIcon("arrow-up-from-line", __iconNode88);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up-left.js
var __iconNode89 = [
  ["path", { d: "M7 17V7h10", key: "11bw93" }],
  ["path", { d: "M17 17 7 7", key: "2786uv" }]
];
var ArrowUpLeft = createLucideIcon("arrow-up-left", __iconNode89);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up-right.js
var __iconNode90 = [
  ["path", { d: "M7 7h10v10", key: "1tivn9" }],
  ["path", { d: "M7 17 17 7", key: "1vkiza" }]
];
var ArrowUpRight = createLucideIcon("arrow-up-right", __iconNode90);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up-narrow-wide.js
var __iconNode91 = [
  ["path", { d: "m3 8 4-4 4 4", key: "11wl7u" }],
  ["path", { d: "M7 4v16", key: "1glfcx" }],
  ["path", { d: "M11 12h4", key: "q8tih4" }],
  ["path", { d: "M11 16h7", key: "uosisv" }],
  ["path", { d: "M11 20h10", key: "jvxblo" }]
];
var ArrowUpNarrowWide = createLucideIcon("arrow-up-narrow-wide", __iconNode91);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up-to-line.js
var __iconNode92 = [
  ["path", { d: "M5 3h14", key: "7usisc" }],
  ["path", { d: "m18 13-6-6-6 6", key: "1kf1n9" }],
  ["path", { d: "M12 7v14", key: "1akyts" }]
];
var ArrowUpToLine = createLucideIcon("arrow-up-to-line", __iconNode92);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up-wide-narrow.js
var __iconNode93 = [
  ["path", { d: "m3 8 4-4 4 4", key: "11wl7u" }],
  ["path", { d: "M7 4v16", key: "1glfcx" }],
  ["path", { d: "M11 12h10", key: "1438ji" }],
  ["path", { d: "M11 16h7", key: "uosisv" }],
  ["path", { d: "M11 20h4", key: "1krc32" }]
];
var ArrowUpWideNarrow = createLucideIcon("arrow-up-wide-narrow", __iconNode93);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up-z-a.js
var __iconNode94 = [
  ["path", { d: "m3 8 4-4 4 4", key: "11wl7u" }],
  ["path", { d: "M7 4v16", key: "1glfcx" }],
  ["path", { d: "M15 4h5l-5 6h5", key: "8asdl1" }],
  ["path", { d: "M15 20v-3.5a2.5 2.5 0 0 1 5 0V20", key: "r6l5cz" }],
  ["path", { d: "M20 18h-5", key: "18j1r2" }]
];
var ArrowUpZA = createLucideIcon("arrow-up-z-a", __iconNode94);

// ../node_modules/lucide-react/dist/esm/icons/arrow-up.js
var __iconNode95 = [
  ["path", { d: "m5 12 7-7 7 7", key: "hav0vg" }],
  ["path", { d: "M12 19V5", key: "x0mq9r" }]
];
var ArrowUp = createLucideIcon("arrow-up", __iconNode95);

// ../node_modules/lucide-react/dist/esm/icons/arrows-up-from-line.js
var __iconNode96 = [
  ["path", { d: "m4 6 3-3 3 3", key: "9aidw8" }],
  ["path", { d: "M7 17V3", key: "19qxw1" }],
  ["path", { d: "m14 6 3-3 3 3", key: "6iy689" }],
  ["path", { d: "M17 17V3", key: "o0fmgi" }],
  ["path", { d: "M4 21h16", key: "1h09gz" }]
];
var ArrowsUpFromLine = createLucideIcon("arrows-up-from-line", __iconNode96);

// ../node_modules/lucide-react/dist/esm/icons/asterisk.js
var __iconNode97 = [
  ["path", { d: "M12 6v12", key: "1vza4d" }],
  ["path", { d: "M17.196 9 6.804 15", key: "1ah31z" }],
  ["path", { d: "m6.804 9 10.392 6", key: "1b6pxd" }]
];
var Asterisk = createLucideIcon("asterisk", __iconNode97);

// ../node_modules/lucide-react/dist/esm/icons/at-sign.js
var __iconNode98 = [
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }],
  ["path", { d: "M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8", key: "7n84p3" }]
];
var AtSign = createLucideIcon("at-sign", __iconNode98);

// ../node_modules/lucide-react/dist/esm/icons/atom.js
var __iconNode99 = [
  ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }],
  [
    "path",
    {
      d: "M20.2 20.2c2.04-2.03.02-7.36-4.5-11.9-4.54-4.52-9.87-6.54-11.9-4.5-2.04 2.03-.02 7.36 4.5 11.9 4.54 4.52 9.87 6.54 11.9 4.5Z",
      key: "1l2ple"
    }
  ],
  [
    "path",
    {
      d: "M15.7 15.7c4.52-4.54 6.54-9.87 4.5-11.9-2.03-2.04-7.36-.02-11.9 4.5-4.52 4.54-6.54 9.87-4.5 11.9 2.03 2.04 7.36.02 11.9-4.5Z",
      key: "1wam0m"
    }
  ]
];
var Atom = createLucideIcon("atom", __iconNode99);

// ../node_modules/lucide-react/dist/esm/icons/audio-waveform.js
var __iconNode100 = [
  [
    "path",
    {
      d: "M2 13a2 2 0 0 0 2-2V7a2 2 0 0 1 4 0v13a2 2 0 0 0 4 0V4a2 2 0 0 1 4 0v13a2 2 0 0 0 4 0v-4a2 2 0 0 1 2-2",
      key: "57tc96"
    }
  ]
];
var AudioWaveform = createLucideIcon("audio-waveform", __iconNode100);

// ../node_modules/lucide-react/dist/esm/icons/audio-lines.js
var __iconNode101 = [
  ["path", { d: "M2 10v3", key: "1fnikh" }],
  ["path", { d: "M6 6v11", key: "11sgs0" }],
  ["path", { d: "M10 3v18", key: "yhl04a" }],
  ["path", { d: "M14 8v7", key: "3a1oy3" }],
  ["path", { d: "M18 5v13", key: "123xd1" }],
  ["path", { d: "M22 10v3", key: "154ddg" }]
];
var AudioLines = createLucideIcon("audio-lines", __iconNode101);

// ../node_modules/lucide-react/dist/esm/icons/award.js
var __iconNode102 = [
  [
    "path",
    {
      d: "m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",
      key: "1yiouv"
    }
  ],
  ["circle", { cx: "12", cy: "8", r: "6", key: "1vp47v" }]
];
var Award = createLucideIcon("award", __iconNode102);

// ../node_modules/lucide-react/dist/esm/icons/axe.js
var __iconNode103 = [
  ["path", { d: "m14 12-8.381 8.38a1 1 0 0 1-3.001-3L11 9", key: "5z9253" }],
  [
    "path",
    {
      d: "M15 15.5a.5.5 0 0 0 .5.5A6.5 6.5 0 0 0 22 9.5a.5.5 0 0 0-.5-.5h-1.672a2 2 0 0 1-1.414-.586l-5.062-5.062a1.205 1.205 0 0 0-1.704 0L9.352 5.648a1.205 1.205 0 0 0 0 1.704l5.062 5.062A2 2 0 0 1 15 13.828z",
      key: "19zklq"
    }
  ]
];
var Axe = createLucideIcon("axe", __iconNode103);

// ../node_modules/lucide-react/dist/esm/icons/axis-3d.js
var __iconNode104 = [
  ["path", { d: "M13.5 10.5 15 9", key: "1nsxvm" }],
  ["path", { d: "M4 4v15a1 1 0 0 0 1 1h15", key: "1w6lkd" }],
  ["path", { d: "M4.293 19.707 6 18", key: "3g1p8c" }],
  ["path", { d: "m9 15 1.5-1.5", key: "1xfbes" }]
];
var Axis3d = createLucideIcon("axis-3d", __iconNode104);

// ../node_modules/lucide-react/dist/esm/icons/baby.js
var __iconNode105 = [
  ["path", { d: "M10 16c.5.3 1.2.5 2 .5s1.5-.2 2-.5", key: "1u7htd" }],
  ["path", { d: "M15 12h.01", key: "1k8ypt" }],
  [
    "path",
    {
      d: "M19.38 6.813A9 9 0 0 1 20.8 10.2a2 2 0 0 1 0 3.6 9 9 0 0 1-17.6 0 2 2 0 0 1 0-3.6A9 9 0 0 1 12 3c2 0 3.5 1.1 3.5 2.5s-.9 2.5-2 2.5c-.8 0-1.5-.4-1.5-1",
      key: "11xh7x"
    }
  ],
  ["path", { d: "M9 12h.01", key: "157uk2" }]
];
var Baby = createLucideIcon("baby", __iconNode105);

// ../node_modules/lucide-react/dist/esm/icons/backpack.js
var __iconNode106 = [
  [
    "path",
    { d: "M4 10a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4v10a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z", key: "1ol0lm" }
  ],
  ["path", { d: "M8 10h8", key: "c7uz4u" }],
  ["path", { d: "M8 18h8", key: "1no2b1" }],
  ["path", { d: "M8 22v-6a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v6", key: "1fr6do" }],
  ["path", { d: "M9 6V4a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2", key: "donm21" }]
];
var Backpack = createLucideIcon("backpack", __iconNode106);

// ../node_modules/lucide-react/dist/esm/icons/badge-alert.js
var __iconNode107 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "12", key: "1pkeuh" }],
  ["line", { x1: "12", x2: "12.01", y1: "16", y2: "16", key: "4dfq90" }]
];
var BadgeAlert = createLucideIcon("badge-alert", __iconNode107);

// ../node_modules/lucide-react/dist/esm/icons/badge-cent.js
var __iconNode108 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["path", { d: "M12 7v10", key: "jspqdw" }],
  ["path", { d: "M15.4 10a4 4 0 1 0 0 4", key: "2eqtx8" }]
];
var BadgeCent = createLucideIcon("badge-cent", __iconNode108);

// ../node_modules/lucide-react/dist/esm/icons/badge-check.js
var __iconNode109 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
];
var BadgeCheck = createLucideIcon("badge-check", __iconNode109);

// ../node_modules/lucide-react/dist/esm/icons/badge-dollar-sign.js
var __iconNode110 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["path", { d: "M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8", key: "1h4pet" }],
  ["path", { d: "M12 18V6", key: "zqpxq5" }]
];
var BadgeDollarSign = createLucideIcon("badge-dollar-sign", __iconNode110);

// ../node_modules/lucide-react/dist/esm/icons/badge-euro.js
var __iconNode111 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["path", { d: "M7 12h5", key: "gblrwe" }],
  ["path", { d: "M15 9.4a4 4 0 1 0 0 5.2", key: "1makmb" }]
];
var BadgeEuro = createLucideIcon("badge-euro", __iconNode111);

// ../node_modules/lucide-react/dist/esm/icons/badge-indian-rupee.js
var __iconNode112 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["path", { d: "M8 8h8", key: "1bis0t" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }],
  ["path", { d: "m13 17-5-1h1a4 4 0 0 0 0-8", key: "nu2bwa" }]
];
var BadgeIndianRupee = createLucideIcon("badge-indian-rupee", __iconNode112);

// ../node_modules/lucide-react/dist/esm/icons/badge-info.js
var __iconNode113 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["line", { x1: "12", x2: "12", y1: "16", y2: "12", key: "1y1yb1" }],
  ["line", { x1: "12", x2: "12.01", y1: "8", y2: "8", key: "110wyk" }]
];
var BadgeInfo = createLucideIcon("badge-info", __iconNode113);

// ../node_modules/lucide-react/dist/esm/icons/badge-japanese-yen.js
var __iconNode114 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["path", { d: "m9 8 3 3v7", key: "17yadx" }],
  ["path", { d: "m12 11 3-3", key: "p4cfq1" }],
  ["path", { d: "M9 12h6", key: "1c52cq" }],
  ["path", { d: "M9 16h6", key: "8wimt3" }]
];
var BadgeJapaneseYen = createLucideIcon("badge-japanese-yen", __iconNode114);

// ../node_modules/lucide-react/dist/esm/icons/badge-minus.js
var __iconNode115 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["line", { x1: "8", x2: "16", y1: "12", y2: "12", key: "1jonct" }]
];
var BadgeMinus = createLucideIcon("badge-minus", __iconNode115);

// ../node_modules/lucide-react/dist/esm/icons/badge-percent.js
var __iconNode116 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "M9 9h.01", key: "1q5me6" }],
  ["path", { d: "M15 15h.01", key: "lqbp3k" }]
];
var BadgePercent = createLucideIcon("badge-percent", __iconNode116);

// ../node_modules/lucide-react/dist/esm/icons/badge-plus.js
var __iconNode117 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "16", key: "10p56q" }],
  ["line", { x1: "8", x2: "16", y1: "12", y2: "12", key: "1jonct" }]
];
var BadgePlus = createLucideIcon("badge-plus", __iconNode117);

// ../node_modules/lucide-react/dist/esm/icons/badge-pound-sterling.js
var __iconNode118 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["path", { d: "M8 12h4", key: "qz6y1c" }],
  ["path", { d: "M10 16V9.5a2.5 2.5 0 0 1 5 0", key: "3mlbjk" }],
  ["path", { d: "M8 16h7", key: "sbedsn" }]
];
var BadgePoundSterling = createLucideIcon("badge-pound-sterling", __iconNode118);

// ../node_modules/lucide-react/dist/esm/icons/badge-question-mark.js
var __iconNode119 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3", key: "1u773s" }],
  ["line", { x1: "12", x2: "12.01", y1: "17", y2: "17", key: "io3f8k" }]
];
var BadgeQuestionMark = createLucideIcon("badge-question-mark", __iconNode119);

// ../node_modules/lucide-react/dist/esm/icons/badge-russian-ruble.js
var __iconNode120 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["path", { d: "M9 16h5", key: "1syiyw" }],
  ["path", { d: "M9 12h5a2 2 0 1 0 0-4h-3v9", key: "1ge9c1" }]
];
var BadgeRussianRuble = createLucideIcon("badge-russian-ruble", __iconNode120);

// ../node_modules/lucide-react/dist/esm/icons/badge-swiss-franc.js
var __iconNode121 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["path", { d: "M11 17V8h4", key: "1bfq6y" }],
  ["path", { d: "M11 12h3", key: "2eqnfz" }],
  ["path", { d: "M9 16h4", key: "1skf3a" }]
];
var BadgeSwissFranc = createLucideIcon("badge-swiss-franc", __iconNode121);

// ../node_modules/lucide-react/dist/esm/icons/badge-turkish-lira.js
var __iconNode122 = [
  ["path", { d: "M11 7v10a5 5 0 0 0 5-5", key: "1ja3ih" }],
  ["path", { d: "m15 8-6 3", key: "4x0uwz" }],
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76",
      key: "18242g"
    }
  ]
];
var BadgeTurkishLira = createLucideIcon("badge-turkish-lira", __iconNode122);

// ../node_modules/lucide-react/dist/esm/icons/badge-x.js
var __iconNode123 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ],
  ["line", { x1: "15", x2: "9", y1: "9", y2: "15", key: "f7djnv" }],
  ["line", { x1: "9", x2: "15", y1: "9", y2: "15", key: "1shsy8" }]
];
var BadgeX = createLucideIcon("badge-x", __iconNode123);

// ../node_modules/lucide-react/dist/esm/icons/badge.js
var __iconNode124 = [
  [
    "path",
    {
      d: "M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z",
      key: "3c2336"
    }
  ]
];
var Badge = createLucideIcon("badge", __iconNode124);

// ../node_modules/lucide-react/dist/esm/icons/baggage-claim.js
var __iconNode125 = [
  ["path", { d: "M22 18H6a2 2 0 0 1-2-2V7a2 2 0 0 0-2-2", key: "4irg2o" }],
  ["path", { d: "M17 14V4a2 2 0 0 0-2-2h-1a2 2 0 0 0-2 2v10", key: "14fcyx" }],
  ["rect", { width: "13", height: "8", x: "8", y: "6", rx: "1", key: "o6oiis" }],
  ["circle", { cx: "18", cy: "20", r: "2", key: "t9985n" }],
  ["circle", { cx: "9", cy: "20", r: "2", key: "e5v82j" }]
];
var BaggageClaim = createLucideIcon("baggage-claim", __iconNode125);

// ../node_modules/lucide-react/dist/esm/icons/balloon.js
var __iconNode126 = [
  ["path", { d: "M12 16v1a2 2 0 0 0 2 2h1a2 2 0 0 1 2 2v1", key: "2nz4b" }],
  ["path", { d: "M12 6a2 2 0 0 1 2 2", key: "7y7d82" }],
  ["path", { d: "M18 8c0 4-3.5 8-6 8s-6-4-6-8a6 6 0 0 1 12 0", key: "vqb5s3" }]
];
var Balloon = createLucideIcon("balloon", __iconNode126);

// ../node_modules/lucide-react/dist/esm/icons/ban.js
var __iconNode127 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M4.929 4.929 19.07 19.071", key: "196cmz" }]
];
var Ban = createLucideIcon("ban", __iconNode127);

// ../node_modules/lucide-react/dist/esm/icons/banana.js
var __iconNode128 = [
  ["path", { d: "M4 13c3.5-2 8-2 10 2a5.5 5.5 0 0 1 8 5", key: "1cscit" }],
  [
    "path",
    {
      d: "M5.15 17.89c5.52-1.52 8.65-6.89 7-12C11.55 4 11.5 2 13 2c3.22 0 5 5.5 5 8 0 6.5-4.2 12-10.49 12C5.11 22 2 22 2 20c0-1.5 1.14-1.55 3.15-2.11Z",
      key: "1y1nbv"
    }
  ]
];
var Banana = createLucideIcon("banana", __iconNode128);

// ../node_modules/lucide-react/dist/esm/icons/bandage.js
var __iconNode129 = [
  ["path", { d: "M10 10.01h.01", key: "1e9xi7" }],
  ["path", { d: "M10 14.01h.01", key: "ac23bv" }],
  ["path", { d: "M14 10.01h.01", key: "2wfrvf" }],
  ["path", { d: "M14 14.01h.01", key: "8tw8yn" }],
  ["path", { d: "M18 6v12", key: "1bcixs" }],
  ["path", { d: "M6 6v12", key: "vkc79e" }],
  ["rect", { x: "2", y: "6", width: "20", height: "12", rx: "2", key: "1wpnh2" }]
];
var Bandage = createLucideIcon("bandage", __iconNode129);

// ../node_modules/lucide-react/dist/esm/icons/banknote-arrow-down.js
var __iconNode130 = [
  ["path", { d: "M12 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5", key: "x6cv4u" }],
  ["path", { d: "m16 19 3 3 3-3", key: "1ibux0" }],
  ["path", { d: "M18 12h.01", key: "yjnet6" }],
  ["path", { d: "M19 16v6", key: "tddt3s" }],
  ["path", { d: "M6 12h.01", key: "c2rlol" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }]
];
var BanknoteArrowDown = createLucideIcon("banknote-arrow-down", __iconNode130);

// ../node_modules/lucide-react/dist/esm/icons/banknote-arrow-up.js
var __iconNode131 = [
  ["path", { d: "M12 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5", key: "x6cv4u" }],
  ["path", { d: "M18 12h.01", key: "yjnet6" }],
  ["path", { d: "M19 22v-6", key: "qhmiwi" }],
  ["path", { d: "m22 19-3-3-3 3", key: "rn6bg2" }],
  ["path", { d: "M6 12h.01", key: "c2rlol" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }]
];
var BanknoteArrowUp = createLucideIcon("banknote-arrow-up", __iconNode131);

// ../node_modules/lucide-react/dist/esm/icons/banknote-x.js
var __iconNode132 = [
  ["path", { d: "M13 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5", key: "16nib6" }],
  ["path", { d: "m17 17 5 5", key: "p7ous7" }],
  ["path", { d: "M18 12h.01", key: "yjnet6" }],
  ["path", { d: "m22 17-5 5", key: "gqnmv0" }],
  ["path", { d: "M6 12h.01", key: "c2rlol" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }]
];
var BanknoteX = createLucideIcon("banknote-x", __iconNode132);

// ../node_modules/lucide-react/dist/esm/icons/banknote.js
var __iconNode133 = [
  ["rect", { width: "20", height: "12", x: "2", y: "6", rx: "2", key: "9lu3g6" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }],
  ["path", { d: "M6 12h.01M18 12h.01", key: "113zkx" }]
];
var Banknote = createLucideIcon("banknote", __iconNode133);

// ../node_modules/lucide-react/dist/esm/icons/barcode.js
var __iconNode134 = [
  ["path", { d: "M3 5v14", key: "1nt18q" }],
  ["path", { d: "M8 5v14", key: "1ybrkv" }],
  ["path", { d: "M12 5v14", key: "s699le" }],
  ["path", { d: "M17 5v14", key: "ycjyhj" }],
  ["path", { d: "M21 5v14", key: "nzette" }]
];
var Barcode = createLucideIcon("barcode", __iconNode134);

// ../node_modules/lucide-react/dist/esm/icons/barrel.js
var __iconNode135 = [
  ["path", { d: "M10 3a41 41 0 0 0 0 18", key: "1qcnzb" }],
  ["path", { d: "M14 3a41 41 0 0 1 0 18", key: "547vd4" }],
  [
    "path",
    {
      d: "M17 3a2 2 0 0 1 1.68.92 15.25 15.25 0 0 1 0 16.16A2 2 0 0 1 17 21H7a2 2 0 0 1-1.68-.92 15.25 15.25 0 0 1 0-16.16A2 2 0 0 1 7 3z",
      key: "1wepyy"
    }
  ],
  ["path", { d: "M3.84 17h16.32", key: "1wh981" }],
  ["path", { d: "M3.84 7h16.32", key: "19jf4x" }]
];
var Barrel = createLucideIcon("barrel", __iconNode135);

// ../node_modules/lucide-react/dist/esm/icons/baseline.js
var __iconNode136 = [
  ["path", { d: "M4 20h16", key: "14thso" }],
  ["path", { d: "m6 16 6-12 6 12", key: "1b4byz" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }]
];
var Baseline = createLucideIcon("baseline", __iconNode136);

// ../node_modules/lucide-react/dist/esm/icons/bath.js
var __iconNode137 = [
  ["path", { d: "M10 4 8 6", key: "1rru8s" }],
  ["path", { d: "M17 19v2", key: "ts1sot" }],
  ["path", { d: "M2 12h20", key: "9i4pu4" }],
  ["path", { d: "M7 19v2", key: "12npes" }],
  [
    "path",
    {
      d: "M9 5 7.621 3.621A2.121 2.121 0 0 0 4 5v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5",
      key: "14ym8i"
    }
  ]
];
var Bath = createLucideIcon("bath", __iconNode137);

// ../node_modules/lucide-react/dist/esm/icons/battery-charging.js
var __iconNode138 = [
  ["path", { d: "m11 7-3 5h4l-3 5", key: "b4a64w" }],
  ["path", { d: "M14.856 6H16a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.935", key: "lre1cr" }],
  ["path", { d: "M22 14v-4", key: "14q9d5" }],
  ["path", { d: "M5.14 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h2.936", key: "13q5k0" }]
];
var BatteryCharging = createLucideIcon("battery-charging", __iconNode138);

// ../node_modules/lucide-react/dist/esm/icons/battery-full.js
var __iconNode139 = [
  ["path", { d: "M10 10v4", key: "1mb2ec" }],
  ["path", { d: "M14 10v4", key: "1nt88p" }],
  ["path", { d: "M22 14v-4", key: "14q9d5" }],
  ["path", { d: "M6 10v4", key: "1n77qd" }],
  ["rect", { x: "2", y: "6", width: "16", height: "12", rx: "2", key: "13zb55" }]
];
var BatteryFull = createLucideIcon("battery-full", __iconNode139);

// ../node_modules/lucide-react/dist/esm/icons/battery-low.js
var __iconNode140 = [
  ["path", { d: "M22 14v-4", key: "14q9d5" }],
  ["path", { d: "M6 14v-4", key: "14a6bd" }],
  ["rect", { x: "2", y: "6", width: "16", height: "12", rx: "2", key: "13zb55" }]
];
var BatteryLow = createLucideIcon("battery-low", __iconNode140);

// ../node_modules/lucide-react/dist/esm/icons/battery-medium.js
var __iconNode141 = [
  ["path", { d: "M10 14v-4", key: "suye4c" }],
  ["path", { d: "M22 14v-4", key: "14q9d5" }],
  ["path", { d: "M6 14v-4", key: "14a6bd" }],
  ["rect", { x: "2", y: "6", width: "16", height: "12", rx: "2", key: "13zb55" }]
];
var BatteryMedium = createLucideIcon("battery-medium", __iconNode141);

// ../node_modules/lucide-react/dist/esm/icons/battery-plus.js
var __iconNode142 = [
  ["path", { d: "M10 9v6", key: "17i7lo" }],
  ["path", { d: "M12.543 6H16a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-3.605", key: "o09yah" }],
  ["path", { d: "M22 14v-4", key: "14q9d5" }],
  ["path", { d: "M7 12h6", key: "iekk3h" }],
  ["path", { d: "M7.606 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3.606", key: "xyqvf1" }]
];
var BatteryPlus = createLucideIcon("battery-plus", __iconNode142);

// ../node_modules/lucide-react/dist/esm/icons/battery-warning.js
var __iconNode143 = [
  ["path", { d: "M10 17h.01", key: "nbq80n" }],
  ["path", { d: "M10 7v6", key: "nne03l" }],
  ["path", { d: "M14 6h2a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2", key: "1m83kb" }],
  ["path", { d: "M22 14v-4", key: "14q9d5" }],
  ["path", { d: "M6 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h2", key: "h8lgfh" }]
];
var BatteryWarning = createLucideIcon("battery-warning", __iconNode143);

// ../node_modules/lucide-react/dist/esm/icons/battery.js
var __iconNode144 = [
  ["path", { d: "M 22 14 L 22 10", key: "nqc4tb" }],
  ["rect", { x: "2", y: "6", width: "16", height: "12", rx: "2", key: "13zb55" }]
];
var Battery = createLucideIcon("battery", __iconNode144);

// ../node_modules/lucide-react/dist/esm/icons/beaker.js
var __iconNode145 = [
  ["path", { d: "M4.5 3h15", key: "c7n0jr" }],
  ["path", { d: "M6 3v16a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V3", key: "m1uhx7" }],
  ["path", { d: "M6 14h12", key: "4cwo0f" }]
];
var Beaker = createLucideIcon("beaker", __iconNode145);

// ../node_modules/lucide-react/dist/esm/icons/bean-off.js
var __iconNode146 = [
  [
    "path",
    {
      d: "M9 9c-.64.64-1.521.954-2.402 1.165A6 6 0 0 0 8 22a13.96 13.96 0 0 0 9.9-4.1",
      key: "bq3udt"
    }
  ],
  ["path", { d: "M10.75 5.093A6 6 0 0 1 22 8c0 2.411-.61 4.68-1.683 6.66", key: "17ccse" }],
  [
    "path",
    {
      d: "M5.341 10.62a4 4 0 0 0 6.487 1.208M10.62 5.341a4.015 4.015 0 0 1 2.039 2.04",
      key: "18zqgq"
    }
  ],
  ["line", { x1: "2", x2: "22", y1: "2", y2: "22", key: "a6p6uj" }]
];
var BeanOff = createLucideIcon("bean-off", __iconNode146);

// ../node_modules/lucide-react/dist/esm/icons/bean.js
var __iconNode147 = [
  [
    "path",
    {
      d: "M10.165 6.598C9.954 7.478 9.64 8.36 9 9c-.64.64-1.521.954-2.402 1.165A6 6 0 0 0 8 22c7.732 0 14-6.268 14-14a6 6 0 0 0-11.835-1.402Z",
      key: "1tvzk7"
    }
  ],
  ["path", { d: "M5.341 10.62a4 4 0 1 0 5.279-5.28", key: "2cyri2" }]
];
var Bean = createLucideIcon("bean", __iconNode147);

// ../node_modules/lucide-react/dist/esm/icons/bed-double.js
var __iconNode148 = [
  ["path", { d: "M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8", key: "1k78r4" }],
  ["path", { d: "M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4", key: "fb3tl2" }],
  ["path", { d: "M12 4v6", key: "1dcgq2" }],
  ["path", { d: "M2 18h20", key: "ajqnye" }]
];
var BedDouble = createLucideIcon("bed-double", __iconNode148);

// ../node_modules/lucide-react/dist/esm/icons/bed-single.js
var __iconNode149 = [
  ["path", { d: "M3 20v-8a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v8", key: "1wm6mi" }],
  ["path", { d: "M5 10V6a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v4", key: "4k93s5" }],
  ["path", { d: "M3 18h18", key: "1h113x" }]
];
var BedSingle = createLucideIcon("bed-single", __iconNode149);

// ../node_modules/lucide-react/dist/esm/icons/bed.js
var __iconNode150 = [
  ["path", { d: "M2 4v16", key: "vw9hq8" }],
  ["path", { d: "M2 8h18a2 2 0 0 1 2 2v10", key: "1dgv2r" }],
  ["path", { d: "M2 17h20", key: "18nfp3" }],
  ["path", { d: "M6 8v9", key: "1yriud" }]
];
var Bed = createLucideIcon("bed", __iconNode150);

// ../node_modules/lucide-react/dist/esm/icons/beef.js
var __iconNode151 = [
  [
    "path",
    {
      d: "M16.4 13.7A6.5 6.5 0 1 0 6.28 6.6c-1.1 3.13-.78 3.9-3.18 6.08A3 3 0 0 0 5 18c4 0 8.4-1.8 11.4-4.3",
      key: "cisjcv"
    }
  ],
  [
    "path",
    {
      d: "m18.5 6 2.19 4.5a6.48 6.48 0 0 1-2.29 7.2C15.4 20.2 11 22 7 22a3 3 0 0 1-2.68-1.66L2.4 16.5",
      key: "5byaag"
    }
  ],
  ["circle", { cx: "12.5", cy: "8.5", r: "2.5", key: "9738u8" }]
];
var Beef = createLucideIcon("beef", __iconNode151);

// ../node_modules/lucide-react/dist/esm/icons/beer-off.js
var __iconNode152 = [
  ["path", { d: "M13 13v5", key: "igwfh0" }],
  ["path", { d: "M17 11.47V8", key: "16yw0g" }],
  ["path", { d: "M17 11h1a3 3 0 0 1 2.745 4.211", key: "1xbt65" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M5 8v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2v-3", key: "c55o3e" }],
  [
    "path",
    { d: "M7.536 7.535C6.766 7.649 6.154 8 5.5 8a2.5 2.5 0 0 1-1.768-4.268", key: "1ydug7" }
  ],
  [
    "path",
    {
      d: "M8.727 3.204C9.306 2.767 9.885 2 11 2c1.56 0 2 1.5 3 1.5s1.72-.5 2.5-.5a1 1 0 1 1 0 5c-.78 0-1.5-.5-2.5-.5a3.149 3.149 0 0 0-.842.12",
      key: "q81o7q"
    }
  ],
  ["path", { d: "M9 14.6V18", key: "20ek98" }]
];
var BeerOff = createLucideIcon("beer-off", __iconNode152);

// ../node_modules/lucide-react/dist/esm/icons/beer.js
var __iconNode153 = [
  ["path", { d: "M17 11h1a3 3 0 0 1 0 6h-1", key: "1yp76v" }],
  ["path", { d: "M9 12v6", key: "1u1cab" }],
  ["path", { d: "M13 12v6", key: "1sugkk" }],
  [
    "path",
    {
      d: "M14 7.5c-1 0-1.44.5-3 .5s-2-.5-3-.5-1.72.5-2.5.5a2.5 2.5 0 0 1 0-5c.78 0 1.57.5 2.5.5S9.44 2 11 2s2 1.5 3 1.5 1.72-.5 2.5-.5a2.5 2.5 0 0 1 0 5c-.78 0-1.5-.5-2.5-.5Z",
      key: "1510fo"
    }
  ],
  ["path", { d: "M5 8v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8", key: "19jb7n" }]
];
var Beer = createLucideIcon("beer", __iconNode153);

// ../node_modules/lucide-react/dist/esm/icons/bell-dot.js
var __iconNode154 = [
  ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
  [
    "path",
    {
      d: "M11.68 2.009A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673c-.824-.85-1.678-1.731-2.21-3.348",
      key: "xaq59h"
    }
  ],
  ["circle", { cx: "18", cy: "5", r: "3", key: "gq8acd" }]
];
var BellDot = createLucideIcon("bell-dot", __iconNode154);

// ../node_modules/lucide-react/dist/esm/icons/bell-electric.js
var __iconNode155 = [
  ["path", { d: "M18.518 17.347A7 7 0 0 1 14 19", key: "1emhpo" }],
  ["path", { d: "M18.8 4A11 11 0 0 1 20 9", key: "127b67" }],
  ["path", { d: "M9 9h.01", key: "1q5me6" }],
  ["circle", { cx: "20", cy: "16", r: "2", key: "1v9bxh" }],
  ["circle", { cx: "9", cy: "9", r: "7", key: "p2h5vp" }],
  ["rect", { x: "4", y: "16", width: "10", height: "6", rx: "2", key: "bfnviv" }]
];
var BellElectric = createLucideIcon("bell-electric", __iconNode155);

// ../node_modules/lucide-react/dist/esm/icons/bell-minus.js
var __iconNode156 = [
  ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
  ["path", { d: "M15 8h6", key: "8ybuxh" }],
  [
    "path",
    {
      d: "M16.243 3.757A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673A9.4 9.4 0 0 1 18.667 12",
      key: "bdwj86"
    }
  ]
];
var BellMinus = createLucideIcon("bell-minus", __iconNode156);

// ../node_modules/lucide-react/dist/esm/icons/bell-off.js
var __iconNode157 = [
  ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
  [
    "path",
    {
      d: "M17 17H4a1 1 0 0 1-.74-1.673C4.59 13.956 6 12.499 6 8a6 6 0 0 1 .258-1.742",
      key: "178tsu"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M8.668 3.01A6 6 0 0 1 18 8c0 2.687.77 4.653 1.707 6.05", key: "1hqiys" }]
];
var BellOff = createLucideIcon("bell-off", __iconNode157);

// ../node_modules/lucide-react/dist/esm/icons/bell-plus.js
var __iconNode158 = [
  ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
  ["path", { d: "M15 8h6", key: "8ybuxh" }],
  ["path", { d: "M18 5v6", key: "g5ayrv" }],
  [
    "path",
    {
      d: "M20.002 14.464a9 9 0 0 0 .738.863A1 1 0 0 1 20 17H4a1 1 0 0 1-.74-1.673C4.59 13.956 6 12.499 6 8a6 6 0 0 1 8.75-5.332",
      key: "1abcvy"
    }
  ]
];
var BellPlus = createLucideIcon("bell-plus", __iconNode158);

// ../node_modules/lucide-react/dist/esm/icons/bell-ring.js
var __iconNode159 = [
  ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
  ["path", { d: "M22 8c0-2.3-.8-4.3-2-6", key: "5bb3ad" }],
  [
    "path",
    {
      d: "M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",
      key: "11g9vi"
    }
  ],
  ["path", { d: "M4 2C2.8 3.7 2 5.7 2 8", key: "tap9e0" }]
];
var BellRing = createLucideIcon("bell-ring", __iconNode159);

// ../node_modules/lucide-react/dist/esm/icons/bell.js
var __iconNode160 = [
  ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
  [
    "path",
    {
      d: "M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",
      key: "11g9vi"
    }
  ]
];
var Bell = createLucideIcon("bell", __iconNode160);

// ../node_modules/lucide-react/dist/esm/icons/between-horizontal-end.js
var __iconNode161 = [
  ["rect", { width: "13", height: "7", x: "3", y: "3", rx: "1", key: "11xb64" }],
  ["path", { d: "m22 15-3-3 3-3", key: "26chmm" }],
  ["rect", { width: "13", height: "7", x: "3", y: "14", rx: "1", key: "k6ky7n" }]
];
var BetweenHorizontalEnd = createLucideIcon("between-horizontal-end", __iconNode161);

// ../node_modules/lucide-react/dist/esm/icons/between-horizontal-start.js
var __iconNode162 = [
  ["rect", { width: "13", height: "7", x: "8", y: "3", rx: "1", key: "pkso9a" }],
  ["path", { d: "m2 9 3 3-3 3", key: "1agib5" }],
  ["rect", { width: "13", height: "7", x: "8", y: "14", rx: "1", key: "1q5fc1" }]
];
var BetweenHorizontalStart = createLucideIcon("between-horizontal-start", __iconNode162);

// ../node_modules/lucide-react/dist/esm/icons/between-vertical-end.js
var __iconNode163 = [
  ["rect", { width: "7", height: "13", x: "3", y: "3", rx: "1", key: "1fdu0f" }],
  ["path", { d: "m9 22 3-3 3 3", key: "17z65a" }],
  ["rect", { width: "7", height: "13", x: "14", y: "3", rx: "1", key: "1squn4" }]
];
var BetweenVerticalEnd = createLucideIcon("between-vertical-end", __iconNode163);

// ../node_modules/lucide-react/dist/esm/icons/between-vertical-start.js
var __iconNode164 = [
  ["rect", { width: "7", height: "13", x: "3", y: "8", rx: "1", key: "1fjrkv" }],
  ["path", { d: "m15 2-3 3-3-3", key: "1uh6eb" }],
  ["rect", { width: "7", height: "13", x: "14", y: "8", rx: "1", key: "w3fjg8" }]
];
var BetweenVerticalStart = createLucideIcon("between-vertical-start", __iconNode164);

// ../node_modules/lucide-react/dist/esm/icons/biceps-flexed.js
var __iconNode165 = [
  [
    "path",
    {
      d: "M12.409 13.017A5 5 0 0 1 22 15c0 3.866-4 7-9 7-4.077 0-8.153-.82-10.371-2.462-.426-.316-.631-.832-.62-1.362C2.118 12.723 2.627 2 10 2a3 3 0 0 1 3 3 2 2 0 0 1-2 2c-1.105 0-1.64-.444-2-1",
      key: "1pmlyh"
    }
  ],
  ["path", { d: "M15 14a5 5 0 0 0-7.584 2", key: "5rb254" }],
  ["path", { d: "M9.964 6.825C8.019 7.977 9.5 13 8 15", key: "kbvsx9" }]
];
var BicepsFlexed = createLucideIcon("biceps-flexed", __iconNode165);

// ../node_modules/lucide-react/dist/esm/icons/bike.js
var __iconNode166 = [
  ["circle", { cx: "18.5", cy: "17.5", r: "3.5", key: "15x4ox" }],
  ["circle", { cx: "5.5", cy: "17.5", r: "3.5", key: "1noe27" }],
  ["circle", { cx: "15", cy: "5", r: "1", key: "19l28e" }],
  ["path", { d: "M12 17.5V14l-3-3 4-3 2 3h2", key: "1npguv" }]
];
var Bike = createLucideIcon("bike", __iconNode166);

// ../node_modules/lucide-react/dist/esm/icons/binary.js
var __iconNode167 = [
  ["rect", { x: "14", y: "14", width: "4", height: "6", rx: "2", key: "p02svl" }],
  ["rect", { x: "6", y: "4", width: "4", height: "6", rx: "2", key: "xm4xkj" }],
  ["path", { d: "M6 20h4", key: "1i6q5t" }],
  ["path", { d: "M14 10h4", key: "ru81e7" }],
  ["path", { d: "M6 14h2v6", key: "16z9wg" }],
  ["path", { d: "M14 4h2v6", key: "1idq9u" }]
];
var Binary = createLucideIcon("binary", __iconNode167);

// ../node_modules/lucide-react/dist/esm/icons/binoculars.js
var __iconNode168 = [
  ["path", { d: "M10 10h4", key: "tcdvrf" }],
  ["path", { d: "M19 7V4a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v3", key: "3apit1" }],
  [
    "path",
    {
      d: "M20 21a2 2 0 0 0 2-2v-3.851c0-1.39-2-2.962-2-4.829V8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v11a2 2 0 0 0 2 2z",
      key: "rhpgnw"
    }
  ],
  ["path", { d: "M 22 16 L 2 16", key: "14lkq7" }],
  [
    "path",
    {
      d: "M4 21a2 2 0 0 1-2-2v-3.851c0-1.39 2-2.962 2-4.829V8a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v11a2 2 0 0 1-2 2z",
      key: "104b3k"
    }
  ],
  ["path", { d: "M9 7V4a1 1 0 0 0-1-1H6a1 1 0 0 0-1 1v3", key: "14fczp" }]
];
var Binoculars = createLucideIcon("binoculars", __iconNode168);

// ../node_modules/lucide-react/dist/esm/icons/biohazard.js
var __iconNode169 = [
  ["circle", { cx: "12", cy: "11.9", r: "2", key: "e8h31w" }],
  ["path", { d: "M6.7 3.4c-.9 2.5 0 5.2 2.2 6.7C6.5 9 3.7 9.6 2 11.6", key: "17bolr" }],
  ["path", { d: "m8.9 10.1 1.4.8", key: "15ezny" }],
  ["path", { d: "M17.3 3.4c.9 2.5 0 5.2-2.2 6.7 2.4-1.2 5.2-.6 6.9 1.5", key: "wtwa5u" }],
  ["path", { d: "m15.1 10.1-1.4.8", key: "1r0b28" }],
  ["path", { d: "M16.7 20.8c-2.6-.4-4.6-2.6-4.7-5.3-.2 2.6-2.1 4.8-4.7 5.2", key: "m7qszh" }],
  ["path", { d: "M12 13.9v1.6", key: "zfyyim" }],
  ["path", { d: "M13.5 5.4c-1-.2-2-.2-3 0", key: "1bi9q0" }],
  ["path", { d: "M17 16.4c.7-.7 1.2-1.6 1.5-2.5", key: "1rhjqw" }],
  ["path", { d: "M5.5 13.9c.3.9.8 1.8 1.5 2.5", key: "8gsud3" }]
];
var Biohazard = createLucideIcon("biohazard", __iconNode169);

// ../node_modules/lucide-react/dist/esm/icons/bird.js
var __iconNode170 = [
  ["path", { d: "M16 7h.01", key: "1kdx03" }],
  ["path", { d: "M3.4 18H12a8 8 0 0 0 8-8V7a4 4 0 0 0-7.28-2.3L2 20", key: "oj1oa8" }],
  ["path", { d: "m20 7 2 .5-2 .5", key: "12nv4d" }],
  ["path", { d: "M10 18v3", key: "1yea0a" }],
  ["path", { d: "M14 17.75V21", key: "1pymcb" }],
  ["path", { d: "M7 18a6 6 0 0 0 3.84-10.61", key: "1npnn0" }]
];
var Bird = createLucideIcon("bird", __iconNode170);

// ../node_modules/lucide-react/dist/esm/icons/birdhouse.js
var __iconNode171 = [
  ["path", { d: "M12 18v4", key: "jadmvz" }],
  ["path", { d: "m17 18 1.956-11.468", key: "l5n2ro" }],
  ["path", { d: "m3 8 7.82-5.615a2 2 0 0 1 2.36 0L21 8", key: "1sy6n7" }],
  ["path", { d: "M4 18h16", key: "19g7jn" }],
  ["path", { d: "M7 18 5.044 6.532", key: "1uqdf2" }],
  ["circle", { cx: "12", cy: "10", r: "2", key: "1yojzk" }]
];
var Birdhouse = createLucideIcon("birdhouse", __iconNode171);

// ../node_modules/lucide-react/dist/esm/icons/bitcoin.js
var __iconNode172 = [
  [
    "path",
    {
      d: "M11.767 19.089c4.924.868 6.14-6.025 1.216-6.894m-1.216 6.894L5.86 18.047m5.908 1.042-.347 1.97m1.563-8.864c4.924.869 6.14-6.025 1.215-6.893m-1.215 6.893-3.94-.694m5.155-6.2L8.29 4.26m5.908 1.042.348-1.97M7.48 20.364l3.126-17.727",
      key: "yr8idg"
    }
  ]
];
var Bitcoin = createLucideIcon("bitcoin", __iconNode172);

// ../node_modules/lucide-react/dist/esm/icons/blend.js
var __iconNode173 = [
  ["circle", { cx: "9", cy: "9", r: "7", key: "p2h5vp" }],
  ["circle", { cx: "15", cy: "15", r: "7", key: "19ennj" }]
];
var Blend = createLucideIcon("blend", __iconNode173);

// ../node_modules/lucide-react/dist/esm/icons/blinds.js
var __iconNode174 = [
  ["path", { d: "M3 3h18", key: "o7r712" }],
  ["path", { d: "M20 7H8", key: "gd2fo2" }],
  ["path", { d: "M20 11H8", key: "1ynp89" }],
  ["path", { d: "M10 19h10", key: "19hjk5" }],
  ["path", { d: "M8 15h12", key: "1yqzne" }],
  ["path", { d: "M4 3v14", key: "fggqzn" }],
  ["circle", { cx: "4", cy: "19", r: "2", key: "p3m9r0" }]
];
var Blinds = createLucideIcon("blinds", __iconNode174);

// ../node_modules/lucide-react/dist/esm/icons/blocks.js
var __iconNode175 = [
  [
    "path",
    {
      d: "M10 22V7a1 1 0 0 0-1-1H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-5a1 1 0 0 0-1-1H2",
      key: "1ah6g2"
    }
  ],
  ["rect", { x: "14", y: "2", width: "8", height: "8", rx: "1", key: "88lufb" }]
];
var Blocks = createLucideIcon("blocks", __iconNode175);

// ../node_modules/lucide-react/dist/esm/icons/bluetooth-connected.js
var __iconNode176 = [
  ["path", { d: "m7 7 10 10-5 5V2l5 5L7 17", key: "1q5490" }],
  ["line", { x1: "18", x2: "21", y1: "12", y2: "12", key: "1rsjjs" }],
  ["line", { x1: "3", x2: "6", y1: "12", y2: "12", key: "11yl8c" }]
];
var BluetoothConnected = createLucideIcon("bluetooth-connected", __iconNode176);

// ../node_modules/lucide-react/dist/esm/icons/bluetooth-off.js
var __iconNode177 = [
  ["path", { d: "m17 17-5 5V12l-5 5", key: "v5aci6" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M14.5 9.5 17 7l-5-5v4.5", key: "1kddfz" }]
];
var BluetoothOff = createLucideIcon("bluetooth-off", __iconNode177);

// ../node_modules/lucide-react/dist/esm/icons/bluetooth-searching.js
var __iconNode178 = [
  ["path", { d: "m7 7 10 10-5 5V2l5 5L7 17", key: "1q5490" }],
  ["path", { d: "M20.83 14.83a4 4 0 0 0 0-5.66", key: "k8tn1j" }],
  ["path", { d: "M18 12h.01", key: "yjnet6" }]
];
var BluetoothSearching = createLucideIcon("bluetooth-searching", __iconNode178);

// ../node_modules/lucide-react/dist/esm/icons/bluetooth.js
var __iconNode179 = [["path", { d: "m7 7 10 10-5 5V2l5 5L7 17", key: "1q5490" }]];
var Bluetooth = createLucideIcon("bluetooth", __iconNode179);

// ../node_modules/lucide-react/dist/esm/icons/bold.js
var __iconNode180 = [
  [
    "path",
    { d: "M6 12h9a4 4 0 0 1 0 8H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h7a4 4 0 0 1 0 8", key: "mg9rjx" }
  ]
];
var Bold = createLucideIcon("bold", __iconNode180);

// ../node_modules/lucide-react/dist/esm/icons/bolt.js
var __iconNode181 = [
  [
    "path",
    {
      d: "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z",
      key: "yt0hxn"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }]
];
var Bolt = createLucideIcon("bolt", __iconNode181);

// ../node_modules/lucide-react/dist/esm/icons/bomb.js
var __iconNode182 = [
  ["circle", { cx: "11", cy: "13", r: "9", key: "hd149" }],
  [
    "path",
    {
      d: "M14.35 4.65 16.3 2.7a2.41 2.41 0 0 1 3.4 0l1.6 1.6a2.4 2.4 0 0 1 0 3.4l-1.95 1.95",
      key: "jp4j1b"
    }
  ],
  ["path", { d: "m22 2-1.5 1.5", key: "ay92ug" }]
];
var Bomb = createLucideIcon("bomb", __iconNode182);

// ../node_modules/lucide-react/dist/esm/icons/bone.js
var __iconNode183 = [
  [
    "path",
    {
      d: "M17 10c.7-.7 1.69 0 2.5 0a2.5 2.5 0 1 0 0-5 .5.5 0 0 1-.5-.5 2.5 2.5 0 1 0-5 0c0 .81.7 1.8 0 2.5l-7 7c-.7.7-1.69 0-2.5 0a2.5 2.5 0 0 0 0 5c.28 0 .5.22.5.5a2.5 2.5 0 1 0 5 0c0-.81-.7-1.8 0-2.5Z",
      key: "w610uw"
    }
  ]
];
var Bone = createLucideIcon("bone", __iconNode183);

// ../node_modules/lucide-react/dist/esm/icons/book-a.js
var __iconNode184 = [
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  ["path", { d: "m8 13 4-7 4 7", key: "4rari8" }],
  ["path", { d: "M9.1 11h5.7", key: "1gkovt" }]
];
var BookA = createLucideIcon("book-a", __iconNode184);

// ../node_modules/lucide-react/dist/esm/icons/book-alert.js
var __iconNode185 = [
  ["path", { d: "M12 13h.01", key: "y0uutt" }],
  ["path", { d: "M12 6v3", key: "1m4b9j" }],
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ]
];
var BookAlert = createLucideIcon("book-alert", __iconNode185);

// ../node_modules/lucide-react/dist/esm/icons/book-audio.js
var __iconNode186 = [
  ["path", { d: "M12 6v7", key: "1f6ttz" }],
  ["path", { d: "M16 8v3", key: "gejaml" }],
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  ["path", { d: "M8 8v3", key: "1qzp49" }]
];
var BookAudio = createLucideIcon("book-audio", __iconNode186);

// ../node_modules/lucide-react/dist/esm/icons/book-check.js
var __iconNode187 = [
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  ["path", { d: "m9 9.5 2 2 4-4", key: "1dth82" }]
];
var BookCheck = createLucideIcon("book-check", __iconNode187);

// ../node_modules/lucide-react/dist/esm/icons/book-copy.js
var __iconNode188 = [
  ["path", { d: "M5 7a2 2 0 0 0-2 2v11", key: "1yhqjt" }],
  ["path", { d: "M5.803 18H5a2 2 0 0 0 0 4h9.5a.5.5 0 0 0 .5-.5V21", key: "edzzo5" }],
  [
    "path",
    {
      d: "M9 15V4a2 2 0 0 1 2-2h9.5a.5.5 0 0 1 .5.5v14a.5.5 0 0 1-.5.5H11a2 2 0 0 1 0-4h10",
      key: "1nwzrg"
    }
  ]
];
var BookCopy = createLucideIcon("book-copy", __iconNode188);

// ../node_modules/lucide-react/dist/esm/icons/book-dashed.js
var __iconNode189 = [
  ["path", { d: "M12 17h1.5", key: "1gkc67" }],
  ["path", { d: "M12 22h1.5", key: "1my7sn" }],
  ["path", { d: "M12 2h1.5", key: "19tvb7" }],
  ["path", { d: "M17.5 22H19a1 1 0 0 0 1-1", key: "10akbh" }],
  ["path", { d: "M17.5 2H19a1 1 0 0 1 1 1v1.5", key: "1vrfjs" }],
  ["path", { d: "M20 14v3h-2.5", key: "1naeju" }],
  ["path", { d: "M20 8.5V10", key: "1ctpfu" }],
  ["path", { d: "M4 10V8.5", key: "1o3zg5" }],
  ["path", { d: "M4 19.5V14", key: "ob81pf" }],
  ["path", { d: "M4 4.5A2.5 2.5 0 0 1 6.5 2H8", key: "s8vcyb" }],
  ["path", { d: "M8 22H6.5a1 1 0 0 1 0-5H8", key: "1cu73q" }]
];
var BookDashed = createLucideIcon("book-dashed", __iconNode189);

// ../node_modules/lucide-react/dist/esm/icons/book-down.js
var __iconNode190 = [
  ["path", { d: "M12 13V7", key: "h0r20n" }],
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  ["path", { d: "m9 10 3 3 3-3", key: "zt5b4y" }]
];
var BookDown = createLucideIcon("book-down", __iconNode190);

// ../node_modules/lucide-react/dist/esm/icons/book-headphones.js
var __iconNode191 = [
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  ["path", { d: "M8 12v-2a4 4 0 0 1 8 0v2", key: "1vsqkj" }],
  ["circle", { cx: "15", cy: "12", r: "1", key: "1tmaij" }],
  ["circle", { cx: "9", cy: "12", r: "1", key: "1vctgf" }]
];
var BookHeadphones = createLucideIcon("book-headphones", __iconNode191);

// ../node_modules/lucide-react/dist/esm/icons/book-heart.js
var __iconNode192 = [
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  [
    "path",
    {
      d: "M8.62 9.8A2.25 2.25 0 1 1 12 6.836a2.25 2.25 0 1 1 3.38 2.966l-2.626 2.856a.998.998 0 0 1-1.507 0z",
      key: "9v40y5"
    }
  ]
];
var BookHeart = createLucideIcon("book-heart", __iconNode192);

// ../node_modules/lucide-react/dist/esm/icons/book-image.js
var __iconNode193 = [
  ["path", { d: "m20 13.7-2.1-2.1a2 2 0 0 0-2.8 0L9.7 17", key: "q6ojf0" }],
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  ["circle", { cx: "10", cy: "8", r: "2", key: "2qkj4p" }]
];
var BookImage = createLucideIcon("book-image", __iconNode193);

// ../node_modules/lucide-react/dist/esm/icons/book-key.js
var __iconNode194 = [
  ["path", { d: "M13 2H6.5A2.5 2.5 0 0 0 4 4.5v15", key: "4azifu" }],
  ["path", { d: "M17 2v6", key: "qgmh37" }],
  ["path", { d: "M17 4h2", key: "13vrzo" }],
  ["path", { d: "M20 15.2V21a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20", key: "192hzx" }],
  ["circle", { cx: "17", cy: "10", r: "2", key: "y0i25j" }]
];
var BookKey = createLucideIcon("book-key", __iconNode194);

// ../node_modules/lucide-react/dist/esm/icons/book-lock.js
var __iconNode195 = [
  ["path", { d: "M18 6V4a2 2 0 1 0-4 0v2", key: "1aquzs" }],
  ["path", { d: "M20 15v6a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20", key: "1rkj32" }],
  ["path", { d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H10", key: "18wgow" }],
  ["rect", { x: "12", y: "6", width: "8", height: "5", rx: "1", key: "73l30o" }]
];
var BookLock = createLucideIcon("book-lock", __iconNode195);

// ../node_modules/lucide-react/dist/esm/icons/book-marked.js
var __iconNode196 = [
  ["path", { d: "M10 2v8l3-3 3 3V2", key: "sqw3rj" }],
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ]
];
var BookMarked = createLucideIcon("book-marked", __iconNode196);

// ../node_modules/lucide-react/dist/esm/icons/book-minus.js
var __iconNode197 = [
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  ["path", { d: "M9 10h6", key: "9gxzsh" }]
];
var BookMinus = createLucideIcon("book-minus", __iconNode197);

// ../node_modules/lucide-react/dist/esm/icons/book-open-check.js
var __iconNode198 = [
  ["path", { d: "M12 21V7", key: "gj6g52" }],
  ["path", { d: "m16 12 2 2 4-4", key: "mdajum" }],
  [
    "path",
    {
      d: "M22 6V4a1 1 0 0 0-1-1h-5a4 4 0 0 0-4 4 4 4 0 0 0-4-4H3a1 1 0 0 0-1 1v13a1 1 0 0 0 1 1h6a3 3 0 0 1 3 3 3 3 0 0 1 3-3h6a1 1 0 0 0 1-1v-1.3",
      key: "8arnkb"
    }
  ]
];
var BookOpenCheck = createLucideIcon("book-open-check", __iconNode198);

// ../node_modules/lucide-react/dist/esm/icons/book-open-text.js
var __iconNode199 = [
  ["path", { d: "M12 7v14", key: "1akyts" }],
  ["path", { d: "M16 12h2", key: "7q9ll5" }],
  ["path", { d: "M16 8h2", key: "msurwy" }],
  [
    "path",
    {
      d: "M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",
      key: "ruj8y"
    }
  ],
  ["path", { d: "M6 12h2", key: "32wvfc" }],
  ["path", { d: "M6 8h2", key: "30oboj" }]
];
var BookOpenText = createLucideIcon("book-open-text", __iconNode199);

// ../node_modules/lucide-react/dist/esm/icons/book-open.js
var __iconNode200 = [
  ["path", { d: "M12 7v14", key: "1akyts" }],
  [
    "path",
    {
      d: "M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",
      key: "ruj8y"
    }
  ]
];
var BookOpen = createLucideIcon("book-open", __iconNode200);

// ../node_modules/lucide-react/dist/esm/icons/book-plus.js
var __iconNode201 = [
  ["path", { d: "M12 7v6", key: "lw1j43" }],
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  ["path", { d: "M9 10h6", key: "9gxzsh" }]
];
var BookPlus = createLucideIcon("book-plus", __iconNode201);

// ../node_modules/lucide-react/dist/esm/icons/book-search.js
var __iconNode202 = [
  ["path", { d: "M11 22H5.5a1 1 0 0 1 0-5h4.501", key: "mcbepb" }],
  ["path", { d: "m21 22-1.879-1.878", key: "12q7x1" }],
  ["path", { d: "M3 19.5v-15A2.5 2.5 0 0 1 5.5 2H18a1 1 0 0 1 1 1v8", key: "olfd5n" }],
  ["circle", { cx: "17", cy: "18", r: "3", key: "82mm0e" }]
];
var BookSearch = createLucideIcon("book-search", __iconNode202);

// ../node_modules/lucide-react/dist/esm/icons/book-text.js
var __iconNode203 = [
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  ["path", { d: "M8 11h8", key: "vwpz6n" }],
  ["path", { d: "M8 7h6", key: "1f0q6e" }]
];
var BookText = createLucideIcon("book-text", __iconNode203);

// ../node_modules/lucide-react/dist/esm/icons/book-type.js
var __iconNode204 = [
  ["path", { d: "M10 13h4", key: "ytezjc" }],
  ["path", { d: "M12 6v7", key: "1f6ttz" }],
  ["path", { d: "M16 8V6H8v2", key: "x8j6u4" }],
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ]
];
var BookType = createLucideIcon("book-type", __iconNode204);

// ../node_modules/lucide-react/dist/esm/icons/book-up-2.js
var __iconNode205 = [
  ["path", { d: "M12 13V7", key: "h0r20n" }],
  ["path", { d: "M18 2h1a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20", key: "161d7n" }],
  ["path", { d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2", key: "1lorq7" }],
  ["path", { d: "m9 10 3-3 3 3", key: "11gsxs" }],
  ["path", { d: "m9 5 3-3 3 3", key: "l8vdw6" }]
];
var BookUp2 = createLucideIcon("book-up-2", __iconNode205);

// ../node_modules/lucide-react/dist/esm/icons/book-up.js
var __iconNode206 = [
  ["path", { d: "M12 13V7", key: "h0r20n" }],
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  ["path", { d: "m9 10 3-3 3 3", key: "11gsxs" }]
];
var BookUp = createLucideIcon("book-up", __iconNode206);

// ../node_modules/lucide-react/dist/esm/icons/book-user.js
var __iconNode207 = [
  ["path", { d: "M15 13a3 3 0 1 0-6 0", key: "10j68g" }],
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  ["circle", { cx: "12", cy: "8", r: "2", key: "1822b1" }]
];
var BookUser = createLucideIcon("book-user", __iconNode207);

// ../node_modules/lucide-react/dist/esm/icons/book-x.js
var __iconNode208 = [
  ["path", { d: "m14.5 7-5 5", key: "dy991v" }],
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ],
  ["path", { d: "m9.5 7 5 5", key: "s45iea" }]
];
var BookX = createLucideIcon("book-x", __iconNode208);

// ../node_modules/lucide-react/dist/esm/icons/book.js
var __iconNode209 = [
  [
    "path",
    {
      d: "M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H19a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1H6.5a1 1 0 0 1 0-5H20",
      key: "k3hazp"
    }
  ]
];
var Book = createLucideIcon("book", __iconNode209);

// ../node_modules/lucide-react/dist/esm/icons/bookmark-check.js
var __iconNode210 = [
  [
    "path",
    {
      d: "M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z",
      key: "oz39mx"
    }
  ],
  ["path", { d: "m9 10 2 2 4-4", key: "1gnqz4" }]
];
var BookmarkCheck = createLucideIcon("bookmark-check", __iconNode210);

// ../node_modules/lucide-react/dist/esm/icons/bookmark-minus.js
var __iconNode211 = [
  ["path", { d: "M15 10H9", key: "o6yqo3" }],
  [
    "path",
    {
      d: "M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z",
      key: "oz39mx"
    }
  ]
];
var BookmarkMinus = createLucideIcon("bookmark-minus", __iconNode211);

// ../node_modules/lucide-react/dist/esm/icons/bookmark-plus.js
var __iconNode212 = [
  ["path", { d: "M12 7v6", key: "lw1j43" }],
  ["path", { d: "M15 10H9", key: "o6yqo3" }],
  [
    "path",
    {
      d: "M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z",
      key: "oz39mx"
    }
  ]
];
var BookmarkPlus = createLucideIcon("bookmark-plus", __iconNode212);

// ../node_modules/lucide-react/dist/esm/icons/bookmark-x.js
var __iconNode213 = [
  ["path", { d: "m14.5 7.5-5 5", key: "3lb6iw" }],
  [
    "path",
    {
      d: "M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z",
      key: "oz39mx"
    }
  ],
  ["path", { d: "m9.5 7.5 5 5", key: "ko136h" }]
];
var BookmarkX = createLucideIcon("bookmark-x", __iconNode213);

// ../node_modules/lucide-react/dist/esm/icons/bookmark.js
var __iconNode214 = [
  [
    "path",
    {
      d: "M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z",
      key: "oz39mx"
    }
  ]
];
var Bookmark = createLucideIcon("bookmark", __iconNode214);

// ../node_modules/lucide-react/dist/esm/icons/boom-box.js
var __iconNode215 = [
  ["path", { d: "M4 9V5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4", key: "vvzvr1" }],
  ["path", { d: "M8 8v1", key: "xcqmfk" }],
  ["path", { d: "M12 8v1", key: "1rj8u4" }],
  ["path", { d: "M16 8v1", key: "1q12zr" }],
  ["rect", { width: "20", height: "12", x: "2", y: "9", rx: "2", key: "igpb89" }],
  ["circle", { cx: "8", cy: "15", r: "2", key: "fa4a8s" }],
  ["circle", { cx: "16", cy: "15", r: "2", key: "14c3ya" }]
];
var BoomBox = createLucideIcon("boom-box", __iconNode215);

// ../node_modules/lucide-react/dist/esm/icons/bot-message-square.js
var __iconNode216 = [
  ["path", { d: "M12 6V2H8", key: "1155em" }],
  ["path", { d: "M15 11v2", key: "i11awn" }],
  ["path", { d: "M2 12h2", key: "1t8f8n" }],
  ["path", { d: "M20 12h2", key: "1q8mjw" }],
  [
    "path",
    {
      d: "M20 16a2 2 0 0 1-2 2H8.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 4 20.286V8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2z",
      key: "11gyqh"
    }
  ],
  ["path", { d: "M9 11v2", key: "1ueba0" }]
];
var BotMessageSquare = createLucideIcon("bot-message-square", __iconNode216);

// ../node_modules/lucide-react/dist/esm/icons/bot-off.js
var __iconNode217 = [
  ["path", { d: "M13.67 8H18a2 2 0 0 1 2 2v4.33", key: "7az073" }],
  ["path", { d: "M2 14h2", key: "vft8re" }],
  ["path", { d: "M20 14h2", key: "4cs60a" }],
  ["path", { d: "M22 22 2 2", key: "1r8tn9" }],
  ["path", { d: "M8 8H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h12a2 2 0 0 0 1.414-.586", key: "s09a7a" }],
  ["path", { d: "M9 13v2", key: "rq6x2g" }],
  ["path", { d: "M9.67 4H12v2.33", key: "110xot" }]
];
var BotOff = createLucideIcon("bot-off", __iconNode217);

// ../node_modules/lucide-react/dist/esm/icons/bot.js
var __iconNode218 = [
  ["path", { d: "M12 8V4H8", key: "hb8ula" }],
  ["rect", { width: "16", height: "12", x: "4", y: "8", rx: "2", key: "enze0r" }],
  ["path", { d: "M2 14h2", key: "vft8re" }],
  ["path", { d: "M20 14h2", key: "4cs60a" }],
  ["path", { d: "M15 13v2", key: "1xurst" }],
  ["path", { d: "M9 13v2", key: "rq6x2g" }]
];
var Bot = createLucideIcon("bot", __iconNode218);

// ../node_modules/lucide-react/dist/esm/icons/bottle-wine.js
var __iconNode219 = [
  [
    "path",
    {
      d: "M10 3a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v2a6 6 0 0 0 1.2 3.6l.6.8A6 6 0 0 1 17 13v8a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1v-8a6 6 0 0 1 1.2-3.6l.6-.8A6 6 0 0 0 10 5z",
      key: "blqgoc"
    }
  ],
  ["path", { d: "M17 13h-4a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h4", key: "43jbee" }]
];
var BottleWine = createLucideIcon("bottle-wine", __iconNode219);

// ../node_modules/lucide-react/dist/esm/icons/bow-arrow.js
var __iconNode220 = [
  ["path", { d: "M17 3h4v4", key: "19p9u1" }],
  [
    "path",
    { d: "M18.575 11.082a13 13 0 0 1 1.048 9.027 1.17 1.17 0 0 1-1.914.597L14 17", key: "12t3w9" }
  ],
  ["path", { d: "M7 10 3.29 6.29a1.17 1.17 0 0 1 .6-1.91 13 13 0 0 1 9.03 1.05", key: "ogng5l" }],
  [
    "path",
    {
      d: "M7 14a1.7 1.7 0 0 0-1.207.5l-2.646 2.646A.5.5 0 0 0 3.5 18H5a1 1 0 0 1 1 1v1.5a.5.5 0 0 0 .854.354L9.5 18.207A1.7 1.7 0 0 0 10 17v-2a1 1 0 0 0-1-1z",
      key: "8v3fy2"
    }
  ],
  ["path", { d: "M9.707 14.293 21 3", key: "ydm3bn" }]
];
var BowArrow = createLucideIcon("bow-arrow", __iconNode220);

// ../node_modules/lucide-react/dist/esm/icons/box.js
var __iconNode221 = [
  [
    "path",
    {
      d: "M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z",
      key: "hh9hay"
    }
  ],
  ["path", { d: "m3.3 7 8.7 5 8.7-5", key: "g66t2b" }],
  ["path", { d: "M12 22V12", key: "d0xqtd" }]
];
var Box = createLucideIcon("box", __iconNode221);

// ../node_modules/lucide-react/dist/esm/icons/boxes.js
var __iconNode222 = [
  [
    "path",
    {
      d: "M2.97 12.92A2 2 0 0 0 2 14.63v3.24a2 2 0 0 0 .97 1.71l3 1.8a2 2 0 0 0 2.06 0L12 19v-5.5l-5-3-4.03 2.42Z",
      key: "lc1i9w"
    }
  ],
  ["path", { d: "m7 16.5-4.74-2.85", key: "1o9zyk" }],
  ["path", { d: "m7 16.5 5-3", key: "va8pkn" }],
  ["path", { d: "M7 16.5v5.17", key: "jnp8gn" }],
  [
    "path",
    {
      d: "M12 13.5V19l3.97 2.38a2 2 0 0 0 2.06 0l3-1.8a2 2 0 0 0 .97-1.71v-3.24a2 2 0 0 0-.97-1.71L17 10.5l-5 3Z",
      key: "8zsnat"
    }
  ],
  ["path", { d: "m17 16.5-5-3", key: "8arw3v" }],
  ["path", { d: "m17 16.5 4.74-2.85", key: "8rfmw" }],
  ["path", { d: "M17 16.5v5.17", key: "k6z78m" }],
  [
    "path",
    {
      d: "M7.97 4.42A2 2 0 0 0 7 6.13v4.37l5 3 5-3V6.13a2 2 0 0 0-.97-1.71l-3-1.8a2 2 0 0 0-2.06 0l-3 1.8Z",
      key: "1xygjf"
    }
  ],
  ["path", { d: "M12 8 7.26 5.15", key: "1vbdud" }],
  ["path", { d: "m12 8 4.74-2.85", key: "3rx089" }],
  ["path", { d: "M12 13.5V8", key: "1io7kd" }]
];
var Boxes = createLucideIcon("boxes", __iconNode222);

// ../node_modules/lucide-react/dist/esm/icons/braces.js
var __iconNode223 = [
  [
    "path",
    { d: "M8 3H7a2 2 0 0 0-2 2v5a2 2 0 0 1-2 2 2 2 0 0 1 2 2v5c0 1.1.9 2 2 2h1", key: "ezmyqa" }
  ],
  [
    "path",
    {
      d: "M16 21h1a2 2 0 0 0 2-2v-5c0-1.1.9-2 2-2a2 2 0 0 1-2-2V5a2 2 0 0 0-2-2h-1",
      key: "e1hn23"
    }
  ]
];
var Braces = createLucideIcon("braces", __iconNode223);

// ../node_modules/lucide-react/dist/esm/icons/brackets.js
var __iconNode224 = [
  ["path", { d: "M16 3h3a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1h-3", key: "1kt8lf" }],
  ["path", { d: "M8 21H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h3", key: "gduv9" }]
];
var Brackets = createLucideIcon("brackets", __iconNode224);

// ../node_modules/lucide-react/dist/esm/icons/brain-circuit.js
var __iconNode225 = [
  [
    "path",
    {
      d: "M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z",
      key: "l5xja"
    }
  ],
  ["path", { d: "M9 13a4.5 4.5 0 0 0 3-4", key: "10igwf" }],
  ["path", { d: "M6.003 5.125A3 3 0 0 0 6.401 6.5", key: "105sqy" }],
  ["path", { d: "M3.477 10.896a4 4 0 0 1 .585-.396", key: "ql3yin" }],
  ["path", { d: "M6 18a4 4 0 0 1-1.967-.516", key: "2e4loj" }],
  ["path", { d: "M12 13h4", key: "1ku699" }],
  ["path", { d: "M12 18h6a2 2 0 0 1 2 2v1", key: "105ag5" }],
  ["path", { d: "M12 8h8", key: "1lhi5i" }],
  ["path", { d: "M16 8V5a2 2 0 0 1 2-2", key: "u6izg6" }],
  ["circle", { cx: "16", cy: "13", r: ".5", key: "ry7gng" }],
  ["circle", { cx: "18", cy: "3", r: ".5", key: "1aiba7" }],
  ["circle", { cx: "20", cy: "21", r: ".5", key: "yhc1fs" }],
  ["circle", { cx: "20", cy: "8", r: ".5", key: "1e43v0" }]
];
var BrainCircuit = createLucideIcon("brain-circuit", __iconNode225);

// ../node_modules/lucide-react/dist/esm/icons/brain-cog.js
var __iconNode226 = [
  ["path", { d: "m10.852 14.772-.383.923", key: "11vil6" }],
  ["path", { d: "m10.852 9.228-.383-.923", key: "1fjppe" }],
  ["path", { d: "m13.148 14.772.382.924", key: "je3va1" }],
  ["path", { d: "m13.531 8.305-.383.923", key: "18epck" }],
  ["path", { d: "m14.772 10.852.923-.383", key: "k9m8cz" }],
  ["path", { d: "m14.772 13.148.923.383", key: "1xvhww" }],
  [
    "path",
    {
      d: "M17.598 6.5A3 3 0 1 0 12 5a3 3 0 0 0-5.63-1.446 3 3 0 0 0-.368 1.571 4 4 0 0 0-2.525 5.771",
      key: "jcbbz1"
    }
  ],
  ["path", { d: "M17.998 5.125a4 4 0 0 1 2.525 5.771", key: "1kkn7e" }],
  ["path", { d: "M19.505 10.294a4 4 0 0 1-1.5 7.706", key: "18bmuc" }],
  [
    "path",
    {
      d: "M4.032 17.483A4 4 0 0 0 11.464 20c.18-.311.892-.311 1.072 0a4 4 0 0 0 7.432-2.516",
      key: "uozx0d"
    }
  ],
  ["path", { d: "M4.5 10.291A4 4 0 0 0 6 18", key: "whdemb" }],
  ["path", { d: "M6.002 5.125a3 3 0 0 0 .4 1.375", key: "1kqy2g" }],
  ["path", { d: "m9.228 10.852-.923-.383", key: "1wtb30" }],
  ["path", { d: "m9.228 13.148-.923.383", key: "1a830x" }],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
];
var BrainCog = createLucideIcon("brain-cog", __iconNode226);

// ../node_modules/lucide-react/dist/esm/icons/brain.js
var __iconNode227 = [
  ["path", { d: "M12 18V5", key: "adv99a" }],
  ["path", { d: "M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4", key: "1e3is1" }],
  ["path", { d: "M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5", key: "1gqd8o" }],
  ["path", { d: "M17.997 5.125a4 4 0 0 1 2.526 5.77", key: "iwvgf7" }],
  ["path", { d: "M18 18a4 4 0 0 0 2-7.464", key: "efp6ie" }],
  ["path", { d: "M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517", key: "1gq6am" }],
  ["path", { d: "M6 18a4 4 0 0 1-2-7.464", key: "k1g0md" }],
  ["path", { d: "M6.003 5.125a4 4 0 0 0-2.526 5.77", key: "q97ue3" }]
];
var Brain = createLucideIcon("brain", __iconNode227);

// ../node_modules/lucide-react/dist/esm/icons/brick-wall-fire.js
var __iconNode228 = [
  ["path", { d: "M16 3v2.107", key: "gq8xun" }],
  [
    "path",
    {
      d: "M17 9c1 3 2.5 3.5 3.5 4.5A5 5 0 0 1 22 17a5 5 0 0 1-10 0c0-.3 0-.6.1-.9a2 2 0 1 0 3.3-2C13 11.5 16 9 17 9",
      key: "1l2pih"
    }
  ],
  [
    "path",
    { d: "M21 8.274V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3.938", key: "jrnqjp" }
  ],
  ["path", { d: "M3 15h5.253", key: "xqg7rb" }],
  ["path", { d: "M3 9h8.228", key: "1ppb70" }],
  ["path", { d: "M8 15v6", key: "1stoo3" }],
  ["path", { d: "M8 3v6", key: "vlvjmk" }]
];
var BrickWallFire = createLucideIcon("brick-wall-fire", __iconNode228);

// ../node_modules/lucide-react/dist/esm/icons/brick-wall-shield.js
var __iconNode229 = [
  ["path", { d: "M12 9v1.258", key: "iwpddn" }],
  ["path", { d: "M16 3v5.46", key: "d7ew98" }],
  ["path", { d: "M21 9.118V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h5.75", key: "137t5x" }],
  [
    "path",
    {
      d: "M22 17.5c0 2.499-1.75 3.749-3.83 4.474a.5.5 0 0 1-.335-.005c-2.085-.72-3.835-1.97-3.835-4.47V14a.5.5 0 0 1 .5-.499c1 0 2.25-.6 3.12-1.36a.6.6 0 0 1 .76-.001c.875.765 2.12 1.36 3.12 1.36a.5.5 0 0 1 .5.5z",
      key: "16j3tf"
    }
  ],
  ["path", { d: "M3 15h7", key: "1qldh6" }],
  ["path", { d: "M3 9h12.142", key: "1yjd6m" }],
  ["path", { d: "M8 15v6", key: "1stoo3" }],
  ["path", { d: "M8 3v6", key: "vlvjmk" }]
];
var BrickWallShield = createLucideIcon("brick-wall-shield", __iconNode229);

// ../node_modules/lucide-react/dist/esm/icons/brick-wall.js
var __iconNode230 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M12 9v6", key: "199k2o" }],
  ["path", { d: "M16 15v6", key: "8rj2es" }],
  ["path", { d: "M16 3v6", key: "1j6rpj" }],
  ["path", { d: "M3 15h18", key: "5xshup" }],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["path", { d: "M8 15v6", key: "1stoo3" }],
  ["path", { d: "M8 3v6", key: "vlvjmk" }]
];
var BrickWall = createLucideIcon("brick-wall", __iconNode230);

// ../node_modules/lucide-react/dist/esm/icons/briefcase-business.js
var __iconNode231 = [
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M16 6V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2", key: "1ksdt3" }],
  ["path", { d: "M22 13a18.15 18.15 0 0 1-20 0", key: "12hx5q" }],
  ["rect", { width: "20", height: "14", x: "2", y: "6", rx: "2", key: "i6l2r4" }]
];
var BriefcaseBusiness = createLucideIcon("briefcase-business", __iconNode231);

// ../node_modules/lucide-react/dist/esm/icons/briefcase-medical.js
var __iconNode232 = [
  ["path", { d: "M12 11v4", key: "a6ujw6" }],
  ["path", { d: "M14 13h-4", key: "1pl8zg" }],
  ["path", { d: "M16 6V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2", key: "1ksdt3" }],
  ["path", { d: "M18 6v14", key: "1mu4gy" }],
  ["path", { d: "M6 6v14", key: "1s15cj" }],
  ["rect", { width: "20", height: "14", x: "2", y: "6", rx: "2", key: "i6l2r4" }]
];
var BriefcaseMedical = createLucideIcon("briefcase-medical", __iconNode232);

// ../node_modules/lucide-react/dist/esm/icons/briefcase-conveyor-belt.js
var __iconNode233 = [
  ["path", { d: "M10 20v2", key: "1n8e1g" }],
  ["path", { d: "M14 20v2", key: "1lq872" }],
  ["path", { d: "M18 20v2", key: "10uadw" }],
  ["path", { d: "M21 20H3", key: "kdqkdp" }],
  ["path", { d: "M6 20v2", key: "a9bc87" }],
  ["path", { d: "M8 16V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v12", key: "17n9tx" }],
  ["rect", { x: "4", y: "6", width: "16", height: "10", rx: "2", key: "1097i5" }]
];
var BriefcaseConveyorBelt = createLucideIcon("briefcase-conveyor-belt", __iconNode233);

// ../node_modules/lucide-react/dist/esm/icons/bring-to-front.js
var __iconNode234 = [
  ["rect", { x: "8", y: "8", width: "8", height: "8", rx: "2", key: "yj20xf" }],
  ["path", { d: "M4 10a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2", key: "1ltk23" }],
  ["path", { d: "M14 20a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2", key: "1q24h9" }]
];
var BringToFront = createLucideIcon("bring-to-front", __iconNode234);

// ../node_modules/lucide-react/dist/esm/icons/briefcase.js
var __iconNode235 = [
  ["path", { d: "M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16", key: "jecpp" }],
  ["rect", { width: "20", height: "14", x: "2", y: "6", rx: "2", key: "i6l2r4" }]
];
var Briefcase = createLucideIcon("briefcase", __iconNode235);

// ../node_modules/lucide-react/dist/esm/icons/brush-cleaning.js
var __iconNode236 = [
  ["path", { d: "m16 22-1-4", key: "1ow2iv" }],
  [
    "path",
    {
      d: "M19 14a1 1 0 0 0 1-1v-1a2 2 0 0 0-2-2h-3a1 1 0 0 1-1-1V4a2 2 0 0 0-4 0v5a1 1 0 0 1-1 1H6a2 2 0 0 0-2 2v1a1 1 0 0 0 1 1",
      key: "11gii7"
    }
  ],
  ["path", { d: "M19 14H5l-1.973 6.767A1 1 0 0 0 4 22h16a1 1 0 0 0 .973-1.233z", key: "bju7h4" }],
  ["path", { d: "m8 22 1-4", key: "s3unb" }]
];
var BrushCleaning = createLucideIcon("brush-cleaning", __iconNode236);

// ../node_modules/lucide-react/dist/esm/icons/brush.js
var __iconNode237 = [
  ["path", { d: "m11 10 3 3", key: "fzmg1i" }],
  [
    "path",
    { d: "M6.5 21A3.5 3.5 0 1 0 3 17.5a2.62 2.62 0 0 1-.708 1.792A1 1 0 0 0 3 21z", key: "p4q2r7" }
  ],
  ["path", { d: "M9.969 17.031 21.378 5.624a1 1 0 0 0-3.002-3.002L6.967 14.031", key: "wy6l02" }]
];
var Brush = createLucideIcon("brush", __iconNode237);

// ../node_modules/lucide-react/dist/esm/icons/bubbles.js
var __iconNode238 = [
  ["path", { d: "M7.001 15.085A1.5 1.5 0 0 1 9 16.5", key: "y44lvh" }],
  ["circle", { cx: "18.5", cy: "8.5", r: "3.5", key: "1wadoa" }],
  ["circle", { cx: "7.5", cy: "16.5", r: "5.5", key: "6mdt3g" }],
  ["circle", { cx: "7.5", cy: "4.5", r: "2.5", key: "637s54" }]
];
var Bubbles = createLucideIcon("bubbles", __iconNode238);

// ../node_modules/lucide-react/dist/esm/icons/bug-off.js
var __iconNode239 = [
  ["path", { d: "M12 20v-8", key: "i3yub9" }],
  ["path", { d: "M12.656 7H14a4 4 0 0 1 4 4v1.344", key: "vvueyn" }],
  ["path", { d: "M14.12 3.88 16 2", key: "qol33r" }],
  ["path", { d: "M17.123 17.123A6 6 0 0 1 6 14v-3a4 4 0 0 1 1.72-3.287", key: "1cu21y" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M21 5a4 4 0 0 1-3.55 3.97", key: "5cxbf6" }],
  ["path", { d: "M22 13h-3.344", key: "qb08am" }],
  ["path", { d: "M3 21a4 4 0 0 1 3.81-4", key: "1fjd4g" }],
  ["path", { d: "M3 5a4 4 0 0 0 3.55 3.97", key: "1d7oge" }],
  ["path", { d: "M6 13H2", key: "82j7cp" }],
  ["path", { d: "m8 2 1.88 1.88", key: "fmnt4t" }],
  ["path", { d: "M9.712 4.06A3 3 0 0 1 15 6v1.13", key: "1bvup6" }]
];
var BugOff = createLucideIcon("bug-off", __iconNode239);

// ../node_modules/lucide-react/dist/esm/icons/bug-play.js
var __iconNode240 = [
  ["path", { d: "M10 19.655A6 6 0 0 1 6 14v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 3.97", key: "1gnv52" }],
  [
    "path",
    {
      d: "M14 15.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997a1 1 0 0 1-1.517-.86z",
      key: "1weqy9"
    }
  ],
  ["path", { d: "M14.12 3.88 16 2", key: "qol33r" }],
  ["path", { d: "M21 5a4 4 0 0 1-3.55 3.97", key: "5cxbf6" }],
  ["path", { d: "M3 21a4 4 0 0 1 3.81-4", key: "1fjd4g" }],
  ["path", { d: "M3 5a4 4 0 0 0 3.55 3.97", key: "1d7oge" }],
  ["path", { d: "M6 13H2", key: "82j7cp" }],
  ["path", { d: "m8 2 1.88 1.88", key: "fmnt4t" }],
  ["path", { d: "M9 7.13V6a3 3 0 1 1 6 0v1.13", key: "1vgav8" }]
];
var BugPlay = createLucideIcon("bug-play", __iconNode240);

// ../node_modules/lucide-react/dist/esm/icons/bug.js
var __iconNode241 = [
  ["path", { d: "M12 20v-9", key: "1qisl0" }],
  ["path", { d: "M14 7a4 4 0 0 1 4 4v3a6 6 0 0 1-12 0v-3a4 4 0 0 1 4-4z", key: "uouzyp" }],
  ["path", { d: "M14.12 3.88 16 2", key: "qol33r" }],
  ["path", { d: "M21 21a4 4 0 0 0-3.81-4", key: "1b0z45" }],
  ["path", { d: "M21 5a4 4 0 0 1-3.55 3.97", key: "5cxbf6" }],
  ["path", { d: "M22 13h-4", key: "1jl80f" }],
  ["path", { d: "M3 21a4 4 0 0 1 3.81-4", key: "1fjd4g" }],
  ["path", { d: "M3 5a4 4 0 0 0 3.55 3.97", key: "1d7oge" }],
  ["path", { d: "M6 13H2", key: "82j7cp" }],
  ["path", { d: "m8 2 1.88 1.88", key: "fmnt4t" }],
  ["path", { d: "M9 7.13V6a3 3 0 1 1 6 0v1.13", key: "1vgav8" }]
];
var Bug = createLucideIcon("bug", __iconNode241);

// ../node_modules/lucide-react/dist/esm/icons/building-2.js
var __iconNode242 = [
  ["path", { d: "M10 12h4", key: "a56b0p" }],
  ["path", { d: "M10 8h4", key: "1sr2af" }],
  ["path", { d: "M14 21v-3a2 2 0 0 0-4 0v3", key: "1rgiei" }],
  [
    "path",
    {
      d: "M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2",
      key: "secmi2"
    }
  ],
  ["path", { d: "M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16", key: "16ra0t" }]
];
var Building2 = createLucideIcon("building-2", __iconNode242);

// ../node_modules/lucide-react/dist/esm/icons/building.js
var __iconNode243 = [
  ["path", { d: "M12 10h.01", key: "1nrarc" }],
  ["path", { d: "M12 14h.01", key: "1etili" }],
  ["path", { d: "M12 6h.01", key: "1vi96p" }],
  ["path", { d: "M16 10h.01", key: "1m94wz" }],
  ["path", { d: "M16 14h.01", key: "1gbofw" }],
  ["path", { d: "M16 6h.01", key: "1x0f13" }],
  ["path", { d: "M8 10h.01", key: "19clt8" }],
  ["path", { d: "M8 14h.01", key: "6423bh" }],
  ["path", { d: "M8 6h.01", key: "1dz90k" }],
  ["path", { d: "M9 22v-3a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v3", key: "cabbwy" }],
  ["rect", { x: "4", y: "2", width: "16", height: "20", rx: "2", key: "1uxh74" }]
];
var Building = createLucideIcon("building", __iconNode243);

// ../node_modules/lucide-react/dist/esm/icons/bus-front.js
var __iconNode244 = [
  ["path", { d: "M4 6 2 7", key: "1mqr15" }],
  ["path", { d: "M10 6h4", key: "1itunk" }],
  ["path", { d: "m22 7-2-1", key: "1umjhc" }],
  ["rect", { width: "16", height: "16", x: "4", y: "3", rx: "2", key: "1wxw4b" }],
  ["path", { d: "M4 11h16", key: "mpoxn0" }],
  ["path", { d: "M8 15h.01", key: "a7atzg" }],
  ["path", { d: "M16 15h.01", key: "rnfrdf" }],
  ["path", { d: "M6 19v2", key: "1loha6" }],
  ["path", { d: "M18 21v-2", key: "sqyl04" }]
];
var BusFront = createLucideIcon("bus-front", __iconNode244);

// ../node_modules/lucide-react/dist/esm/icons/bus.js
var __iconNode245 = [
  ["path", { d: "M8 6v6", key: "18i7km" }],
  ["path", { d: "M15 6v6", key: "1sg6z9" }],
  ["path", { d: "M2 12h19.6", key: "de5uta" }],
  [
    "path",
    {
      d: "M18 18h3s.5-1.7.8-2.8c.1-.4.2-.8.2-1.2 0-.4-.1-.8-.2-1.2l-1.4-5C20.1 6.8 19.1 6 18 6H4a2 2 0 0 0-2 2v10h3",
      key: "1wwztk"
    }
  ],
  ["circle", { cx: "7", cy: "18", r: "2", key: "19iecd" }],
  ["path", { d: "M9 18h5", key: "lrx6i" }],
  ["circle", { cx: "16", cy: "18", r: "2", key: "1v4tcr" }]
];
var Bus = createLucideIcon("bus", __iconNode245);

// ../node_modules/lucide-react/dist/esm/icons/cable.js
var __iconNode246 = [
  [
    "path",
    { d: "M17 19a1 1 0 0 1-1-1v-2a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2a1 1 0 0 1-1 1z", key: "trhst0" }
  ],
  ["path", { d: "M17 21v-2", key: "ds4u3f" }],
  ["path", { d: "M19 14V6.5a1 1 0 0 0-7 0v11a1 1 0 0 1-7 0V10", key: "1mo9zo" }],
  ["path", { d: "M21 21v-2", key: "eo0ou" }],
  ["path", { d: "M3 5V3", key: "1k5hjh" }],
  [
    "path",
    { d: "M4 10a2 2 0 0 1-2-2V6a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2a2 2 0 0 1-2 2z", key: "1dd30t" }
  ],
  ["path", { d: "M7 5V3", key: "1t1388" }]
];
var Cable = createLucideIcon("cable", __iconNode246);

// ../node_modules/lucide-react/dist/esm/icons/cable-car.js
var __iconNode247 = [
  ["path", { d: "M10 3h.01", key: "lbucoy" }],
  ["path", { d: "M14 2h.01", key: "1k8aa1" }],
  ["path", { d: "m2 9 20-5", key: "1kz0j5" }],
  ["path", { d: "M12 12V6.5", key: "1vbrij" }],
  ["rect", { width: "16", height: "10", x: "4", y: "12", rx: "3", key: "if91er" }],
  ["path", { d: "M9 12v5", key: "3anwtq" }],
  ["path", { d: "M15 12v5", key: "5xh3zn" }],
  ["path", { d: "M4 17h16", key: "g4d7ey" }]
];
var CableCar = createLucideIcon("cable-car", __iconNode247);

// ../node_modules/lucide-react/dist/esm/icons/cake-slice.js
var __iconNode248 = [
  ["path", { d: "M16 13H3", key: "1wpj08" }],
  ["path", { d: "M16 17H3", key: "3lvfcd" }],
  [
    "path",
    {
      d: "m7.2 7.9-3.388 2.5A2 2 0 0 0 3 12.01V20a1 1 0 0 0 1 1h16a1 1 0 0 0 1-1v-8.654c0-2-2.44-6.026-6.44-8.026a1 1 0 0 0-1.082.057L10.4 5.6",
      key: "1gmhf7"
    }
  ],
  ["circle", { cx: "9", cy: "7", r: "2", key: "1305pl" }]
];
var CakeSlice = createLucideIcon("cake-slice", __iconNode248);

// ../node_modules/lucide-react/dist/esm/icons/cake.js
var __iconNode249 = [
  ["path", { d: "M20 21v-8a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8", key: "1w3rig" }],
  ["path", { d: "M4 16s.5-1 2-1 2.5 2 4 2 2.5-2 4-2 2.5 2 4 2 2-1 2-1", key: "n2jgmb" }],
  ["path", { d: "M2 21h20", key: "1nyx9w" }],
  ["path", { d: "M7 8v3", key: "1qtyvj" }],
  ["path", { d: "M12 8v3", key: "hwp4zt" }],
  ["path", { d: "M17 8v3", key: "1i6e5u" }],
  ["path", { d: "M7 4h.01", key: "1bh4kh" }],
  ["path", { d: "M12 4h.01", key: "1ujb9j" }],
  ["path", { d: "M17 4h.01", key: "1upcoc" }]
];
var Cake = createLucideIcon("cake", __iconNode249);

// ../node_modules/lucide-react/dist/esm/icons/calculator.js
var __iconNode250 = [
  ["rect", { width: "16", height: "20", x: "4", y: "2", rx: "2", key: "1nb95v" }],
  ["line", { x1: "8", x2: "16", y1: "6", y2: "6", key: "x4nwl0" }],
  ["line", { x1: "16", x2: "16", y1: "14", y2: "18", key: "wjye3r" }],
  ["path", { d: "M16 10h.01", key: "1m94wz" }],
  ["path", { d: "M12 10h.01", key: "1nrarc" }],
  ["path", { d: "M8 10h.01", key: "19clt8" }],
  ["path", { d: "M12 14h.01", key: "1etili" }],
  ["path", { d: "M8 14h.01", key: "6423bh" }],
  ["path", { d: "M12 18h.01", key: "mhygvu" }],
  ["path", { d: "M8 18h.01", key: "lrp35t" }]
];
var Calculator = createLucideIcon("calculator", __iconNode250);

// ../node_modules/lucide-react/dist/esm/icons/calendar-1.js
var __iconNode251 = [
  ["path", { d: "M11 14h1v4", key: "fy54vd" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["rect", { x: "3", y: "4", width: "18", height: "18", rx: "2", key: "12vinp" }]
];
var Calendar1 = createLucideIcon("calendar-1", __iconNode251);

// ../node_modules/lucide-react/dist/esm/icons/calendar-arrow-down.js
var __iconNode252 = [
  ["path", { d: "m14 18 4 4 4-4", key: "1waygx" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M18 14v8", key: "irew45" }],
  [
    "path",
    { d: "M21 11.354V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h7.343", key: "bse4f3" }
  ],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M8 2v4", key: "1cmpym" }]
];
var CalendarArrowDown = createLucideIcon("calendar-arrow-down", __iconNode252);

// ../node_modules/lucide-react/dist/esm/icons/calendar-arrow-up.js
var __iconNode253 = [
  ["path", { d: "m14 18 4-4 4 4", key: "ftkppy" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M18 22v-8", key: "su0gjh" }],
  ["path", { d: "M21 11.343V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h9", key: "1exg90" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M8 2v4", key: "1cmpym" }]
];
var CalendarArrowUp = createLucideIcon("calendar-arrow-up", __iconNode253);

// ../node_modules/lucide-react/dist/esm/icons/calendar-check-2.js
var __iconNode254 = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M21 14V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8", key: "bce9hv" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "m16 20 2 2 4-4", key: "13tcca" }]
];
var CalendarCheck2 = createLucideIcon("calendar-check-2", __iconNode254);

// ../node_modules/lucide-react/dist/esm/icons/calendar-check.js
var __iconNode255 = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "m9 16 2 2 4-4", key: "19s6y9" }]
];
var CalendarCheck = createLucideIcon("calendar-check", __iconNode255);

// ../node_modules/lucide-react/dist/esm/icons/calendar-clock.js
var __iconNode256 = [
  ["path", { d: "M16 14v2.2l1.6 1", key: "fo4ql5" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M21 7.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3.5", key: "1osxxc" }],
  ["path", { d: "M3 10h5", key: "r794hk" }],
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["circle", { cx: "16", cy: "16", r: "6", key: "qoo3c4" }]
];
var CalendarClock = createLucideIcon("calendar-clock", __iconNode256);

// ../node_modules/lucide-react/dist/esm/icons/calendar-cog.js
var __iconNode257 = [
  ["path", { d: "m15.228 16.852-.923-.383", key: "npixar" }],
  ["path", { d: "m15.228 19.148-.923.383", key: "51cr3n" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "m16.47 14.305.382.923", key: "obybxd" }],
  ["path", { d: "m16.852 20.772-.383.924", key: "dpfhf9" }],
  ["path", { d: "m19.148 15.228.383-.923", key: "1reyyz" }],
  ["path", { d: "m19.53 21.696-.382-.924", key: "1goivc" }],
  ["path", { d: "m20.772 16.852.924-.383", key: "htqkph" }],
  ["path", { d: "m20.772 19.148.924.383", key: "9w9pjp" }],
  ["path", { d: "M21 10.592V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6", key: "1pvbig" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }]
];
var CalendarCog = createLucideIcon("calendar-cog", __iconNode257);

// ../node_modules/lucide-react/dist/esm/icons/calendar-days.js
var __iconNode258 = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M8 14h.01", key: "6423bh" }],
  ["path", { d: "M12 14h.01", key: "1etili" }],
  ["path", { d: "M16 14h.01", key: "1gbofw" }],
  ["path", { d: "M8 18h.01", key: "lrp35t" }],
  ["path", { d: "M12 18h.01", key: "mhygvu" }],
  ["path", { d: "M16 18h.01", key: "kzsmim" }]
];
var CalendarDays = createLucideIcon("calendar-days", __iconNode258);

// ../node_modules/lucide-react/dist/esm/icons/calendar-fold.js
var __iconNode259 = [
  [
    "path",
    {
      d: "M3 20a2 2 0 0 0 2 2h10a2.4 2.4 0 0 0 1.706-.706l3.588-3.588A2.4 2.4 0 0 0 21 16V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z",
      key: "r586nh"
    }
  ],
  ["path", { d: "M15 22v-5a1 1 0 0 1 1-1h5", key: "xl3app" }],
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M3 10h18", key: "8toen8" }]
];
var CalendarFold = createLucideIcon("calendar-fold", __iconNode259);

// ../node_modules/lucide-react/dist/esm/icons/calendar-heart.js
var __iconNode260 = [
  [
    "path",
    { d: "M12.127 22H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5.125", key: "vxdnp4" }
  ],
  [
    "path",
    {
      d: "M14.62 18.8A2.25 2.25 0 1 1 18 15.836a2.25 2.25 0 1 1 3.38 2.966l-2.626 2.856a.998.998 0 0 1-1.507 0z",
      key: "15cy7q"
    }
  ],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M8 2v4", key: "1cmpym" }]
];
var CalendarHeart = createLucideIcon("calendar-heart", __iconNode260);

// ../node_modules/lucide-react/dist/esm/icons/calendar-minus-2.js
var __iconNode261 = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M10 16h4", key: "17e571" }]
];
var CalendarMinus2 = createLucideIcon("calendar-minus-2", __iconNode261);

// ../node_modules/lucide-react/dist/esm/icons/calendar-minus.js
var __iconNode262 = [
  ["path", { d: "M16 19h6", key: "xwg31i" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M21 15V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8.5", key: "1scpom" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M8 2v4", key: "1cmpym" }]
];
var CalendarMinus = createLucideIcon("calendar-minus", __iconNode262);

// ../node_modules/lucide-react/dist/esm/icons/calendar-off.js
var __iconNode263 = [
  ["path", { d: "M4.2 4.2A2 2 0 0 0 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 1.82-1.18", key: "16swn3" }],
  ["path", { d: "M21 15.5V6a2 2 0 0 0-2-2H9.5", key: "yhw86o" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M3 10h7", key: "1wap6i" }],
  ["path", { d: "M21 10h-5.5", key: "quycpq" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var CalendarOff = createLucideIcon("calendar-off", __iconNode263);

// ../node_modules/lucide-react/dist/esm/icons/calendar-plus.js
var __iconNode264 = [
  ["path", { d: "M16 19h6", key: "xwg31i" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M19 16v6", key: "tddt3s" }],
  ["path", { d: "M21 12.598V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8.5", key: "1glfrc" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M8 2v4", key: "1cmpym" }]
];
var CalendarPlus = createLucideIcon("calendar-plus", __iconNode264);

// ../node_modules/lucide-react/dist/esm/icons/calendar-plus-2.js
var __iconNode265 = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M10 16h4", key: "17e571" }],
  ["path", { d: "M12 14v4", key: "1thi36" }]
];
var CalendarPlus2 = createLucideIcon("calendar-plus-2", __iconNode265);

// ../node_modules/lucide-react/dist/esm/icons/calendar-range.js
var __iconNode266 = [
  ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M17 14h-6", key: "bkmgh3" }],
  ["path", { d: "M13 18H7", key: "bb0bb7" }],
  ["path", { d: "M7 14h.01", key: "1qa3f1" }],
  ["path", { d: "M17 18h.01", key: "1bdyru" }]
];
var CalendarRange = createLucideIcon("calendar-range", __iconNode266);

// ../node_modules/lucide-react/dist/esm/icons/calendar-search.js
var __iconNode267 = [
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M21 11.75V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h7.25", key: "1jrsq6" }],
  ["path", { d: "m22 22-1.875-1.875", key: "13zax7" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }]
];
var CalendarSearch = createLucideIcon("calendar-search", __iconNode267);

// ../node_modules/lucide-react/dist/esm/icons/calendar-sync.js
var __iconNode268 = [
  ["path", { d: "M11 10v4h4", key: "172dkj" }],
  ["path", { d: "m11 14 1.535-1.605a5 5 0 0 1 8 1.5", key: "vu0qm5" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "m21 18-1.535 1.605a5 5 0 0 1-8-1.5", key: "1qgeyt" }],
  ["path", { d: "M21 22v-4h-4", key: "hrummi" }],
  ["path", { d: "M21 8.5V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h4.3", key: "mctw84" }],
  ["path", { d: "M3 10h4", key: "1el30a" }],
  ["path", { d: "M8 2v4", key: "1cmpym" }]
];
var CalendarSync = createLucideIcon("calendar-sync", __iconNode268);

// ../node_modules/lucide-react/dist/esm/icons/calendar-x-2.js
var __iconNode269 = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M21 13V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8", key: "3spt84" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "m17 22 5-5", key: "1k6ppv" }],
  ["path", { d: "m17 17 5 5", key: "p7ous7" }]
];
var CalendarX2 = createLucideIcon("calendar-x-2", __iconNode269);

// ../node_modules/lucide-react/dist/esm/icons/calendar-x.js
var __iconNode270 = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "m14 14-4 4", key: "rymu2i" }],
  ["path", { d: "m10 14 4 4", key: "3sz06r" }]
];
var CalendarX = createLucideIcon("calendar-x", __iconNode270);

// ../node_modules/lucide-react/dist/esm/icons/calendar.js
var __iconNode271 = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
  ["path", { d: "M3 10h18", key: "8toen8" }]
];
var Calendar = createLucideIcon("calendar", __iconNode271);

// ../node_modules/lucide-react/dist/esm/icons/calendars.js
var __iconNode272 = [
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "M15.726 21.01A2 2 0 0 1 14 22H4a2 2 0 0 1-2-2V10a2 2 0 0 1 2-2", key: "j6srht" }],
  ["path", { d: "M18 2v2", key: "1kh14s" }],
  ["path", { d: "M2 13h2", key: "13gyu8" }],
  ["path", { d: "M8 8h14", key: "12jxz2" }],
  ["rect", { x: "8", y: "3", width: "14", height: "14", rx: "2", key: "nsru6w" }]
];
var Calendars = createLucideIcon("calendars", __iconNode272);

// ../node_modules/lucide-react/dist/esm/icons/camera-off.js
var __iconNode273 = [
  ["path", { d: "M14.564 14.558a3 3 0 1 1-4.122-4.121", key: "1rnrzw" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    { d: "M20 20H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 .819-.175", key: "1x3arw" }
  ],
  [
    "path",
    {
      d: "M9.695 4.024A2 2 0 0 1 10.004 4h3.993a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v7.344",
      key: "1i84u0"
    }
  ]
];
var CameraOff = createLucideIcon("camera-off", __iconNode273);

// ../node_modules/lucide-react/dist/esm/icons/camera.js
var __iconNode274 = [
  [
    "path",
    {
      d: "M13.997 4a2 2 0 0 1 1.76 1.05l.486.9A2 2 0 0 0 18.003 7H20a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2h1.997a2 2 0 0 0 1.759-1.048l.489-.904A2 2 0 0 1 10.004 4z",
      key: "18u6gg"
    }
  ],
  ["circle", { cx: "12", cy: "13", r: "3", key: "1vg3eu" }]
];
var Camera = createLucideIcon("camera", __iconNode274);

// ../node_modules/lucide-react/dist/esm/icons/candy-cane.js
var __iconNode275 = [
  [
    "path",
    {
      d: "M5.7 21a2 2 0 0 1-3.5-2l8.6-14a6 6 0 0 1 10.4 6 2 2 0 1 1-3.464-2 2 2 0 1 0-3.464-2Z",
      key: "isaq8g"
    }
  ],
  ["path", { d: "M17.75 7 15 2.1", key: "12x7e8" }],
  ["path", { d: "M10.9 4.8 13 9", key: "100a87" }],
  ["path", { d: "m7.9 9.7 2 4.4", key: "ntfhaj" }],
  ["path", { d: "M4.9 14.7 7 18.9", key: "1x43jy" }]
];
var CandyCane = createLucideIcon("candy-cane", __iconNode275);

// ../node_modules/lucide-react/dist/esm/icons/candy-off.js
var __iconNode276 = [
  ["path", { d: "M10 10v7.9", key: "m8g9tt" }],
  ["path", { d: "M11.802 6.145a5 5 0 0 1 6.053 6.053", key: "dn87i3" }],
  ["path", { d: "M14 6.1v2.243", key: "1kzysn" }],
  [
    "path",
    { d: "m15.5 15.571-.964.964a5 5 0 0 1-7.071 0 5 5 0 0 1 0-7.07l.964-.965", key: "3sxy18" }
  ],
  [
    "path",
    {
      d: "M16 7V3a1 1 0 0 1 1.707-.707 2.5 2.5 0 0 0 2.152.717 1 1 0 0 1 1.131 1.131 2.5 2.5 0 0 0 .717 2.152A1 1 0 0 1 21 8h-4",
      key: "gpb6xx"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    {
      d: "M8 17v4a1 1 0 0 1-1.707.707 2.5 2.5 0 0 0-2.152-.717 1 1 0 0 1-1.131-1.131 2.5 2.5 0 0 0-.717-2.152A1 1 0 0 1 3 16h4",
      key: "qexcha"
    }
  ]
];
var CandyOff = createLucideIcon("candy-off", __iconNode276);

// ../node_modules/lucide-react/dist/esm/icons/candy.js
var __iconNode277 = [
  ["path", { d: "M10 7v10.9", key: "1gynux" }],
  ["path", { d: "M14 6.1V17", key: "116kdf" }],
  [
    "path",
    {
      d: "M16 7V3a1 1 0 0 1 1.707-.707 2.5 2.5 0 0 0 2.152.717 1 1 0 0 1 1.131 1.131 2.5 2.5 0 0 0 .717 2.152A1 1 0 0 1 21 8h-4",
      key: "gpb6xx"
    }
  ],
  [
    "path",
    {
      d: "M16.536 7.465a5 5 0 0 0-7.072 0l-2 2a5 5 0 0 0 0 7.07 5 5 0 0 0 7.072 0l2-2a5 5 0 0 0 0-7.07",
      key: "1tsln4"
    }
  ],
  [
    "path",
    {
      d: "M8 17v4a1 1 0 0 1-1.707.707 2.5 2.5 0 0 0-2.152-.717 1 1 0 0 1-1.131-1.131 2.5 2.5 0 0 0-.717-2.152A1 1 0 0 1 3 16h4",
      key: "qexcha"
    }
  ]
];
var Candy = createLucideIcon("candy", __iconNode277);

// ../node_modules/lucide-react/dist/esm/icons/cannabis-off.js
var __iconNode278 = [
  ["path", { d: "M12 22v-4c1.5 1.5 3.5 3 6 3 0-1.5-.5-3.5-2-5", key: "1bqfb7" }],
  [
    "path",
    { d: "M13.988 8.327C13.902 6.054 13.365 3.82 12 2a9.3 9.3 0 0 0-1.445 2.9", key: "1p520n" }
  ],
  [
    "path",
    {
      d: "M17.375 11.725C18.882 10.53 21 7.841 21 6c-2.324 0-5.08 1.296-6.662 2.684",
      key: "q2itvb"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    { d: "M21.024 15.378A15 15 0 0 0 22 15c-.426-1.279-2.67-2.557-4.25-2.907", key: "j9amvs" }
  ],
  [
    "path",
    {
      d: "M6.995 6.992C5.714 6.4 4.29 6 3 6c0 2 2.5 5 4 6-1.5 0-4.5 1.5-5 3 3.5 1.5 6 1 6 1-1.5 1.5-2 3.5-2 5 2.5 0 4.5-1.5 6-3",
      key: "8gmd5g"
    }
  ]
];
var CannabisOff = createLucideIcon("cannabis-off", __iconNode278);

// ../node_modules/lucide-react/dist/esm/icons/cannabis.js
var __iconNode279 = [
  ["path", { d: "M12 22v-4", key: "1utk9m" }],
  [
    "path",
    {
      d: "M7 12c-1.5 0-4.5 1.5-5 3 3.5 1.5 6 1 6 1-1.5 1.5-2 3.5-2 5 2.5 0 4.5-1.5 6-3 1.5 1.5 3.5 3 6 3 0-1.5-.5-3.5-2-5 0 0 2.5.5 6-1-.5-1.5-3.5-3-5-3 1.5-1 4-4 4-6-2.5 0-5.5 1.5-7 3 0-2.5-.5-5-2-7-1.5 2-2 4.5-2 7-1.5-1.5-4.5-3-7-3 0 2 2.5 5 4 6",
      key: "1mezod"
    }
  ]
];
var Cannabis = createLucideIcon("cannabis", __iconNode279);

// ../node_modules/lucide-react/dist/esm/icons/captions-off.js
var __iconNode280 = [
  ["path", { d: "M10.5 5H19a2 2 0 0 1 2 2v8.5", key: "jqtk4d" }],
  ["path", { d: "M17 11h-.5", key: "1961ue" }],
  ["path", { d: "M19 19H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2", key: "1keqsi" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M7 11h4", key: "1o1z6v" }],
  ["path", { d: "M7 15h2.5", key: "1ina1g" }]
];
var CaptionsOff = createLucideIcon("captions-off", __iconNode280);

// ../node_modules/lucide-react/dist/esm/icons/captions.js
var __iconNode281 = [
  ["rect", { width: "18", height: "14", x: "3", y: "5", rx: "2", ry: "2", key: "12ruh7" }],
  ["path", { d: "M7 15h4M15 15h2M7 11h2M13 11h4", key: "1ueiar" }]
];
var Captions = createLucideIcon("captions", __iconNode281);

// ../node_modules/lucide-react/dist/esm/icons/car-front.js
var __iconNode282 = [
  [
    "path",
    { d: "m21 8-2 2-1.5-3.7A2 2 0 0 0 15.646 5H8.4a2 2 0 0 0-1.903 1.257L5 10 3 8", key: "1imjwt" }
  ],
  ["path", { d: "M7 14h.01", key: "1qa3f1" }],
  ["path", { d: "M17 14h.01", key: "7oqj8z" }],
  ["rect", { width: "18", height: "8", x: "3", y: "10", rx: "2", key: "a7itu8" }],
  ["path", { d: "M5 18v2", key: "ppbyun" }],
  ["path", { d: "M19 18v2", key: "gy7782" }]
];
var CarFront = createLucideIcon("car-front", __iconNode282);

// ../node_modules/lucide-react/dist/esm/icons/car-taxi-front.js
var __iconNode283 = [
  ["path", { d: "M10 2h4", key: "n1abiw" }],
  [
    "path",
    { d: "m21 8-2 2-1.5-3.7A2 2 0 0 0 15.646 5H8.4a2 2 0 0 0-1.903 1.257L5 10 3 8", key: "1imjwt" }
  ],
  ["path", { d: "M7 14h.01", key: "1qa3f1" }],
  ["path", { d: "M17 14h.01", key: "7oqj8z" }],
  ["rect", { width: "18", height: "8", x: "3", y: "10", rx: "2", key: "a7itu8" }],
  ["path", { d: "M5 18v2", key: "ppbyun" }],
  ["path", { d: "M19 18v2", key: "gy7782" }]
];
var CarTaxiFront = createLucideIcon("car-taxi-front", __iconNode283);

// ../node_modules/lucide-react/dist/esm/icons/car.js
var __iconNode284 = [
  [
    "path",
    {
      d: "M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2",
      key: "5owen"
    }
  ],
  ["circle", { cx: "7", cy: "17", r: "2", key: "u2ysq9" }],
  ["path", { d: "M9 17h6", key: "r8uit2" }],
  ["circle", { cx: "17", cy: "17", r: "2", key: "axvx0g" }]
];
var Car = createLucideIcon("car", __iconNode284);

// ../node_modules/lucide-react/dist/esm/icons/caravan.js
var __iconNode285 = [
  ["path", { d: "M18 19V9a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v8a2 2 0 0 0 2 2h2", key: "19jm3t" }],
  ["path", { d: "M2 9h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H2", key: "13hakp" }],
  ["path", { d: "M22 17v1a1 1 0 0 1-1 1H10v-9a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v9", key: "1crci8" }],
  ["circle", { cx: "8", cy: "19", r: "2", key: "t8fc5s" }]
];
var Caravan = createLucideIcon("caravan", __iconNode285);

// ../node_modules/lucide-react/dist/esm/icons/card-sim.js
var __iconNode286 = [
  ["path", { d: "M12 14v4", key: "1thi36" }],
  [
    "path",
    {
      d: "M14.172 2a2 2 0 0 1 1.414.586l3.828 3.828A2 2 0 0 1 20 7.828V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z",
      key: "1o66bk"
    }
  ],
  ["path", { d: "M8 14h8", key: "1fgep2" }],
  ["rect", { x: "8", y: "10", width: "8", height: "8", rx: "1", key: "1aonk6" }]
];
var CardSim = createLucideIcon("card-sim", __iconNode286);

// ../node_modules/lucide-react/dist/esm/icons/carrot.js
var __iconNode287 = [
  [
    "path",
    {
      d: "M2.27 21.7s9.87-3.5 12.73-6.36a4.5 4.5 0 0 0-6.36-6.37C5.77 11.84 2.27 21.7 2.27 21.7zM8.64 14l-2.05-2.04M15.34 15l-2.46-2.46",
      key: "rfqxbe"
    }
  ],
  ["path", { d: "M22 9s-1.33-2-3.5-2C16.86 7 15 9 15 9s1.33 2 3.5 2S22 9 22 9z", key: "6b25w4" }],
  ["path", { d: "M15 2s-2 1.33-2 3.5S15 9 15 9s2-1.84 2-3.5C17 3.33 15 2 15 2z", key: "fn65lo" }]
];
var Carrot = createLucideIcon("carrot", __iconNode287);

// ../node_modules/lucide-react/dist/esm/icons/case-lower.js
var __iconNode288 = [
  ["path", { d: "M10 9v7", key: "ylp826" }],
  ["path", { d: "M14 6v10", key: "1jy4vg" }],
  ["circle", { cx: "17.5", cy: "12.5", r: "3.5", key: "1a9481" }],
  ["circle", { cx: "6.5", cy: "12.5", r: "3.5", key: "2jlv1r" }]
];
var CaseLower = createLucideIcon("case-lower", __iconNode288);

// ../node_modules/lucide-react/dist/esm/icons/case-sensitive.js
var __iconNode289 = [
  ["path", { d: "m2 16 4.039-9.69a.5.5 0 0 1 .923 0L11 16", key: "d5nyq2" }],
  ["path", { d: "M22 9v7", key: "pvm9v3" }],
  ["path", { d: "M3.304 13h6.392", key: "1q3zxz" }],
  ["circle", { cx: "18.5", cy: "12.5", r: "3.5", key: "z97x68" }]
];
var CaseSensitive = createLucideIcon("case-sensitive", __iconNode289);

// ../node_modules/lucide-react/dist/esm/icons/case-upper.js
var __iconNode290 = [
  [
    "path",
    {
      d: "M15 11h4.5a1 1 0 0 1 0 5h-4a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h3a1 1 0 0 1 0 5",
      key: "nxs35"
    }
  ],
  ["path", { d: "m2 16 4.039-9.69a.5.5 0 0 1 .923 0L11 16", key: "d5nyq2" }],
  ["path", { d: "M3.304 13h6.392", key: "1q3zxz" }]
];
var CaseUpper = createLucideIcon("case-upper", __iconNode290);

// ../node_modules/lucide-react/dist/esm/icons/cast.js
var __iconNode291 = [
  ["path", { d: "M2 8V6a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-6", key: "3zrzxg" }],
  ["path", { d: "M2 12a9 9 0 0 1 8 8", key: "g6cvee" }],
  ["path", { d: "M2 16a5 5 0 0 1 4 4", key: "1y1dii" }],
  ["line", { x1: "2", x2: "2.01", y1: "20", y2: "20", key: "xu2jvo" }]
];
var Cast = createLucideIcon("cast", __iconNode291);

// ../node_modules/lucide-react/dist/esm/icons/cassette-tape.js
var __iconNode292 = [
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }],
  ["circle", { cx: "8", cy: "10", r: "2", key: "1xl4ub" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }],
  ["circle", { cx: "16", cy: "10", r: "2", key: "r14t7q" }],
  ["path", { d: "m6 20 .7-2.9A1.4 1.4 0 0 1 8.1 16h7.8a1.4 1.4 0 0 1 1.4 1l.7 3", key: "l01ucn" }]
];
var CassetteTape = createLucideIcon("cassette-tape", __iconNode292);

// ../node_modules/lucide-react/dist/esm/icons/castle.js
var __iconNode293 = [
  ["path", { d: "M10 5V3", key: "1y54qe" }],
  ["path", { d: "M14 5V3", key: "m6isi" }],
  ["path", { d: "M15 21v-3a3 3 0 0 0-6 0v3", key: "lbp5hj" }],
  ["path", { d: "M18 3v8", key: "2ollhf" }],
  ["path", { d: "M18 5H6", key: "98imr9" }],
  ["path", { d: "M22 11H2", key: "1lmjae" }],
  ["path", { d: "M22 9v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9", key: "1rly83" }],
  ["path", { d: "M6 3v8", key: "csox7g" }]
];
var Castle = createLucideIcon("castle", __iconNode293);

// ../node_modules/lucide-react/dist/esm/icons/cat.js
var __iconNode294 = [
  [
    "path",
    {
      d: "M12 5c.67 0 1.35.09 2 .26 1.78-2 5.03-2.84 6.42-2.26 1.4.58-.42 7-.42 7 .57 1.07 1 2.24 1 3.44C21 17.9 16.97 21 12 21s-9-3-9-7.56c0-1.25.5-2.4 1-3.44 0 0-1.89-6.42-.5-7 1.39-.58 4.72.23 6.5 2.23A9.04 9.04 0 0 1 12 5Z",
      key: "x6xyqk"
    }
  ],
  ["path", { d: "M8 14v.5", key: "1nzgdb" }],
  ["path", { d: "M16 14v.5", key: "1lajdz" }],
  ["path", { d: "M11.25 16.25h1.5L12 17l-.75-.75Z", key: "12kq1m" }]
];
var Cat = createLucideIcon("cat", __iconNode294);

// ../node_modules/lucide-react/dist/esm/icons/cctv.js
var __iconNode295 = [
  [
    "path",
    {
      d: "M16.75 12h3.632a1 1 0 0 1 .894 1.447l-2.034 4.069a1 1 0 0 1-1.708.134l-2.124-2.97",
      key: "ir91b5"
    }
  ],
  [
    "path",
    {
      d: "M17.106 9.053a1 1 0 0 1 .447 1.341l-3.106 6.211a1 1 0 0 1-1.342.447L3.61 12.3a2.92 2.92 0 0 1-1.3-3.91L3.69 5.6a2.92 2.92 0 0 1 3.92-1.3z",
      key: "jlp8i1"
    }
  ],
  ["path", { d: "M2 19h3.76a2 2 0 0 0 1.8-1.1L9 15", key: "19bib8" }],
  ["path", { d: "M2 21v-4", key: "l40lih" }],
  ["path", { d: "M7 9h.01", key: "19b3jx" }]
];
var Cctv = createLucideIcon("cctv", __iconNode295);

// ../node_modules/lucide-react/dist/esm/icons/chart-area.js
var __iconNode296 = [
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  [
    "path",
    {
      d: "M7 11.207a.5.5 0 0 1 .146-.353l2-2a.5.5 0 0 1 .708 0l3.292 3.292a.5.5 0 0 0 .708 0l4.292-4.292a.5.5 0 0 1 .854.353V16a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1z",
      key: "q0gr47"
    }
  ]
];
var ChartArea = createLucideIcon("chart-area", __iconNode296);

// ../node_modules/lucide-react/dist/esm/icons/chart-bar-big.js
var __iconNode297 = [
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["rect", { x: "7", y: "13", width: "9", height: "4", rx: "1", key: "1iip1u" }],
  ["rect", { x: "7", y: "5", width: "12", height: "4", rx: "1", key: "1anskk" }]
];
var ChartBarBig = createLucideIcon("chart-bar-big", __iconNode297);

// ../node_modules/lucide-react/dist/esm/icons/chart-bar-decreasing.js
var __iconNode298 = [
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["path", { d: "M7 11h8", key: "1feolt" }],
  ["path", { d: "M7 16h3", key: "ur6vzw" }],
  ["path", { d: "M7 6h12", key: "sz5b0d" }]
];
var ChartBarDecreasing = createLucideIcon("chart-bar-decreasing", __iconNode298);

// ../node_modules/lucide-react/dist/esm/icons/chart-bar-increasing.js
var __iconNode299 = [
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["path", { d: "M7 11h8", key: "1feolt" }],
  ["path", { d: "M7 16h12", key: "wsnu98" }],
  ["path", { d: "M7 6h3", key: "w9rmul" }]
];
var ChartBarIncreasing = createLucideIcon("chart-bar-increasing", __iconNode299);

// ../node_modules/lucide-react/dist/esm/icons/chart-bar-stacked.js
var __iconNode300 = [
  ["path", { d: "M11 13v4", key: "vyy2rb" }],
  ["path", { d: "M15 5v4", key: "1gx88a" }],
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["rect", { x: "7", y: "13", width: "9", height: "4", rx: "1", key: "1iip1u" }],
  ["rect", { x: "7", y: "5", width: "12", height: "4", rx: "1", key: "1anskk" }]
];
var ChartBarStacked = createLucideIcon("chart-bar-stacked", __iconNode300);

// ../node_modules/lucide-react/dist/esm/icons/chart-bar.js
var __iconNode301 = [
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["path", { d: "M7 16h8", key: "srdodz" }],
  ["path", { d: "M7 11h12", key: "127s9w" }],
  ["path", { d: "M7 6h3", key: "w9rmul" }]
];
var ChartBar = createLucideIcon("chart-bar", __iconNode301);

// ../node_modules/lucide-react/dist/esm/icons/chart-candlestick.js
var __iconNode302 = [
  ["path", { d: "M9 5v4", key: "14uxtq" }],
  ["rect", { width: "4", height: "6", x: "7", y: "9", rx: "1", key: "f4fvz0" }],
  ["path", { d: "M9 15v2", key: "r5rk32" }],
  ["path", { d: "M17 3v2", key: "1l2re6" }],
  ["rect", { width: "4", height: "8", x: "15", y: "5", rx: "1", key: "z38je5" }],
  ["path", { d: "M17 13v3", key: "5l0wba" }],
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }]
];
var ChartCandlestick = createLucideIcon("chart-candlestick", __iconNode302);

// ../node_modules/lucide-react/dist/esm/icons/chart-column-big.js
var __iconNode303 = [
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["rect", { x: "15", y: "5", width: "4", height: "12", rx: "1", key: "q8uenq" }],
  ["rect", { x: "7", y: "8", width: "4", height: "9", rx: "1", key: "sr5ea" }]
];
var ChartColumnBig = createLucideIcon("chart-column-big", __iconNode303);

// ../node_modules/lucide-react/dist/esm/icons/chart-column-decreasing.js
var __iconNode304 = [
  ["path", { d: "M13 17V9", key: "1fwyjl" }],
  ["path", { d: "M18 17v-3", key: "1sqioe" }],
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["path", { d: "M8 17V5", key: "1wzmnc" }]
];
var ChartColumnDecreasing = createLucideIcon("chart-column-decreasing", __iconNode304);

// ../node_modules/lucide-react/dist/esm/icons/chart-column-increasing.js
var __iconNode305 = [
  ["path", { d: "M13 17V9", key: "1fwyjl" }],
  ["path", { d: "M18 17V5", key: "sfb6ij" }],
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["path", { d: "M8 17v-3", key: "17ska0" }]
];
var ChartColumnIncreasing = createLucideIcon("chart-column-increasing", __iconNode305);

// ../node_modules/lucide-react/dist/esm/icons/chart-column-stacked.js
var __iconNode306 = [
  ["path", { d: "M11 13H7", key: "t0o9gq" }],
  ["path", { d: "M19 9h-4", key: "rera1j" }],
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["rect", { x: "15", y: "5", width: "4", height: "12", rx: "1", key: "q8uenq" }],
  ["rect", { x: "7", y: "8", width: "4", height: "9", rx: "1", key: "sr5ea" }]
];
var ChartColumnStacked = createLucideIcon("chart-column-stacked", __iconNode306);

// ../node_modules/lucide-react/dist/esm/icons/chart-column.js
var __iconNode307 = [
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["path", { d: "M18 17V9", key: "2bz60n" }],
  ["path", { d: "M13 17V5", key: "1frdt8" }],
  ["path", { d: "M8 17v-3", key: "17ska0" }]
];
var ChartColumn = createLucideIcon("chart-column", __iconNode307);

// ../node_modules/lucide-react/dist/esm/icons/chart-gantt.js
var __iconNode308 = [
  ["path", { d: "M10 6h8", key: "zvc2xc" }],
  ["path", { d: "M12 16h6", key: "yi5mkt" }],
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["path", { d: "M8 11h7", key: "wz2hg0" }]
];
var ChartGantt = createLucideIcon("chart-gantt", __iconNode308);

// ../node_modules/lucide-react/dist/esm/icons/chart-line.js
var __iconNode309 = [
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["path", { d: "m19 9-5 5-4-4-3 3", key: "2osh9i" }]
];
var ChartLine = createLucideIcon("chart-line", __iconNode309);

// ../node_modules/lucide-react/dist/esm/icons/chart-network.js
var __iconNode310 = [
  ["path", { d: "m13.11 7.664 1.78 2.672", key: "go2gg9" }],
  ["path", { d: "m14.162 12.788-3.324 1.424", key: "11x848" }],
  ["path", { d: "m20 4-6.06 1.515", key: "1wxxh7" }],
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["circle", { cx: "12", cy: "6", r: "2", key: "1jj5th" }],
  ["circle", { cx: "16", cy: "12", r: "2", key: "4ma0v8" }],
  ["circle", { cx: "9", cy: "15", r: "2", key: "lf2ghp" }]
];
var ChartNetwork = createLucideIcon("chart-network", __iconNode310);

// ../node_modules/lucide-react/dist/esm/icons/chart-no-axes-column-decreasing.js
var __iconNode311 = [
  ["path", { d: "M5 21V3", key: "clc1r8" }],
  ["path", { d: "M12 21V9", key: "uvy0l4" }],
  ["path", { d: "M19 21v-6", key: "tkawy9" }]
];
var ChartNoAxesColumnDecreasing = createLucideIcon("chart-no-axes-column-decreasing", __iconNode311);

// ../node_modules/lucide-react/dist/esm/icons/chart-no-axes-column-increasing.js
var __iconNode312 = [
  ["path", { d: "M5 21v-6", key: "1hz6c0" }],
  ["path", { d: "M12 21V9", key: "uvy0l4" }],
  ["path", { d: "M19 21V3", key: "11j9sm" }]
];
var ChartNoAxesColumnIncreasing = createLucideIcon("chart-no-axes-column-increasing", __iconNode312);

// ../node_modules/lucide-react/dist/esm/icons/chart-no-axes-column.js
var __iconNode313 = [
  ["path", { d: "M5 21v-6", key: "1hz6c0" }],
  ["path", { d: "M12 21V3", key: "1lcnhd" }],
  ["path", { d: "M19 21V9", key: "unv183" }]
];
var ChartNoAxesColumn = createLucideIcon("chart-no-axes-column", __iconNode313);

// ../node_modules/lucide-react/dist/esm/icons/chart-no-axes-combined.js
var __iconNode314 = [
  ["path", { d: "M12 16v5", key: "zza2cw" }],
  ["path", { d: "M16 14v7", key: "1g90b9" }],
  ["path", { d: "M20 10v11", key: "1iqoj0" }],
  [
    "path",
    { d: "m22 3-8.646 8.646a.5.5 0 0 1-.708 0L9.354 8.354a.5.5 0 0 0-.707 0L2 15", key: "1fw8x9" }
  ],
  ["path", { d: "M4 18v3", key: "1yp0dc" }],
  ["path", { d: "M8 14v7", key: "n3cwzv" }]
];
var ChartNoAxesCombined = createLucideIcon("chart-no-axes-combined", __iconNode314);

// ../node_modules/lucide-react/dist/esm/icons/chart-no-axes-gantt.js
var __iconNode315 = [
  ["path", { d: "M6 5h12", key: "fvfigv" }],
  ["path", { d: "M4 12h10", key: "oujl3d" }],
  ["path", { d: "M12 19h8", key: "baeox8" }]
];
var ChartNoAxesGantt = createLucideIcon("chart-no-axes-gantt", __iconNode315);

// ../node_modules/lucide-react/dist/esm/icons/chart-pie.js
var __iconNode316 = [
  [
    "path",
    {
      d: "M21 12c.552 0 1.005-.449.95-.998a10 10 0 0 0-8.953-8.951c-.55-.055-.998.398-.998.95v8a1 1 0 0 0 1 1z",
      key: "pzmjnu"
    }
  ],
  ["path", { d: "M21.21 15.89A10 10 0 1 1 8 2.83", key: "k2fpak" }]
];
var ChartPie = createLucideIcon("chart-pie", __iconNode316);

// ../node_modules/lucide-react/dist/esm/icons/chart-scatter.js
var __iconNode317 = [
  ["circle", { cx: "7.5", cy: "7.5", r: ".5", fill: "currentColor", key: "kqv944" }],
  ["circle", { cx: "18.5", cy: "5.5", r: ".5", fill: "currentColor", key: "lysivs" }],
  ["circle", { cx: "11.5", cy: "11.5", r: ".5", fill: "currentColor", key: "byv1b8" }],
  ["circle", { cx: "7.5", cy: "16.5", r: ".5", fill: "currentColor", key: "nkw3mc" }],
  ["circle", { cx: "17.5", cy: "14.5", r: ".5", fill: "currentColor", key: "1gjh6j" }],
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }]
];
var ChartScatter = createLucideIcon("chart-scatter", __iconNode317);

// ../node_modules/lucide-react/dist/esm/icons/chart-spline.js
var __iconNode318 = [
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["path", { d: "M7 16c.5-2 1.5-7 4-7 2 0 2 3 4 3 2.5 0 4.5-5 5-7", key: "lw07rv" }]
];
var ChartSpline = createLucideIcon("chart-spline", __iconNode318);

// ../node_modules/lucide-react/dist/esm/icons/check-check.js
var __iconNode319 = [
  ["path", { d: "M18 6 7 17l-5-5", key: "116fxf" }],
  ["path", { d: "m22 10-7.5 7.5L13 16", key: "ke71qq" }]
];
var CheckCheck = createLucideIcon("check-check", __iconNode319);

// ../node_modules/lucide-react/dist/esm/icons/check-line.js
var __iconNode320 = [
  ["path", { d: "M20 4L9 15", key: "1qkx8z" }],
  ["path", { d: "M21 19L3 19", key: "100sma" }],
  ["path", { d: "M9 15L4 10", key: "9zxff7" }]
];
var CheckLine = createLucideIcon("check-line", __iconNode320);

// ../node_modules/lucide-react/dist/esm/icons/check.js
var __iconNode321 = [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]];
var Check = createLucideIcon("check", __iconNode321);

// ../node_modules/lucide-react/dist/esm/icons/chef-hat.js
var __iconNode322 = [
  [
    "path",
    {
      d: "M17 21a1 1 0 0 0 1-1v-5.35c0-.457.316-.844.727-1.041a4 4 0 0 0-2.134-7.589 5 5 0 0 0-9.186 0 4 4 0 0 0-2.134 7.588c.411.198.727.585.727 1.041V20a1 1 0 0 0 1 1Z",
      key: "1qvrer"
    }
  ],
  ["path", { d: "M6 17h12", key: "1jwigz" }]
];
var ChefHat = createLucideIcon("chef-hat", __iconNode322);

// ../node_modules/lucide-react/dist/esm/icons/cherry.js
var __iconNode323 = [
  ["path", { d: "M2 17a5 5 0 0 0 10 0c0-2.76-2.5-5-5-3-2.5-2-5 .24-5 3Z", key: "cvxqlc" }],
  ["path", { d: "M12 17a5 5 0 0 0 10 0c0-2.76-2.5-5-5-3-2.5-2-5 .24-5 3Z", key: "1ostrc" }],
  ["path", { d: "M7 14c3.22-2.91 4.29-8.75 5-12 1.66 2.38 4.94 9 5 12", key: "hqx58h" }],
  ["path", { d: "M22 9c-4.29 0-7.14-2.33-10-7 5.71 0 10 4.67 10 7Z", key: "eykp1o" }]
];
var Cherry = createLucideIcon("cherry", __iconNode323);

// ../node_modules/lucide-react/dist/esm/icons/chess-bishop.js
var __iconNode324 = [
  [
    "path",
    { d: "M5 20a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z", key: "b89hwq" }
  ],
  [
    "path",
    {
      d: "M15 18c1.5-.615 3-2.461 3-4.923C18 8.769 14.5 4.462 12 2 9.5 4.462 6 8.77 6 13.077 6 15.539 7.5 17.385 9 18",
      key: "8jdkhx"
    }
  ],
  ["path", { d: "m16 7-2.5 2.5", key: "1jq90w" }],
  ["path", { d: "M9 2h6", key: "1jrp98" }]
];
var ChessBishop = createLucideIcon("chess-bishop", __iconNode324);

// ../node_modules/lucide-react/dist/esm/icons/chess-king.js
var __iconNode325 = [
  [
    "path",
    { d: "M4 20a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z", key: "mqzwx6" }
  ],
  [
    "path",
    {
      d: "m6.7 18-1-1C4.35 15.682 3 14.09 3 12a5 5 0 0 1 4.95-5c1.584 0 2.7.455 4.05 1.818C13.35 7.455 14.466 7 16.05 7A5 5 0 0 1 21 12c0 2.082-1.359 3.673-2.7 5l-1 1",
      key: "1gdt1g"
    }
  ],
  ["path", { d: "M10 4h4", key: "1xpv9s" }],
  ["path", { d: "M12 2v6.818", key: "b17a49" }]
];
var ChessKing = createLucideIcon("chess-king", __iconNode325);

// ../node_modules/lucide-react/dist/esm/icons/chess-knight.js
var __iconNode326 = [
  [
    "path",
    { d: "M5 20a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z", key: "b89hwq" }
  ],
  [
    "path",
    {
      d: "M16.5 18c1-2 2.5-5 2.5-9a7 7 0 0 0-7-7H6.635a1 1 0 0 0-.768 1.64L7 5l-2.32 5.802a2 2 0 0 0 .95 2.526l2.87 1.456",
      key: "axbnlq"
    }
  ],
  ["path", { d: "m15 5 1.425-1.425", key: "15xz8w" }],
  ["path", { d: "m17 8 1.53-1.53", key: "15zhqh" }],
  ["path", { d: "M9.713 12.185 7 18", key: "1ocm0l" }]
];
var ChessKnight = createLucideIcon("chess-knight", __iconNode326);

// ../node_modules/lucide-react/dist/esm/icons/chess-queen.js
var __iconNode327 = [
  [
    "path",
    { d: "M4 20a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z", key: "mqzwx6" }
  ],
  ["path", { d: "m12.474 5.943 1.567 5.34a1 1 0 0 0 1.75.328l2.616-3.402", key: "1js4gl" }],
  ["path", { d: "m20 9-3 9", key: "r75r3f" }],
  ["path", { d: "m5.594 8.209 2.615 3.403a1 1 0 0 0 1.75-.329l1.567-5.34", key: "1joj19" }],
  ["path", { d: "M7 18 4 9", key: "1mfzj8" }],
  ["circle", { cx: "12", cy: "4", r: "2", key: "muu5ef" }],
  ["circle", { cx: "20", cy: "7", r: "2", key: "9w7p1x" }],
  ["circle", { cx: "4", cy: "7", r: "2", key: "1d9wy8" }]
];
var ChessQueen = createLucideIcon("chess-queen", __iconNode327);

// ../node_modules/lucide-react/dist/esm/icons/chess-pawn.js
var __iconNode328 = [
  [
    "path",
    { d: "M5 20a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z", key: "b89hwq" }
  ],
  ["path", { d: "m14.5 10 1.5 8", key: "cim3qy" }],
  ["path", { d: "M7 10h10", key: "1101jm" }],
  ["path", { d: "m8 18 1.5-8", key: "ja3yjd" }],
  ["circle", { cx: "12", cy: "6", r: "4", key: "1frrej" }]
];
var ChessPawn = createLucideIcon("chess-pawn", __iconNode328);

// ../node_modules/lucide-react/dist/esm/icons/chess-rook.js
var __iconNode329 = [
  [
    "path",
    { d: "M5 20a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1z", key: "b89hwq" }
  ],
  ["path", { d: "M10 2v2", key: "7u0qdc" }],
  ["path", { d: "M14 2v2", key: "6buw04" }],
  ["path", { d: "m17 18-1-9", key: "10nd7q" }],
  ["path", { d: "M6 2v5a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2", key: "uxf4yx" }],
  ["path", { d: "M6 4h12", key: "1x2ag7" }],
  ["path", { d: "m7 18 1-9", key: "1si9vq" }]
];
var ChessRook = createLucideIcon("chess-rook", __iconNode329);

// ../node_modules/lucide-react/dist/esm/icons/chevron-down.js
var __iconNode330 = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]];
var ChevronDown = createLucideIcon("chevron-down", __iconNode330);

// ../node_modules/lucide-react/dist/esm/icons/chevron-last.js
var __iconNode331 = [
  ["path", { d: "m7 18 6-6-6-6", key: "lwmzdw" }],
  ["path", { d: "M17 6v12", key: "1o0aio" }]
];
var ChevronLast = createLucideIcon("chevron-last", __iconNode331);

// ../node_modules/lucide-react/dist/esm/icons/chevron-first.js
var __iconNode332 = [
  ["path", { d: "m17 18-6-6 6-6", key: "1yerx2" }],
  ["path", { d: "M7 6v12", key: "1p53r6" }]
];
var ChevronFirst = createLucideIcon("chevron-first", __iconNode332);

// ../node_modules/lucide-react/dist/esm/icons/chevron-left.js
var __iconNode333 = [["path", { d: "m15 18-6-6 6-6", key: "1wnfg3" }]];
var ChevronLeft = createLucideIcon("chevron-left", __iconNode333);

// ../node_modules/lucide-react/dist/esm/icons/chevron-right.js
var __iconNode334 = [["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]];
var ChevronRight = createLucideIcon("chevron-right", __iconNode334);

// ../node_modules/lucide-react/dist/esm/icons/chevron-up.js
var __iconNode335 = [["path", { d: "m18 15-6-6-6 6", key: "153udz" }]];
var ChevronUp = createLucideIcon("chevron-up", __iconNode335);

// ../node_modules/lucide-react/dist/esm/icons/chevrons-down-up.js
var __iconNode336 = [
  ["path", { d: "m7 20 5-5 5 5", key: "13a0gw" }],
  ["path", { d: "m7 4 5 5 5-5", key: "1kwcof" }]
];
var ChevronsDownUp = createLucideIcon("chevrons-down-up", __iconNode336);

// ../node_modules/lucide-react/dist/esm/icons/chevrons-down.js
var __iconNode337 = [
  ["path", { d: "m7 6 5 5 5-5", key: "1lc07p" }],
  ["path", { d: "m7 13 5 5 5-5", key: "1d48rs" }]
];
var ChevronsDown = createLucideIcon("chevrons-down", __iconNode337);

// ../node_modules/lucide-react/dist/esm/icons/chevrons-left-right-ellipsis.js
var __iconNode338 = [
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M16 12h.01", key: "1l6xoz" }],
  ["path", { d: "m17 7 5 5-5 5", key: "1xlxn0" }],
  ["path", { d: "m7 7-5 5 5 5", key: "19njba" }],
  ["path", { d: "M8 12h.01", key: "czm47f" }]
];
var ChevronsLeftRightEllipsis = createLucideIcon("chevrons-left-right-ellipsis", __iconNode338);

// ../node_modules/lucide-react/dist/esm/icons/chevrons-left-right.js
var __iconNode339 = [
  ["path", { d: "m9 7-5 5 5 5", key: "j5w590" }],
  ["path", { d: "m15 7 5 5-5 5", key: "1bl6da" }]
];
var ChevronsLeftRight = createLucideIcon("chevrons-left-right", __iconNode339);

// ../node_modules/lucide-react/dist/esm/icons/chevrons-left.js
var __iconNode340 = [
  ["path", { d: "m11 17-5-5 5-5", key: "13zhaf" }],
  ["path", { d: "m18 17-5-5 5-5", key: "h8a8et" }]
];
var ChevronsLeft = createLucideIcon("chevrons-left", __iconNode340);

// ../node_modules/lucide-react/dist/esm/icons/chevrons-right-left.js
var __iconNode341 = [
  ["path", { d: "m20 17-5-5 5-5", key: "30x0n2" }],
  ["path", { d: "m4 17 5-5-5-5", key: "16spf4" }]
];
var ChevronsRightLeft = createLucideIcon("chevrons-right-left", __iconNode341);

// ../node_modules/lucide-react/dist/esm/icons/chevrons-right.js
var __iconNode342 = [
  ["path", { d: "m6 17 5-5-5-5", key: "xnjwq" }],
  ["path", { d: "m13 17 5-5-5-5", key: "17xmmf" }]
];
var ChevronsRight = createLucideIcon("chevrons-right", __iconNode342);

// ../node_modules/lucide-react/dist/esm/icons/chevrons-up-down.js
var __iconNode343 = [
  ["path", { d: "m7 15 5 5 5-5", key: "1hf1tw" }],
  ["path", { d: "m7 9 5-5 5 5", key: "sgt6xg" }]
];
var ChevronsUpDown = createLucideIcon("chevrons-up-down", __iconNode343);

// ../node_modules/lucide-react/dist/esm/icons/chevrons-up.js
var __iconNode344 = [
  ["path", { d: "m17 11-5-5-5 5", key: "e8nh98" }],
  ["path", { d: "m17 18-5-5-5 5", key: "2avn1x" }]
];
var ChevronsUp = createLucideIcon("chevrons-up", __iconNode344);

// ../node_modules/lucide-react/dist/esm/icons/chromium.js
var __iconNode345 = [
  ["path", { d: "M10.88 21.94 15.46 14", key: "xkve6t" }],
  ["path", { d: "M21.17 8H12", key: "19dcdn" }],
  ["path", { d: "M3.95 6.06 8.54 14", key: "g8jz9m" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }]
];
var Chromium = createLucideIcon("chromium", __iconNode345);

// ../node_modules/lucide-react/dist/esm/icons/church.js
var __iconNode346 = [
  ["path", { d: "M10 9h4", key: "u4k05v" }],
  ["path", { d: "M12 7v5", key: "ma6bk" }],
  ["path", { d: "M14 21v-3a2 2 0 0 0-4 0v3", key: "1rgiei" }],
  [
    "path",
    {
      d: "m18 9 3.52 2.147a1 1 0 0 1 .48.854V19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6.999a1 1 0 0 1 .48-.854L6 9",
      key: "flvdwo"
    }
  ],
  [
    "path",
    {
      d: "M6 21V7a1 1 0 0 1 .376-.782l5-3.999a1 1 0 0 1 1.249.001l5 4A1 1 0 0 1 18 7v14",
      key: "a5i0n2"
    }
  ]
];
var Church = createLucideIcon("church", __iconNode346);

// ../node_modules/lucide-react/dist/esm/icons/cigarette-off.js
var __iconNode347 = [
  ["path", { d: "M12 12H3a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h13", key: "1gdiyg" }],
  ["path", { d: "M18 8c0-2.5-2-2.5-2-5", key: "1il607" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M21 12a1 1 0 0 1 1 1v2a1 1 0 0 1-.5.866", key: "166zjj" }],
  ["path", { d: "M22 8c0-2.5-2-2.5-2-5", key: "1gah44" }],
  ["path", { d: "M7 12v4", key: "jqww69" }]
];
var CigaretteOff = createLucideIcon("cigarette-off", __iconNode347);

// ../node_modules/lucide-react/dist/esm/icons/cigarette.js
var __iconNode348 = [
  ["path", { d: "M17 12H3a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h14", key: "1mb5g1" }],
  ["path", { d: "M18 8c0-2.5-2-2.5-2-5", key: "1il607" }],
  ["path", { d: "M21 16a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1", key: "1yl5r7" }],
  ["path", { d: "M22 8c0-2.5-2-2.5-2-5", key: "1gah44" }],
  ["path", { d: "M7 12v4", key: "jqww69" }]
];
var Cigarette = createLucideIcon("cigarette", __iconNode348);

// ../node_modules/lucide-react/dist/esm/icons/circle-alert.js
var __iconNode349 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "12", key: "1pkeuh" }],
  ["line", { x1: "12", x2: "12.01", y1: "16", y2: "16", key: "4dfq90" }]
];
var CircleAlert = createLucideIcon("circle-alert", __iconNode349);

// ../node_modules/lucide-react/dist/esm/icons/circle-arrow-down.js
var __iconNode350 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 8v8", key: "napkw2" }],
  ["path", { d: "m8 12 4 4 4-4", key: "k98ssh" }]
];
var CircleArrowDown = createLucideIcon("circle-arrow-down", __iconNode350);

// ../node_modules/lucide-react/dist/esm/icons/circle-arrow-left.js
var __iconNode351 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m12 8-4 4 4 4", key: "15vm53" }],
  ["path", { d: "M16 12H8", key: "1fr5h0" }]
];
var CircleArrowLeft = createLucideIcon("circle-arrow-left", __iconNode351);

// ../node_modules/lucide-react/dist/esm/icons/circle-arrow-out-down-left.js
var __iconNode352 = [
  ["path", { d: "M2 12a10 10 0 1 1 10 10", key: "1yn6ov" }],
  ["path", { d: "m2 22 10-10", key: "28ilpk" }],
  ["path", { d: "M8 22H2v-6", key: "sulq54" }]
];
var CircleArrowOutDownLeft = createLucideIcon("circle-arrow-out-down-left", __iconNode352);

// ../node_modules/lucide-react/dist/esm/icons/circle-arrow-out-down-right.js
var __iconNode353 = [
  ["path", { d: "M12 22a10 10 0 1 1 10-10", key: "130bv5" }],
  ["path", { d: "M22 22 12 12", key: "131aw7" }],
  ["path", { d: "M22 16v6h-6", key: "1gvm70" }]
];
var CircleArrowOutDownRight = createLucideIcon("circle-arrow-out-down-right", __iconNode353);

// ../node_modules/lucide-react/dist/esm/icons/circle-arrow-out-up-left.js
var __iconNode354 = [
  ["path", { d: "M2 8V2h6", key: "hiwtdz" }],
  ["path", { d: "m2 2 10 10", key: "1oh8rs" }],
  ["path", { d: "M12 2A10 10 0 1 1 2 12", key: "rrk4fa" }]
];
var CircleArrowOutUpLeft = createLucideIcon("circle-arrow-out-up-left", __iconNode354);

// ../node_modules/lucide-react/dist/esm/icons/circle-arrow-out-up-right.js
var __iconNode355 = [
  ["path", { d: "M22 12A10 10 0 1 1 12 2", key: "1fm58d" }],
  ["path", { d: "M22 2 12 12", key: "yg2myt" }],
  ["path", { d: "M16 2h6v6", key: "zan5cs" }]
];
var CircleArrowOutUpRight = createLucideIcon("circle-arrow-out-up-right", __iconNode355);

// ../node_modules/lucide-react/dist/esm/icons/circle-arrow-right.js
var __iconNode356 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m12 16 4-4-4-4", key: "1i9zcv" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }]
];
var CircleArrowRight = createLucideIcon("circle-arrow-right", __iconNode356);

// ../node_modules/lucide-react/dist/esm/icons/circle-arrow-up.js
var __iconNode357 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m16 12-4-4-4 4", key: "177agl" }],
  ["path", { d: "M12 16V8", key: "1sbj14" }]
];
var CircleArrowUp = createLucideIcon("circle-arrow-up", __iconNode357);

// ../node_modules/lucide-react/dist/esm/icons/circle-check-big.js
var __iconNode358 = [
  ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
  ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }]
];
var CircleCheckBig = createLucideIcon("circle-check-big", __iconNode358);

// ../node_modules/lucide-react/dist/esm/icons/circle-check.js
var __iconNode359 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
];
var CircleCheck = createLucideIcon("circle-check", __iconNode359);

// ../node_modules/lucide-react/dist/esm/icons/circle-chevron-down.js
var __iconNode360 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m16 10-4 4-4-4", key: "894hmk" }]
];
var CircleChevronDown = createLucideIcon("circle-chevron-down", __iconNode360);

// ../node_modules/lucide-react/dist/esm/icons/circle-chevron-left.js
var __iconNode361 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m14 16-4-4 4-4", key: "ojs7w8" }]
];
var CircleChevronLeft = createLucideIcon("circle-chevron-left", __iconNode361);

// ../node_modules/lucide-react/dist/esm/icons/circle-chevron-right.js
var __iconNode362 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m10 8 4 4-4 4", key: "1wy4r4" }]
];
var CircleChevronRight = createLucideIcon("circle-chevron-right", __iconNode362);

// ../node_modules/lucide-react/dist/esm/icons/circle-chevron-up.js
var __iconNode363 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m8 14 4-4 4 4", key: "fy2ptz" }]
];
var CircleChevronUp = createLucideIcon("circle-chevron-up", __iconNode363);

// ../node_modules/lucide-react/dist/esm/icons/circle-dashed.js
var __iconNode364 = [
  ["path", { d: "M10.1 2.182a10 10 0 0 1 3.8 0", key: "5ilxe3" }],
  ["path", { d: "M13.9 21.818a10 10 0 0 1-3.8 0", key: "11zvb9" }],
  ["path", { d: "M17.609 3.721a10 10 0 0 1 2.69 2.7", key: "1iw5b2" }],
  ["path", { d: "M2.182 13.9a10 10 0 0 1 0-3.8", key: "c0bmvh" }],
  ["path", { d: "M20.279 17.609a10 10 0 0 1-2.7 2.69", key: "1ruxm7" }],
  ["path", { d: "M21.818 10.1a10 10 0 0 1 0 3.8", key: "qkgqxc" }],
  ["path", { d: "M3.721 6.391a10 10 0 0 1 2.7-2.69", key: "1mcia2" }],
  ["path", { d: "M6.391 20.279a10 10 0 0 1-2.69-2.7", key: "1fvljs" }]
];
var CircleDashed = createLucideIcon("circle-dashed", __iconNode364);

// ../node_modules/lucide-react/dist/esm/icons/circle-divide.js
var __iconNode365 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "8", x2: "16", y1: "12", y2: "12", key: "1jonct" }],
  ["line", { x1: "12", x2: "12", y1: "16", y2: "16", key: "aqc6ln" }],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "8", key: "1mkcni" }]
];
var CircleDivide = createLucideIcon("circle-divide", __iconNode365);

// ../node_modules/lucide-react/dist/esm/icons/circle-dollar-sign.js
var __iconNode366 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8", key: "1h4pet" }],
  ["path", { d: "M12 18V6", key: "zqpxq5" }]
];
var CircleDollarSign = createLucideIcon("circle-dollar-sign", __iconNode366);

// ../node_modules/lucide-react/dist/esm/icons/circle-dot-dashed.js
var __iconNode367 = [
  ["path", { d: "M10.1 2.18a9.93 9.93 0 0 1 3.8 0", key: "1qdqn0" }],
  ["path", { d: "M17.6 3.71a9.95 9.95 0 0 1 2.69 2.7", key: "1bq7p6" }],
  ["path", { d: "M21.82 10.1a9.93 9.93 0 0 1 0 3.8", key: "1rlaqf" }],
  ["path", { d: "M20.29 17.6a9.95 9.95 0 0 1-2.7 2.69", key: "1xk03u" }],
  ["path", { d: "M13.9 21.82a9.94 9.94 0 0 1-3.8 0", key: "l7re25" }],
  ["path", { d: "M6.4 20.29a9.95 9.95 0 0 1-2.69-2.7", key: "1v18p6" }],
  ["path", { d: "M2.18 13.9a9.93 9.93 0 0 1 0-3.8", key: "xdo6bj" }],
  ["path", { d: "M3.71 6.4a9.95 9.95 0 0 1 2.7-2.69", key: "1jjmaz" }],
  ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }]
];
var CircleDotDashed = createLucideIcon("circle-dot-dashed", __iconNode367);

// ../node_modules/lucide-react/dist/esm/icons/circle-dot.js
var __iconNode368 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }]
];
var CircleDot = createLucideIcon("circle-dot", __iconNode368);

// ../node_modules/lucide-react/dist/esm/icons/circle-ellipsis.js
var __iconNode369 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M17 12h.01", key: "1m0b6t" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M7 12h.01", key: "eqddd0" }]
];
var CircleEllipsis = createLucideIcon("circle-ellipsis", __iconNode369);

// ../node_modules/lucide-react/dist/esm/icons/circle-equal.js
var __iconNode370 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M7 10h10", key: "1101jm" }],
  ["path", { d: "M7 14h10", key: "1mhdw3" }]
];
var CircleEqual = createLucideIcon("circle-equal", __iconNode370);

// ../node_modules/lucide-react/dist/esm/icons/circle-fading-arrow-up.js
var __iconNode371 = [
  ["path", { d: "M12 2a10 10 0 0 1 7.38 16.75", key: "175t95" }],
  ["path", { d: "m16 12-4-4-4 4", key: "177agl" }],
  ["path", { d: "M12 16V8", key: "1sbj14" }],
  ["path", { d: "M2.5 8.875a10 10 0 0 0-.5 3", key: "1vce0s" }],
  ["path", { d: "M2.83 16a10 10 0 0 0 2.43 3.4", key: "o3fkw4" }],
  ["path", { d: "M4.636 5.235a10 10 0 0 1 .891-.857", key: "1szpfk" }],
  ["path", { d: "M8.644 21.42a10 10 0 0 0 7.631-.38", key: "9yhvd4" }]
];
var CircleFadingArrowUp = createLucideIcon("circle-fading-arrow-up", __iconNode371);

// ../node_modules/lucide-react/dist/esm/icons/circle-fading-plus.js
var __iconNode372 = [
  ["path", { d: "M12 2a10 10 0 0 1 7.38 16.75", key: "175t95" }],
  ["path", { d: "M12 8v8", key: "napkw2" }],
  ["path", { d: "M16 12H8", key: "1fr5h0" }],
  ["path", { d: "M2.5 8.875a10 10 0 0 0-.5 3", key: "1vce0s" }],
  ["path", { d: "M2.83 16a10 10 0 0 0 2.43 3.4", key: "o3fkw4" }],
  ["path", { d: "M4.636 5.235a10 10 0 0 1 .891-.857", key: "1szpfk" }],
  ["path", { d: "M8.644 21.42a10 10 0 0 0 7.631-.38", key: "9yhvd4" }]
];
var CircleFadingPlus = createLucideIcon("circle-fading-plus", __iconNode372);

// ../node_modules/lucide-react/dist/esm/icons/circle-gauge.js
var __iconNode373 = [
  ["path", { d: "M15.6 2.7a10 10 0 1 0 5.7 5.7", key: "1e0p6d" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }],
  ["path", { d: "M13.4 10.6 19 5", key: "1kr7tw" }]
];
var CircleGauge = createLucideIcon("circle-gauge", __iconNode373);

// ../node_modules/lucide-react/dist/esm/icons/circle-minus.js
var __iconNode374 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }]
];
var CircleMinus = createLucideIcon("circle-minus", __iconNode374);

// ../node_modules/lucide-react/dist/esm/icons/circle-off.js
var __iconNode375 = [
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M8.35 2.69A10 10 0 0 1 21.3 15.65", key: "1pfsoa" }],
  ["path", { d: "M19.08 19.08A10 10 0 1 1 4.92 4.92", key: "1ablyi" }]
];
var CircleOff = createLucideIcon("circle-off", __iconNode375);

// ../node_modules/lucide-react/dist/esm/icons/circle-parking-off.js
var __iconNode376 = [
  ["path", { d: "M12.656 7H13a3 3 0 0 1 2.984 3.307", key: "1sjx87" }],
  ["path", { d: "M13 13H9", key: "e2beee" }],
  ["path", { d: "M19.071 19.071A1 1 0 0 1 4.93 4.93", key: "1kb595" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M8.357 2.687a10 10 0 0 1 12.956 12.956", key: "5bsfdx" }],
  ["path", { d: "M9 17V9", key: "ojradj" }]
];
var CircleParkingOff = createLucideIcon("circle-parking-off", __iconNode376);

// ../node_modules/lucide-react/dist/esm/icons/circle-parking.js
var __iconNode377 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M9 17V7h4a3 3 0 0 1 0 6H9", key: "1dfk2c" }]
];
var CircleParking = createLucideIcon("circle-parking", __iconNode377);

// ../node_modules/lucide-react/dist/esm/icons/circle-percent.js
var __iconNode378 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "M9 9h.01", key: "1q5me6" }],
  ["path", { d: "M15 15h.01", key: "lqbp3k" }]
];
var CirclePercent = createLucideIcon("circle-percent", __iconNode378);

// ../node_modules/lucide-react/dist/esm/icons/circle-pause.js
var __iconNode379 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "10", x2: "10", y1: "15", y2: "9", key: "c1nkhi" }],
  ["line", { x1: "14", x2: "14", y1: "15", y2: "9", key: "h65svq" }]
];
var CirclePause = createLucideIcon("circle-pause", __iconNode379);

// ../node_modules/lucide-react/dist/esm/icons/circle-pile.js
var __iconNode380 = [
  ["circle", { cx: "12", cy: "19", r: "2", key: "13j0tp" }],
  ["circle", { cx: "12", cy: "5", r: "2", key: "f1ur92" }],
  ["circle", { cx: "16", cy: "12", r: "2", key: "4ma0v8" }],
  ["circle", { cx: "20", cy: "19", r: "2", key: "1obnsp" }],
  ["circle", { cx: "4", cy: "19", r: "2", key: "p3m9r0" }],
  ["circle", { cx: "8", cy: "12", r: "2", key: "1nvbw3" }]
];
var CirclePile = createLucideIcon("circle-pile", __iconNode380);

// ../node_modules/lucide-react/dist/esm/icons/circle-play.js
var __iconNode381 = [
  [
    "path",
    {
      d: "M9 9.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997A1 1 0 0 1 9 14.996z",
      key: "kmsa83"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
];
var CirclePlay = createLucideIcon("circle-play", __iconNode381);

// ../node_modules/lucide-react/dist/esm/icons/circle-plus.js
var __iconNode382 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }],
  ["path", { d: "M12 8v8", key: "napkw2" }]
];
var CirclePlus = createLucideIcon("circle-plus", __iconNode382);

// ../node_modules/lucide-react/dist/esm/icons/circle-pound-sterling.js
var __iconNode383 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M10 16V9.5a1 1 0 0 1 5 0", key: "1i1are" }],
  ["path", { d: "M8 12h4", key: "qz6y1c" }],
  ["path", { d: "M8 16h7", key: "sbedsn" }]
];
var CirclePoundSterling = createLucideIcon("circle-pound-sterling", __iconNode383);

// ../node_modules/lucide-react/dist/esm/icons/circle-power.js
var __iconNode384 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 7v4", key: "xawao1" }],
  ["path", { d: "M7.998 9.003a5 5 0 1 0 8-.005", key: "1pek45" }]
];
var CirclePower = createLucideIcon("circle-power", __iconNode384);

// ../node_modules/lucide-react/dist/esm/icons/circle-question-mark.js
var __iconNode385 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3", key: "1u773s" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
];
var CircleQuestionMark = createLucideIcon("circle-question-mark", __iconNode385);

// ../node_modules/lucide-react/dist/esm/icons/circle-slash-2.js
var __iconNode386 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M22 2 2 22", key: "y4kqgn" }]
];
var CircleSlash2 = createLucideIcon("circle-slash-2", __iconNode386);

// ../node_modules/lucide-react/dist/esm/icons/circle-slash.js
var __iconNode387 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "9", x2: "15", y1: "15", y2: "9", key: "1dfufj" }]
];
var CircleSlash = createLucideIcon("circle-slash", __iconNode387);

// ../node_modules/lucide-react/dist/esm/icons/circle-small.js
var __iconNode388 = [["circle", { cx: "12", cy: "12", r: "6", key: "1vlfrh" }]];
var CircleSmall = createLucideIcon("circle-small", __iconNode388);

// ../node_modules/lucide-react/dist/esm/icons/circle-star.js
var __iconNode389 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  [
    "path",
    {
      d: "M11.051 7.616a1 1 0 0 1 1.909.024l.737 1.452a1 1 0 0 0 .737.535l1.634.256a1 1 0 0 1 .588 1.806l-1.172 1.168a1 1 0 0 0-.282.866l.259 1.613a1 1 0 0 1-1.541 1.134l-1.465-.75a1 1 0 0 0-.912 0l-1.465.75a1 1 0 0 1-1.539-1.133l.258-1.613a1 1 0 0 0-.282-.867l-1.156-1.152a1 1 0 0 1 .572-1.822l1.633-.256a1 1 0 0 0 .737-.535z",
      key: "285bvi"
    }
  ]
];
var CircleStar = createLucideIcon("circle-star", __iconNode389);

// ../node_modules/lucide-react/dist/esm/icons/circle-stop.js
var __iconNode390 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["rect", { x: "9", y: "9", width: "6", height: "6", rx: "1", key: "1ssd4o" }]
];
var CircleStop = createLucideIcon("circle-stop", __iconNode390);

// ../node_modules/lucide-react/dist/esm/icons/circle-user-round.js
var __iconNode391 = [
  ["path", { d: "M18 20a6 6 0 0 0-12 0", key: "1qehca" }],
  ["circle", { cx: "12", cy: "10", r: "4", key: "1h16sb" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
];
var CircleUserRound = createLucideIcon("circle-user-round", __iconNode391);

// ../node_modules/lucide-react/dist/esm/icons/circle-user.js
var __iconNode392 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }],
  ["path", { d: "M7 20.662V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.662", key: "154egf" }]
];
var CircleUser = createLucideIcon("circle-user", __iconNode392);

// ../node_modules/lucide-react/dist/esm/icons/circle-x.js
var __iconNode393 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "m9 9 6 6", key: "z0biqf" }]
];
var CircleX = createLucideIcon("circle-x", __iconNode393);

// ../node_modules/lucide-react/dist/esm/icons/circle.js
var __iconNode394 = [["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]];
var Circle = createLucideIcon("circle", __iconNode394);

// ../node_modules/lucide-react/dist/esm/icons/circuit-board.js
var __iconNode395 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M11 9h4a2 2 0 0 0 2-2V3", key: "1ve2rv" }],
  ["circle", { cx: "9", cy: "9", r: "2", key: "af1f0g" }],
  ["path", { d: "M7 21v-4a2 2 0 0 1 2-2h4", key: "1fwkro" }],
  ["circle", { cx: "15", cy: "15", r: "2", key: "3i40o0" }]
];
var CircuitBoard = createLucideIcon("circuit-board", __iconNode395);

// ../node_modules/lucide-react/dist/esm/icons/citrus.js
var __iconNode396 = [
  [
    "path",
    {
      d: "M21.66 17.67a1.08 1.08 0 0 1-.04 1.6A12 12 0 0 1 4.73 2.38a1.1 1.1 0 0 1 1.61-.04z",
      key: "4ite01"
    }
  ],
  ["path", { d: "M19.65 15.66A8 8 0 0 1 8.35 4.34", key: "1gxipu" }],
  ["path", { d: "m14 10-5.5 5.5", key: "92pfem" }],
  ["path", { d: "M14 17.85V10H6.15", key: "xqmtsk" }]
];
var Citrus = createLucideIcon("citrus", __iconNode396);

// ../node_modules/lucide-react/dist/esm/icons/clapperboard.js
var __iconNode397 = [
  ["path", { d: "m12.296 3.464 3.02 3.956", key: "qash78" }],
  [
    "path",
    { d: "M20.2 6 3 11l-.9-2.4c-.3-1.1.3-2.2 1.3-2.5l13.5-4c1.1-.3 2.2.3 2.5 1.3z", key: "1h7j8b" }
  ],
  ["path", { d: "M3 11h18v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z", key: "4lm6w1" }],
  ["path", { d: "m6.18 5.276 3.1 3.899", key: "zjj9t3" }]
];
var Clapperboard = createLucideIcon("clapperboard", __iconNode397);

// ../node_modules/lucide-react/dist/esm/icons/clipboard-check.js
var __iconNode398 = [
  ["rect", { width: "8", height: "4", x: "8", y: "2", rx: "1", ry: "1", key: "tgr4d6" }],
  [
    "path",
    {
      d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
      key: "116196"
    }
  ],
  ["path", { d: "m9 14 2 2 4-4", key: "df797q" }]
];
var ClipboardCheck = createLucideIcon("clipboard-check", __iconNode398);

// ../node_modules/lucide-react/dist/esm/icons/clipboard-clock.js
var __iconNode399 = [
  ["path", { d: "M16 14v2.2l1.6 1", key: "fo4ql5" }],
  ["path", { d: "M16 4h2a2 2 0 0 1 2 2v.832", key: "1ujtp2" }],
  ["path", { d: "M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h2", key: "qvpao1" }],
  ["circle", { cx: "16", cy: "16", r: "6", key: "qoo3c4" }],
  ["rect", { x: "8", y: "2", width: "8", height: "4", rx: "1", key: "ublpy" }]
];
var ClipboardClock = createLucideIcon("clipboard-clock", __iconNode399);

// ../node_modules/lucide-react/dist/esm/icons/clipboard-copy.js
var __iconNode400 = [
  ["rect", { width: "8", height: "4", x: "8", y: "2", rx: "1", ry: "1", key: "tgr4d6" }],
  ["path", { d: "M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2", key: "4jdomd" }],
  ["path", { d: "M16 4h2a2 2 0 0 1 2 2v4", key: "3hqy98" }],
  ["path", { d: "M21 14H11", key: "1bme5i" }],
  ["path", { d: "m15 10-4 4 4 4", key: "5dvupr" }]
];
var ClipboardCopy = createLucideIcon("clipboard-copy", __iconNode400);

// ../node_modules/lucide-react/dist/esm/icons/clipboard-minus.js
var __iconNode401 = [
  ["rect", { width: "8", height: "4", x: "8", y: "2", rx: "1", ry: "1", key: "tgr4d6" }],
  [
    "path",
    {
      d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
      key: "116196"
    }
  ],
  ["path", { d: "M9 14h6", key: "159ibu" }]
];
var ClipboardMinus = createLucideIcon("clipboard-minus", __iconNode401);

// ../node_modules/lucide-react/dist/esm/icons/clipboard-list.js
var __iconNode402 = [
  ["rect", { width: "8", height: "4", x: "8", y: "2", rx: "1", ry: "1", key: "tgr4d6" }],
  [
    "path",
    {
      d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
      key: "116196"
    }
  ],
  ["path", { d: "M12 11h4", key: "1jrz19" }],
  ["path", { d: "M12 16h4", key: "n85exb" }],
  ["path", { d: "M8 11h.01", key: "1dfujw" }],
  ["path", { d: "M8 16h.01", key: "18s6g9" }]
];
var ClipboardList = createLucideIcon("clipboard-list", __iconNode402);

// ../node_modules/lucide-react/dist/esm/icons/clipboard-paste.js
var __iconNode403 = [
  ["path", { d: "M11 14h10", key: "1w8e9d" }],
  ["path", { d: "M16 4h2a2 2 0 0 1 2 2v1.344", key: "1e62lh" }],
  ["path", { d: "m17 18 4-4-4-4", key: "z2g111" }],
  ["path", { d: "M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 1.793-1.113", key: "bjbb7m" }],
  ["rect", { x: "8", y: "2", width: "8", height: "4", rx: "1", key: "ublpy" }]
];
var ClipboardPaste = createLucideIcon("clipboard-paste", __iconNode403);

// ../node_modules/lucide-react/dist/esm/icons/clipboard-pen-line.js
var __iconNode404 = [
  ["rect", { width: "8", height: "4", x: "8", y: "2", rx: "1", key: "1oijnt" }],
  ["path", { d: "M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-.5", key: "1but9f" }],
  ["path", { d: "M16 4h2a2 2 0 0 1 1.73 1", key: "1p8n7l" }],
  ["path", { d: "M8 18h1", key: "13wk12" }],
  [
    "path",
    {
      d: "M21.378 12.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
      key: "2t3380"
    }
  ]
];
var ClipboardPenLine = createLucideIcon("clipboard-pen-line", __iconNode404);

// ../node_modules/lucide-react/dist/esm/icons/clipboard-pen.js
var __iconNode405 = [
  ["path", { d: "M16 4h2a2 2 0 0 1 2 2v2", key: "j91f56" }],
  [
    "path",
    {
      d: "M21.34 15.664a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
      key: "16fuwn"
    }
  ],
  ["path", { d: "M8 22H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2", key: "120tdm" }],
  ["rect", { x: "8", y: "2", width: "8", height: "4", rx: "1", key: "ublpy" }]
];
var ClipboardPen = createLucideIcon("clipboard-pen", __iconNode405);

// ../node_modules/lucide-react/dist/esm/icons/clipboard-type.js
var __iconNode406 = [
  ["rect", { width: "8", height: "4", x: "8", y: "2", rx: "1", ry: "1", key: "tgr4d6" }],
  [
    "path",
    {
      d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
      key: "116196"
    }
  ],
  ["path", { d: "M9 12v-1h6v1", key: "iehl6m" }],
  ["path", { d: "M11 17h2", key: "12w5me" }],
  ["path", { d: "M12 11v6", key: "1bwqyc" }]
];
var ClipboardType = createLucideIcon("clipboard-type", __iconNode406);

// ../node_modules/lucide-react/dist/esm/icons/clipboard-plus.js
var __iconNode407 = [
  ["rect", { width: "8", height: "4", x: "8", y: "2", rx: "1", ry: "1", key: "tgr4d6" }],
  [
    "path",
    {
      d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
      key: "116196"
    }
  ],
  ["path", { d: "M9 14h6", key: "159ibu" }],
  ["path", { d: "M12 17v-6", key: "1y8rbf" }]
];
var ClipboardPlus = createLucideIcon("clipboard-plus", __iconNode407);

// ../node_modules/lucide-react/dist/esm/icons/clipboard-x.js
var __iconNode408 = [
  ["rect", { width: "8", height: "4", x: "8", y: "2", rx: "1", ry: "1", key: "tgr4d6" }],
  [
    "path",
    {
      d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
      key: "116196"
    }
  ],
  ["path", { d: "m15 11-6 6", key: "1toa9n" }],
  ["path", { d: "m9 11 6 6", key: "wlibny" }]
];
var ClipboardX = createLucideIcon("clipboard-x", __iconNode408);

// ../node_modules/lucide-react/dist/esm/icons/clipboard.js
var __iconNode409 = [
  ["rect", { width: "8", height: "4", x: "8", y: "2", rx: "1", ry: "1", key: "tgr4d6" }],
  [
    "path",
    {
      d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
      key: "116196"
    }
  ]
];
var Clipboard = createLucideIcon("clipboard", __iconNode409);

// ../node_modules/lucide-react/dist/esm/icons/clock-1.js
var __iconNode410 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6l2-4", key: "miptyd" }]
];
var Clock1 = createLucideIcon("clock-1", __iconNode410);

// ../node_modules/lucide-react/dist/esm/icons/clock-10.js
var __iconNode411 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6l-4-2", key: "cedpoo" }]
];
var Clock10 = createLucideIcon("clock-10", __iconNode411);

// ../node_modules/lucide-react/dist/esm/icons/clock-11.js
var __iconNode412 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6l-2-4", key: "ns39ag" }]
];
var Clock11 = createLucideIcon("clock-11", __iconNode412);

// ../node_modules/lucide-react/dist/esm/icons/clock-12.js
var __iconNode413 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6", key: "1ipuwl" }]
];
var Clock12 = createLucideIcon("clock-12", __iconNode413);

// ../node_modules/lucide-react/dist/esm/icons/clock-2.js
var __iconNode414 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6l4-2", key: "1r2kuh" }]
];
var Clock2 = createLucideIcon("clock-2", __iconNode414);

// ../node_modules/lucide-react/dist/esm/icons/clock-3.js
var __iconNode415 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6h4", key: "135r8i" }]
];
var Clock3 = createLucideIcon("clock-3", __iconNode415);

// ../node_modules/lucide-react/dist/esm/icons/clock-4.js
var __iconNode416 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6l4 2", key: "mmk7yg" }]
];
var Clock4 = createLucideIcon("clock-4", __iconNode416);

// ../node_modules/lucide-react/dist/esm/icons/clock-5.js
var __iconNode417 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6l2 4", key: "1287s9" }]
];
var Clock5 = createLucideIcon("clock-5", __iconNode417);

// ../node_modules/lucide-react/dist/esm/icons/clock-6.js
var __iconNode418 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v10", key: "wf7rdh" }]
];
var Clock6 = createLucideIcon("clock-6", __iconNode418);

// ../node_modules/lucide-react/dist/esm/icons/clock-7.js
var __iconNode419 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6l-2 4", key: "1095bu" }]
];
var Clock7 = createLucideIcon("clock-7", __iconNode419);

// ../node_modules/lucide-react/dist/esm/icons/clock-8.js
var __iconNode420 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6l-4 2", key: "imc3wl" }]
];
var Clock8 = createLucideIcon("clock-8", __iconNode420);

// ../node_modules/lucide-react/dist/esm/icons/clock-9.js
var __iconNode421 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6H8", key: "u39vzm" }]
];
var Clock9 = createLucideIcon("clock-9", __iconNode421);

// ../node_modules/lucide-react/dist/esm/icons/clock-alert.js
var __iconNode422 = [
  ["path", { d: "M12 6v6l4 2", key: "mmk7yg" }],
  ["path", { d: "M20 12v5", key: "12wsvk" }],
  ["path", { d: "M20 21h.01", key: "1p6o6n" }],
  ["path", { d: "M21.25 8.2A10 10 0 1 0 16 21.16", key: "17fp9f" }]
];
var ClockAlert = createLucideIcon("clock-alert", __iconNode422);

// ../node_modules/lucide-react/dist/esm/icons/clock-arrow-down.js
var __iconNode423 = [
  ["path", { d: "M12 6v6l2 1", key: "19cm8n" }],
  ["path", { d: "M12.337 21.994a10 10 0 1 1 9.588-8.767", key: "28moa" }],
  ["path", { d: "m14 18 4 4 4-4", key: "1waygx" }],
  ["path", { d: "M18 14v8", key: "irew45" }]
];
var ClockArrowDown = createLucideIcon("clock-arrow-down", __iconNode423);

// ../node_modules/lucide-react/dist/esm/icons/clock-arrow-up.js
var __iconNode424 = [
  ["path", { d: "M12 6v6l1.56.78", key: "14ed3g" }],
  ["path", { d: "M13.227 21.925a10 10 0 1 1 8.767-9.588", key: "jwkls1" }],
  ["path", { d: "m14 18 4-4 4 4", key: "ftkppy" }],
  ["path", { d: "M18 22v-8", key: "su0gjh" }]
];
var ClockArrowUp = createLucideIcon("clock-arrow-up", __iconNode424);

// ../node_modules/lucide-react/dist/esm/icons/clock-check.js
var __iconNode425 = [
  ["path", { d: "M12 6v6l4 2", key: "mmk7yg" }],
  ["path", { d: "M22 12a10 10 0 1 0-11 9.95", key: "17dhok" }],
  ["path", { d: "m22 16-5.5 5.5L14 19", key: "1eibut" }]
];
var ClockCheck = createLucideIcon("clock-check", __iconNode425);

// ../node_modules/lucide-react/dist/esm/icons/clock-fading.js
var __iconNode426 = [
  ["path", { d: "M12 2a10 10 0 0 1 7.38 16.75", key: "175t95" }],
  ["path", { d: "M12 6v6l4 2", key: "mmk7yg" }],
  ["path", { d: "M2.5 8.875a10 10 0 0 0-.5 3", key: "1vce0s" }],
  ["path", { d: "M2.83 16a10 10 0 0 0 2.43 3.4", key: "o3fkw4" }],
  ["path", { d: "M4.636 5.235a10 10 0 0 1 .891-.857", key: "1szpfk" }],
  ["path", { d: "M8.644 21.42a10 10 0 0 0 7.631-.38", key: "9yhvd4" }]
];
var ClockFading = createLucideIcon("clock-fading", __iconNode426);

// ../node_modules/lucide-react/dist/esm/icons/clock-plus.js
var __iconNode427 = [
  ["path", { d: "M12 6v6l3.644 1.822", key: "1jmett" }],
  ["path", { d: "M16 19h6", key: "xwg31i" }],
  ["path", { d: "M19 16v6", key: "tddt3s" }],
  ["path", { d: "M21.92 13.267a10 10 0 1 0-8.653 8.653", key: "1u0osk" }]
];
var ClockPlus = createLucideIcon("clock-plus", __iconNode427);

// ../node_modules/lucide-react/dist/esm/icons/clock.js
var __iconNode428 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 6v6l4 2", key: "mmk7yg" }]
];
var Clock = createLucideIcon("clock", __iconNode428);

// ../node_modules/lucide-react/dist/esm/icons/closed-caption.js
var __iconNode429 = [
  ["path", { d: "M10 9.17a3 3 0 1 0 0 5.66", key: "h9wayk" }],
  ["path", { d: "M17 9.17a3 3 0 1 0 0 5.66", key: "1v6zke" }],
  ["rect", { x: "2", y: "5", width: "20", height: "14", rx: "2", key: "qneu4z" }]
];
var ClosedCaption = createLucideIcon("closed-caption", __iconNode429);

// ../node_modules/lucide-react/dist/esm/icons/cloud-alert.js
var __iconNode430 = [
  ["path", { d: "M12 12v4", key: "tww15h" }],
  ["path", { d: "M12 20h.01", key: "zekei9" }],
  ["path", { d: "M8.128 16.949A7 7 0 1 1 15.71 8h1.79a1 1 0 0 1 0 9h-1.642", key: "1namsd" }]
];
var CloudAlert = createLucideIcon("cloud-alert", __iconNode430);

// ../node_modules/lucide-react/dist/esm/icons/cloud-backup.js
var __iconNode431 = [
  ["path", { d: "M21 15.251A4.5 4.5 0 0 0 17.5 8h-1.79A7 7 0 1 0 3 13.607", key: "xpoh9y" }],
  ["path", { d: "M7 11v4h4", key: "q9yh32" }],
  [
    "path",
    {
      d: "M8 19a5 5 0 0 0 9-3 4.5 4.5 0 0 0-4.5-4.5 4.82 4.82 0 0 0-3.41 1.41L7 15",
      key: "1xm8iu"
    }
  ]
];
var CloudBackup = createLucideIcon("cloud-backup", __iconNode431);

// ../node_modules/lucide-react/dist/esm/icons/cloud-check.js
var __iconNode432 = [
  ["path", { d: "m17 15-5.5 5.5L9 18", key: "15q87x" }],
  ["path", { d: "M5.516 16.07A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 3.501 7.327", key: "1xtj56" }]
];
var CloudCheck = createLucideIcon("cloud-check", __iconNode432);

// ../node_modules/lucide-react/dist/esm/icons/cloud-cog.js
var __iconNode433 = [
  ["path", { d: "m10.852 19.772-.383.924", key: "r7sl7d" }],
  ["path", { d: "m13.148 14.228.383-.923", key: "1d5zpm" }],
  ["path", { d: "M13.148 19.772a3 3 0 1 0-2.296-5.544l-.383-.923", key: "1ydik7" }],
  ["path", { d: "m13.53 20.696-.382-.924a3 3 0 1 1-2.296-5.544", key: "1m1vsf" }],
  ["path", { d: "m14.772 15.852.923-.383", key: "660p6e" }],
  ["path", { d: "m14.772 18.148.923.383", key: "hrcpis" }],
  [
    "path",
    {
      d: "M4.2 15.1a7 7 0 1 1 9.93-9.858A7 7 0 0 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.2",
      key: "j2q98n"
    }
  ],
  ["path", { d: "m9.228 15.852-.923-.383", key: "1p9ong" }],
  ["path", { d: "m9.228 18.148-.923.383", key: "6558rz" }]
];
var CloudCog = createLucideIcon("cloud-cog", __iconNode433);

// ../node_modules/lucide-react/dist/esm/icons/cloud-download.js
var __iconNode434 = [
  ["path", { d: "M12 13v8l-4-4", key: "1f5nwf" }],
  ["path", { d: "m12 21 4-4", key: "1lfcce" }],
  ["path", { d: "M4.393 15.269A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.436 8.284", key: "ui1hmy" }]
];
var CloudDownload = createLucideIcon("cloud-download", __iconNode434);

// ../node_modules/lucide-react/dist/esm/icons/cloud-drizzle.js
var __iconNode435 = [
  ["path", { d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242", key: "1pljnt" }],
  ["path", { d: "M8 19v1", key: "1dk2by" }],
  ["path", { d: "M8 14v1", key: "84yxot" }],
  ["path", { d: "M16 19v1", key: "v220m7" }],
  ["path", { d: "M16 14v1", key: "g12gj6" }],
  ["path", { d: "M12 21v1", key: "q8vafk" }],
  ["path", { d: "M12 16v1", key: "1mx6rx" }]
];
var CloudDrizzle = createLucideIcon("cloud-drizzle", __iconNode435);

// ../node_modules/lucide-react/dist/esm/icons/cloud-fog.js
var __iconNode436 = [
  ["path", { d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242", key: "1pljnt" }],
  ["path", { d: "M16 17H7", key: "pygtm1" }],
  ["path", { d: "M17 21H9", key: "1u2q02" }]
];
var CloudFog = createLucideIcon("cloud-fog", __iconNode436);

// ../node_modules/lucide-react/dist/esm/icons/cloud-hail.js
var __iconNode437 = [
  ["path", { d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242", key: "1pljnt" }],
  ["path", { d: "M16 14v2", key: "a1is7l" }],
  ["path", { d: "M8 14v2", key: "1e9m6t" }],
  ["path", { d: "M16 20h.01", key: "xwek51" }],
  ["path", { d: "M8 20h.01", key: "1vjney" }],
  ["path", { d: "M12 16v2", key: "z66u1j" }],
  ["path", { d: "M12 22h.01", key: "1urd7a" }]
];
var CloudHail = createLucideIcon("cloud-hail", __iconNode437);

// ../node_modules/lucide-react/dist/esm/icons/cloud-lightning.js
var __iconNode438 = [
  ["path", { d: "M6 16.326A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 .5 8.973", key: "1cez44" }],
  ["path", { d: "m13 12-3 5h4l-3 5", key: "1t22er" }]
];
var CloudLightning = createLucideIcon("cloud-lightning", __iconNode438);

// ../node_modules/lucide-react/dist/esm/icons/cloud-moon-rain.js
var __iconNode439 = [
  ["path", { d: "M11 20v2", key: "174qtz" }],
  [
    "path",
    {
      d: "M18.376 14.512a6 6 0 0 0 3.461-4.127c.148-.625-.659-.97-1.248-.714a4 4 0 0 1-5.259-5.26c.255-.589-.09-1.395-.716-1.248a6 6 0 0 0-4.594 5.36",
      key: "zwnc1e"
    }
  ],
  ["path", { d: "M3 20a5 5 0 1 1 8.9-4H13a3 3 0 0 1 2 5.24", key: "1qmrp3" }],
  ["path", { d: "M7 19v2", key: "12npes" }]
];
var CloudMoonRain = createLucideIcon("cloud-moon-rain", __iconNode439);

// ../node_modules/lucide-react/dist/esm/icons/cloud-moon.js
var __iconNode440 = [
  ["path", { d: "M13 16a3 3 0 0 1 0 6H7a5 5 0 1 1 4.9-6z", key: "ie2ih4" }],
  [
    "path",
    {
      d: "M18.376 14.512a6 6 0 0 0 3.461-4.127c.148-.625-.659-.97-1.248-.714a4 4 0 0 1-5.259-5.26c.255-.589-.09-1.395-.716-1.248a6 6 0 0 0-4.594 5.36",
      key: "zwnc1e"
    }
  ]
];
var CloudMoon = createLucideIcon("cloud-moon", __iconNode440);

// ../node_modules/lucide-react/dist/esm/icons/cloud-off.js
var __iconNode441 = [
  ["path", { d: "M10.94 5.274A7 7 0 0 1 15.71 10h1.79a4.5 4.5 0 0 1 4.222 6.057", key: "1uxyv8" }],
  ["path", { d: "M18.796 18.81A4.5 4.5 0 0 1 17.5 19H9A7 7 0 0 1 5.79 5.78", key: "99tcn7" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var CloudOff = createLucideIcon("cloud-off", __iconNode441);

// ../node_modules/lucide-react/dist/esm/icons/cloud-rain-wind.js
var __iconNode442 = [
  ["path", { d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242", key: "1pljnt" }],
  ["path", { d: "m9.2 22 3-7", key: "sb5f6j" }],
  ["path", { d: "m9 13-3 7", key: "500co5" }],
  ["path", { d: "m17 13-3 7", key: "8t2fiy" }]
];
var CloudRainWind = createLucideIcon("cloud-rain-wind", __iconNode442);

// ../node_modules/lucide-react/dist/esm/icons/cloud-rain.js
var __iconNode443 = [
  ["path", { d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242", key: "1pljnt" }],
  ["path", { d: "M16 14v6", key: "1j4efv" }],
  ["path", { d: "M8 14v6", key: "17c4r9" }],
  ["path", { d: "M12 16v6", key: "c8a4gj" }]
];
var CloudRain = createLucideIcon("cloud-rain", __iconNode443);

// ../node_modules/lucide-react/dist/esm/icons/cloud-snow.js
var __iconNode444 = [
  ["path", { d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242", key: "1pljnt" }],
  ["path", { d: "M8 15h.01", key: "a7atzg" }],
  ["path", { d: "M8 19h.01", key: "puxtts" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }],
  ["path", { d: "M12 21h.01", key: "h35vbk" }],
  ["path", { d: "M16 15h.01", key: "rnfrdf" }],
  ["path", { d: "M16 19h.01", key: "1vcnzz" }]
];
var CloudSnow = createLucideIcon("cloud-snow", __iconNode444);

// ../node_modules/lucide-react/dist/esm/icons/cloud-sun-rain.js
var __iconNode445 = [
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "m4.93 4.93 1.41 1.41", key: "149t6j" }],
  ["path", { d: "M20 12h2", key: "1q8mjw" }],
  ["path", { d: "m19.07 4.93-1.41 1.41", key: "1shlcs" }],
  ["path", { d: "M15.947 12.65a4 4 0 0 0-5.925-4.128", key: "dpwdj0" }],
  ["path", { d: "M3 20a5 5 0 1 1 8.9-4H13a3 3 0 0 1 2 5.24", key: "1qmrp3" }],
  ["path", { d: "M11 20v2", key: "174qtz" }],
  ["path", { d: "M7 19v2", key: "12npes" }]
];
var CloudSunRain = createLucideIcon("cloud-sun-rain", __iconNode445);

// ../node_modules/lucide-react/dist/esm/icons/cloud-sun.js
var __iconNode446 = [
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "m4.93 4.93 1.41 1.41", key: "149t6j" }],
  ["path", { d: "M20 12h2", key: "1q8mjw" }],
  ["path", { d: "m19.07 4.93-1.41 1.41", key: "1shlcs" }],
  ["path", { d: "M15.947 12.65a4 4 0 0 0-5.925-4.128", key: "dpwdj0" }],
  ["path", { d: "M13 22H7a5 5 0 1 1 4.9-6H13a3 3 0 0 1 0 6Z", key: "s09mg5" }]
];
var CloudSun = createLucideIcon("cloud-sun", __iconNode446);

// ../node_modules/lucide-react/dist/esm/icons/cloud-sync.js
var __iconNode447 = [
  ["path", { d: "m17 18-1.535 1.605a5 5 0 0 1-8-1.5", key: "adpv5j" }],
  ["path", { d: "M17 22v-4h-4", key: "ex1ofj" }],
  [
    "path",
    { d: "M20.996 15.251A4.5 4.5 0 0 0 17.495 8h-1.79a7 7 0 1 0-12.709 5.607", key: "ziqt14" }
  ],
  ["path", { d: "M7 10v4h4", key: "1j6gx1" }],
  ["path", { d: "m7 14 1.535-1.605a5 5 0 0 1 8 1.5", key: "19q5h7" }]
];
var CloudSync = createLucideIcon("cloud-sync", __iconNode447);

// ../node_modules/lucide-react/dist/esm/icons/cloud-upload.js
var __iconNode448 = [
  ["path", { d: "M12 13v8", key: "1l5pq0" }],
  ["path", { d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242", key: "1pljnt" }],
  ["path", { d: "m8 17 4-4 4 4", key: "1quai1" }]
];
var CloudUpload = createLucideIcon("cloud-upload", __iconNode448);

// ../node_modules/lucide-react/dist/esm/icons/cloudy.js
var __iconNode449 = [
  ["path", { d: "M17.5 12a1 1 0 1 1 0 9H9.006a7 7 0 1 1 6.702-9z", key: "44yre2" }],
  ["path", { d: "M21.832 9A3 3 0 0 0 19 7h-2.207a5.5 5.5 0 0 0-10.72.61", key: "leugyv" }]
];
var Cloudy = createLucideIcon("cloudy", __iconNode449);

// ../node_modules/lucide-react/dist/esm/icons/cloud.js
var __iconNode450 = [
  ["path", { d: "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z", key: "p7xjir" }]
];
var Cloud = createLucideIcon("cloud", __iconNode450);

// ../node_modules/lucide-react/dist/esm/icons/clover.js
var __iconNode451 = [
  ["path", { d: "M16.17 7.83 2 22", key: "t58vo8" }],
  [
    "path",
    {
      d: "M4.02 12a2.827 2.827 0 1 1 3.81-4.17A2.827 2.827 0 1 1 12 4.02a2.827 2.827 0 1 1 4.17 3.81A2.827 2.827 0 1 1 19.98 12a2.827 2.827 0 1 1-3.81 4.17A2.827 2.827 0 1 1 12 19.98a2.827 2.827 0 1 1-4.17-3.81A1 1 0 1 1 4 12",
      key: "17k36q"
    }
  ],
  ["path", { d: "m7.83 7.83 8.34 8.34", key: "1d7sxk" }]
];
var Clover = createLucideIcon("clover", __iconNode451);

// ../node_modules/lucide-react/dist/esm/icons/club.js
var __iconNode452 = [
  [
    "path",
    {
      d: "M17.28 9.05a5.5 5.5 0 1 0-10.56 0A5.5 5.5 0 1 0 12 17.66a5.5 5.5 0 1 0 5.28-8.6Z",
      key: "27yuqz"
    }
  ],
  ["path", { d: "M12 17.66L12 22", key: "ogfahf" }]
];
var Club = createLucideIcon("club", __iconNode452);

// ../node_modules/lucide-react/dist/esm/icons/code-xml.js
var __iconNode453 = [
  ["path", { d: "m18 16 4-4-4-4", key: "1inbqp" }],
  ["path", { d: "m6 8-4 4 4 4", key: "15zrgr" }],
  ["path", { d: "m14.5 4-5 16", key: "e7oirm" }]
];
var CodeXml = createLucideIcon("code-xml", __iconNode453);

// ../node_modules/lucide-react/dist/esm/icons/code.js
var __iconNode454 = [
  ["path", { d: "m16 18 6-6-6-6", key: "eg8j8" }],
  ["path", { d: "m8 6-6 6 6 6", key: "ppft3o" }]
];
var Code = createLucideIcon("code", __iconNode454);

// ../node_modules/lucide-react/dist/esm/icons/codepen.js
var __iconNode455 = [
  ["polygon", { points: "12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5 12 2", key: "srzb37" }],
  ["line", { x1: "12", x2: "12", y1: "22", y2: "15.5", key: "1t73f2" }],
  ["polyline", { points: "22 8.5 12 15.5 2 8.5", key: "ajlxae" }],
  ["polyline", { points: "2 15.5 12 8.5 22 15.5", key: "susrui" }],
  ["line", { x1: "12", x2: "12", y1: "2", y2: "8.5", key: "2cldga" }]
];
var Codepen = createLucideIcon("codepen", __iconNode455);

// ../node_modules/lucide-react/dist/esm/icons/codesandbox.js
var __iconNode456 = [
  [
    "path",
    {
      d: "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z",
      key: "yt0hxn"
    }
  ],
  ["polyline", { points: "7.5 4.21 12 6.81 16.5 4.21", key: "fabo96" }],
  ["polyline", { points: "7.5 19.79 7.5 14.6 3 12", key: "z377f1" }],
  ["polyline", { points: "21 12 16.5 14.6 16.5 19.79", key: "9nrev1" }],
  ["polyline", { points: "3.27 6.96 12 12.01 20.73 6.96", key: "1180pa" }],
  ["line", { x1: "12", x2: "12", y1: "22.08", y2: "12", key: "3z3uq6" }]
];
var Codesandbox = createLucideIcon("codesandbox", __iconNode456);

// ../node_modules/lucide-react/dist/esm/icons/coffee.js
var __iconNode457 = [
  ["path", { d: "M10 2v2", key: "7u0qdc" }],
  ["path", { d: "M14 2v2", key: "6buw04" }],
  [
    "path",
    {
      d: "M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1",
      key: "pwadti"
    }
  ],
  ["path", { d: "M6 2v2", key: "colzsn" }]
];
var Coffee = createLucideIcon("coffee", __iconNode457);

// ../node_modules/lucide-react/dist/esm/icons/cog.js
var __iconNode458 = [
  ["path", { d: "M11 10.27 7 3.34", key: "16pf9h" }],
  ["path", { d: "m11 13.73-4 6.93", key: "794ttg" }],
  ["path", { d: "M12 22v-2", key: "1osdcq" }],
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "M14 12h8", key: "4f43i9" }],
  ["path", { d: "m17 20.66-1-1.73", key: "eq3orb" }],
  ["path", { d: "m17 3.34-1 1.73", key: "2wel8s" }],
  ["path", { d: "M2 12h2", key: "1t8f8n" }],
  ["path", { d: "m20.66 17-1.73-1", key: "sg0v6f" }],
  ["path", { d: "m20.66 7-1.73 1", key: "1ow05n" }],
  ["path", { d: "m3.34 17 1.73-1", key: "nuk764" }],
  ["path", { d: "m3.34 7 1.73 1", key: "1ulond" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }],
  ["circle", { cx: "12", cy: "12", r: "8", key: "46899m" }]
];
var Cog = createLucideIcon("cog", __iconNode458);

// ../node_modules/lucide-react/dist/esm/icons/coins.js
var __iconNode459 = [
  ["path", { d: "M13.744 17.736a6 6 0 1 1-7.48-7.48", key: "bq4yh3" }],
  ["path", { d: "M15 6h1v4", key: "11y1tn" }],
  ["path", { d: "m6.134 14.768.866-.5 2 3.464", key: "17snzx" }],
  ["circle", { cx: "16", cy: "8", r: "6", key: "14bfc9" }]
];
var Coins = createLucideIcon("coins", __iconNode459);

// ../node_modules/lucide-react/dist/esm/icons/columns-2.js
var __iconNode460 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M12 3v18", key: "108xh3" }]
];
var Columns2 = createLucideIcon("columns-2", __iconNode460);

// ../node_modules/lucide-react/dist/esm/icons/columns-3-cog.js
var __iconNode461 = [
  ["path", { d: "M10.5 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5.5", key: "1g2yzs" }],
  ["path", { d: "m14.3 19.6 1-.4", key: "11sv9r" }],
  ["path", { d: "M15 3v7.5", key: "7lm50a" }],
  ["path", { d: "m15.2 16.9-.9-.3", key: "1t7mvx" }],
  ["path", { d: "m16.6 21.7.3-.9", key: "1j67ps" }],
  ["path", { d: "m16.8 15.3-.4-1", key: "1ei7r6" }],
  ["path", { d: "m19.1 15.2.3-.9", key: "18r7jp" }],
  ["path", { d: "m19.6 21.7-.4-1", key: "z2vh2" }],
  ["path", { d: "m20.7 16.8 1-.4", key: "19m87a" }],
  ["path", { d: "m21.7 19.4-.9-.3", key: "1qgwi9" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }],
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }]
];
var Columns3Cog = createLucideIcon("columns-3-cog", __iconNode461);

// ../node_modules/lucide-react/dist/esm/icons/columns-3.js
var __iconNode462 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }],
  ["path", { d: "M15 3v18", key: "14nvp0" }]
];
var Columns3 = createLucideIcon("columns-3", __iconNode462);

// ../node_modules/lucide-react/dist/esm/icons/columns-4.js
var __iconNode463 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M7.5 3v18", key: "w0wo6v" }],
  ["path", { d: "M12 3v18", key: "108xh3" }],
  ["path", { d: "M16.5 3v18", key: "10tjh1" }]
];
var Columns4 = createLucideIcon("columns-4", __iconNode463);

// ../node_modules/lucide-react/dist/esm/icons/combine.js
var __iconNode464 = [
  ["path", { d: "M14 3a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1", key: "1l7d7l" }],
  ["path", { d: "M19 3a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1", key: "9955pe" }],
  ["path", { d: "m7 15 3 3", key: "4hkfgk" }],
  ["path", { d: "m7 21 3-3H5a2 2 0 0 1-2-2v-2", key: "1xljwe" }],
  ["rect", { x: "14", y: "14", width: "7", height: "7", rx: "1", key: "1cdgtw" }],
  ["rect", { x: "3", y: "3", width: "7", height: "7", rx: "1", key: "zi3rio" }]
];
var Combine = createLucideIcon("combine", __iconNode464);

// ../node_modules/lucide-react/dist/esm/icons/command.js
var __iconNode465 = [
  [
    "path",
    { d: "M15 6v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3V6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3", key: "11bfej" }
  ]
];
var Command = createLucideIcon("command", __iconNode465);

// ../node_modules/lucide-react/dist/esm/icons/compass.js
var __iconNode466 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  [
    "path",
    {
      d: "m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z",
      key: "9ktpf1"
    }
  ]
];
var Compass = createLucideIcon("compass", __iconNode466);

// ../node_modules/lucide-react/dist/esm/icons/component.js
var __iconNode467 = [
  [
    "path",
    {
      d: "M15.536 11.293a1 1 0 0 0 0 1.414l2.376 2.377a1 1 0 0 0 1.414 0l2.377-2.377a1 1 0 0 0 0-1.414l-2.377-2.377a1 1 0 0 0-1.414 0z",
      key: "1uwlt4"
    }
  ],
  [
    "path",
    {
      d: "M2.297 11.293a1 1 0 0 0 0 1.414l2.377 2.377a1 1 0 0 0 1.414 0l2.377-2.377a1 1 0 0 0 0-1.414L6.088 8.916a1 1 0 0 0-1.414 0z",
      key: "10291m"
    }
  ],
  [
    "path",
    {
      d: "M8.916 17.912a1 1 0 0 0 0 1.415l2.377 2.376a1 1 0 0 0 1.414 0l2.377-2.376a1 1 0 0 0 0-1.415l-2.377-2.376a1 1 0 0 0-1.414 0z",
      key: "1tqoq1"
    }
  ],
  [
    "path",
    {
      d: "M8.916 4.674a1 1 0 0 0 0 1.414l2.377 2.376a1 1 0 0 0 1.414 0l2.377-2.376a1 1 0 0 0 0-1.414l-2.377-2.377a1 1 0 0 0-1.414 0z",
      key: "1x6lto"
    }
  ]
];
var Component = createLucideIcon("component", __iconNode467);

// ../node_modules/lucide-react/dist/esm/icons/computer.js
var __iconNode468 = [
  ["rect", { width: "14", height: "8", x: "5", y: "2", rx: "2", key: "wc9tft" }],
  ["rect", { width: "20", height: "8", x: "2", y: "14", rx: "2", key: "w68u3i" }],
  ["path", { d: "M6 18h2", key: "rwmk9e" }],
  ["path", { d: "M12 18h6", key: "aqd8w3" }]
];
var Computer = createLucideIcon("computer", __iconNode468);

// ../node_modules/lucide-react/dist/esm/icons/concierge-bell.js
var __iconNode469 = [
  [
    "path",
    { d: "M3 20a1 1 0 0 1-1-1v-1a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1Z", key: "1pvr1r" }
  ],
  ["path", { d: "M20 16a8 8 0 1 0-16 0", key: "1pa543" }],
  ["path", { d: "M12 4v4", key: "1bq03y" }],
  ["path", { d: "M10 4h4", key: "1xpv9s" }]
];
var ConciergeBell = createLucideIcon("concierge-bell", __iconNode469);

// ../node_modules/lucide-react/dist/esm/icons/cone.js
var __iconNode470 = [
  ["path", { d: "m20.9 18.55-8-15.98a1 1 0 0 0-1.8 0l-8 15.98", key: "53pte7" }],
  ["ellipse", { cx: "12", cy: "19", rx: "9", ry: "3", key: "1ji25f" }]
];
var Cone = createLucideIcon("cone", __iconNode470);

// ../node_modules/lucide-react/dist/esm/icons/construction.js
var __iconNode471 = [
  ["rect", { x: "2", y: "6", width: "20", height: "8", rx: "1", key: "1estib" }],
  ["path", { d: "M17 14v7", key: "7m2elx" }],
  ["path", { d: "M7 14v7", key: "1cm7wv" }],
  ["path", { d: "M17 3v3", key: "1v4jwn" }],
  ["path", { d: "M7 3v3", key: "7o6guu" }],
  ["path", { d: "M10 14 2.3 6.3", key: "1023jk" }],
  ["path", { d: "m14 6 7.7 7.7", key: "1s8pl2" }],
  ["path", { d: "m8 6 8 8", key: "hl96qh" }]
];
var Construction = createLucideIcon("construction", __iconNode471);

// ../node_modules/lucide-react/dist/esm/icons/contact-round.js
var __iconNode472 = [
  ["path", { d: "M16 2v2", key: "scm5qe" }],
  ["path", { d: "M17.915 22a6 6 0 0 0-12 0", key: "suqz9p" }],
  ["path", { d: "M8 2v2", key: "pbkmx" }],
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }],
  ["rect", { x: "3", y: "4", width: "18", height: "18", rx: "2", key: "12vinp" }]
];
var ContactRound = createLucideIcon("contact-round", __iconNode472);

// ../node_modules/lucide-react/dist/esm/icons/container.js
var __iconNode473 = [
  [
    "path",
    {
      d: "M22 7.7c0-.6-.4-1.2-.8-1.5l-6.3-3.9a1.72 1.72 0 0 0-1.7 0l-10.3 6c-.5.2-.9.8-.9 1.4v6.6c0 .5.4 1.2.8 1.5l6.3 3.9a1.72 1.72 0 0 0 1.7 0l10.3-6c.5-.3.9-1 .9-1.5Z",
      key: "1t2lqe"
    }
  ],
  ["path", { d: "M10 21.9V14L2.1 9.1", key: "o7czzq" }],
  ["path", { d: "m10 14 11.9-6.9", key: "zm5e20" }],
  ["path", { d: "M14 19.8v-8.1", key: "159ecu" }],
  ["path", { d: "M18 17.5V9.4", key: "11uown" }]
];
var Container = createLucideIcon("container", __iconNode473);

// ../node_modules/lucide-react/dist/esm/icons/contact.js
var __iconNode474 = [
  ["path", { d: "M16 2v2", key: "scm5qe" }],
  ["path", { d: "M7 22v-2a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v2", key: "1waht3" }],
  ["path", { d: "M8 2v2", key: "pbkmx" }],
  ["circle", { cx: "12", cy: "11", r: "3", key: "itu57m" }],
  ["rect", { x: "3", y: "4", width: "18", height: "18", rx: "2", key: "12vinp" }]
];
var Contact = createLucideIcon("contact", __iconNode474);

// ../node_modules/lucide-react/dist/esm/icons/cookie.js
var __iconNode475 = [
  ["path", { d: "M12 2a10 10 0 1 0 10 10 4 4 0 0 1-5-5 4 4 0 0 1-5-5", key: "laymnq" }],
  ["path", { d: "M8.5 8.5v.01", key: "ue8clq" }],
  ["path", { d: "M16 15.5v.01", key: "14dtrp" }],
  ["path", { d: "M12 12v.01", key: "u5ubse" }],
  ["path", { d: "M11 17v.01", key: "1hyl5a" }],
  ["path", { d: "M7 14v.01", key: "uct60s" }]
];
var Cookie = createLucideIcon("cookie", __iconNode475);

// ../node_modules/lucide-react/dist/esm/icons/contrast.js
var __iconNode476 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 18a6 6 0 0 0 0-12v12z", key: "j4l70d" }]
];
var Contrast = createLucideIcon("contrast", __iconNode476);

// ../node_modules/lucide-react/dist/esm/icons/cooking-pot.js
var __iconNode477 = [
  ["path", { d: "M2 12h20", key: "9i4pu4" }],
  ["path", { d: "M20 12v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-8", key: "u0tga0" }],
  ["path", { d: "m4 8 16-4", key: "16g0ng" }],
  [
    "path",
    {
      d: "m8.86 6.78-.45-1.81a2 2 0 0 1 1.45-2.43l1.94-.48a2 2 0 0 1 2.43 1.46l.45 1.8",
      key: "12cejc"
    }
  ]
];
var CookingPot = createLucideIcon("cooking-pot", __iconNode477);

// ../node_modules/lucide-react/dist/esm/icons/copy-check.js
var __iconNode478 = [
  ["path", { d: "m12 15 2 2 4-4", key: "2c609p" }],
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
];
var CopyCheck = createLucideIcon("copy-check", __iconNode478);

// ../node_modules/lucide-react/dist/esm/icons/copy-minus.js
var __iconNode479 = [
  ["line", { x1: "12", x2: "18", y1: "15", y2: "15", key: "1nscbv" }],
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
];
var CopyMinus = createLucideIcon("copy-minus", __iconNode479);

// ../node_modules/lucide-react/dist/esm/icons/copy-plus.js
var __iconNode480 = [
  ["line", { x1: "15", x2: "15", y1: "12", y2: "18", key: "1p7wdc" }],
  ["line", { x1: "12", x2: "18", y1: "15", y2: "15", key: "1nscbv" }],
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
];
var CopyPlus = createLucideIcon("copy-plus", __iconNode480);

// ../node_modules/lucide-react/dist/esm/icons/copy-slash.js
var __iconNode481 = [
  ["line", { x1: "12", x2: "18", y1: "18", y2: "12", key: "ebkxgr" }],
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
];
var CopySlash = createLucideIcon("copy-slash", __iconNode481);

// ../node_modules/lucide-react/dist/esm/icons/copy-x.js
var __iconNode482 = [
  ["line", { x1: "12", x2: "18", y1: "12", y2: "18", key: "1rg63v" }],
  ["line", { x1: "12", x2: "18", y1: "18", y2: "12", key: "ebkxgr" }],
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
];
var CopyX = createLucideIcon("copy-x", __iconNode482);

// ../node_modules/lucide-react/dist/esm/icons/copy.js
var __iconNode483 = [
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
];
var Copy = createLucideIcon("copy", __iconNode483);

// ../node_modules/lucide-react/dist/esm/icons/copyleft.js
var __iconNode484 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M9.17 14.83a4 4 0 1 0 0-5.66", key: "1sveal" }]
];
var Copyleft = createLucideIcon("copyleft", __iconNode484);

// ../node_modules/lucide-react/dist/esm/icons/copyright.js
var __iconNode485 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M14.83 14.83a4 4 0 1 1 0-5.66", key: "1i56pz" }]
];
var Copyright = createLucideIcon("copyright", __iconNode485);

// ../node_modules/lucide-react/dist/esm/icons/corner-down-left.js
var __iconNode486 = [
  ["path", { d: "M20 4v7a4 4 0 0 1-4 4H4", key: "6o5b7l" }],
  ["path", { d: "m9 10-5 5 5 5", key: "1kshq7" }]
];
var CornerDownLeft = createLucideIcon("corner-down-left", __iconNode486);

// ../node_modules/lucide-react/dist/esm/icons/corner-down-right.js
var __iconNode487 = [
  ["path", { d: "m15 10 5 5-5 5", key: "qqa56n" }],
  ["path", { d: "M4 4v7a4 4 0 0 0 4 4h12", key: "z08zvw" }]
];
var CornerDownRight = createLucideIcon("corner-down-right", __iconNode487);

// ../node_modules/lucide-react/dist/esm/icons/corner-left-up.js
var __iconNode488 = [
  ["path", { d: "M14 9 9 4 4 9", key: "1af5af" }],
  ["path", { d: "M20 20h-7a4 4 0 0 1-4-4V4", key: "1blwi3" }]
];
var CornerLeftUp = createLucideIcon("corner-left-up", __iconNode488);

// ../node_modules/lucide-react/dist/esm/icons/corner-left-down.js
var __iconNode489 = [
  ["path", { d: "m14 15-5 5-5-5", key: "1eia93" }],
  ["path", { d: "M20 4h-7a4 4 0 0 0-4 4v12", key: "nbpdq2" }]
];
var CornerLeftDown = createLucideIcon("corner-left-down", __iconNode489);

// ../node_modules/lucide-react/dist/esm/icons/corner-right-down.js
var __iconNode490 = [
  ["path", { d: "m10 15 5 5 5-5", key: "1hpjnr" }],
  ["path", { d: "M4 4h7a4 4 0 0 1 4 4v12", key: "wcbgct" }]
];
var CornerRightDown = createLucideIcon("corner-right-down", __iconNode490);

// ../node_modules/lucide-react/dist/esm/icons/corner-up-left.js
var __iconNode491 = [
  ["path", { d: "M20 20v-7a4 4 0 0 0-4-4H4", key: "1nkjon" }],
  ["path", { d: "M9 14 4 9l5-5", key: "102s5s" }]
];
var CornerUpLeft = createLucideIcon("corner-up-left", __iconNode491);

// ../node_modules/lucide-react/dist/esm/icons/corner-right-up.js
var __iconNode492 = [
  ["path", { d: "m10 9 5-5 5 5", key: "9ctzwi" }],
  ["path", { d: "M4 20h7a4 4 0 0 0 4-4V4", key: "1plgdj" }]
];
var CornerRightUp = createLucideIcon("corner-right-up", __iconNode492);

// ../node_modules/lucide-react/dist/esm/icons/corner-up-right.js
var __iconNode493 = [
  ["path", { d: "m15 14 5-5-5-5", key: "12vg1m" }],
  ["path", { d: "M4 20v-7a4 4 0 0 1 4-4h12", key: "1lu4f8" }]
];
var CornerUpRight = createLucideIcon("corner-up-right", __iconNode493);

// ../node_modules/lucide-react/dist/esm/icons/cpu.js
var __iconNode494 = [
  ["path", { d: "M12 20v2", key: "1lh1kg" }],
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "M17 20v2", key: "1rnc9c" }],
  ["path", { d: "M17 2v2", key: "11trls" }],
  ["path", { d: "M2 12h2", key: "1t8f8n" }],
  ["path", { d: "M2 17h2", key: "7oei6x" }],
  ["path", { d: "M2 7h2", key: "asdhe0" }],
  ["path", { d: "M20 12h2", key: "1q8mjw" }],
  ["path", { d: "M20 17h2", key: "1fpfkl" }],
  ["path", { d: "M20 7h2", key: "1o8tra" }],
  ["path", { d: "M7 20v2", key: "4gnj0m" }],
  ["path", { d: "M7 2v2", key: "1i4yhu" }],
  ["rect", { x: "4", y: "4", width: "16", height: "16", rx: "2", key: "1vbyd7" }],
  ["rect", { x: "8", y: "8", width: "8", height: "8", rx: "1", key: "z9xiuo" }]
];
var Cpu = createLucideIcon("cpu", __iconNode494);

// ../node_modules/lucide-react/dist/esm/icons/creative-commons.js
var __iconNode495 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  [
    "path",
    { d: "M10 9.3a2.8 2.8 0 0 0-3.5 1 3.1 3.1 0 0 0 0 3.4 2.7 2.7 0 0 0 3.5 1", key: "1ss3eq" }
  ],
  [
    "path",
    { d: "M17 9.3a2.8 2.8 0 0 0-3.5 1 3.1 3.1 0 0 0 0 3.4 2.7 2.7 0 0 0 3.5 1", key: "1od56t" }
  ]
];
var CreativeCommons = createLucideIcon("creative-commons", __iconNode495);

// ../node_modules/lucide-react/dist/esm/icons/credit-card.js
var __iconNode496 = [
  ["rect", { width: "20", height: "14", x: "2", y: "5", rx: "2", key: "ynyp8z" }],
  ["line", { x1: "2", x2: "22", y1: "10", y2: "10", key: "1b3vmo" }]
];
var CreditCard = createLucideIcon("credit-card", __iconNode496);

// ../node_modules/lucide-react/dist/esm/icons/crop.js
var __iconNode497 = [
  ["path", { d: "M6 2v14a2 2 0 0 0 2 2h14", key: "ron5a4" }],
  ["path", { d: "M18 22V8a2 2 0 0 0-2-2H2", key: "7s9ehn" }]
];
var Crop = createLucideIcon("crop", __iconNode497);

// ../node_modules/lucide-react/dist/esm/icons/croissant.js
var __iconNode498 = [
  ["path", { d: "M10.2 18H4.774a1.5 1.5 0 0 1-1.352-.97 11 11 0 0 1 .132-6.487", key: "14kkz9" }],
  ["path", { d: "M18 10.2V4.774a1.5 1.5 0 0 0-.97-1.352 11 11 0 0 0-6.486.132", key: "1g7v07" }],
  ["path", { d: "M18 5a4 3 0 0 1 4 3 2 2 0 0 1-2 2 10 10 0 0 0-5.139 1.42", key: "ratg6b" }],
  ["path", { d: "M5 18a3 4 0 0 0 3 4 2 2 0 0 0 2-2 10 10 0 0 1 1.42-5.14", key: "4454f0" }],
  [
    "path",
    {
      d: "M8.709 2.554a10 10 0 0 0-6.155 6.155 1.5 1.5 0 0 0 .676 1.626l9.807 5.42a2 2 0 0 0 2.718-2.718l-5.42-9.807a1.5 1.5 0 0 0-1.626-.676",
      key: "qmemie"
    }
  ]
];
var Croissant = createLucideIcon("croissant", __iconNode498);

// ../node_modules/lucide-react/dist/esm/icons/cross.js
var __iconNode499 = [
  [
    "path",
    {
      d: "M4 9a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h4a1 1 0 0 1 1 1v4a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2v-4a1 1 0 0 1 1-1h4a2 2 0 0 0 2-2v-2a2 2 0 0 0-2-2h-4a1 1 0 0 1-1-1V4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4a1 1 0 0 1-1 1z",
      key: "1xbrqy"
    }
  ]
];
var Cross = createLucideIcon("cross", __iconNode499);

// ../node_modules/lucide-react/dist/esm/icons/crosshair.js
var __iconNode500 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "22", x2: "18", y1: "12", y2: "12", key: "l9bcsi" }],
  ["line", { x1: "6", x2: "2", y1: "12", y2: "12", key: "13hhkx" }],
  ["line", { x1: "12", x2: "12", y1: "6", y2: "2", key: "10w3f3" }],
  ["line", { x1: "12", x2: "12", y1: "22", y2: "18", key: "15g9kq" }]
];
var Crosshair = createLucideIcon("crosshair", __iconNode500);

// ../node_modules/lucide-react/dist/esm/icons/crown.js
var __iconNode501 = [
  [
    "path",
    {
      d: "M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z",
      key: "1vdc57"
    }
  ],
  ["path", { d: "M5 21h14", key: "11awu3" }]
];
var Crown = createLucideIcon("crown", __iconNode501);

// ../node_modules/lucide-react/dist/esm/icons/cuboid.js
var __iconNode502 = [
  [
    "path",
    {
      d: "m21.12 6.4-6.05-4.06a2 2 0 0 0-2.17-.05L2.95 8.41a2 2 0 0 0-.95 1.7v5.82a2 2 0 0 0 .88 1.66l6.05 4.07a2 2 0 0 0 2.17.05l9.95-6.12a2 2 0 0 0 .95-1.7V8.06a2 2 0 0 0-.88-1.66Z",
      key: "1u2ovd"
    }
  ],
  ["path", { d: "M10 22v-8L2.25 9.15", key: "11pn4q" }],
  ["path", { d: "m10 14 11.77-6.87", key: "1kt1wh" }]
];
var Cuboid = createLucideIcon("cuboid", __iconNode502);

// ../node_modules/lucide-react/dist/esm/icons/cup-soda.js
var __iconNode503 = [
  ["path", { d: "m6 8 1.75 12.28a2 2 0 0 0 2 1.72h4.54a2 2 0 0 0 2-1.72L18 8", key: "8166m8" }],
  ["path", { d: "M5 8h14", key: "pcz4l3" }],
  ["path", { d: "M7 15a6.47 6.47 0 0 1 5 0 6.47 6.47 0 0 0 5 0", key: "yjz344" }],
  ["path", { d: "m12 8 1-6h2", key: "3ybfa4" }]
];
var CupSoda = createLucideIcon("cup-soda", __iconNode503);

// ../node_modules/lucide-react/dist/esm/icons/currency.js
var __iconNode504 = [
  ["circle", { cx: "12", cy: "12", r: "8", key: "46899m" }],
  ["line", { x1: "3", x2: "6", y1: "3", y2: "6", key: "1jkytn" }],
  ["line", { x1: "21", x2: "18", y1: "3", y2: "6", key: "14zfjt" }],
  ["line", { x1: "3", x2: "6", y1: "21", y2: "18", key: "iusuec" }],
  ["line", { x1: "21", x2: "18", y1: "21", y2: "18", key: "yj2dd7" }]
];
var Currency = createLucideIcon("currency", __iconNode504);

// ../node_modules/lucide-react/dist/esm/icons/cylinder.js
var __iconNode505 = [
  ["ellipse", { cx: "12", cy: "5", rx: "9", ry: "3", key: "msslwz" }],
  ["path", { d: "M3 5v14a9 3 0 0 0 18 0V5", key: "aqi0yr" }]
];
var Cylinder = createLucideIcon("cylinder", __iconNode505);

// ../node_modules/lucide-react/dist/esm/icons/dam.js
var __iconNode506 = [
  [
    "path",
    { d: "M11 11.31c1.17.56 1.54 1.69 3.5 1.69 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1", key: "157kva" }
  ],
  ["path", { d: "M11.75 18c.35.5 1.45 1 2.75 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1", key: "d7q6m6" }],
  ["path", { d: "M2 10h4", key: "l0bgd4" }],
  ["path", { d: "M2 14h4", key: "1gsvsf" }],
  ["path", { d: "M2 18h4", key: "1bu2t1" }],
  ["path", { d: "M2 6h4", key: "aawbzj" }],
  [
    "path",
    { d: "M7 3a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1L10 4a1 1 0 0 0-1-1z", key: "pr6s65" }
  ]
];
var Dam = createLucideIcon("dam", __iconNode506);

// ../node_modules/lucide-react/dist/esm/icons/database-backup.js
var __iconNode507 = [
  ["ellipse", { cx: "12", cy: "5", rx: "9", ry: "3", key: "msslwz" }],
  ["path", { d: "M3 12a9 3 0 0 0 5 2.69", key: "1ui2ym" }],
  ["path", { d: "M21 9.3V5", key: "6k6cib" }],
  ["path", { d: "M3 5v14a9 3 0 0 0 6.47 2.88", key: "i62tjy" }],
  ["path", { d: "M12 12v4h4", key: "1bxaet" }],
  [
    "path",
    {
      d: "M13 20a5 5 0 0 0 9-3 4.5 4.5 0 0 0-4.5-4.5c-1.33 0-2.54.54-3.41 1.41L12 16",
      key: "1f4ei9"
    }
  ]
];
var DatabaseBackup = createLucideIcon("database-backup", __iconNode507);

// ../node_modules/lucide-react/dist/esm/icons/database-search.js
var __iconNode508 = [
  ["path", { d: "M21 11.693V5", key: "175m1t" }],
  ["path", { d: "m22 22-1.875-1.875", key: "13zax7" }],
  ["path", { d: "M3 12a9 3 0 0 0 8.697 2.998", key: "151u9p" }],
  ["path", { d: "M3 5v14a9 3 0 0 0 9.28 2.999", key: "q2rs2p" }],
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }],
  ["ellipse", { cx: "12", cy: "5", rx: "9", ry: "3", key: "msslwz" }]
];
var DatabaseSearch = createLucideIcon("database-search", __iconNode508);

// ../node_modules/lucide-react/dist/esm/icons/database-zap.js
var __iconNode509 = [
  ["ellipse", { cx: "12", cy: "5", rx: "9", ry: "3", key: "msslwz" }],
  ["path", { d: "M3 5V19A9 3 0 0 0 15 21.84", key: "14ibmq" }],
  ["path", { d: "M21 5V8", key: "1marbg" }],
  ["path", { d: "M21 12L18 17H22L19 22", key: "zafso" }],
  ["path", { d: "M3 12A9 3 0 0 0 14.59 14.87", key: "1y4wr8" }]
];
var DatabaseZap = createLucideIcon("database-zap", __iconNode509);

// ../node_modules/lucide-react/dist/esm/icons/database.js
var __iconNode510 = [
  ["ellipse", { cx: "12", cy: "5", rx: "9", ry: "3", key: "msslwz" }],
  ["path", { d: "M3 5V19A9 3 0 0 0 21 19V5", key: "1wlel7" }],
  ["path", { d: "M3 12A9 3 0 0 0 21 12", key: "mv7ke4" }]
];
var Database = createLucideIcon("database", __iconNode510);

// ../node_modules/lucide-react/dist/esm/icons/decimals-arrow-left.js
var __iconNode511 = [
  ["path", { d: "m13 21-3-3 3-3", key: "s3o1nf" }],
  ["path", { d: "M20 18H10", key: "14r3mt" }],
  ["path", { d: "M3 11h.01", key: "1eifu7" }],
  ["rect", { x: "6", y: "3", width: "5", height: "8", rx: "2.5", key: "v9paqo" }]
];
var DecimalsArrowLeft = createLucideIcon("decimals-arrow-left", __iconNode511);

// ../node_modules/lucide-react/dist/esm/icons/decimals-arrow-right.js
var __iconNode512 = [
  ["path", { d: "M10 18h10", key: "1y5s8o" }],
  ["path", { d: "m17 21 3-3-3-3", key: "1ammt0" }],
  ["path", { d: "M3 11h.01", key: "1eifu7" }],
  ["rect", { x: "15", y: "3", width: "5", height: "8", rx: "2.5", key: "76md6a" }],
  ["rect", { x: "6", y: "3", width: "5", height: "8", rx: "2.5", key: "v9paqo" }]
];
var DecimalsArrowRight = createLucideIcon("decimals-arrow-right", __iconNode512);

// ../node_modules/lucide-react/dist/esm/icons/delete.js
var __iconNode513 = [
  [
    "path",
    {
      d: "M10 5a2 2 0 0 0-1.344.519l-6.328 5.74a1 1 0 0 0 0 1.481l6.328 5.741A2 2 0 0 0 10 19h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2z",
      key: "1yo7s0"
    }
  ],
  ["path", { d: "m12 9 6 6", key: "anjzzh" }],
  ["path", { d: "m18 9-6 6", key: "1fp51s" }]
];
var Delete = createLucideIcon("delete", __iconNode513);

// ../node_modules/lucide-react/dist/esm/icons/dessert.js
var __iconNode514 = [
  [
    "path",
    {
      d: "M10.162 3.167A10 10 0 0 0 2 13a2 2 0 0 0 4 0v-1a2 2 0 0 1 4 0v4a2 2 0 0 0 4 0v-4a2 2 0 0 1 4 0v1a2 2 0 0 0 4-.006 10 10 0 0 0-8.161-9.826",
      key: "xi88qy"
    }
  ],
  ["path", { d: "M20.804 14.869a9 9 0 0 1-17.608 0", key: "1r28rg" }],
  ["circle", { cx: "12", cy: "4", r: "2", key: "muu5ef" }]
];
var Dessert = createLucideIcon("dessert", __iconNode514);

// ../node_modules/lucide-react/dist/esm/icons/diameter.js
var __iconNode515 = [
  ["circle", { cx: "19", cy: "19", r: "2", key: "17f5cg" }],
  ["circle", { cx: "5", cy: "5", r: "2", key: "1gwv83" }],
  ["path", { d: "M6.48 3.66a10 10 0 0 1 13.86 13.86", key: "xr8kdq" }],
  ["path", { d: "m6.41 6.41 11.18 11.18", key: "uhpjw7" }],
  ["path", { d: "M3.66 6.48a10 10 0 0 0 13.86 13.86", key: "cldpwv" }]
];
var Diameter = createLucideIcon("diameter", __iconNode515);

// ../node_modules/lucide-react/dist/esm/icons/diamond-percent.js
var __iconNode516 = [
  [
    "path",
    {
      d: "M2.7 10.3a2.41 2.41 0 0 0 0 3.41l7.59 7.59a2.41 2.41 0 0 0 3.41 0l7.59-7.59a2.41 2.41 0 0 0 0-3.41L13.7 2.71a2.41 2.41 0 0 0-3.41 0Z",
      key: "1tpxz2"
    }
  ],
  ["path", { d: "M9.2 9.2h.01", key: "1b7bvt" }],
  ["path", { d: "m14.5 9.5-5 5", key: "17q4r4" }],
  ["path", { d: "M14.7 14.8h.01", key: "17nsh4" }]
];
var DiamondPercent = createLucideIcon("diamond-percent", __iconNode516);

// ../node_modules/lucide-react/dist/esm/icons/diamond-minus.js
var __iconNode517 = [
  [
    "path",
    {
      d: "M2.7 10.3a2.41 2.41 0 0 0 0 3.41l7.59 7.59a2.41 2.41 0 0 0 3.41 0l7.59-7.59a2.41 2.41 0 0 0 0-3.41L13.7 2.71a2.41 2.41 0 0 0-3.41 0z",
      key: "1ey20j"
    }
  ],
  ["path", { d: "M8 12h8", key: "1wcyev" }]
];
var DiamondMinus = createLucideIcon("diamond-minus", __iconNode517);

// ../node_modules/lucide-react/dist/esm/icons/diamond-plus.js
var __iconNode518 = [
  ["path", { d: "M12 8v8", key: "napkw2" }],
  [
    "path",
    {
      d: "M2.7 10.3a2.41 2.41 0 0 0 0 3.41l7.59 7.59a2.41 2.41 0 0 0 3.41 0l7.59-7.59a2.41 2.41 0 0 0 0-3.41L13.7 2.71a2.41 2.41 0 0 0-3.41 0z",
      key: "1ey20j"
    }
  ],
  ["path", { d: "M8 12h8", key: "1wcyev" }]
];
var DiamondPlus = createLucideIcon("diamond-plus", __iconNode518);

// ../node_modules/lucide-react/dist/esm/icons/diamond.js
var __iconNode519 = [
  [
    "path",
    {
      d: "M2.7 10.3a2.41 2.41 0 0 0 0 3.41l7.59 7.59a2.41 2.41 0 0 0 3.41 0l7.59-7.59a2.41 2.41 0 0 0 0-3.41l-7.59-7.59a2.41 2.41 0 0 0-3.41 0Z",
      key: "1f1r0c"
    }
  ]
];
var Diamond = createLucideIcon("diamond", __iconNode519);

// ../node_modules/lucide-react/dist/esm/icons/dice-1.js
var __iconNode520 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }]
];
var Dice1 = createLucideIcon("dice-1", __iconNode520);

// ../node_modules/lucide-react/dist/esm/icons/dice-2.js
var __iconNode521 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["path", { d: "M15 9h.01", key: "x1ddxp" }],
  ["path", { d: "M9 15h.01", key: "fzyn71" }]
];
var Dice2 = createLucideIcon("dice-2", __iconNode521);

// ../node_modules/lucide-react/dist/esm/icons/dice-3.js
var __iconNode522 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["path", { d: "M16 8h.01", key: "cr5u4v" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M8 16h.01", key: "18s6g9" }]
];
var Dice3 = createLucideIcon("dice-3", __iconNode522);

// ../node_modules/lucide-react/dist/esm/icons/dice-4.js
var __iconNode523 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["path", { d: "M16 8h.01", key: "cr5u4v" }],
  ["path", { d: "M8 8h.01", key: "1e4136" }],
  ["path", { d: "M8 16h.01", key: "18s6g9" }],
  ["path", { d: "M16 16h.01", key: "1f9h7w" }]
];
var Dice4 = createLucideIcon("dice-4", __iconNode523);

// ../node_modules/lucide-react/dist/esm/icons/dice-5.js
var __iconNode524 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["path", { d: "M16 8h.01", key: "cr5u4v" }],
  ["path", { d: "M8 8h.01", key: "1e4136" }],
  ["path", { d: "M8 16h.01", key: "18s6g9" }],
  ["path", { d: "M16 16h.01", key: "1f9h7w" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }]
];
var Dice5 = createLucideIcon("dice-5", __iconNode524);

// ../node_modules/lucide-react/dist/esm/icons/dice-6.js
var __iconNode525 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["path", { d: "M16 8h.01", key: "cr5u4v" }],
  ["path", { d: "M16 12h.01", key: "1l6xoz" }],
  ["path", { d: "M16 16h.01", key: "1f9h7w" }],
  ["path", { d: "M8 8h.01", key: "1e4136" }],
  ["path", { d: "M8 12h.01", key: "czm47f" }],
  ["path", { d: "M8 16h.01", key: "18s6g9" }]
];
var Dice6 = createLucideIcon("dice-6", __iconNode525);

// ../node_modules/lucide-react/dist/esm/icons/dices.js
var __iconNode526 = [
  ["rect", { width: "12", height: "12", x: "2", y: "10", rx: "2", ry: "2", key: "6agr2n" }],
  [
    "path",
    { d: "m17.92 14 3.5-3.5a2.24 2.24 0 0 0 0-3l-5-4.92a2.24 2.24 0 0 0-3 0L10 6", key: "1o487t" }
  ],
  ["path", { d: "M6 18h.01", key: "uhywen" }],
  ["path", { d: "M10 14h.01", key: "ssrbsk" }],
  ["path", { d: "M15 6h.01", key: "cblpky" }],
  ["path", { d: "M18 9h.01", key: "2061c0" }]
];
var Dices = createLucideIcon("dices", __iconNode526);

// ../node_modules/lucide-react/dist/esm/icons/diff.js
var __iconNode527 = [
  ["path", { d: "M12 3v14", key: "7cf3v8" }],
  ["path", { d: "M5 10h14", key: "elsbfy" }],
  ["path", { d: "M5 21h14", key: "11awu3" }]
];
var Diff = createLucideIcon("diff", __iconNode527);

// ../node_modules/lucide-react/dist/esm/icons/disc-2.js
var __iconNode528 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }]
];
var Disc2 = createLucideIcon("disc-2", __iconNode528);

// ../node_modules/lucide-react/dist/esm/icons/disc-3.js
var __iconNode529 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M6 12c0-1.7.7-3.2 1.8-4.2", key: "oqkarx" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }],
  ["path", { d: "M18 12c0 1.7-.7 3.2-1.8 4.2", key: "1eah9h" }]
];
var Disc3 = createLucideIcon("disc-3", __iconNode529);

// ../node_modules/lucide-react/dist/esm/icons/disc-album.js
var __iconNode530 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["circle", { cx: "12", cy: "12", r: "5", key: "nd82uf" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }]
];
var DiscAlbum = createLucideIcon("disc-album", __iconNode530);

// ../node_modules/lucide-react/dist/esm/icons/disc.js
var __iconNode531 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }]
];
var Disc = createLucideIcon("disc", __iconNode531);

// ../node_modules/lucide-react/dist/esm/icons/divide.js
var __iconNode532 = [
  ["circle", { cx: "12", cy: "6", r: "1", key: "1bh7o1" }],
  ["line", { x1: "5", x2: "19", y1: "12", y2: "12", key: "13b5wn" }],
  ["circle", { cx: "12", cy: "18", r: "1", key: "lqb9t5" }]
];
var Divide = createLucideIcon("divide", __iconNode532);

// ../node_modules/lucide-react/dist/esm/icons/dna-off.js
var __iconNode533 = [
  ["path", { d: "M15 2c-1.35 1.5-2.092 3-2.5 4.5L14 8", key: "1bivrr" }],
  ["path", { d: "m17 6-2.891-2.891", key: "xu6p2f" }],
  ["path", { d: "M2 15c3.333-3 6.667-3 10-3", key: "nxix30" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "m20 9 .891.891", key: "3xwk7g" }],
  ["path", { d: "M22 9c-1.5 1.35-3 2.092-4.5 2.5l-1-1", key: "18cutr" }],
  ["path", { d: "M3.109 14.109 4 15", key: "q76aoh" }],
  ["path", { d: "m6.5 12.5 1 1", key: "cs35ky" }],
  ["path", { d: "m7 18 2.891 2.891", key: "1sisit" }],
  ["path", { d: "M9 22c1.35-1.5 2.092-3 2.5-4.5L10 16", key: "rlvei3" }]
];
var DnaOff = createLucideIcon("dna-off", __iconNode533);

// ../node_modules/lucide-react/dist/esm/icons/dna.js
var __iconNode534 = [
  ["path", { d: "m10 16 1.5 1.5", key: "11lckj" }],
  ["path", { d: "m14 8-1.5-1.5", key: "1ohn8i" }],
  ["path", { d: "M15 2c-1.798 1.998-2.518 3.995-2.807 5.993", key: "80uv8i" }],
  ["path", { d: "m16.5 10.5 1 1", key: "696xn5" }],
  ["path", { d: "m17 6-2.891-2.891", key: "xu6p2f" }],
  ["path", { d: "M2 15c6.667-6 13.333 0 20-6", key: "1pyr53" }],
  ["path", { d: "m20 9 .891.891", key: "3xwk7g" }],
  ["path", { d: "M3.109 14.109 4 15", key: "q76aoh" }],
  ["path", { d: "m6.5 12.5 1 1", key: "cs35ky" }],
  ["path", { d: "m7 18 2.891 2.891", key: "1sisit" }],
  ["path", { d: "M9 22c1.798-1.998 2.518-3.995 2.807-5.993", key: "q3hbxp" }]
];
var Dna = createLucideIcon("dna", __iconNode534);

// ../node_modules/lucide-react/dist/esm/icons/dock.js
var __iconNode535 = [
  ["path", { d: "M2 8h20", key: "d11cs7" }],
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }],
  ["path", { d: "M6 16h12", key: "u522kt" }]
];
var Dock = createLucideIcon("dock", __iconNode535);

// ../node_modules/lucide-react/dist/esm/icons/dog.js
var __iconNode536 = [
  ["path", { d: "M11.25 16.25h1.5L12 17z", key: "w7jh35" }],
  ["path", { d: "M16 14v.5", key: "1lajdz" }],
  [
    "path",
    {
      d: "M4.42 11.247A13.152 13.152 0 0 0 4 14.556C4 18.728 7.582 21 12 21s8-2.272 8-6.444a11.702 11.702 0 0 0-.493-3.309",
      key: "u7s9ue"
    }
  ],
  ["path", { d: "M8 14v.5", key: "1nzgdb" }],
  [
    "path",
    {
      d: "M8.5 8.5c-.384 1.05-1.083 2.028-2.344 2.5-1.931.722-3.576-.297-3.656-1-.113-.994 1.177-6.53 4-7 1.923-.321 3.651.845 3.651 2.235A7.497 7.497 0 0 1 14 5.277c0-1.39 1.844-2.598 3.767-2.277 2.823.47 4.113 6.006 4 7-.08.703-1.725 1.722-3.656 1-1.261-.472-1.855-1.45-2.239-2.5",
      key: "v8hric"
    }
  ]
];
var Dog = createLucideIcon("dog", __iconNode536);

// ../node_modules/lucide-react/dist/esm/icons/dollar-sign.js
var __iconNode537 = [
  ["line", { x1: "12", x2: "12", y1: "2", y2: "22", key: "7eqyqh" }],
  ["path", { d: "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6", key: "1b0p4s" }]
];
var DollarSign = createLucideIcon("dollar-sign", __iconNode537);

// ../node_modules/lucide-react/dist/esm/icons/donut.js
var __iconNode538 = [
  [
    "path",
    {
      d: "M20.5 10a2.5 2.5 0 0 1-2.4-3H18a2.95 2.95 0 0 1-2.6-4.4 10 10 0 1 0 6.3 7.1c-.3.2-.8.3-1.2.3",
      key: "19sr3x"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
];
var Donut = createLucideIcon("donut", __iconNode538);

// ../node_modules/lucide-react/dist/esm/icons/door-closed-locked.js
var __iconNode539 = [
  ["path", { d: "M10 12h.01", key: "1kxr2c" }],
  ["path", { d: "M18 9V6a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v14", key: "1bnhmg" }],
  ["path", { d: "M2 20h8", key: "10ntw1" }],
  ["path", { d: "M20 17v-2a2 2 0 1 0-4 0v2", key: "pwaxnr" }],
  ["rect", { x: "14", y: "17", width: "8", height: "5", rx: "1", key: "15pjcy" }]
];
var DoorClosedLocked = createLucideIcon("door-closed-locked", __iconNode539);

// ../node_modules/lucide-react/dist/esm/icons/door-open.js
var __iconNode540 = [
  ["path", { d: "M11 20H2", key: "nlcfvz" }],
  [
    "path",
    {
      d: "M11 4.562v16.157a1 1 0 0 0 1.242.97L19 20V5.562a2 2 0 0 0-1.515-1.94l-4-1A2 2 0 0 0 11 4.561z",
      key: "au4z13"
    }
  ],
  ["path", { d: "M11 4H8a2 2 0 0 0-2 2v14", key: "74r1mk" }],
  ["path", { d: "M14 12h.01", key: "1jfl7z" }],
  ["path", { d: "M22 20h-3", key: "vhrsz" }]
];
var DoorOpen = createLucideIcon("door-open", __iconNode540);

// ../node_modules/lucide-react/dist/esm/icons/door-closed.js
var __iconNode541 = [
  ["path", { d: "M10 12h.01", key: "1kxr2c" }],
  ["path", { d: "M18 20V6a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v14", key: "36qu9e" }],
  ["path", { d: "M2 20h20", key: "owomy5" }]
];
var DoorClosed = createLucideIcon("door-closed", __iconNode541);

// ../node_modules/lucide-react/dist/esm/icons/dot.js
var __iconNode542 = [["circle", { cx: "12.1", cy: "12.1", r: "1", key: "18d7e5" }]];
var Dot = createLucideIcon("dot", __iconNode542);

// ../node_modules/lucide-react/dist/esm/icons/download.js
var __iconNode543 = [
  ["path", { d: "M12 15V3", key: "m9g1x1" }],
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["path", { d: "m7 10 5 5 5-5", key: "brsn70" }]
];
var Download = createLucideIcon("download", __iconNode543);

// ../node_modules/lucide-react/dist/esm/icons/drafting-compass.js
var __iconNode544 = [
  ["path", { d: "m12.99 6.74 1.93 3.44", key: "iwagvd" }],
  ["path", { d: "M19.136 12a10 10 0 0 1-14.271 0", key: "ppmlo4" }],
  ["path", { d: "m21 21-2.16-3.84", key: "vylbct" }],
  ["path", { d: "m3 21 8.02-14.26", key: "1ssaw4" }],
  ["circle", { cx: "12", cy: "5", r: "2", key: "f1ur92" }]
];
var DraftingCompass = createLucideIcon("drafting-compass", __iconNode544);

// ../node_modules/lucide-react/dist/esm/icons/drama.js
var __iconNode545 = [
  ["path", { d: "M10 11h.01", key: "d2at3l" }],
  ["path", { d: "M14 6h.01", key: "k028ub" }],
  ["path", { d: "M18 6h.01", key: "1v4wsw" }],
  ["path", { d: "M6.5 13.1h.01", key: "1748ia" }],
  ["path", { d: "M22 5c0 9-4 12-6 12s-6-3-6-12c0-2 2-3 6-3s6 1 6 3", key: "172yzv" }],
  ["path", { d: "M17.4 9.9c-.8.8-2 .8-2.8 0", key: "1obv0w" }],
  [
    "path",
    {
      d: "M10.1 7.1C9 7.2 7.7 7.7 6 8.6c-3.5 2-4.7 3.9-3.7 5.6 4.5 7.8 9.5 8.4 11.2 7.4.9-.5 1.9-2.1 1.9-4.7",
      key: "rqjl8i"
    }
  ],
  ["path", { d: "M9.1 16.5c.3-1.1 1.4-1.7 2.4-1.4", key: "1mr6wy" }]
];
var Drama = createLucideIcon("drama", __iconNode545);

// ../node_modules/lucide-react/dist/esm/icons/dribbble.js
var __iconNode546 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M19.13 5.09C15.22 9.14 10 10.44 2.25 10.94", key: "hpej1" }],
  ["path", { d: "M21.75 12.84c-6.62-1.41-12.14 1-16.38 6.32", key: "1tr44o" }],
  ["path", { d: "M8.56 2.75c4.37 6 6 9.42 8 17.72", key: "kbh691" }]
];
var Dribbble = createLucideIcon("dribbble", __iconNode546);

// ../node_modules/lucide-react/dist/esm/icons/drill.js
var __iconNode547 = [
  [
    "path",
    { d: "M10 18a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1H5a3 3 0 0 1-3-3 1 1 0 0 1 1-1z", key: "ioqxb1" }
  ],
  [
    "path",
    {
      d: "M13 10H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1l-.81 3.242a1 1 0 0 1-.97.758H8",
      key: "1rs59n"
    }
  ],
  ["path", { d: "M14 4h3a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-3", key: "105ega" }],
  ["path", { d: "M18 6h4", key: "66u95g" }],
  ["path", { d: "m5 10-2 8", key: "xt2lic" }],
  ["path", { d: "m7 18 2-8", key: "1bzku2" }]
];
var Drill = createLucideIcon("drill", __iconNode547);

// ../node_modules/lucide-react/dist/esm/icons/drone.js
var __iconNode548 = [
  ["path", { d: "M10 10 7 7", key: "zp14k7" }],
  ["path", { d: "m10 14-3 3", key: "1jrpxk" }],
  ["path", { d: "m14 10 3-3", key: "7tigam" }],
  ["path", { d: "m14 14 3 3", key: "vm23p3" }],
  ["path", { d: "M14.205 4.139a4 4 0 1 1 5.439 5.863", key: "1tm5p2" }],
  ["path", { d: "M19.637 14a4 4 0 1 1-5.432 5.868", key: "16egi2" }],
  ["path", { d: "M4.367 10a4 4 0 1 1 5.438-5.862", key: "1wta6a" }],
  ["path", { d: "M9.795 19.862a4 4 0 1 1-5.429-5.873", key: "q39hpv" }],
  ["rect", { x: "10", y: "8", width: "4", height: "8", rx: "1", key: "phrjt1" }]
];
var Drone = createLucideIcon("drone", __iconNode548);

// ../node_modules/lucide-react/dist/esm/icons/droplet-off.js
var __iconNode549 = [
  [
    "path",
    {
      d: "M18.715 13.186C18.29 11.858 17.384 10.607 16 9.5c-2-1.6-3.5-4-4-6.5a10.7 10.7 0 0 1-.884 2.586",
      key: "8suz2t"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    { d: "M8.795 8.797A11 11 0 0 1 8 9.5C6 11.1 5 13 5 15a7 7 0 0 0 13.222 3.208", key: "19dw9m" }
  ]
];
var DropletOff = createLucideIcon("droplet-off", __iconNode549);

// ../node_modules/lucide-react/dist/esm/icons/droplet.js
var __iconNode550 = [
  [
    "path",
    {
      d: "M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z",
      key: "c7niix"
    }
  ]
];
var Droplet = createLucideIcon("droplet", __iconNode550);

// ../node_modules/lucide-react/dist/esm/icons/droplets.js
var __iconNode551 = [
  [
    "path",
    {
      d: "M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z",
      key: "1ptgy4"
    }
  ],
  [
    "path",
    {
      d: "M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5a6.98 6.98 0 0 1-11.91 4.97",
      key: "1sl1rz"
    }
  ]
];
var Droplets = createLucideIcon("droplets", __iconNode551);

// ../node_modules/lucide-react/dist/esm/icons/drum.js
var __iconNode552 = [
  ["path", { d: "m2 2 8 8", key: "1v6059" }],
  ["path", { d: "m22 2-8 8", key: "173r8a" }],
  ["ellipse", { cx: "12", cy: "9", rx: "10", ry: "5", key: "liohsx" }],
  ["path", { d: "M7 13.4v7.9", key: "1yi6u9" }],
  ["path", { d: "M12 14v8", key: "1tn2tj" }],
  ["path", { d: "M17 13.4v7.9", key: "eqz2v3" }],
  ["path", { d: "M2 9v8a10 5 0 0 0 20 0V9", key: "1750ul" }]
];
var Drum = createLucideIcon("drum", __iconNode552);

// ../node_modules/lucide-react/dist/esm/icons/drumstick.js
var __iconNode553 = [
  [
    "path",
    { d: "M15.4 15.63a7.875 6 135 1 1 6.23-6.23 4.5 3.43 135 0 0-6.23 6.23", key: "1dtqwm" }
  ],
  [
    "path",
    {
      d: "m8.29 12.71-2.6 2.6a2.5 2.5 0 1 0-1.65 4.65A2.5 2.5 0 1 0 8.7 18.3l2.59-2.59",
      key: "1oq1fw"
    }
  ]
];
var Drumstick = createLucideIcon("drumstick", __iconNode553);

// ../node_modules/lucide-react/dist/esm/icons/dumbbell.js
var __iconNode554 = [
  [
    "path",
    {
      d: "M17.596 12.768a2 2 0 1 0 2.829-2.829l-1.768-1.767a2 2 0 0 0 2.828-2.829l-2.828-2.828a2 2 0 0 0-2.829 2.828l-1.767-1.768a2 2 0 1 0-2.829 2.829z",
      key: "9m4mmf"
    }
  ],
  ["path", { d: "m2.5 21.5 1.4-1.4", key: "17g3f0" }],
  ["path", { d: "m20.1 3.9 1.4-1.4", key: "1qn309" }],
  [
    "path",
    {
      d: "M5.343 21.485a2 2 0 1 0 2.829-2.828l1.767 1.768a2 2 0 1 0 2.829-2.829l-6.364-6.364a2 2 0 1 0-2.829 2.829l1.768 1.767a2 2 0 0 0-2.828 2.829z",
      key: "1t2c92"
    }
  ],
  ["path", { d: "m9.6 14.4 4.8-4.8", key: "6umqxw" }]
];
var Dumbbell = createLucideIcon("dumbbell", __iconNode554);

// ../node_modules/lucide-react/dist/esm/icons/ear-off.js
var __iconNode555 = [
  ["path", { d: "M6 18.5a3.5 3.5 0 1 0 7 0c0-1.57.92-2.52 2.04-3.46", key: "1qngmn" }],
  ["path", { d: "M6 8.5c0-.75.13-1.47.36-2.14", key: "b06bma" }],
  ["path", { d: "M8.8 3.15A6.5 6.5 0 0 1 19 8.5c0 1.63-.44 2.81-1.09 3.76", key: "g10hsz" }],
  ["path", { d: "M12.5 6A2.5 2.5 0 0 1 15 8.5M10 13a2 2 0 0 0 1.82-1.18", key: "ygzou7" }],
  ["line", { x1: "2", x2: "22", y1: "2", y2: "22", key: "a6p6uj" }]
];
var EarOff = createLucideIcon("ear-off", __iconNode555);

// ../node_modules/lucide-react/dist/esm/icons/ear.js
var __iconNode556 = [
  ["path", { d: "M6 8.5a6.5 6.5 0 1 1 13 0c0 6-6 6-6 10a3.5 3.5 0 1 1-7 0", key: "1dfaln" }],
  ["path", { d: "M15 8.5a2.5 2.5 0 0 0-5 0v1a2 2 0 1 1 0 4", key: "1qnva7" }]
];
var Ear = createLucideIcon("ear", __iconNode556);

// ../node_modules/lucide-react/dist/esm/icons/earth-lock.js
var __iconNode557 = [
  ["path", { d: "M7 3.34V5a3 3 0 0 0 3 3", key: "w732o8" }],
  ["path", { d: "M11 21.95V18a2 2 0 0 0-2-2 2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05", key: "f02343" }],
  ["path", { d: "M21.54 15H17a2 2 0 0 0-2 2v4.54", key: "1djwo0" }],
  ["path", { d: "M12 2a10 10 0 1 0 9.54 13", key: "zjsr6q" }],
  ["path", { d: "M20 6V4a2 2 0 1 0-4 0v2", key: "1of5e8" }],
  ["rect", { width: "8", height: "5", x: "14", y: "6", rx: "1", key: "1fmf51" }]
];
var EarthLock = createLucideIcon("earth-lock", __iconNode557);

// ../node_modules/lucide-react/dist/esm/icons/earth.js
var __iconNode558 = [
  ["path", { d: "M21.54 15H17a2 2 0 0 0-2 2v4.54", key: "1djwo0" }],
  [
    "path",
    {
      d: "M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17",
      key: "1tzkfa"
    }
  ],
  ["path", { d: "M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05", key: "14pb5j" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
];
var Earth = createLucideIcon("earth", __iconNode558);

// ../node_modules/lucide-react/dist/esm/icons/eclipse.js
var __iconNode559 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 2a7 7 0 1 0 10 10", key: "1yuj32" }]
];
var Eclipse = createLucideIcon("eclipse", __iconNode559);

// ../node_modules/lucide-react/dist/esm/icons/egg-fried.js
var __iconNode560 = [
  ["circle", { cx: "11.5", cy: "12.5", r: "3.5", key: "1cl1mi" }],
  [
    "path",
    {
      d: "M3 8c0-3.5 2.5-6 6.5-6 5 0 4.83 3 7.5 5s5 2 5 6c0 4.5-2.5 6.5-7 6.5-2.5 0-2.5 2.5-6 2.5s-7-2-7-5.5c0-3 1.5-3 1.5-5C3.5 10 3 9 3 8Z",
      key: "165ef9"
    }
  ]
];
var EggFried = createLucideIcon("egg-fried", __iconNode560);

// ../node_modules/lucide-react/dist/esm/icons/egg-off.js
var __iconNode561 = [
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M20 14.347V14c0-6-4-12-8-12-1.078 0-2.157.436-3.157 1.19", key: "13g2jy" }],
  ["path", { d: "M6.206 6.21C4.871 8.4 4 11.2 4 14a8 8 0 0 0 14.568 4.568", key: "1581id" }]
];
var EggOff = createLucideIcon("egg-off", __iconNode561);

// ../node_modules/lucide-react/dist/esm/icons/egg.js
var __iconNode562 = [
  ["path", { d: "M12 2C8 2 4 8 4 14a8 8 0 0 0 16 0c0-6-4-12-8-12", key: "1le142" }]
];
var Egg = createLucideIcon("egg", __iconNode562);

// ../node_modules/lucide-react/dist/esm/icons/ellipsis-vertical.js
var __iconNode563 = [
  ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }],
  ["circle", { cx: "12", cy: "5", r: "1", key: "gxeob9" }],
  ["circle", { cx: "12", cy: "19", r: "1", key: "lyex9k" }]
];
var EllipsisVertical = createLucideIcon("ellipsis-vertical", __iconNode563);

// ../node_modules/lucide-react/dist/esm/icons/ellipsis.js
var __iconNode564 = [
  ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }],
  ["circle", { cx: "19", cy: "12", r: "1", key: "1wjl8i" }],
  ["circle", { cx: "5", cy: "12", r: "1", key: "1pcz8c" }]
];
var Ellipsis = createLucideIcon("ellipsis", __iconNode564);

// ../node_modules/lucide-react/dist/esm/icons/equal-approximately.js
var __iconNode565 = [
  ["path", { d: "M5 15a6.5 6.5 0 0 1 7 0 6.5 6.5 0 0 0 7 0", key: "yrdkhy" }],
  ["path", { d: "M5 9a6.5 6.5 0 0 1 7 0 6.5 6.5 0 0 0 7 0", key: "gzkvyz" }]
];
var EqualApproximately = createLucideIcon("equal-approximately", __iconNode565);

// ../node_modules/lucide-react/dist/esm/icons/equal-not.js
var __iconNode566 = [
  ["line", { x1: "5", x2: "19", y1: "9", y2: "9", key: "1nwqeh" }],
  ["line", { x1: "5", x2: "19", y1: "15", y2: "15", key: "g8yjpy" }],
  ["line", { x1: "19", x2: "5", y1: "5", y2: "19", key: "1x9vlm" }]
];
var EqualNot = createLucideIcon("equal-not", __iconNode566);

// ../node_modules/lucide-react/dist/esm/icons/equal.js
var __iconNode567 = [
  ["line", { x1: "5", x2: "19", y1: "9", y2: "9", key: "1nwqeh" }],
  ["line", { x1: "5", x2: "19", y1: "15", y2: "15", key: "g8yjpy" }]
];
var Equal = createLucideIcon("equal", __iconNode567);

// ../node_modules/lucide-react/dist/esm/icons/eraser.js
var __iconNode568 = [
  [
    "path",
    {
      d: "M21 21H8a2 2 0 0 1-1.42-.587l-3.994-3.999a2 2 0 0 1 0-2.828l10-10a2 2 0 0 1 2.829 0l5.999 6a2 2 0 0 1 0 2.828L12.834 21",
      key: "g5wo59"
    }
  ],
  ["path", { d: "m5.082 11.09 8.828 8.828", key: "1wx5vj" }]
];
var Eraser = createLucideIcon("eraser", __iconNode568);

// ../node_modules/lucide-react/dist/esm/icons/ethernet-port.js
var __iconNode569 = [
  [
    "path",
    {
      d: "m15 20 3-3h2a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h2l3 3z",
      key: "rbahqx"
    }
  ],
  ["path", { d: "M6 8v1", key: "1636ez" }],
  ["path", { d: "M10 8v1", key: "1talb4" }],
  ["path", { d: "M14 8v1", key: "1rsfgr" }],
  ["path", { d: "M18 8v1", key: "gnkwox" }]
];
var EthernetPort = createLucideIcon("ethernet-port", __iconNode569);

// ../node_modules/lucide-react/dist/esm/icons/euro.js
var __iconNode570 = [
  ["path", { d: "M4 10h12", key: "1y6xl8" }],
  ["path", { d: "M4 14h9", key: "1loblj" }],
  [
    "path",
    {
      d: "M19 6a7.7 7.7 0 0 0-5.2-2A7.9 7.9 0 0 0 6 12c0 4.4 3.5 8 7.8 8 2 0 3.8-.8 5.2-2",
      key: "1j6lzo"
    }
  ]
];
var Euro = createLucideIcon("euro", __iconNode570);

// ../node_modules/lucide-react/dist/esm/icons/ev-charger.js
var __iconNode571 = [
  [
    "path",
    { d: "M14 13h2a2 2 0 0 1 2 2v2a2 2 0 0 0 4 0v-6.998a2 2 0 0 0-.59-1.42L18 5", key: "1wtuz0" }
  ],
  ["path", { d: "M14 21V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v16", key: "e09ifn" }],
  ["path", { d: "M2 21h13", key: "1x0fut" }],
  ["path", { d: "M3 7h11", key: "19efrr" }],
  ["path", { d: "m9 11-2 3h3l-2 3", key: "lmzxi1" }]
];
var EvCharger = createLucideIcon("ev-charger", __iconNode571);

// ../node_modules/lucide-react/dist/esm/icons/expand.js
var __iconNode572 = [
  ["path", { d: "m15 15 6 6", key: "1s409w" }],
  ["path", { d: "m15 9 6-6", key: "ko1vev" }],
  ["path", { d: "M21 16v5h-5", key: "1ck2sf" }],
  ["path", { d: "M21 8V3h-5", key: "1qoq8a" }],
  ["path", { d: "M3 16v5h5", key: "1t08am" }],
  ["path", { d: "m3 21 6-6", key: "wwnumi" }],
  ["path", { d: "M3 8V3h5", key: "1ln10m" }],
  ["path", { d: "M9 9 3 3", key: "v551iv" }]
];
var Expand = createLucideIcon("expand", __iconNode572);

// ../node_modules/lucide-react/dist/esm/icons/external-link.js
var __iconNode573 = [
  ["path", { d: "M15 3h6v6", key: "1q9fwt" }],
  ["path", { d: "M10 14 21 3", key: "gplh6r" }],
  ["path", { d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6", key: "a6xqqp" }]
];
var ExternalLink = createLucideIcon("external-link", __iconNode573);

// ../node_modules/lucide-react/dist/esm/icons/eye-closed.js
var __iconNode574 = [
  ["path", { d: "m15 18-.722-3.25", key: "1j64jw" }],
  ["path", { d: "M2 8a10.645 10.645 0 0 0 20 0", key: "1e7gxb" }],
  ["path", { d: "m20 15-1.726-2.05", key: "1cnuld" }],
  ["path", { d: "m4 15 1.726-2.05", key: "1dsqqd" }],
  ["path", { d: "m9 18 .722-3.25", key: "ypw2yx" }]
];
var EyeClosed = createLucideIcon("eye-closed", __iconNode574);

// ../node_modules/lucide-react/dist/esm/icons/eye-off.js
var __iconNode575 = [
  [
    "path",
    {
      d: "M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",
      key: "ct8e1f"
    }
  ],
  ["path", { d: "M14.084 14.158a3 3 0 0 1-4.242-4.242", key: "151rxh" }],
  [
    "path",
    {
      d: "M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",
      key: "13bj9a"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var EyeOff = createLucideIcon("eye-off", __iconNode575);

// ../node_modules/lucide-react/dist/esm/icons/eye.js
var __iconNode576 = [
  [
    "path",
    {
      d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",
      key: "1nclc0"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
];
var Eye = createLucideIcon("eye", __iconNode576);

// ../node_modules/lucide-react/dist/esm/icons/facebook.js
var __iconNode577 = [
  [
    "path",
    { d: "M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z", key: "1jg4f8" }
  ]
];
var Facebook = createLucideIcon("facebook", __iconNode577);

// ../node_modules/lucide-react/dist/esm/icons/factory.js
var __iconNode578 = [
  ["path", { d: "M12 16h.01", key: "1drbdi" }],
  ["path", { d: "M16 16h.01", key: "1f9h7w" }],
  [
    "path",
    {
      d: "M3 19a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8.5a.5.5 0 0 0-.769-.422l-4.462 2.844A.5.5 0 0 1 15 10.5v-2a.5.5 0 0 0-.769-.422L9.77 10.922A.5.5 0 0 1 9 10.5V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2z",
      key: "1iv0i2"
    }
  ],
  ["path", { d: "M8 16h.01", key: "18s6g9" }]
];
var Factory = createLucideIcon("factory", __iconNode578);

// ../node_modules/lucide-react/dist/esm/icons/fan.js
var __iconNode579 = [
  [
    "path",
    {
      d: "M10.827 16.379a6.082 6.082 0 0 1-8.618-7.002l5.412 1.45a6.082 6.082 0 0 1 7.002-8.618l-1.45 5.412a6.082 6.082 0 0 1 8.618 7.002l-5.412-1.45a6.082 6.082 0 0 1-7.002 8.618l1.45-5.412Z",
      key: "484a7f"
    }
  ],
  ["path", { d: "M12 12v.01", key: "u5ubse" }]
];
var Fan = createLucideIcon("fan", __iconNode579);

// ../node_modules/lucide-react/dist/esm/icons/fast-forward.js
var __iconNode580 = [
  [
    "path",
    { d: "M12 6a2 2 0 0 1 3.414-1.414l6 6a2 2 0 0 1 0 2.828l-6 6A2 2 0 0 1 12 18z", key: "b19h5q" }
  ],
  [
    "path",
    { d: "M2 6a2 2 0 0 1 3.414-1.414l6 6a2 2 0 0 1 0 2.828l-6 6A2 2 0 0 1 2 18z", key: "h7h5ge" }
  ]
];
var FastForward = createLucideIcon("fast-forward", __iconNode580);

// ../node_modules/lucide-react/dist/esm/icons/feather.js
var __iconNode581 = [
  [
    "path",
    {
      d: "M12.67 19a2 2 0 0 0 1.416-.588l6.154-6.172a6 6 0 0 0-8.49-8.49L5.586 9.914A2 2 0 0 0 5 11.328V18a1 1 0 0 0 1 1z",
      key: "18jl4k"
    }
  ],
  ["path", { d: "M16 8 2 22", key: "vp34q" }],
  ["path", { d: "M17.5 15H9", key: "1oz8nu" }]
];
var Feather = createLucideIcon("feather", __iconNode581);

// ../node_modules/lucide-react/dist/esm/icons/fence.js
var __iconNode582 = [
  ["path", { d: "M4 3 2 5v15c0 .6.4 1 1 1h2c.6 0 1-.4 1-1V5Z", key: "1n2rgs" }],
  ["path", { d: "M6 8h4", key: "utf9t1" }],
  ["path", { d: "M6 18h4", key: "12yh4b" }],
  ["path", { d: "m12 3-2 2v15c0 .6.4 1 1 1h2c.6 0 1-.4 1-1V5Z", key: "3ha7mj" }],
  ["path", { d: "M14 8h4", key: "1r8wg2" }],
  ["path", { d: "M14 18h4", key: "1t3kbu" }],
  ["path", { d: "m20 3-2 2v15c0 .6.4 1 1 1h2c.6 0 1-.4 1-1V5Z", key: "dfd4e2" }]
];
var Fence = createLucideIcon("fence", __iconNode582);

// ../node_modules/lucide-react/dist/esm/icons/ferris-wheel.js
var __iconNode583 = [
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }],
  ["path", { d: "M12 2v4", key: "3427ic" }],
  ["path", { d: "m6.8 15-3.5 2", key: "hjy98k" }],
  ["path", { d: "m20.7 7-3.5 2", key: "f08gto" }],
  ["path", { d: "M6.8 9 3.3 7", key: "1aevh4" }],
  ["path", { d: "m20.7 17-3.5-2", key: "1liqo3" }],
  ["path", { d: "m9 22 3-8 3 8", key: "wees03" }],
  ["path", { d: "M8 22h8", key: "rmew8v" }],
  ["path", { d: "M18 18.7a9 9 0 1 0-12 0", key: "dhzg4g" }]
];
var FerrisWheel = createLucideIcon("ferris-wheel", __iconNode583);

// ../node_modules/lucide-react/dist/esm/icons/figma.js
var __iconNode584 = [
  ["path", { d: "M5 5.5A3.5 3.5 0 0 1 8.5 2H12v7H8.5A3.5 3.5 0 0 1 5 5.5z", key: "1340ok" }],
  ["path", { d: "M12 2h3.5a3.5 3.5 0 1 1 0 7H12V2z", key: "1hz3m3" }],
  ["path", { d: "M12 12.5a3.5 3.5 0 1 1 7 0 3.5 3.5 0 1 1-7 0z", key: "1oz8n2" }],
  ["path", { d: "M5 19.5A3.5 3.5 0 0 1 8.5 16H12v3.5a3.5 3.5 0 1 1-7 0z", key: "1ff65i" }],
  ["path", { d: "M5 12.5A3.5 3.5 0 0 1 8.5 9H12v7H8.5A3.5 3.5 0 0 1 5 12.5z", key: "pdip6e" }]
];
var Figma = createLucideIcon("figma", __iconNode584);

// ../node_modules/lucide-react/dist/esm/icons/file-archive.js
var __iconNode585 = [
  [
    "path",
    {
      d: "M13.659 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v11.5",
      key: "4pqfef"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M8 12v-1", key: "1ej8lb" }],
  ["path", { d: "M8 18v-2", key: "qcmpov" }],
  ["path", { d: "M8 7V6", key: "1nbb54" }],
  ["circle", { cx: "8", cy: "20", r: "2", key: "ckkr5m" }]
];
var FileArchive = createLucideIcon("file-archive", __iconNode585);

// ../node_modules/lucide-react/dist/esm/icons/file-axis-3d.js
var __iconNode586 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "m8 18 4-4", key: "12zab0" }],
  ["path", { d: "M8 10v8h8", key: "tlaukw" }]
];
var FileAxis3d = createLucideIcon("file-axis-3d", __iconNode586);

// ../node_modules/lucide-react/dist/esm/icons/file-badge.js
var __iconNode587 = [
  [
    "path",
    {
      d: "M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.3",
      key: "cvl1xm"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  [
    "path",
    {
      d: "m7.69 16.479 1.29 4.88a.5.5 0 0 1-.698.591l-1.843-.849a1 1 0 0 0-.879.001l-1.846.85a.5.5 0 0 1-.692-.593l1.29-4.88",
      key: "1ff7gj"
    }
  ],
  ["circle", { cx: "6", cy: "14", r: "3", key: "a1xfv6" }]
];
var FileBadge = createLucideIcon("file-badge", __iconNode587);

// ../node_modules/lucide-react/dist/esm/icons/file-box.js
var __iconNode588 = [
  [
    "path",
    {
      d: "M14.5 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.8",
      key: "1kchwa"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M11.7 14.2 7 17l-4.7-2.8", key: "1yk8tc" }],
  [
    "path",
    {
      d: "M3 13.1a2 2 0 0 0-.999 1.76v3.24a2 2 0 0 0 .969 1.78L6 21.7a2 2 0 0 0 2.03.01L11 19.9a2 2 0 0 0 1-1.76V14.9a2 2 0 0 0-.97-1.78L8 11.3a2 2 0 0 0-2.03-.01z",
      key: "19flxy"
    }
  ],
  ["path", { d: "M7 17v5", key: "1yj1jh" }]
];
var FileBox = createLucideIcon("file-box", __iconNode588);

// ../node_modules/lucide-react/dist/esm/icons/file-braces-corner.js
var __iconNode589 = [
  [
    "path",
    {
      d: "M14 22h4a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v6",
      key: "14cnrg"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  [
    "path",
    { d: "M5 14a1 1 0 0 0-1 1v2a1 1 0 0 1-1 1 1 1 0 0 1 1 1v2a1 1 0 0 0 1 1", key: "sr0ebq" }
  ],
  [
    "path",
    { d: "M9 22a1 1 0 0 0 1-1v-2a1 1 0 0 1 1-1 1 1 0 0 1-1-1v-2a1 1 0 0 0-1-1", key: "w793db" }
  ]
];
var FileBracesCorner = createLucideIcon("file-braces-corner", __iconNode589);

// ../node_modules/lucide-react/dist/esm/icons/file-braces.js
var __iconNode590 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  [
    "path",
    { d: "M10 12a1 1 0 0 0-1 1v1a1 1 0 0 1-1 1 1 1 0 0 1 1 1v1a1 1 0 0 0 1 1", key: "1oajmo" }
  ],
  [
    "path",
    { d: "M14 18a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1 1 1 0 0 1-1-1v-1a1 1 0 0 0-1-1", key: "mpwhp6" }
  ]
];
var FileBraces = createLucideIcon("file-braces", __iconNode590);

// ../node_modules/lucide-react/dist/esm/icons/file-chart-column-increasing.js
var __iconNode591 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M8 18v-2", key: "qcmpov" }],
  ["path", { d: "M12 18v-4", key: "q1q25u" }],
  ["path", { d: "M16 18v-6", key: "15y0np" }]
];
var FileChartColumnIncreasing = createLucideIcon("file-chart-column-increasing", __iconNode591);

// ../node_modules/lucide-react/dist/esm/icons/file-chart-line.js
var __iconNode592 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "m16 13-3.5 3.5-2-2L8 17", key: "zz7yod" }]
];
var FileChartLine = createLucideIcon("file-chart-line", __iconNode592);

// ../node_modules/lucide-react/dist/esm/icons/file-chart-column.js
var __iconNode593 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M8 18v-1", key: "zg0ygc" }],
  ["path", { d: "M12 18v-6", key: "17g6i2" }],
  ["path", { d: "M16 18v-3", key: "j5jt4h" }]
];
var FileChartColumn = createLucideIcon("file-chart-column", __iconNode593);

// ../node_modules/lucide-react/dist/esm/icons/file-chart-pie.js
var __iconNode594 = [
  [
    "path",
    {
      d: "M15.941 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.704l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.512",
      key: "13hoie"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M4.017 11.512a6 6 0 1 0 8.466 8.475", key: "s6vs5t" }],
  [
    "path",
    {
      d: "M9 16a1 1 0 0 1-1-1v-4c0-.552.45-1.008.995-.917a6 6 0 0 1 4.922 4.922c.091.544-.365.995-.917.995z",
      key: "1dl6s6"
    }
  ]
];
var FileChartPie = createLucideIcon("file-chart-pie", __iconNode594);

// ../node_modules/lucide-react/dist/esm/icons/file-check-corner.js
var __iconNode595 = [
  [
    "path",
    {
      d: "M10.5 22H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v6",
      key: "g5mvt7"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "m14 20 2 2 4-4", key: "15kota" }]
];
var FileCheckCorner = createLucideIcon("file-check-corner", __iconNode595);

// ../node_modules/lucide-react/dist/esm/icons/file-check.js
var __iconNode596 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "m9 15 2 2 4-4", key: "1grp1n" }]
];
var FileCheck = createLucideIcon("file-check", __iconNode596);

// ../node_modules/lucide-react/dist/esm/icons/file-clock.js
var __iconNode597 = [
  [
    "path",
    {
      d: "M16 22h2a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v2.85",
      key: "ryk6xj"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M8 14v2.2l1.6 1", key: "6m4bie" }],
  ["circle", { cx: "8", cy: "16", r: "6", key: "10v15b" }]
];
var FileClock = createLucideIcon("file-clock", __iconNode597);

// ../node_modules/lucide-react/dist/esm/icons/file-code-corner.js
var __iconNode598 = [
  [
    "path",
    {
      d: "M4 12.15V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-3.35",
      key: "1wthlu"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "m5 16-3 3 3 3", key: "331omg" }],
  ["path", { d: "m9 22 3-3-3-3", key: "lsp7cz" }]
];
var FileCodeCorner = createLucideIcon("file-code-corner", __iconNode598);

// ../node_modules/lucide-react/dist/esm/icons/file-code.js
var __iconNode599 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M10 12.5 8 15l2 2.5", key: "1tg20x" }],
  ["path", { d: "m14 12.5 2 2.5-2 2.5", key: "yinavb" }]
];
var FileCode = createLucideIcon("file-code", __iconNode599);

// ../node_modules/lucide-react/dist/esm/icons/file-cog.js
var __iconNode600 = [
  [
    "path",
    {
      d: "M15 8a1 1 0 0 1-1-1V2a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8z",
      key: "1ckgky"
    }
  ],
  ["path", { d: "M20 8v12a2 2 0 0 1-2 2h-4.182", key: "1726p0" }],
  ["path", { d: "m3.305 19.53.923-.382", key: "ao1pio" }],
  ["path", { d: "M4 10.592V4a2 2 0 0 1 2-2h8", key: "1foop0" }],
  ["path", { d: "m4.228 16.852-.924-.383", key: "1fv9zy" }],
  ["path", { d: "m5.852 15.228-.383-.923", key: "1a9hc2" }],
  ["path", { d: "m5.852 20.772-.383.924", key: "1sh9ke" }],
  ["path", { d: "m8.148 15.228.383-.923", key: "4yu6lf" }],
  ["path", { d: "m8.53 21.696-.382-.924", key: "18b0s9" }],
  ["path", { d: "m9.773 16.852.922-.383", key: "ti6xop" }],
  ["path", { d: "m9.773 19.148.922.383", key: "rws47d" }],
  ["circle", { cx: "7", cy: "18", r: "3", key: "lvkj7j" }]
];
var FileCog = createLucideIcon("file-cog", __iconNode600);

// ../node_modules/lucide-react/dist/esm/icons/file-diff.js
var __iconNode601 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M9 10h6", key: "9gxzsh" }],
  ["path", { d: "M12 13V7", key: "h0r20n" }],
  ["path", { d: "M9 17h6", key: "r8uit2" }]
];
var FileDiff = createLucideIcon("file-diff", __iconNode601);

// ../node_modules/lucide-react/dist/esm/icons/file-digit.js
var __iconNode602 = [
  [
    "path",
    {
      d: "M4 12V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2",
      key: "jrl274"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M10 16h2v6", key: "1bxocy" }],
  ["path", { d: "M10 22h4", key: "ceow96" }],
  ["rect", { x: "2", y: "16", width: "4", height: "6", rx: "2", key: "r45zd0" }]
];
var FileDigit = createLucideIcon("file-digit", __iconNode602);

// ../node_modules/lucide-react/dist/esm/icons/file-down.js
var __iconNode603 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M12 18v-6", key: "17g6i2" }],
  ["path", { d: "m9 15 3 3 3-3", key: "1npd3o" }]
];
var FileDown = createLucideIcon("file-down", __iconNode603);

// ../node_modules/lucide-react/dist/esm/icons/file-exclamation-point.js
var __iconNode604 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M12 9v4", key: "juzpu7" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
];
var FileExclamationPoint = createLucideIcon("file-exclamation-point", __iconNode604);

// ../node_modules/lucide-react/dist/esm/icons/file-headphone.js
var __iconNode605 = [
  [
    "path",
    {
      d: "M4 6.835V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-.343",
      key: "1vfytu"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  [
    "path",
    {
      d: "M2 19a2 2 0 0 1 4 0v1a2 2 0 0 1-4 0v-4a6 6 0 0 1 12 0v4a2 2 0 0 1-4 0v-1a2 2 0 0 1 4 0",
      key: "1etmh7"
    }
  ]
];
var FileHeadphone = createLucideIcon("file-headphone", __iconNode605);

// ../node_modules/lucide-react/dist/esm/icons/file-heart.js
var __iconNode606 = [
  [
    "path",
    {
      d: "M13 22h5a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v7",
      key: "oagw2b"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  [
    "path",
    {
      d: "M3.62 18.8A2.25 2.25 0 1 1 7 15.836a2.25 2.25 0 1 1 3.38 2.966l-2.626 2.856a1 1 0 0 1-1.507 0z",
      key: "rg3psg"
    }
  ]
];
var FileHeart = createLucideIcon("file-heart", __iconNode606);

// ../node_modules/lucide-react/dist/esm/icons/file-input.js
var __iconNode607 = [
  [
    "path",
    {
      d: "M4 11V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-1",
      key: "1q9hii"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M2 15h10", key: "jfw4w8" }],
  ["path", { d: "m9 18 3-3-3-3", key: "112psh" }]
];
var FileInput = createLucideIcon("file-input", __iconNode607);

// ../node_modules/lucide-react/dist/esm/icons/file-image.js
var __iconNode608 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["circle", { cx: "10", cy: "12", r: "2", key: "737tya" }],
  ["path", { d: "m20 17-1.296-1.296a2.41 2.41 0 0 0-3.408 0L9 22", key: "wt3hpn" }]
];
var FileImage = createLucideIcon("file-image", __iconNode608);

// ../node_modules/lucide-react/dist/esm/icons/file-key.js
var __iconNode609 = [
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M4 12v6", key: "bg1pfk" }],
  ["path", { d: "M4 14h2", key: "1sf9f8" }],
  [
    "path",
    {
      d: "M9.65 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v4",
      key: "d56i0q"
    }
  ],
  ["circle", { cx: "4", cy: "20", r: "2", key: "6kqj1y" }]
];
var FileKey = createLucideIcon("file-key", __iconNode609);

// ../node_modules/lucide-react/dist/esm/icons/file-lock.js
var __iconNode610 = [
  [
    "path",
    {
      d: "M4 9.8V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-3",
      key: "1432pc"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M9 17v-2a2 2 0 0 0-4 0v2", key: "168m41" }],
  ["rect", { width: "8", height: "5", x: "3", y: "17", rx: "1", key: "o8vfew" }]
];
var FileLock = createLucideIcon("file-lock", __iconNode610);

// ../node_modules/lucide-react/dist/esm/icons/file-minus-corner.js
var __iconNode611 = [
  [
    "path",
    {
      d: "M20 14V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12",
      key: "l9p8hp"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M14 18h6", key: "1m8k6r" }]
];
var FileMinusCorner = createLucideIcon("file-minus-corner", __iconNode611);

// ../node_modules/lucide-react/dist/esm/icons/file-minus.js
var __iconNode612 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M9 15h6", key: "cctwl0" }]
];
var FileMinus = createLucideIcon("file-minus", __iconNode612);

// ../node_modules/lucide-react/dist/esm/icons/file-music.js
var __iconNode613 = [
  [
    "path",
    {
      d: "M11.65 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v10.35",
      key: "5ad7z2"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M8 20v-7l3 1.474", key: "1ggyb9" }],
  ["circle", { cx: "6", cy: "20", r: "2", key: "j7wjp0" }]
];
var FileMusic = createLucideIcon("file-music", __iconNode613);

// ../node_modules/lucide-react/dist/esm/icons/file-output.js
var __iconNode614 = [
  [
    "path",
    {
      d: "M4.226 20.925A2 2 0 0 0 6 22h12a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v3.127",
      key: "wfxp4w"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "m5 11-3 3", key: "1dgrs4" }],
  ["path", { d: "m5 17-3-3h10", key: "1mvvaf" }]
];
var FileOutput = createLucideIcon("file-output", __iconNode614);

// ../node_modules/lucide-react/dist/esm/icons/file-pen-line.js
var __iconNode615 = [
  [
    "path",
    {
      d: "M14.364 13.634a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506l4.013-4.009a1 1 0 0 0-3.004-3.004z",
      key: "ukzhwg"
    }
  ],
  ["path", { d: "M14.487 7.858A1 1 0 0 1 14 7V2", key: "1klhew" }],
  [
    "path",
    {
      d: "M20 19.645V20a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l2.516 2.516",
      key: "rxaxab"
    }
  ],
  ["path", { d: "M8 18h1", key: "13wk12" }]
];
var FilePenLine = createLucideIcon("file-pen-line", __iconNode615);

// ../node_modules/lucide-react/dist/esm/icons/file-pen.js
var __iconNode616 = [
  [
    "path",
    {
      d: "M12.659 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v9.34",
      key: "o6klzx"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  [
    "path",
    {
      d: "M10.378 12.622a1 1 0 0 1 3 3.003L8.36 20.637a2 2 0 0 1-.854.506l-2.867.837a.5.5 0 0 1-.62-.62l.836-2.869a2 2 0 0 1 .506-.853z",
      key: "zhnas1"
    }
  ]
];
var FilePen = createLucideIcon("file-pen", __iconNode616);

// ../node_modules/lucide-react/dist/esm/icons/file-play.js
var __iconNode617 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  [
    "path",
    {
      d: "M15.033 13.44a.647.647 0 0 1 0 1.12l-4.065 2.352a.645.645 0 0 1-.968-.56v-4.704a.645.645 0 0 1 .967-.56z",
      key: "1tzo1f"
    }
  ]
];
var FilePlay = createLucideIcon("file-play", __iconNode617);

// ../node_modules/lucide-react/dist/esm/icons/file-plus-corner.js
var __iconNode618 = [
  [
    "path",
    {
      d: "M11.35 22H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v5.35",
      key: "17jvcc"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M14 19h6", key: "bvotb8" }],
  ["path", { d: "M17 16v6", key: "18yu1i" }]
];
var FilePlusCorner = createLucideIcon("file-plus-corner", __iconNode618);

// ../node_modules/lucide-react/dist/esm/icons/file-plus.js
var __iconNode619 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M9 15h6", key: "cctwl0" }],
  ["path", { d: "M12 18v-6", key: "17g6i2" }]
];
var FilePlus = createLucideIcon("file-plus", __iconNode619);

// ../node_modules/lucide-react/dist/esm/icons/file-question-mark.js
var __iconNode620 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M12 17h.01", key: "p32p05" }],
  ["path", { d: "M9.1 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3", key: "mhlwft" }]
];
var FileQuestionMark = createLucideIcon("file-question-mark", __iconNode620);

// ../node_modules/lucide-react/dist/esm/icons/file-scan.js
var __iconNode621 = [
  [
    "path",
    {
      d: "M20 10V8a2.4 2.4 0 0 0-.706-1.704l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h4.35",
      key: "1cdjst"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M16 14a2 2 0 0 0-2 2", key: "ceaadl" }],
  ["path", { d: "M16 22a2 2 0 0 1-2-2", key: "1wqh5n" }],
  ["path", { d: "M20 14a2 2 0 0 1 2 2", key: "1ny6zw" }],
  ["path", { d: "M20 22a2 2 0 0 0 2-2", key: "1l9q4k" }]
];
var FileScan = createLucideIcon("file-scan", __iconNode621);

// ../node_modules/lucide-react/dist/esm/icons/file-search-corner.js
var __iconNode622 = [
  [
    "path",
    {
      d: "M11.1 22H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.589 3.588A2.4 2.4 0 0 1 20 8v3.25",
      key: "uh4ikj"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "m21 22-2.88-2.88", key: "9dd25w" }],
  ["circle", { cx: "16", cy: "17", r: "3", key: "11br10" }]
];
var FileSearchCorner = createLucideIcon("file-search-corner", __iconNode622);

// ../node_modules/lucide-react/dist/esm/icons/file-search.js
var __iconNode623 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["circle", { cx: "11.5", cy: "14.5", r: "2.5", key: "1bq0ko" }],
  ["path", { d: "M13.3 16.3 15 18", key: "2quom7" }]
];
var FileSearch = createLucideIcon("file-search", __iconNode623);

// ../node_modules/lucide-react/dist/esm/icons/file-signal.js
var __iconNode624 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M8 15h.01", key: "a7atzg" }],
  ["path", { d: "M11.5 13.5a2.5 2.5 0 0 1 0 3", key: "1fccat" }],
  ["path", { d: "M15 12a5 5 0 0 1 0 6", key: "ps46cm" }]
];
var FileSignal = createLucideIcon("file-signal", __iconNode624);

// ../node_modules/lucide-react/dist/esm/icons/file-sliders.js
var __iconNode625 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }],
  ["path", { d: "M10 11v2", key: "1s651w" }],
  ["path", { d: "M8 17h8", key: "wh5c61" }],
  ["path", { d: "M14 16v2", key: "12fp5e" }]
];
var FileSliders = createLucideIcon("file-sliders", __iconNode625);

// ../node_modules/lucide-react/dist/esm/icons/file-spreadsheet.js
var __iconNode626 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M8 13h2", key: "yr2amv" }],
  ["path", { d: "M14 13h2", key: "un5t4a" }],
  ["path", { d: "M8 17h2", key: "2yhykz" }],
  ["path", { d: "M14 17h2", key: "10kma7" }]
];
var FileSpreadsheet = createLucideIcon("file-spreadsheet", __iconNode626);

// ../node_modules/lucide-react/dist/esm/icons/file-stack.js
var __iconNode627 = [
  ["path", { d: "M11 21a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-8a1 1 0 0 1 1-1", key: "likhh7" }],
  ["path", { d: "M16 16a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1", key: "17ky3x" }],
  [
    "path",
    {
      d: "M21 6a2 2 0 0 0-.586-1.414l-2-2A2 2 0 0 0 17 2h-3a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1z",
      key: "1hyeo0"
    }
  ]
];
var FileStack = createLucideIcon("file-stack", __iconNode627);

// ../node_modules/lucide-react/dist/esm/icons/file-symlink.js
var __iconNode628 = [
  [
    "path",
    {
      d: "M4 11V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h7",
      key: "huwfnr"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "m10 18 3-3-3-3", key: "18f6ys" }]
];
var FileSymlink = createLucideIcon("file-symlink", __iconNode628);

// ../node_modules/lucide-react/dist/esm/icons/file-terminal.js
var __iconNode629 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "m8 16 2-2-2-2", key: "10vzyd" }],
  ["path", { d: "M12 18h4", key: "1wd2n7" }]
];
var FileTerminal = createLucideIcon("file-terminal", __iconNode629);

// ../node_modules/lucide-react/dist/esm/icons/file-text.js
var __iconNode630 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M10 9H8", key: "b1mrlr" }],
  ["path", { d: "M16 13H8", key: "t4e002" }],
  ["path", { d: "M16 17H8", key: "z1uh3a" }]
];
var FileText = createLucideIcon("file-text", __iconNode630);

// ../node_modules/lucide-react/dist/esm/icons/file-type-corner.js
var __iconNode631 = [
  [
    "path",
    {
      d: "M12 22h6a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v6",
      key: "15usau"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M3 16v-1.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 .5.5V16", key: "s1gz5" }],
  ["path", { d: "M6 22h2", key: "194x9m" }],
  ["path", { d: "M7 14v8", key: "11ixej" }]
];
var FileTypeCorner = createLucideIcon("file-type-corner", __iconNode631);

// ../node_modules/lucide-react/dist/esm/icons/file-type.js
var __iconNode632 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M11 18h2", key: "12mj7e" }],
  ["path", { d: "M12 12v6", key: "3ahymv" }],
  ["path", { d: "M9 13v-.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 .5.5v.5", key: "qbrxap" }]
];
var FileType = createLucideIcon("file-type", __iconNode632);

// ../node_modules/lucide-react/dist/esm/icons/file-up.js
var __iconNode633 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M12 12v6", key: "3ahymv" }],
  ["path", { d: "m15 15-3-3-3 3", key: "15xj92" }]
];
var FileUp = createLucideIcon("file-up", __iconNode633);

// ../node_modules/lucide-react/dist/esm/icons/file-user.js
var __iconNode634 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M16 22a4 4 0 0 0-8 0", key: "7a83pg" }],
  ["circle", { cx: "12", cy: "15", r: "3", key: "g36mzq" }]
];
var FileUser = createLucideIcon("file-user", __iconNode634);

// ../node_modules/lucide-react/dist/esm/icons/file-video-camera.js
var __iconNode635 = [
  [
    "path",
    {
      d: "M4 12V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2",
      key: "jrl274"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  [
    "path",
    {
      d: "m10 17.843 3.033-1.755a.64.64 0 0 1 .967.56v4.704a.65.65 0 0 1-.967.56L10 20.157",
      key: "17aeo9"
    }
  ],
  ["rect", { width: "7", height: "6", x: "3", y: "16", rx: "1", key: "s27ndx" }]
];
var FileVideoCamera = createLucideIcon("file-video-camera", __iconNode635);

// ../node_modules/lucide-react/dist/esm/icons/file-volume.js
var __iconNode636 = [
  [
    "path",
    {
      d: "M4 11.55V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-1.95",
      key: "44gpjv"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M12 15a5 5 0 0 1 0 6", key: "oxg87a" }],
  [
    "path",
    {
      d: "M8 14.502a.5.5 0 0 0-.826-.381l-1.893 1.631a1 1 0 0 1-.651.243H3.5a.5.5 0 0 0-.5.501v3.006a.5.5 0 0 0 .5.501h1.129a1 1 0 0 1 .652.243l1.893 1.633a.5.5 0 0 0 .826-.38z",
      key: "8rtoi1"
    }
  ]
];
var FileVolume = createLucideIcon("file-volume", __iconNode636);

// ../node_modules/lucide-react/dist/esm/icons/file-x-corner.js
var __iconNode637 = [
  [
    "path",
    {
      d: "M11 22H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v5",
      key: "1jo35a"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "m15 17 5 5", key: "36xl1x" }],
  ["path", { d: "m20 17-5 5", key: "vdz27y" }]
];
var FileXCorner = createLucideIcon("file-x-corner", __iconNode637);

// ../node_modules/lucide-react/dist/esm/icons/file-x.js
var __iconNode638 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "m14.5 12.5-5 5", key: "b62r18" }],
  ["path", { d: "m9.5 12.5 5 5", key: "1rk7el" }]
];
var FileX = createLucideIcon("file-x", __iconNode638);

// ../node_modules/lucide-react/dist/esm/icons/file.js
var __iconNode639 = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }]
];
var File = createLucideIcon("file", __iconNode639);

// ../node_modules/lucide-react/dist/esm/icons/files.js
var __iconNode640 = [
  ["path", { d: "M15 2h-4a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8", key: "14sh0y" }],
  [
    "path",
    {
      d: "M16.706 2.706A2.4 2.4 0 0 0 15 2v5a1 1 0 0 0 1 1h5a2.4 2.4 0 0 0-.706-1.706z",
      key: "1970lx"
    }
  ],
  ["path", { d: "M5 7a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h8a2 2 0 0 0 1.732-1", key: "l4dndm" }]
];
var Files = createLucideIcon("files", __iconNode640);

// ../node_modules/lucide-react/dist/esm/icons/film.js
var __iconNode641 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M7 3v18", key: "bbkbws" }],
  ["path", { d: "M3 7.5h4", key: "zfgn84" }],
  ["path", { d: "M3 12h18", key: "1i2n21" }],
  ["path", { d: "M3 16.5h4", key: "1230mu" }],
  ["path", { d: "M17 3v18", key: "in4fa5" }],
  ["path", { d: "M17 7.5h4", key: "myr1c1" }],
  ["path", { d: "M17 16.5h4", key: "go4c1d" }]
];
var Film = createLucideIcon("film", __iconNode641);

// ../node_modules/lucide-react/dist/esm/icons/fingerprint-pattern.js
var __iconNode642 = [
  ["path", { d: "M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4", key: "1nerag" }],
  ["path", { d: "M14 13.12c0 2.38 0 6.38-1 8.88", key: "o46ks0" }],
  ["path", { d: "M17.29 21.02c.12-.6.43-2.3.5-3.02", key: "ptglia" }],
  ["path", { d: "M2 12a10 10 0 0 1 18-6", key: "ydlgp0" }],
  ["path", { d: "M2 16h.01", key: "1gqxmh" }],
  ["path", { d: "M21.8 16c.2-2 .131-5.354 0-6", key: "drycrb" }],
  ["path", { d: "M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2", key: "1tidbn" }],
  ["path", { d: "M8.65 22c.21-.66.45-1.32.57-2", key: "13wd9y" }],
  ["path", { d: "M9 6.8a6 6 0 0 1 9 5.2v2", key: "1fr1j5" }]
];
var FingerprintPattern = createLucideIcon("fingerprint-pattern", __iconNode642);

// ../node_modules/lucide-react/dist/esm/icons/fire-extinguisher.js
var __iconNode643 = [
  ["path", { d: "M15 6.5V3a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v3.5", key: "sqyvz" }],
  ["path", { d: "M9 18h8", key: "i7pszb" }],
  ["path", { d: "M18 3h-3", key: "7idoqj" }],
  ["path", { d: "M11 3a6 6 0 0 0-6 6v11", key: "1v5je3" }],
  ["path", { d: "M5 13h4", key: "svpcxo" }],
  ["path", { d: "M17 10a4 4 0 0 0-8 0v10a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2Z", key: "vsjego" }]
];
var FireExtinguisher = createLucideIcon("fire-extinguisher", __iconNode643);

// ../node_modules/lucide-react/dist/esm/icons/fish-off.js
var __iconNode644 = [
  [
    "path",
    {
      d: "M18 12.47v.03m0-.5v.47m-.475 5.056A6.744 6.744 0 0 1 15 18c-3.56 0-7.56-2.53-8.5-6 .348-1.28 1.114-2.433 2.121-3.38m3.444-2.088A8.802 8.802 0 0 1 15 6c3.56 0 6.06 2.54 7 6-.309 1.14-.786 2.177-1.413 3.058",
      key: "1j1hse"
    }
  ],
  [
    "path",
    {
      d: "M7 10.67C7 8 5.58 5.97 2.73 5.5c-1 1.5-1 5 .23 6.5-1.24 1.5-1.24 5-.23 6.5C5.58 18.03 7 16 7 13.33m7.48-4.372A9.77 9.77 0 0 1 16 6.07m0 11.86a9.77 9.77 0 0 1-1.728-3.618",
      key: "1q46z8"
    }
  ],
  [
    "path",
    {
      d: "m16.01 17.93-.23 1.4A2 2 0 0 1 13.8 21H9.5a5.96 5.96 0 0 0 1.49-3.98M8.53 3h5.27a2 2 0 0 1 1.98 1.67l.23 1.4M2 2l20 20",
      key: "1407gh"
    }
  ]
];
var FishOff = createLucideIcon("fish-off", __iconNode644);

// ../node_modules/lucide-react/dist/esm/icons/fish-symbol.js
var __iconNode645 = [
  ["path", { d: "M2 16s9-15 20-4C11 23 2 8 2 8", key: "h4oh4o" }]
];
var FishSymbol = createLucideIcon("fish-symbol", __iconNode645);

// ../node_modules/lucide-react/dist/esm/icons/fishing-hook.js
var __iconNode646 = [
  [
    "path",
    {
      d: "m17.586 11.414-5.93 5.93a1 1 0 0 1-8-8l3.137-3.137a.707.707 0 0 1 1.207.5V10",
      key: "157y8s"
    }
  ],
  ["path", { d: "M20.414 8.586 22 7", key: "5g2s34" }],
  ["circle", { cx: "19", cy: "10", r: "2", key: "7363ft" }]
];
var FishingHook = createLucideIcon("fishing-hook", __iconNode646);

// ../node_modules/lucide-react/dist/esm/icons/fish.js
var __iconNode647 = [
  [
    "path",
    {
      d: "M6.5 12c.94-3.46 4.94-6 8.5-6 3.56 0 6.06 2.54 7 6-.94 3.47-3.44 6-7 6s-7.56-2.53-8.5-6Z",
      key: "15baut"
    }
  ],
  ["path", { d: "M18 12v.5", key: "18hhni" }],
  ["path", { d: "M16 17.93a9.77 9.77 0 0 1 0-11.86", key: "16dt7o" }],
  [
    "path",
    {
      d: "M7 10.67C7 8 5.58 5.97 2.73 5.5c-1 1.5-1 5 .23 6.5-1.24 1.5-1.24 5-.23 6.5C5.58 18.03 7 16 7 13.33",
      key: "l9di03"
    }
  ],
  [
    "path",
    { d: "M10.46 7.26C10.2 5.88 9.17 4.24 8 3h5.8a2 2 0 0 1 1.98 1.67l.23 1.4", key: "1kjonw" }
  ],
  [
    "path",
    { d: "m16.01 17.93-.23 1.4A2 2 0 0 1 13.8 21H9.5a5.96 5.96 0 0 0 1.49-3.98", key: "1zlm23" }
  ]
];
var Fish = createLucideIcon("fish", __iconNode647);

// ../node_modules/lucide-react/dist/esm/icons/flag-off.js
var __iconNode648 = [
  ["path", { d: "M16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528", key: "1q158e" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M4 22V4", key: "1plyxx" }],
  ["path", { d: "M7.656 2H8c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10.347", key: "xj1b71" }]
];
var FlagOff = createLucideIcon("flag-off", __iconNode648);

// ../node_modules/lucide-react/dist/esm/icons/flag-triangle-right.js
var __iconNode649 = [
  [
    "path",
    { d: "M6 22V2.8a.8.8 0 0 1 1.17-.71l11.38 5.69a.8.8 0 0 1 0 1.44L6 15.5", key: "kfjsu0" }
  ]
];
var FlagTriangleRight = createLucideIcon("flag-triangle-right", __iconNode649);

// ../node_modules/lucide-react/dist/esm/icons/flag-triangle-left.js
var __iconNode650 = [
  [
    "path",
    { d: "M18 22V2.8a.8.8 0 0 0-1.17-.71L5.45 7.78a.8.8 0 0 0 0 1.44L18 15.5", key: "rbbtmw" }
  ]
];
var FlagTriangleLeft = createLucideIcon("flag-triangle-left", __iconNode650);

// ../node_modules/lucide-react/dist/esm/icons/flag.js
var __iconNode651 = [
  [
    "path",
    {
      d: "M4 22V4a1 1 0 0 1 .4-.8A6 6 0 0 1 8 2c3 0 5 2 7.333 2q2 0 3.067-.8A1 1 0 0 1 20 4v10a1 1 0 0 1-.4.8A6 6 0 0 1 16 16c-3 0-5-2-8-2a6 6 0 0 0-4 1.528",
      key: "1jaruq"
    }
  ]
];
var Flag = createLucideIcon("flag", __iconNode651);

// ../node_modules/lucide-react/dist/esm/icons/flame-kindling.js
var __iconNode652 = [
  [
    "path",
    {
      d: "M12 2c1 3 2.5 3.5 3.5 4.5A5 5 0 0 1 17 10a5 5 0 1 1-10 0c0-.3 0-.6.1-.9a2 2 0 1 0 3.3-2C8 4.5 11 2 12 2Z",
      key: "1ir223"
    }
  ],
  ["path", { d: "m5 22 14-4", key: "1brv4h" }],
  ["path", { d: "m5 18 14 4", key: "lgyyje" }]
];
var FlameKindling = createLucideIcon("flame-kindling", __iconNode652);

// ../node_modules/lucide-react/dist/esm/icons/flame.js
var __iconNode653 = [
  [
    "path",
    {
      d: "M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4",
      key: "1slcih"
    }
  ]
];
var Flame = createLucideIcon("flame", __iconNode653);

// ../node_modules/lucide-react/dist/esm/icons/flashlight-off.js
var __iconNode654 = [
  ["path", { d: "M11.652 6H18", key: "voqkpr" }],
  ["path", { d: "M12 13v1", key: "176q98" }],
  [
    "path",
    {
      d: "M16 16v4a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2v-8a4 4 0 0 0-.8-2.4l-.6-.8A3 3 0 0 1 6 7V6",
      key: "dzyf92"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    { d: "M7.649 2H17a1 1 0 0 1 1 1v4a3 3 0 0 1-.6 1.8l-.6.8a4 4 0 0 0-.55 1.007", key: "1hvcfn" }
  ]
];
var FlashlightOff = createLucideIcon("flashlight-off", __iconNode654);

// ../node_modules/lucide-react/dist/esm/icons/flashlight.js
var __iconNode655 = [
  ["path", { d: "M12 13v1", key: "176q98" }],
  [
    "path",
    {
      d: "M17 2a1 1 0 0 1 1 1v4a3 3 0 0 1-.6 1.8l-.6.8A4 4 0 0 0 16 12v8a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2v-8a4 4 0 0 0-.8-2.4l-.6-.8A3 3 0 0 1 6 7V3a1 1 0 0 1 1-1z",
      key: "17vh7j"
    }
  ],
  ["path", { d: "M6 6h12", key: "n6hhss" }]
];
var Flashlight = createLucideIcon("flashlight", __iconNode655);

// ../node_modules/lucide-react/dist/esm/icons/flask-conical-off.js
var __iconNode656 = [
  ["path", { d: "M10 2v2.343", key: "15t272" }],
  ["path", { d: "M14 2v6.343", key: "sxr80q" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M20 20a2 2 0 0 1-2 2H6a2 2 0 0 1-1.755-2.96l5.227-9.563", key: "k0duyd" }],
  ["path", { d: "M6.453 15H15", key: "1f0z33" }],
  ["path", { d: "M8.5 2h7", key: "csnxdl" }]
];
var FlaskConicalOff = createLucideIcon("flask-conical-off", __iconNode656);

// ../node_modules/lucide-react/dist/esm/icons/flask-conical.js
var __iconNode657 = [
  [
    "path",
    {
      d: "M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2",
      key: "18mbvz"
    }
  ],
  ["path", { d: "M6.453 15h11.094", key: "3shlmq" }],
  ["path", { d: "M8.5 2h7", key: "csnxdl" }]
];
var FlaskConical = createLucideIcon("flask-conical", __iconNode657);

// ../node_modules/lucide-react/dist/esm/icons/flask-round.js
var __iconNode658 = [
  ["path", { d: "M10 2v6.292a7 7 0 1 0 4 0V2", key: "1s42pc" }],
  ["path", { d: "M5 15h14", key: "m0yey3" }],
  ["path", { d: "M8.5 2h7", key: "csnxdl" }]
];
var FlaskRound = createLucideIcon("flask-round", __iconNode658);

// ../node_modules/lucide-react/dist/esm/icons/flip-horizontal-2.js
var __iconNode659 = [
  ["path", { d: "m3 7 5 5-5 5V7", key: "couhi7" }],
  ["path", { d: "m21 7-5 5 5 5V7", key: "6ouia7" }],
  ["path", { d: "M12 20v2", key: "1lh1kg" }],
  ["path", { d: "M12 14v2", key: "8jcxud" }],
  ["path", { d: "M12 8v2", key: "1woqiv" }],
  ["path", { d: "M12 2v2", key: "tus03m" }]
];
var FlipHorizontal2 = createLucideIcon("flip-horizontal-2", __iconNode659);

// ../node_modules/lucide-react/dist/esm/icons/flip-vertical-2.js
var __iconNode660 = [
  ["path", { d: "m17 3-5 5-5-5h10", key: "1ftt6x" }],
  ["path", { d: "m17 21-5-5-5 5h10", key: "1m0wmu" }],
  ["path", { d: "M4 12H2", key: "rhcxmi" }],
  ["path", { d: "M10 12H8", key: "s88cx1" }],
  ["path", { d: "M16 12h-2", key: "10asgb" }],
  ["path", { d: "M22 12h-2", key: "14jgyd" }]
];
var FlipVertical2 = createLucideIcon("flip-vertical-2", __iconNode660);

// ../node_modules/lucide-react/dist/esm/icons/flower-2.js
var __iconNode661 = [
  [
    "path",
    {
      d: "M12 5a3 3 0 1 1 3 3m-3-3a3 3 0 1 0-3 3m3-3v1M9 8a3 3 0 1 0 3 3M9 8h1m5 0a3 3 0 1 1-3 3m3-3h-1m-2 3v-1",
      key: "3pnvol"
    }
  ],
  ["circle", { cx: "12", cy: "8", r: "2", key: "1822b1" }],
  ["path", { d: "M12 10v12", key: "6ubwww" }],
  ["path", { d: "M12 22c4.2 0 7-1.667 7-5-4.2 0-7 1.667-7 5Z", key: "9hd38g" }],
  ["path", { d: "M12 22c-4.2 0-7-1.667-7-5 4.2 0 7 1.667 7 5Z", key: "ufn41s" }]
];
var Flower2 = createLucideIcon("flower-2", __iconNode661);

// ../node_modules/lucide-react/dist/esm/icons/focus.js
var __iconNode662 = [
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
  ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
  ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }]
];
var Focus = createLucideIcon("focus", __iconNode662);

// ../node_modules/lucide-react/dist/esm/icons/flower.js
var __iconNode663 = [
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
  [
    "path",
    {
      d: "M12 16.5A4.5 4.5 0 1 1 7.5 12 4.5 4.5 0 1 1 12 7.5a4.5 4.5 0 1 1 4.5 4.5 4.5 4.5 0 1 1-4.5 4.5",
      key: "14wa3c"
    }
  ],
  ["path", { d: "M12 7.5V9", key: "1oy5b0" }],
  ["path", { d: "M7.5 12H9", key: "eltsq1" }],
  ["path", { d: "M16.5 12H15", key: "vk5kw4" }],
  ["path", { d: "M12 16.5V15", key: "k7eayi" }],
  ["path", { d: "m8 8 1.88 1.88", key: "nxy4qf" }],
  ["path", { d: "M14.12 9.88 16 8", key: "1lst6k" }],
  ["path", { d: "m8 16 1.88-1.88", key: "h2eex1" }],
  ["path", { d: "M14.12 14.12 16 16", key: "uqkrx3" }]
];
var Flower = createLucideIcon("flower", __iconNode663);

// ../node_modules/lucide-react/dist/esm/icons/fold-horizontal.js
var __iconNode664 = [
  ["path", { d: "M2 12h6", key: "1wqiqv" }],
  ["path", { d: "M22 12h-6", key: "1eg9hc" }],
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "M12 8v2", key: "1woqiv" }],
  ["path", { d: "M12 14v2", key: "8jcxud" }],
  ["path", { d: "M12 20v2", key: "1lh1kg" }],
  ["path", { d: "m19 9-3 3 3 3", key: "12ol22" }],
  ["path", { d: "m5 15 3-3-3-3", key: "1kdhjc" }]
];
var FoldHorizontal = createLucideIcon("fold-horizontal", __iconNode664);

// ../node_modules/lucide-react/dist/esm/icons/fold-vertical.js
var __iconNode665 = [
  ["path", { d: "M12 22v-6", key: "6o8u61" }],
  ["path", { d: "M12 8V2", key: "1wkif3" }],
  ["path", { d: "M4 12H2", key: "rhcxmi" }],
  ["path", { d: "M10 12H8", key: "s88cx1" }],
  ["path", { d: "M16 12h-2", key: "10asgb" }],
  ["path", { d: "M22 12h-2", key: "14jgyd" }],
  ["path", { d: "m15 19-3-3-3 3", key: "e37ymu" }],
  ["path", { d: "m15 5-3 3-3-3", key: "19d6lf" }]
];
var FoldVertical = createLucideIcon("fold-vertical", __iconNode665);

// ../node_modules/lucide-react/dist/esm/icons/folder-archive.js
var __iconNode666 = [
  ["circle", { cx: "15", cy: "19", r: "2", key: "u2pros" }],
  [
    "path",
    {
      d: "M20.9 19.8A2 2 0 0 0 22 18V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h5.1",
      key: "1jj40k"
    }
  ],
  ["path", { d: "M15 11v-1", key: "cntcp" }],
  ["path", { d: "M15 17v-2", key: "1279jj" }]
];
var FolderArchive = createLucideIcon("folder-archive", __iconNode666);

// ../node_modules/lucide-react/dist/esm/icons/folder-check.js
var __iconNode667 = [
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ],
  ["path", { d: "m9 13 2 2 4-4", key: "6343dt" }]
];
var FolderCheck = createLucideIcon("folder-check", __iconNode667);

// ../node_modules/lucide-react/dist/esm/icons/folder-clock.js
var __iconNode668 = [
  ["path", { d: "M16 14v2.2l1.6 1", key: "fo4ql5" }],
  [
    "path",
    {
      d: "M7 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2",
      key: "1urifu"
    }
  ],
  ["circle", { cx: "16", cy: "16", r: "6", key: "qoo3c4" }]
];
var FolderClock = createLucideIcon("folder-clock", __iconNode668);

// ../node_modules/lucide-react/dist/esm/icons/folder-closed.js
var __iconNode669 = [
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ],
  ["path", { d: "M2 10h20", key: "1ir3d8" }]
];
var FolderClosed = createLucideIcon("folder-closed", __iconNode669);

// ../node_modules/lucide-react/dist/esm/icons/folder-code.js
var __iconNode670 = [
  ["path", { d: "M10 10.5 8 13l2 2.5", key: "m4t9c1" }],
  ["path", { d: "m14 10.5 2 2.5-2 2.5", key: "14w2eb" }],
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2z",
      key: "1u1bxd"
    }
  ]
];
var FolderCode = createLucideIcon("folder-code", __iconNode670);

// ../node_modules/lucide-react/dist/esm/icons/folder-cog.js
var __iconNode671 = [
  [
    "path",
    {
      d: "M10.3 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.98a2 2 0 0 1 1.69.9l.66 1.2A2 2 0 0 0 12 6h8a2 2 0 0 1 2 2v3.3",
      key: "128dxu"
    }
  ],
  ["path", { d: "m14.305 19.53.923-.382", key: "3m78fa" }],
  ["path", { d: "m15.228 16.852-.923-.383", key: "npixar" }],
  ["path", { d: "m16.852 15.228-.383-.923", key: "5xggr7" }],
  ["path", { d: "m16.852 20.772-.383.924", key: "dpfhf9" }],
  ["path", { d: "m19.148 15.228.383-.923", key: "1reyyz" }],
  ["path", { d: "m19.53 21.696-.382-.924", key: "1goivc" }],
  ["path", { d: "m20.772 16.852.924-.383", key: "htqkph" }],
  ["path", { d: "m20.772 19.148.924.383", key: "9w9pjp" }],
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }]
];
var FolderCog = createLucideIcon("folder-cog", __iconNode671);

// ../node_modules/lucide-react/dist/esm/icons/folder-dot.js
var __iconNode672 = [
  [
    "path",
    {
      d: "M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z",
      key: "1fr9dc"
    }
  ],
  ["circle", { cx: "12", cy: "13", r: "1", key: "49l61u" }]
];
var FolderDot = createLucideIcon("folder-dot", __iconNode672);

// ../node_modules/lucide-react/dist/esm/icons/folder-down.js
var __iconNode673 = [
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ],
  ["path", { d: "M12 10v6", key: "1bos4e" }],
  ["path", { d: "m15 13-3 3-3-3", key: "6j2sf0" }]
];
var FolderDown = createLucideIcon("folder-down", __iconNode673);

// ../node_modules/lucide-react/dist/esm/icons/folder-git-2.js
var __iconNode674 = [
  ["path", { d: "M18 19a5 5 0 0 1-5-5v8", key: "sz5oeg" }],
  [
    "path",
    {
      d: "M9 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v5",
      key: "1w6njk"
    }
  ],
  ["circle", { cx: "13", cy: "12", r: "2", key: "1j92g6" }],
  ["circle", { cx: "20", cy: "19", r: "2", key: "1obnsp" }]
];
var FolderGit2 = createLucideIcon("folder-git-2", __iconNode674);

// ../node_modules/lucide-react/dist/esm/icons/folder-git.js
var __iconNode675 = [
  ["circle", { cx: "12", cy: "13", r: "2", key: "1c1ljs" }],
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ],
  ["path", { d: "M14 13h3", key: "1dgedf" }],
  ["path", { d: "M7 13h3", key: "1pygq7" }]
];
var FolderGit = createLucideIcon("folder-git", __iconNode675);

// ../node_modules/lucide-react/dist/esm/icons/folder-heart.js
var __iconNode676 = [
  [
    "path",
    {
      d: "M10.638 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v3.417",
      key: "10r6g4"
    }
  ],
  [
    "path",
    {
      d: "M14.62 18.8A2.25 2.25 0 1 1 18 15.836a2.25 2.25 0 1 1 3.38 2.966l-2.626 2.856a.998.998 0 0 1-1.507 0z",
      key: "15cy7q"
    }
  ]
];
var FolderHeart = createLucideIcon("folder-heart", __iconNode676);

// ../node_modules/lucide-react/dist/esm/icons/folder-input.js
var __iconNode677 = [
  [
    "path",
    {
      d: "M2 9V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-1",
      key: "fm4g5t"
    }
  ],
  ["path", { d: "M2 13h10", key: "pgb2dq" }],
  ["path", { d: "m9 16 3-3-3-3", key: "6m91ic" }]
];
var FolderInput = createLucideIcon("folder-input", __iconNode677);

// ../node_modules/lucide-react/dist/esm/icons/folder-kanban.js
var __iconNode678 = [
  [
    "path",
    {
      d: "M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z",
      key: "1fr9dc"
    }
  ],
  ["path", { d: "M8 10v4", key: "tgpxqk" }],
  ["path", { d: "M12 10v2", key: "hh53o1" }],
  ["path", { d: "M16 10v6", key: "1d6xys" }]
];
var FolderKanban = createLucideIcon("folder-kanban", __iconNode678);

// ../node_modules/lucide-react/dist/esm/icons/folder-key.js
var __iconNode679 = [
  [
    "path",
    {
      d: "M13 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v1.36",
      key: "1shsnm"
    }
  ],
  ["path", { d: "M19 12v6", key: "kflna4" }],
  ["path", { d: "M19 14h2", key: "wp2qbk" }],
  ["circle", { cx: "19", cy: "20", r: "2", key: "1jfyz6" }]
];
var FolderKey = createLucideIcon("folder-key", __iconNode679);

// ../node_modules/lucide-react/dist/esm/icons/folder-lock.js
var __iconNode680 = [
  ["rect", { width: "8", height: "5", x: "14", y: "17", rx: "1", key: "19aais" }],
  [
    "path",
    {
      d: "M10 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v2.5",
      key: "1w6v7t"
    }
  ],
  ["path", { d: "M20 17v-2a2 2 0 1 0-4 0v2", key: "pwaxnr" }]
];
var FolderLock = createLucideIcon("folder-lock", __iconNode680);

// ../node_modules/lucide-react/dist/esm/icons/folder-minus.js
var __iconNode681 = [
  ["path", { d: "M9 13h6", key: "1uhe8q" }],
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ]
];
var FolderMinus = createLucideIcon("folder-minus", __iconNode681);

// ../node_modules/lucide-react/dist/esm/icons/folder-open-dot.js
var __iconNode682 = [
  [
    "path",
    {
      d: "m6 14 1.45-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.55 6a2 2 0 0 1-1.94 1.5H4a2 2 0 0 1-2-2V5c0-1.1.9-2 2-2h3.93a2 2 0 0 1 1.66.9l.82 1.2a2 2 0 0 0 1.66.9H18a2 2 0 0 1 2 2v2",
      key: "1nmvlm"
    }
  ],
  ["circle", { cx: "14", cy: "15", r: "1", key: "1gm4qj" }]
];
var FolderOpenDot = createLucideIcon("folder-open-dot", __iconNode682);

// ../node_modules/lucide-react/dist/esm/icons/folder-open.js
var __iconNode683 = [
  [
    "path",
    {
      d: "m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",
      key: "usdka0"
    }
  ]
];
var FolderOpen = createLucideIcon("folder-open", __iconNode683);

// ../node_modules/lucide-react/dist/esm/icons/folder-output.js
var __iconNode684 = [
  [
    "path",
    {
      d: "M2 7.5V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-1.5",
      key: "1yk7aj"
    }
  ],
  ["path", { d: "M2 13h10", key: "pgb2dq" }],
  ["path", { d: "m5 10-3 3 3 3", key: "1r8ie0" }]
];
var FolderOutput = createLucideIcon("folder-output", __iconNode684);

// ../node_modules/lucide-react/dist/esm/icons/folder-pen.js
var __iconNode685 = [
  [
    "path",
    {
      d: "M2 11.5V5a2 2 0 0 1 2-2h3.9c.7 0 1.3.3 1.7.9l.8 1.2c.4.6 1 .9 1.7.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-9.5",
      key: "a8xqs0"
    }
  ],
  [
    "path",
    {
      d: "M11.378 13.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
      key: "1saktj"
    }
  ]
];
var FolderPen = createLucideIcon("folder-pen", __iconNode685);

// ../node_modules/lucide-react/dist/esm/icons/folder-plus.js
var __iconNode686 = [
  ["path", { d: "M12 10v6", key: "1bos4e" }],
  ["path", { d: "M9 13h6", key: "1uhe8q" }],
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ]
];
var FolderPlus = createLucideIcon("folder-plus", __iconNode686);

// ../node_modules/lucide-react/dist/esm/icons/folder-root.js
var __iconNode687 = [
  [
    "path",
    {
      d: "M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z",
      key: "1fr9dc"
    }
  ],
  ["circle", { cx: "12", cy: "13", r: "2", key: "1c1ljs" }],
  ["path", { d: "M12 15v5", key: "11xva1" }]
];
var FolderRoot = createLucideIcon("folder-root", __iconNode687);

// ../node_modules/lucide-react/dist/esm/icons/folder-search-2.js
var __iconNode688 = [
  ["circle", { cx: "11.5", cy: "12.5", r: "2.5", key: "1ea5ju" }],
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ],
  ["path", { d: "M13.3 14.3 15 16", key: "1y4v1n" }]
];
var FolderSearch2 = createLucideIcon("folder-search-2", __iconNode688);

// ../node_modules/lucide-react/dist/esm/icons/folder-search.js
var __iconNode689 = [
  [
    "path",
    {
      d: "M10.7 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v4.1",
      key: "1bw5m7"
    }
  ],
  ["path", { d: "m21 21-1.9-1.9", key: "1g2n9r" }],
  ["circle", { cx: "17", cy: "17", r: "3", key: "18b49y" }]
];
var FolderSearch = createLucideIcon("folder-search", __iconNode689);

// ../node_modules/lucide-react/dist/esm/icons/folder-symlink.js
var __iconNode690 = [
  [
    "path",
    {
      d: "M2 9.35V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h7",
      key: "y8kt7d"
    }
  ],
  ["path", { d: "m8 16 3-3-3-3", key: "rlqrt1" }]
];
var FolderSymlink = createLucideIcon("folder-symlink", __iconNode690);

// ../node_modules/lucide-react/dist/esm/icons/folder-sync.js
var __iconNode691 = [
  [
    "path",
    {
      d: "M9 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H20a2 2 0 0 1 2 2v.5",
      key: "1dkoa9"
    }
  ],
  ["path", { d: "M12 10v4h4", key: "1czhmt" }],
  ["path", { d: "m12 14 1.535-1.605a5 5 0 0 1 8 1.5", key: "lvuxfi" }],
  ["path", { d: "M22 22v-4h-4", key: "1ewp4q" }],
  ["path", { d: "m22 18-1.535 1.605a5 5 0 0 1-8-1.5", key: "14ync0" }]
];
var FolderSync = createLucideIcon("folder-sync", __iconNode691);

// ../node_modules/lucide-react/dist/esm/icons/folder-tree.js
var __iconNode692 = [
  [
    "path",
    {
      d: "M20 10a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1h-2.5a1 1 0 0 1-.8-.4l-.9-1.2A1 1 0 0 0 15 3h-2a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z",
      key: "hod4my"
    }
  ],
  [
    "path",
    {
      d: "M20 21a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1h-2.9a1 1 0 0 1-.88-.55l-.42-.85a1 1 0 0 0-.92-.6H13a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z",
      key: "w4yl2u"
    }
  ],
  ["path", { d: "M3 5a2 2 0 0 0 2 2h3", key: "f2jnh7" }],
  ["path", { d: "M3 3v13a2 2 0 0 0 2 2h3", key: "k8epm1" }]
];
var FolderTree = createLucideIcon("folder-tree", __iconNode692);

// ../node_modules/lucide-react/dist/esm/icons/folder-up.js
var __iconNode693 = [
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ],
  ["path", { d: "M12 10v6", key: "1bos4e" }],
  ["path", { d: "m9 13 3-3 3 3", key: "1pxg3c" }]
];
var FolderUp = createLucideIcon("folder-up", __iconNode693);

// ../node_modules/lucide-react/dist/esm/icons/folder-x.js
var __iconNode694 = [
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ],
  ["path", { d: "m9.5 10.5 5 5", key: "ra9qjz" }],
  ["path", { d: "m14.5 10.5-5 5", key: "l2rkpq" }]
];
var FolderX = createLucideIcon("folder-x", __iconNode694);

// ../node_modules/lucide-react/dist/esm/icons/folder.js
var __iconNode695 = [
  [
    "path",
    {
      d: "M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",
      key: "1kt360"
    }
  ]
];
var Folder = createLucideIcon("folder", __iconNode695);

// ../node_modules/lucide-react/dist/esm/icons/folders.js
var __iconNode696 = [
  [
    "path",
    {
      d: "M20 5a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H9a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h2.5a1.5 1.5 0 0 1 1.2.6l.6.8a1.5 1.5 0 0 0 1.2.6z",
      key: "a4852j"
    }
  ],
  [
    "path",
    { d: "M3 8.268a2 2 0 0 0-1 1.738V19a2 2 0 0 0 2 2h11a2 2 0 0 0 1.732-1", key: "yxbcw3" }
  ]
];
var Folders = createLucideIcon("folders", __iconNode696);

// ../node_modules/lucide-react/dist/esm/icons/footprints.js
var __iconNode697 = [
  [
    "path",
    {
      d: "M4 16v-2.38C4 11.5 2.97 10.5 3 8c.03-2.72 1.49-6 4.5-6C9.37 2 10 3.8 10 5.5c0 3.11-2 5.66-2 8.68V16a2 2 0 1 1-4 0Z",
      key: "1dudjm"
    }
  ],
  [
    "path",
    {
      d: "M20 20v-2.38c0-2.12 1.03-3.12 1-5.62-.03-2.72-1.49-6-4.5-6C14.63 6 14 7.8 14 9.5c0 3.11 2 5.66 2 8.68V20a2 2 0 1 0 4 0Z",
      key: "l2t8xc"
    }
  ],
  ["path", { d: "M16 17h4", key: "1dejxt" }],
  ["path", { d: "M4 13h4", key: "1bwh8b" }]
];
var Footprints = createLucideIcon("footprints", __iconNode697);

// ../node_modules/lucide-react/dist/esm/icons/forklift.js
var __iconNode698 = [
  ["path", { d: "M12 12H5a2 2 0 0 0-2 2v5", key: "7zsz91" }],
  ["path", { d: "M15 19h7", key: "1askl3" }],
  ["path", { d: "M16 19V2", key: "1gf9nk" }],
  [
    "path",
    {
      d: "M6 12V7a2 2 0 0 1 2-2h2.172a2 2 0 0 1 1.414.586l3.828 3.828A2 2 0 0 1 16 10.828",
      key: "enx9tf"
    }
  ],
  ["path", { d: "M7 19h4", key: "fumhkk" }],
  ["circle", { cx: "13", cy: "19", r: "2", key: "wjnkru" }],
  ["circle", { cx: "5", cy: "19", r: "2", key: "v8kfzx" }]
];
var Forklift = createLucideIcon("forklift", __iconNode698);

// ../node_modules/lucide-react/dist/esm/icons/form.js
var __iconNode699 = [
  ["path", { d: "M4 14h6", key: "77gv2w" }],
  ["path", { d: "M4 2h10", key: "a2b314" }],
  ["rect", { x: "4", y: "18", width: "16", height: "4", rx: "1", key: "sybzq6" }],
  ["rect", { x: "4", y: "6", width: "16", height: "4", rx: "1", key: "1osc9e" }]
];
var Form = createLucideIcon("form", __iconNode699);

// ../node_modules/lucide-react/dist/esm/icons/forward.js
var __iconNode700 = [
  ["path", { d: "m15 17 5-5-5-5", key: "nf172w" }],
  ["path", { d: "M4 18v-2a4 4 0 0 1 4-4h12", key: "jmiej9" }]
];
var Forward = createLucideIcon("forward", __iconNode700);

// ../node_modules/lucide-react/dist/esm/icons/frame.js
var __iconNode701 = [
  ["line", { x1: "22", x2: "2", y1: "6", y2: "6", key: "15w7dq" }],
  ["line", { x1: "22", x2: "2", y1: "18", y2: "18", key: "1ip48p" }],
  ["line", { x1: "6", x2: "6", y1: "2", y2: "22", key: "a2lnyx" }],
  ["line", { x1: "18", x2: "18", y1: "2", y2: "22", key: "8vb6jd" }]
];
var Frame = createLucideIcon("frame", __iconNode701);

// ../node_modules/lucide-react/dist/esm/icons/framer.js
var __iconNode702 = [
  ["path", { d: "M5 16V9h14V2H5l14 14h-7m-7 0 7 7v-7m-7 0h7", key: "1a2nng" }]
];
var Framer = createLucideIcon("framer", __iconNode702);

// ../node_modules/lucide-react/dist/esm/icons/frown.js
var __iconNode703 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M16 16s-1.5-2-4-2-4 2-4 2", key: "epbg0q" }],
  ["line", { x1: "9", x2: "9.01", y1: "9", y2: "9", key: "yxxnd0" }],
  ["line", { x1: "15", x2: "15.01", y1: "9", y2: "9", key: "1p4y9e" }]
];
var Frown = createLucideIcon("frown", __iconNode703);

// ../node_modules/lucide-react/dist/esm/icons/fuel.js
var __iconNode704 = [
  [
    "path",
    { d: "M14 13h2a2 2 0 0 1 2 2v2a2 2 0 0 0 4 0v-6.998a2 2 0 0 0-.59-1.42L18 5", key: "1wtuz0" }
  ],
  ["path", { d: "M14 21V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v16", key: "e09ifn" }],
  ["path", { d: "M2 21h13", key: "1x0fut" }],
  ["path", { d: "M3 9h11", key: "1p7c0w" }]
];
var Fuel = createLucideIcon("fuel", __iconNode704);

// ../node_modules/lucide-react/dist/esm/icons/fullscreen.js
var __iconNode705 = [
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
  ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
  ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }],
  ["rect", { width: "10", height: "8", x: "7", y: "8", rx: "1", key: "vys8me" }]
];
var Fullscreen = createLucideIcon("fullscreen", __iconNode705);

// ../node_modules/lucide-react/dist/esm/icons/funnel-plus.js
var __iconNode706 = [
  [
    "path",
    {
      d: "M13.354 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14v6a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341l1.218-1.348",
      key: "8mvsmf"
    }
  ],
  ["path", { d: "M16 6h6", key: "1dogtp" }],
  ["path", { d: "M19 3v6", key: "1ytpjt" }]
];
var FunnelPlus = createLucideIcon("funnel-plus", __iconNode706);

// ../node_modules/lucide-react/dist/esm/icons/funnel-x.js
var __iconNode707 = [
  [
    "path",
    {
      d: "M12.531 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14v6a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341l.427-.473",
      key: "ol2ft2"
    }
  ],
  ["path", { d: "m16.5 3.5 5 5", key: "15e6fa" }],
  ["path", { d: "m21.5 3.5-5 5", key: "m0lwru" }]
];
var FunnelX = createLucideIcon("funnel-x", __iconNode707);

// ../node_modules/lucide-react/dist/esm/icons/funnel.js
var __iconNode708 = [
  [
    "path",
    {
      d: "M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z",
      key: "sc7q7i"
    }
  ]
];
var Funnel = createLucideIcon("funnel", __iconNode708);

// ../node_modules/lucide-react/dist/esm/icons/gallery-horizontal-end.js
var __iconNode709 = [
  ["path", { d: "M2 7v10", key: "a2pl2d" }],
  ["path", { d: "M6 5v14", key: "1kq3d7" }],
  ["rect", { width: "12", height: "18", x: "10", y: "3", rx: "2", key: "13i7bc" }]
];
var GalleryHorizontalEnd = createLucideIcon("gallery-horizontal-end", __iconNode709);

// ../node_modules/lucide-react/dist/esm/icons/gallery-horizontal.js
var __iconNode710 = [
  ["path", { d: "M2 3v18", key: "pzttux" }],
  ["rect", { width: "12", height: "18", x: "6", y: "3", rx: "2", key: "btr8bg" }],
  ["path", { d: "M22 3v18", key: "6jf3v" }]
];
var GalleryHorizontal = createLucideIcon("gallery-horizontal", __iconNode710);

// ../node_modules/lucide-react/dist/esm/icons/gallery-thumbnails.js
var __iconNode711 = [
  ["rect", { width: "18", height: "14", x: "3", y: "3", rx: "2", key: "74y24f" }],
  ["path", { d: "M4 21h1", key: "16zlid" }],
  ["path", { d: "M9 21h1", key: "15o7lz" }],
  ["path", { d: "M14 21h1", key: "v9vybs" }],
  ["path", { d: "M19 21h1", key: "edywat" }]
];
var GalleryThumbnails = createLucideIcon("gallery-thumbnails", __iconNode711);

// ../node_modules/lucide-react/dist/esm/icons/gallery-vertical-end.js
var __iconNode712 = [
  ["path", { d: "M7 2h10", key: "nczekb" }],
  ["path", { d: "M5 6h14", key: "u2x4p" }],
  ["rect", { width: "18", height: "12", x: "3", y: "10", rx: "2", key: "l0tzu3" }]
];
var GalleryVerticalEnd = createLucideIcon("gallery-vertical-end", __iconNode712);

// ../node_modules/lucide-react/dist/esm/icons/gallery-vertical.js
var __iconNode713 = [
  ["path", { d: "M3 2h18", key: "15qxfx" }],
  ["rect", { width: "18", height: "12", x: "3", y: "6", rx: "2", key: "1439r6" }],
  ["path", { d: "M3 22h18", key: "8prr45" }]
];
var GalleryVertical = createLucideIcon("gallery-vertical", __iconNode713);

// ../node_modules/lucide-react/dist/esm/icons/gamepad-directional.js
var __iconNode714 = [
  [
    "path",
    {
      d: "M11.146 15.854a1.207 1.207 0 0 1 1.708 0l1.56 1.56A2 2 0 0 1 15 18.828V21a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1v-2.172a2 2 0 0 1 .586-1.414z",
      key: "1re2og"
    }
  ],
  [
    "path",
    {
      d: "M18.828 15a2 2 0 0 1-1.414-.586l-1.56-1.56a1.207 1.207 0 0 1 0-1.708l1.56-1.56A2 2 0 0 1 18.828 9H21a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1z",
      key: "1pchrj"
    }
  ],
  [
    "path",
    {
      d: "M6.586 14.414A2 2 0 0 1 5.172 15H3a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1h2.172a2 2 0 0 1 1.414.586l1.56 1.56a1.207 1.207 0 0 1 0 1.708z",
      key: "16mt4c"
    }
  ],
  [
    "path",
    {
      d: "M9 3a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2.172a2 2 0 0 1-.586 1.414l-1.56 1.56a1.207 1.207 0 0 1-1.708 0l-1.56-1.56A2 2 0 0 1 9 5.172z",
      key: "19ox6c"
    }
  ]
];
var GamepadDirectional = createLucideIcon("gamepad-directional", __iconNode714);

// ../node_modules/lucide-react/dist/esm/icons/gamepad-2.js
var __iconNode715 = [
  ["line", { x1: "6", x2: "10", y1: "11", y2: "11", key: "1gktln" }],
  ["line", { x1: "8", x2: "8", y1: "9", y2: "13", key: "qnk9ow" }],
  ["line", { x1: "15", x2: "15.01", y1: "12", y2: "12", key: "krot7o" }],
  ["line", { x1: "18", x2: "18.01", y1: "10", y2: "10", key: "1lcuu1" }],
  [
    "path",
    {
      d: "M17.32 5H6.68a4 4 0 0 0-3.978 3.59c-.006.052-.01.101-.017.152C2.604 9.416 2 14.456 2 16a3 3 0 0 0 3 3c1 0 1.5-.5 2-1l1.414-1.414A2 2 0 0 1 9.828 16h4.344a2 2 0 0 1 1.414.586L17 18c.5.5 1 1 2 1a3 3 0 0 0 3-3c0-1.545-.604-6.584-.685-7.258-.007-.05-.011-.1-.017-.151A4 4 0 0 0 17.32 5z",
      key: "mfqc10"
    }
  ]
];
var Gamepad2 = createLucideIcon("gamepad-2", __iconNode715);

// ../node_modules/lucide-react/dist/esm/icons/gamepad.js
var __iconNode716 = [
  ["line", { x1: "6", x2: "10", y1: "12", y2: "12", key: "161bw2" }],
  ["line", { x1: "8", x2: "8", y1: "10", y2: "14", key: "1i6ji0" }],
  ["line", { x1: "15", x2: "15.01", y1: "13", y2: "13", key: "dqpgro" }],
  ["line", { x1: "18", x2: "18.01", y1: "11", y2: "11", key: "meh2c" }],
  ["rect", { width: "20", height: "12", x: "2", y: "6", rx: "2", key: "9lu3g6" }]
];
var Gamepad = createLucideIcon("gamepad", __iconNode716);

// ../node_modules/lucide-react/dist/esm/icons/gauge.js
var __iconNode717 = [
  ["path", { d: "m12 14 4-4", key: "9kzdfg" }],
  ["path", { d: "M3.34 19a10 10 0 1 1 17.32 0", key: "19p75a" }]
];
var Gauge = createLucideIcon("gauge", __iconNode717);

// ../node_modules/lucide-react/dist/esm/icons/gavel.js
var __iconNode718 = [
  ["path", { d: "m14 13-8.381 8.38a1 1 0 0 1-3.001-3l8.384-8.381", key: "pgg06f" }],
  ["path", { d: "m16 16 6-6", key: "vzrcl6" }],
  ["path", { d: "m21.5 10.5-8-8", key: "a17d9x" }],
  ["path", { d: "m8 8 6-6", key: "18bi4p" }],
  ["path", { d: "m8.5 7.5 8 8", key: "1oyaui" }]
];
var Gavel = createLucideIcon("gavel", __iconNode718);

// ../node_modules/lucide-react/dist/esm/icons/gem.js
var __iconNode719 = [
  ["path", { d: "M10.5 3 8 9l4 13 4-13-2.5-6", key: "b3dvk1" }],
  [
    "path",
    {
      d: "M17 3a2 2 0 0 1 1.6.8l3 4a2 2 0 0 1 .013 2.382l-7.99 10.986a2 2 0 0 1-3.247 0l-7.99-10.986A2 2 0 0 1 2.4 7.8l2.998-3.997A2 2 0 0 1 7 3z",
      key: "7w4byz"
    }
  ],
  ["path", { d: "M2 9h20", key: "16fsjt" }]
];
var Gem = createLucideIcon("gem", __iconNode719);

// ../node_modules/lucide-react/dist/esm/icons/georgian-lari.js
var __iconNode720 = [
  ["path", { d: "M11.5 21a7.5 7.5 0 1 1 7.35-9", key: "1gyj8k" }],
  ["path", { d: "M13 12V3", key: "18om2a" }],
  ["path", { d: "M4 21h16", key: "1h09gz" }],
  ["path", { d: "M9 12V3", key: "geutu0" }]
];
var GeorgianLari = createLucideIcon("georgian-lari", __iconNode720);

// ../node_modules/lucide-react/dist/esm/icons/ghost.js
var __iconNode721 = [
  ["path", { d: "M9 10h.01", key: "qbtxuw" }],
  ["path", { d: "M15 10h.01", key: "1qmjsl" }],
  [
    "path",
    {
      d: "M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z",
      key: "uwwb07"
    }
  ]
];
var Ghost = createLucideIcon("ghost", __iconNode721);

// ../node_modules/lucide-react/dist/esm/icons/gift.js
var __iconNode722 = [
  ["path", { d: "M12 7v14", key: "1akyts" }],
  ["path", { d: "M20 11v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-8", key: "1sqzm4" }],
  [
    "path",
    { d: "M7.5 7a1 1 0 0 1 0-5A4.8 8 0 0 1 12 7a4.8 8 0 0 1 4.5-5 1 1 0 0 1 0 5", key: "kc0143" }
  ],
  ["rect", { x: "3", y: "7", width: "18", height: "4", rx: "1", key: "1hberx" }]
];
var Gift = createLucideIcon("gift", __iconNode722);

// ../node_modules/lucide-react/dist/esm/icons/git-branch-minus.js
var __iconNode723 = [
  ["path", { d: "M15 6a9 9 0 0 0-9 9V3", key: "1cii5b" }],
  ["path", { d: "M21 18h-6", key: "139f0c" }],
  ["circle", { cx: "18", cy: "6", r: "3", key: "1h7g24" }],
  ["circle", { cx: "6", cy: "18", r: "3", key: "fqmcym" }]
];
var GitBranchMinus = createLucideIcon("git-branch-minus", __iconNode723);

// ../node_modules/lucide-react/dist/esm/icons/git-branch-plus.js
var __iconNode724 = [
  ["path", { d: "M6 3v12", key: "qpgusn" }],
  ["path", { d: "M18 9a3 3 0 1 0 0-6 3 3 0 0 0 0 6z", key: "1d02ji" }],
  ["path", { d: "M6 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6z", key: "chk6ph" }],
  ["path", { d: "M15 6a9 9 0 0 0-9 9", key: "or332x" }],
  ["path", { d: "M18 15v6", key: "9wciyi" }],
  ["path", { d: "M21 18h-6", key: "139f0c" }]
];
var GitBranchPlus = createLucideIcon("git-branch-plus", __iconNode724);

// ../node_modules/lucide-react/dist/esm/icons/git-branch.js
var __iconNode725 = [
  ["path", { d: "M15 6a9 9 0 0 0-9 9V3", key: "1cii5b" }],
  ["circle", { cx: "18", cy: "6", r: "3", key: "1h7g24" }],
  ["circle", { cx: "6", cy: "18", r: "3", key: "fqmcym" }]
];
var GitBranch = createLucideIcon("git-branch", __iconNode725);

// ../node_modules/lucide-react/dist/esm/icons/git-commit-horizontal.js
var __iconNode726 = [
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
  ["line", { x1: "3", x2: "9", y1: "12", y2: "12", key: "1dyftd" }],
  ["line", { x1: "15", x2: "21", y1: "12", y2: "12", key: "oup4p8" }]
];
var GitCommitHorizontal = createLucideIcon("git-commit-horizontal", __iconNode726);

// ../node_modules/lucide-react/dist/esm/icons/git-commit-vertical.js
var __iconNode727 = [
  ["path", { d: "M12 3v6", key: "1holv5" }],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
  ["path", { d: "M12 15v6", key: "a9ows0" }]
];
var GitCommitVertical = createLucideIcon("git-commit-vertical", __iconNode727);

// ../node_modules/lucide-react/dist/esm/icons/git-compare-arrows.js
var __iconNode728 = [
  ["circle", { cx: "5", cy: "6", r: "3", key: "1qnov2" }],
  ["path", { d: "M12 6h5a2 2 0 0 1 2 2v7", key: "1yj91y" }],
  ["path", { d: "m15 9-3-3 3-3", key: "1lwv8l" }],
  ["circle", { cx: "19", cy: "18", r: "3", key: "1qljk2" }],
  ["path", { d: "M12 18H7a2 2 0 0 1-2-2V9", key: "16sdep" }],
  ["path", { d: "m9 15 3 3-3 3", key: "1m3kbl" }]
];
var GitCompareArrows = createLucideIcon("git-compare-arrows", __iconNode728);

// ../node_modules/lucide-react/dist/esm/icons/git-compare.js
var __iconNode729 = [
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }],
  ["circle", { cx: "6", cy: "6", r: "3", key: "1lh9wr" }],
  ["path", { d: "M13 6h3a2 2 0 0 1 2 2v7", key: "1yeb86" }],
  ["path", { d: "M11 18H8a2 2 0 0 1-2-2V9", key: "19pyzm" }]
];
var GitCompare = createLucideIcon("git-compare", __iconNode729);

// ../node_modules/lucide-react/dist/esm/icons/git-fork.js
var __iconNode730 = [
  ["circle", { cx: "12", cy: "18", r: "3", key: "1mpf1b" }],
  ["circle", { cx: "6", cy: "6", r: "3", key: "1lh9wr" }],
  ["circle", { cx: "18", cy: "6", r: "3", key: "1h7g24" }],
  ["path", { d: "M18 9v2c0 .6-.4 1-1 1H7c-.6 0-1-.4-1-1V9", key: "1uq4wg" }],
  ["path", { d: "M12 12v3", key: "158kv8" }]
];
var GitFork = createLucideIcon("git-fork", __iconNode730);

// ../node_modules/lucide-react/dist/esm/icons/git-graph.js
var __iconNode731 = [
  ["circle", { cx: "5", cy: "6", r: "3", key: "1qnov2" }],
  ["path", { d: "M5 9v6", key: "158jrl" }],
  ["circle", { cx: "5", cy: "18", r: "3", key: "104gr9" }],
  ["path", { d: "M12 3v18", key: "108xh3" }],
  ["circle", { cx: "19", cy: "6", r: "3", key: "108a5v" }],
  ["path", { d: "M16 15.7A9 9 0 0 0 19 9", key: "1e3vqb" }]
];
var GitGraph = createLucideIcon("git-graph", __iconNode731);

// ../node_modules/lucide-react/dist/esm/icons/git-merge-conflict.js
var __iconNode732 = [
  ["path", { d: "M12 6h4a2 2 0 0 1 2 2v7", key: "18ej7s" }],
  ["path", { d: "M6 12v9", key: "9e33v1" }],
  ["path", { d: "M9 3 3 9", key: "ahyygn" }],
  ["path", { d: "M9 9 3 3", key: "v551iv" }],
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }]
];
var GitMergeConflict = createLucideIcon("git-merge-conflict", __iconNode732);

// ../node_modules/lucide-react/dist/esm/icons/git-merge.js
var __iconNode733 = [
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }],
  ["circle", { cx: "6", cy: "6", r: "3", key: "1lh9wr" }],
  ["path", { d: "M6 21V9a9 9 0 0 0 9 9", key: "7kw0sc" }]
];
var GitMerge = createLucideIcon("git-merge", __iconNode733);

// ../node_modules/lucide-react/dist/esm/icons/git-pull-request-closed.js
var __iconNode734 = [
  ["circle", { cx: "6", cy: "6", r: "3", key: "1lh9wr" }],
  ["path", { d: "M6 9v12", key: "1sc30k" }],
  ["path", { d: "m21 3-6 6", key: "16nqsk" }],
  ["path", { d: "m21 9-6-6", key: "9j17rh" }],
  ["path", { d: "M18 11.5V15", key: "65xf6f" }],
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }]
];
var GitPullRequestClosed = createLucideIcon("git-pull-request-closed", __iconNode734);

// ../node_modules/lucide-react/dist/esm/icons/git-pull-request-arrow.js
var __iconNode735 = [
  ["circle", { cx: "5", cy: "6", r: "3", key: "1qnov2" }],
  ["path", { d: "M5 9v12", key: "ih889a" }],
  ["circle", { cx: "19", cy: "18", r: "3", key: "1qljk2" }],
  ["path", { d: "m15 9-3-3 3-3", key: "1lwv8l" }],
  ["path", { d: "M12 6h5a2 2 0 0 1 2 2v7", key: "1yj91y" }]
];
var GitPullRequestArrow = createLucideIcon("git-pull-request-arrow", __iconNode735);

// ../node_modules/lucide-react/dist/esm/icons/git-pull-request-create.js
var __iconNode736 = [
  ["circle", { cx: "6", cy: "6", r: "3", key: "1lh9wr" }],
  ["path", { d: "M6 9v12", key: "1sc30k" }],
  ["path", { d: "M13 6h3a2 2 0 0 1 2 2v3", key: "1jb6z3" }],
  ["path", { d: "M18 15v6", key: "9wciyi" }],
  ["path", { d: "M21 18h-6", key: "139f0c" }]
];
var GitPullRequestCreate = createLucideIcon("git-pull-request-create", __iconNode736);

// ../node_modules/lucide-react/dist/esm/icons/git-pull-request-create-arrow.js
var __iconNode737 = [
  ["circle", { cx: "5", cy: "6", r: "3", key: "1qnov2" }],
  ["path", { d: "M5 9v12", key: "ih889a" }],
  ["path", { d: "m15 9-3-3 3-3", key: "1lwv8l" }],
  ["path", { d: "M12 6h5a2 2 0 0 1 2 2v3", key: "1rbwk6" }],
  ["path", { d: "M19 15v6", key: "10aioa" }],
  ["path", { d: "M22 18h-6", key: "1d5gi5" }]
];
var GitPullRequestCreateArrow = createLucideIcon("git-pull-request-create-arrow", __iconNode737);

// ../node_modules/lucide-react/dist/esm/icons/git-pull-request-draft.js
var __iconNode738 = [
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }],
  ["circle", { cx: "6", cy: "6", r: "3", key: "1lh9wr" }],
  ["path", { d: "M18 6V5", key: "1oao2s" }],
  ["path", { d: "M18 11v-1", key: "11c8tz" }],
  ["line", { x1: "6", x2: "6", y1: "9", y2: "21", key: "rroup" }]
];
var GitPullRequestDraft = createLucideIcon("git-pull-request-draft", __iconNode738);

// ../node_modules/lucide-react/dist/esm/icons/git-pull-request.js
var __iconNode739 = [
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }],
  ["circle", { cx: "6", cy: "6", r: "3", key: "1lh9wr" }],
  ["path", { d: "M13 6h3a2 2 0 0 1 2 2v7", key: "1yeb86" }],
  ["line", { x1: "6", x2: "6", y1: "9", y2: "21", key: "rroup" }]
];
var GitPullRequest = createLucideIcon("git-pull-request", __iconNode739);

// ../node_modules/lucide-react/dist/esm/icons/github.js
var __iconNode740 = [
  [
    "path",
    {
      d: "M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4",
      key: "tonef"
    }
  ],
  ["path", { d: "M9 18c-4.51 2-5-2-7-2", key: "9comsn" }]
];
var Github = createLucideIcon("github", __iconNode740);

// ../node_modules/lucide-react/dist/esm/icons/gitlab.js
var __iconNode741 = [
  [
    "path",
    {
      d: "m22 13.29-3.33-10a.42.42 0 0 0-.14-.18.38.38 0 0 0-.22-.11.39.39 0 0 0-.23.07.42.42 0 0 0-.14.18l-2.26 6.67H8.32L6.1 3.26a.42.42 0 0 0-.1-.18.38.38 0 0 0-.26-.08.39.39 0 0 0-.23.07.42.42 0 0 0-.14.18L2 13.29a.74.74 0 0 0 .27.83L12 21l9.69-6.88a.71.71 0 0 0 .31-.83Z",
      key: "148pdi"
    }
  ]
];
var Gitlab = createLucideIcon("gitlab", __iconNode741);

// ../node_modules/lucide-react/dist/esm/icons/glass-water.js
var __iconNode742 = [
  [
    "path",
    {
      d: "M5.116 4.104A1 1 0 0 1 6.11 3h11.78a1 1 0 0 1 .994 1.105L17.19 20.21A2 2 0 0 1 15.2 22H8.8a2 2 0 0 1-2-1.79z",
      key: "p55z4y"
    }
  ],
  ["path", { d: "M6 12a5 5 0 0 1 6 0 5 5 0 0 0 6 0", key: "mjntcy" }]
];
var GlassWater = createLucideIcon("glass-water", __iconNode742);

// ../node_modules/lucide-react/dist/esm/icons/glasses.js
var __iconNode743 = [
  ["circle", { cx: "6", cy: "15", r: "4", key: "vux9w4" }],
  ["circle", { cx: "18", cy: "15", r: "4", key: "18o8ve" }],
  ["path", { d: "M14 15a2 2 0 0 0-2-2 2 2 0 0 0-2 2", key: "1ag4bs" }],
  ["path", { d: "M2.5 13 5 7c.7-1.3 1.4-2 3-2", key: "1hm1gs" }],
  ["path", { d: "M21.5 13 19 7c-.7-1.3-1.5-2-3-2", key: "1r31ai" }]
];
var Glasses = createLucideIcon("glasses", __iconNode743);

// ../node_modules/lucide-react/dist/esm/icons/globe-lock.js
var __iconNode744 = [
  [
    "path",
    {
      d: "M15.686 15A14.5 14.5 0 0 1 12 22a14.5 14.5 0 0 1 0-20 10 10 0 1 0 9.542 13",
      key: "qkt0x6"
    }
  ],
  ["path", { d: "M2 12h8.5", key: "ovaggd" }],
  ["path", { d: "M20 6V4a2 2 0 1 0-4 0v2", key: "1of5e8" }],
  ["rect", { width: "8", height: "5", x: "14", y: "6", rx: "1", key: "1fmf51" }]
];
var GlobeLock = createLucideIcon("globe-lock", __iconNode744);

// ../node_modules/lucide-react/dist/esm/icons/globe-off.js
var __iconNode745 = [
  ["path", { d: "M10.114 4.462A14.5 14.5 0 0 1 12 2a10 10 0 0 1 9.313 13.643", key: "1jq2r7" }],
  ["path", { d: "M15.557 15.556A14.5 14.5 0 0 1 12 22 10 10 0 0 1 4.929 4.929", key: "1ohfya" }],
  ["path", { d: "M15.892 10.234A14.5 14.5 0 0 0 12 2a10 10 0 0 0-3.643.687", key: "1fyh9w" }],
  ["path", { d: "M17.656 12H22", key: "1ttse4" }],
  ["path", { d: "M19.071 19.071A10 10 0 0 1 12 22 14.5 14.5 0 0 1 8.44 8.45", key: "rmtjzo" }],
  ["path", { d: "M2 12h10", key: "19562f" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var GlobeOff = createLucideIcon("globe-off", __iconNode745);

// ../node_modules/lucide-react/dist/esm/icons/globe-x.js
var __iconNode746 = [
  ["path", { d: "m16 3 5 5", key: "1husv6" }],
  [
    "path",
    { d: "M2 12h20A10 10 0 1 1 12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 4-10", key: "46evmv" }
  ],
  ["path", { d: "m21 3-5 5", key: "1g5oa7" }]
];
var GlobeX = createLucideIcon("globe-x", __iconNode746);

// ../node_modules/lucide-react/dist/esm/icons/globe.js
var __iconNode747 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20", key: "13o1zl" }],
  ["path", { d: "M2 12h20", key: "9i4pu4" }]
];
var Globe = createLucideIcon("globe", __iconNode747);

// ../node_modules/lucide-react/dist/esm/icons/goal.js
var __iconNode748 = [
  ["path", { d: "M12 13V2l8 4-8 4", key: "5wlwwj" }],
  ["path", { d: "M20.561 10.222a9 9 0 1 1-12.55-5.29", key: "1c0wjv" }],
  ["path", { d: "M8.002 9.997a5 5 0 1 0 8.9 2.02", key: "gb1g7m" }]
];
var Goal = createLucideIcon("goal", __iconNode748);

// ../node_modules/lucide-react/dist/esm/icons/gpu.js
var __iconNode749 = [
  ["path", { d: "M2 21V3", key: "1bzk4w" }],
  ["path", { d: "M2 5h18a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2.26", key: "1d64pi" }],
  ["path", { d: "M7 17v3a1 1 0 0 0 1 1h5a1 1 0 0 0 1-1v-3", key: "5hbqbf" }],
  ["circle", { cx: "16", cy: "11", r: "2", key: "qt15rb" }],
  ["circle", { cx: "8", cy: "11", r: "2", key: "ssideg" }]
];
var Gpu = createLucideIcon("gpu", __iconNode749);

// ../node_modules/lucide-react/dist/esm/icons/graduation-cap.js
var __iconNode750 = [
  [
    "path",
    {
      d: "M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",
      key: "j76jl0"
    }
  ],
  ["path", { d: "M22 10v6", key: "1lu8f3" }],
  ["path", { d: "M6 12.5V16a6 3 0 0 0 12 0v-3.5", key: "1r8lef" }]
];
var GraduationCap = createLucideIcon("graduation-cap", __iconNode750);

// ../node_modules/lucide-react/dist/esm/icons/grape.js
var __iconNode751 = [
  ["path", { d: "M22 5V2l-5.89 5.89", key: "1eenpo" }],
  ["circle", { cx: "16.6", cy: "15.89", r: "3", key: "xjtalx" }],
  ["circle", { cx: "8.11", cy: "7.4", r: "3", key: "u2fv6i" }],
  ["circle", { cx: "12.35", cy: "11.65", r: "3", key: "i6i8g7" }],
  ["circle", { cx: "13.91", cy: "5.85", r: "3", key: "6ye0dv" }],
  ["circle", { cx: "18.15", cy: "10.09", r: "3", key: "snx9no" }],
  ["circle", { cx: "6.56", cy: "13.2", r: "3", key: "17x4xg" }],
  ["circle", { cx: "10.8", cy: "17.44", r: "3", key: "1hogw9" }],
  ["circle", { cx: "5", cy: "19", r: "3", key: "1sn6vo" }]
];
var Grape = createLucideIcon("grape", __iconNode751);

// ../node_modules/lucide-react/dist/esm/icons/grid-2x2-check.js
var __iconNode752 = [
  [
    "path",
    {
      d: "M12 3v17a1 1 0 0 1-1 1H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1H3",
      key: "11za1p"
    }
  ],
  ["path", { d: "m16 19 2 2 4-4", key: "1b14m6" }]
];
var Grid2x2Check = createLucideIcon("grid-2x2-check", __iconNode752);

// ../node_modules/lucide-react/dist/esm/icons/grid-2x2-plus.js
var __iconNode753 = [
  [
    "path",
    {
      d: "M12 3v17a1 1 0 0 1-1 1H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1H3",
      key: "11za1p"
    }
  ],
  ["path", { d: "M16 19h6", key: "xwg31i" }],
  ["path", { d: "M19 22v-6", key: "qhmiwi" }]
];
var Grid2x2Plus = createLucideIcon("grid-2x2-plus", __iconNode753);

// ../node_modules/lucide-react/dist/esm/icons/grid-2x2-x.js
var __iconNode754 = [
  [
    "path",
    {
      d: "M12 3v17a1 1 0 0 1-1 1H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1H3",
      key: "11za1p"
    }
  ],
  ["path", { d: "m16 16 5 5", key: "8tpb07" }],
  ["path", { d: "m16 21 5-5", key: "193jll" }]
];
var Grid2x2X = createLucideIcon("grid-2x2-x", __iconNode754);

// ../node_modules/lucide-react/dist/esm/icons/grid-2x2.js
var __iconNode755 = [
  ["path", { d: "M12 3v18", key: "108xh3" }],
  ["path", { d: "M3 12h18", key: "1i2n21" }],
  ["rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", key: "h1oib" }]
];
var Grid2x2 = createLucideIcon("grid-2x2", __iconNode755);

// ../node_modules/lucide-react/dist/esm/icons/grid-3x2.js
var __iconNode756 = [
  ["path", { d: "M15 3v18", key: "14nvp0" }],
  ["path", { d: "M3 12h18", key: "1i2n21" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }],
  ["rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", key: "h1oib" }]
];
var Grid3x2 = createLucideIcon("grid-3x2", __iconNode756);

// ../node_modules/lucide-react/dist/esm/icons/grip-horizontal.js
var __iconNode757 = [
  ["circle", { cx: "12", cy: "9", r: "1", key: "124mty" }],
  ["circle", { cx: "19", cy: "9", r: "1", key: "1ruzo2" }],
  ["circle", { cx: "5", cy: "9", r: "1", key: "1a8b28" }],
  ["circle", { cx: "12", cy: "15", r: "1", key: "1e56xg" }],
  ["circle", { cx: "19", cy: "15", r: "1", key: "1a92ep" }],
  ["circle", { cx: "5", cy: "15", r: "1", key: "5r1jwy" }]
];
var GripHorizontal = createLucideIcon("grip-horizontal", __iconNode757);

// ../node_modules/lucide-react/dist/esm/icons/grid-3x3.js
var __iconNode758 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["path", { d: "M3 15h18", key: "5xshup" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }],
  ["path", { d: "M15 3v18", key: "14nvp0" }]
];
var Grid3x3 = createLucideIcon("grid-3x3", __iconNode758);

// ../node_modules/lucide-react/dist/esm/icons/grip.js
var __iconNode759 = [
  ["circle", { cx: "12", cy: "5", r: "1", key: "gxeob9" }],
  ["circle", { cx: "19", cy: "5", r: "1", key: "w8mnmm" }],
  ["circle", { cx: "5", cy: "5", r: "1", key: "lttvr7" }],
  ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }],
  ["circle", { cx: "19", cy: "12", r: "1", key: "1wjl8i" }],
  ["circle", { cx: "5", cy: "12", r: "1", key: "1pcz8c" }],
  ["circle", { cx: "12", cy: "19", r: "1", key: "lyex9k" }],
  ["circle", { cx: "19", cy: "19", r: "1", key: "shf9b7" }],
  ["circle", { cx: "5", cy: "19", r: "1", key: "bfqh0e" }]
];
var Grip = createLucideIcon("grip", __iconNode759);

// ../node_modules/lucide-react/dist/esm/icons/grip-vertical.js
var __iconNode760 = [
  ["circle", { cx: "9", cy: "12", r: "1", key: "1vctgf" }],
  ["circle", { cx: "9", cy: "5", r: "1", key: "hp0tcf" }],
  ["circle", { cx: "9", cy: "19", r: "1", key: "fkjjf6" }],
  ["circle", { cx: "15", cy: "12", r: "1", key: "1tmaij" }],
  ["circle", { cx: "15", cy: "5", r: "1", key: "19l28e" }],
  ["circle", { cx: "15", cy: "19", r: "1", key: "f4zoj3" }]
];
var GripVertical = createLucideIcon("grip-vertical", __iconNode760);

// ../node_modules/lucide-react/dist/esm/icons/group.js
var __iconNode761 = [
  ["path", { d: "M3 7V5c0-1.1.9-2 2-2h2", key: "adw53z" }],
  ["path", { d: "M17 3h2c1.1 0 2 .9 2 2v2", key: "an4l38" }],
  ["path", { d: "M21 17v2c0 1.1-.9 2-2 2h-2", key: "144t0e" }],
  ["path", { d: "M7 21H5c-1.1 0-2-.9-2-2v-2", key: "rtnfgi" }],
  ["rect", { width: "7", height: "5", x: "7", y: "7", rx: "1", key: "1eyiv7" }],
  ["rect", { width: "7", height: "5", x: "10", y: "12", rx: "1", key: "1qlmkx" }]
];
var Group = createLucideIcon("group", __iconNode761);

// ../node_modules/lucide-react/dist/esm/icons/guitar.js
var __iconNode762 = [
  ["path", { d: "m11.9 12.1 4.514-4.514", key: "109xqo" }],
  [
    "path",
    {
      d: "M20.1 2.3a1 1 0 0 0-1.4 0l-1.114 1.114A2 2 0 0 0 17 4.828v1.344a2 2 0 0 1-.586 1.414A2 2 0 0 1 17.828 7h1.344a2 2 0 0 0 1.414-.586L21.7 5.3a1 1 0 0 0 0-1.4z",
      key: "txyc8t"
    }
  ],
  ["path", { d: "m6 16 2 2", key: "16qmzd" }],
  [
    "path",
    {
      d: "M8.23 9.85A3 3 0 0 1 11 8a5 5 0 0 1 5 5 3 3 0 0 1-1.85 2.77l-.92.38A2 2 0 0 0 12 18a4 4 0 0 1-4 4 6 6 0 0 1-6-6 4 4 0 0 1 4-4 2 2 0 0 0 1.85-1.23z",
      key: "1de1vg"
    }
  ]
];
var Guitar = createLucideIcon("guitar", __iconNode762);

// ../node_modules/lucide-react/dist/esm/icons/ham.js
var __iconNode763 = [
  ["path", { d: "M13.144 21.144A7.274 10.445 45 1 0 2.856 10.856", key: "1k1t7q" }],
  [
    "path",
    {
      d: "M13.144 21.144A7.274 4.365 45 0 0 2.856 10.856a7.274 4.365 45 0 0 10.288 10.288",
      key: "153t1g"
    }
  ],
  [
    "path",
    {
      d: "M16.565 10.435 18.6 8.4a2.501 2.501 0 1 0 1.65-4.65 2.5 2.5 0 1 0-4.66 1.66l-2.024 2.025",
      key: "gzrt0n"
    }
  ],
  ["path", { d: "m8.5 16.5-1-1", key: "otr954" }]
];
var Ham = createLucideIcon("ham", __iconNode763);

// ../node_modules/lucide-react/dist/esm/icons/hamburger.js
var __iconNode764 = [
  ["path", { d: "M12 16H4a2 2 0 1 1 0-4h16a2 2 0 1 1 0 4h-4.25", key: "5dloqd" }],
  ["path", { d: "M5 12a2 2 0 0 1-2-2 9 7 0 0 1 18 0 2 2 0 0 1-2 2", key: "1vl3my" }],
  [
    "path",
    {
      d: "M5 16a2 2 0 0 0-2 2 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 2 2 0 0 0-2-2q0 0 0 0",
      key: "1us75o"
    }
  ],
  ["path", { d: "m6.67 12 6.13 4.6a2 2 0 0 0 2.8-.4l3.15-4.2", key: "qqzweh" }]
];
var Hamburger = createLucideIcon("hamburger", __iconNode764);

// ../node_modules/lucide-react/dist/esm/icons/hammer.js
var __iconNode765 = [
  ["path", { d: "m15 12-9.373 9.373a1 1 0 0 1-3.001-3L12 9", key: "1hayfq" }],
  ["path", { d: "m18 15 4-4", key: "16gjal" }],
  [
    "path",
    {
      d: "m21.5 11.5-1.914-1.914A2 2 0 0 1 19 8.172v-.344a2 2 0 0 0-.586-1.414l-1.657-1.657A6 6 0 0 0 12.516 3H9l1.243 1.243A6 6 0 0 1 12 8.485V10l2 2h1.172a2 2 0 0 1 1.414.586L18.5 14.5",
      key: "15ts47"
    }
  ]
];
var Hammer = createLucideIcon("hammer", __iconNode765);

// ../node_modules/lucide-react/dist/esm/icons/hand-fist.js
var __iconNode766 = [
  [
    "path",
    {
      d: "M12.035 17.012a3 3 0 0 0-3-3l-.311-.002a.72.72 0 0 1-.505-1.229l1.195-1.195A2 2 0 0 1 10.828 11H12a2 2 0 0 0 0-4H9.243a3 3 0 0 0-2.122.879l-2.707 2.707A4.83 4.83 0 0 0 3 14a8 8 0 0 0 8 8h2a8 8 0 0 0 8-8V7a2 2 0 1 0-4 0v2a2 2 0 1 0 4 0",
      key: "1ff7rl"
    }
  ],
  ["path", { d: "M13.888 9.662A2 2 0 0 0 17 8V5A2 2 0 1 0 13 5", key: "1xmd21" }],
  ["path", { d: "M9 5A2 2 0 1 0 5 5V10", key: "f3wfjw" }],
  ["path", { d: "M9 7V4A2 2 0 1 1 13 4V7.268", key: "eaoucv" }]
];
var HandFist = createLucideIcon("hand-fist", __iconNode766);

// ../node_modules/lucide-react/dist/esm/icons/hand-coins.js
var __iconNode767 = [
  ["path", { d: "M11 15h2a2 2 0 1 0 0-4h-3c-.6 0-1.1.2-1.4.6L3 17", key: "geh8rc" }],
  [
    "path",
    {
      d: "m7 21 1.6-1.4c.3-.4.8-.6 1.4-.6h4c1.1 0 2.1-.4 2.8-1.2l4.6-4.4a2 2 0 0 0-2.75-2.91l-4.2 3.9",
      key: "1fto5m"
    }
  ],
  ["path", { d: "m2 16 6 6", key: "1pfhp9" }],
  ["circle", { cx: "16", cy: "9", r: "2.9", key: "1n0dlu" }],
  ["circle", { cx: "6", cy: "5", r: "3", key: "151irh" }]
];
var HandCoins = createLucideIcon("hand-coins", __iconNode767);

// ../node_modules/lucide-react/dist/esm/icons/hand-grab.js
var __iconNode768 = [
  ["path", { d: "M18 11.5V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1.4", key: "edstyy" }],
  ["path", { d: "M14 10V8a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2", key: "19wdwo" }],
  ["path", { d: "M10 9.9V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v5", key: "1lugqo" }],
  ["path", { d: "M6 14a2 2 0 0 0-2-2a2 2 0 0 0-2 2", key: "1hbeus" }],
  [
    "path",
    { d: "M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-4a8 8 0 0 1-8-8 2 2 0 1 1 4 0", key: "1etffm" }
  ]
];
var HandGrab = createLucideIcon("hand-grab", __iconNode768);

// ../node_modules/lucide-react/dist/esm/icons/hand-heart.js
var __iconNode769 = [
  ["path", { d: "M11 14h2a2 2 0 0 0 0-4h-3c-.6 0-1.1.2-1.4.6L3 16", key: "1v1a37" }],
  [
    "path",
    {
      d: "m14.45 13.39 5.05-4.694C20.196 8 21 6.85 21 5.75a2.75 2.75 0 0 0-4.797-1.837.276.276 0 0 1-.406 0A2.75 2.75 0 0 0 11 5.75c0 1.2.802 2.248 1.5 2.946L16 11.95",
      key: "fhfbnt"
    }
  ],
  ["path", { d: "m2 15 6 6", key: "10dquu" }],
  [
    "path",
    {
      d: "m7 20 1.6-1.4c.3-.4.8-.6 1.4-.6h4c1.1 0 2.1-.4 2.8-1.2l4.6-4.4a1 1 0 0 0-2.75-2.91",
      key: "1x6kdw"
    }
  ]
];
var HandHeart = createLucideIcon("hand-heart", __iconNode769);

// ../node_modules/lucide-react/dist/esm/icons/hand-helping.js
var __iconNode770 = [
  ["path", { d: "M11 12h2a2 2 0 1 0 0-4h-3c-.6 0-1.1.2-1.4.6L3 14", key: "1j4xps" }],
  [
    "path",
    {
      d: "m7 18 1.6-1.4c.3-.4.8-.6 1.4-.6h4c1.1 0 2.1-.4 2.8-1.2l4.6-4.4a2 2 0 0 0-2.75-2.91l-4.2 3.9",
      key: "uospg8"
    }
  ],
  ["path", { d: "m2 13 6 6", key: "16e5sb" }]
];
var HandHelping = createLucideIcon("hand-helping", __iconNode770);

// ../node_modules/lucide-react/dist/esm/icons/hand-metal.js
var __iconNode771 = [
  ["path", { d: "M18 12.5V10a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1.4", key: "wc6myp" }],
  ["path", { d: "M14 11V9a2 2 0 1 0-4 0v2", key: "94qvcw" }],
  ["path", { d: "M10 10.5V5a2 2 0 1 0-4 0v9", key: "m1ah89" }],
  [
    "path",
    {
      d: "m7 15-1.76-1.76a2 2 0 0 0-2.83 2.82l3.6 3.6C7.5 21.14 9.2 22 12 22h2a8 8 0 0 0 8-8V7a2 2 0 1 0-4 0v5",
      key: "t1skq1"
    }
  ]
];
var HandMetal = createLucideIcon("hand-metal", __iconNode771);

// ../node_modules/lucide-react/dist/esm/icons/hand-platter.js
var __iconNode772 = [
  ["path", { d: "M12 3V2", key: "ar7q03" }],
  [
    "path",
    {
      d: "m15.4 17.4 3.2-2.8a2 2 0 1 1 2.8 2.9l-3.6 3.3c-.7.8-1.7 1.2-2.8 1.2h-4c-1.1 0-2.1-.4-2.8-1.2l-1.302-1.464A1 1 0 0 0 6.151 19H5",
      key: "n2g93r"
    }
  ],
  ["path", { d: "M2 14h12a2 2 0 0 1 0 4h-2", key: "1o2jem" }],
  ["path", { d: "M4 10h16", key: "img6z1" }],
  ["path", { d: "M5 10a7 7 0 0 1 14 0", key: "1ega1o" }],
  ["path", { d: "M5 14v6a1 1 0 0 1-1 1H2", key: "1hescx" }]
];
var HandPlatter = createLucideIcon("hand-platter", __iconNode772);

// ../node_modules/lucide-react/dist/esm/icons/hand.js
var __iconNode773 = [
  ["path", { d: "M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2", key: "1fvzgz" }],
  ["path", { d: "M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2", key: "1kc0my" }],
  ["path", { d: "M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8", key: "10h0bg" }],
  [
    "path",
    {
      d: "M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15",
      key: "1s1gnw"
    }
  ]
];
var Hand = createLucideIcon("hand", __iconNode773);

// ../node_modules/lucide-react/dist/esm/icons/handbag.js
var __iconNode774 = [
  [
    "path",
    {
      d: "M2.048 18.566A2 2 0 0 0 4 21h16a2 2 0 0 0 1.952-2.434l-2-9A2 2 0 0 0 18 8H6a2 2 0 0 0-1.952 1.566z",
      key: "1qbui5"
    }
  ],
  ["path", { d: "M8 11V6a4 4 0 0 1 8 0v5", key: "tcht90" }]
];
var Handbag = createLucideIcon("handbag", __iconNode774);

// ../node_modules/lucide-react/dist/esm/icons/handshake.js
var __iconNode775 = [
  ["path", { d: "m11 17 2 2a1 1 0 1 0 3-3", key: "efffak" }],
  [
    "path",
    {
      d: "m14 14 2.5 2.5a1 1 0 1 0 3-3l-3.88-3.88a3 3 0 0 0-4.24 0l-.88.88a1 1 0 1 1-3-3l2.81-2.81a5.79 5.79 0 0 1 7.06-.87l.47.28a2 2 0 0 0 1.42.25L21 4",
      key: "9pr0kb"
    }
  ],
  ["path", { d: "m21 3 1 11h-2", key: "1tisrp" }],
  ["path", { d: "M3 3 2 14l6.5 6.5a1 1 0 1 0 3-3", key: "1uvwmv" }],
  ["path", { d: "M3 4h8", key: "1ep09j" }]
];
var Handshake = createLucideIcon("handshake", __iconNode775);

// ../node_modules/lucide-react/dist/esm/icons/hard-drive-download.js
var __iconNode776 = [
  ["path", { d: "M12 2v8", key: "1q4o3n" }],
  ["path", { d: "m16 6-4 4-4-4", key: "6wukr" }],
  ["rect", { width: "20", height: "8", x: "2", y: "14", rx: "2", key: "w68u3i" }],
  ["path", { d: "M6 18h.01", key: "uhywen" }],
  ["path", { d: "M10 18h.01", key: "h775k" }]
];
var HardDriveDownload = createLucideIcon("hard-drive-download", __iconNode776);

// ../node_modules/lucide-react/dist/esm/icons/hard-drive-upload.js
var __iconNode777 = [
  ["path", { d: "m16 6-4-4-4 4", key: "13yo43" }],
  ["path", { d: "M12 2v8", key: "1q4o3n" }],
  ["rect", { width: "20", height: "8", x: "2", y: "14", rx: "2", key: "w68u3i" }],
  ["path", { d: "M6 18h.01", key: "uhywen" }],
  ["path", { d: "M10 18h.01", key: "h775k" }]
];
var HardDriveUpload = createLucideIcon("hard-drive-upload", __iconNode777);

// ../node_modules/lucide-react/dist/esm/icons/hard-drive.js
var __iconNode778 = [
  ["path", { d: "M10 16h.01", key: "1bzywj" }],
  [
    "path",
    {
      d: "M2.212 11.577a2 2 0 0 0-.212.896V18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5.527a2 2 0 0 0-.212-.896L18.55 5.11A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
      key: "18tbho"
    }
  ],
  ["path", { d: "M21.946 12.013H2.054", key: "zqlbp7" }],
  ["path", { d: "M6 16h.01", key: "1pmjb7" }]
];
var HardDrive = createLucideIcon("hard-drive", __iconNode778);

// ../node_modules/lucide-react/dist/esm/icons/hard-hat.js
var __iconNode779 = [
  ["path", { d: "M10 10V5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v5", key: "1p9q5i" }],
  ["path", { d: "M14 6a6 6 0 0 1 6 6v3", key: "1hnv84" }],
  ["path", { d: "M4 15v-3a6 6 0 0 1 6-6", key: "9ciidu" }],
  ["rect", { x: "2", y: "15", width: "20", height: "4", rx: "1", key: "g3x8cw" }]
];
var HardHat = createLucideIcon("hard-hat", __iconNode779);

// ../node_modules/lucide-react/dist/esm/icons/hash.js
var __iconNode780 = [
  ["line", { x1: "4", x2: "20", y1: "9", y2: "9", key: "4lhtct" }],
  ["line", { x1: "4", x2: "20", y1: "15", y2: "15", key: "vyu0kd" }],
  ["line", { x1: "10", x2: "8", y1: "3", y2: "21", key: "1ggp8o" }],
  ["line", { x1: "16", x2: "14", y1: "3", y2: "21", key: "weycgp" }]
];
var Hash = createLucideIcon("hash", __iconNode780);

// ../node_modules/lucide-react/dist/esm/icons/hat-glasses.js
var __iconNode781 = [
  ["path", { d: "M14 18a2 2 0 0 0-4 0", key: "1v8fkw" }],
  [
    "path",
    {
      d: "m19 11-2.11-6.657a2 2 0 0 0-2.752-1.148l-1.276.61A2 2 0 0 1 12 4H8.5a2 2 0 0 0-1.925 1.456L5 11",
      key: "1fkr7p"
    }
  ],
  ["path", { d: "M2 11h20", key: "3eubbj" }],
  ["circle", { cx: "17", cy: "18", r: "3", key: "82mm0e" }],
  ["circle", { cx: "7", cy: "18", r: "3", key: "lvkj7j" }]
];
var HatGlasses = createLucideIcon("hat-glasses", __iconNode781);

// ../node_modules/lucide-react/dist/esm/icons/haze.js
var __iconNode782 = [
  ["path", { d: "m5.2 6.2 1.4 1.4", key: "17imol" }],
  ["path", { d: "M2 13h2", key: "13gyu8" }],
  ["path", { d: "M20 13h2", key: "16rner" }],
  ["path", { d: "m17.4 7.6 1.4-1.4", key: "t4xlah" }],
  ["path", { d: "M22 17H2", key: "1gtaj3" }],
  ["path", { d: "M22 21H2", key: "1gy6en" }],
  ["path", { d: "M16 13a4 4 0 0 0-8 0", key: "1dyczq" }],
  ["path", { d: "M12 5V2.5", key: "1vytko" }]
];
var Haze = createLucideIcon("haze", __iconNode782);

// ../node_modules/lucide-react/dist/esm/icons/hd.js
var __iconNode783 = [
  ["path", { d: "M10 12H6", key: "15f2ro" }],
  ["path", { d: "M10 15V9", key: "1lckn7" }],
  [
    "path",
    {
      d: "M14 14.5a.5.5 0 0 0 .5.5h1a2.5 2.5 0 0 0 2.5-2.5v-1A2.5 2.5 0 0 0 15.5 9h-1a.5.5 0 0 0-.5.5z",
      key: "b3f847"
    }
  ],
  ["path", { d: "M6 15V9", key: "12stmj" }],
  ["rect", { x: "2", y: "5", width: "20", height: "14", rx: "2", key: "qneu4z" }]
];
var Hd = createLucideIcon("hd", __iconNode783);

// ../node_modules/lucide-react/dist/esm/icons/hdmi-port.js
var __iconNode784 = [
  [
    "path",
    {
      d: "M22 9a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h1l2 2h12l2-2h1a1 1 0 0 0 1-1Z",
      key: "2128wb"
    }
  ],
  ["path", { d: "M7.5 12h9", key: "1t0ckc" }]
];
var HdmiPort = createLucideIcon("hdmi-port", __iconNode784);

// ../node_modules/lucide-react/dist/esm/icons/heading-1.js
var __iconNode785 = [
  ["path", { d: "M4 12h8", key: "17cfdx" }],
  ["path", { d: "M4 18V6", key: "1rz3zl" }],
  ["path", { d: "M12 18V6", key: "zqpxq5" }],
  ["path", { d: "m17 12 3-2v8", key: "1hhhft" }]
];
var Heading1 = createLucideIcon("heading-1", __iconNode785);

// ../node_modules/lucide-react/dist/esm/icons/heading-2.js
var __iconNode786 = [
  ["path", { d: "M4 12h8", key: "17cfdx" }],
  ["path", { d: "M4 18V6", key: "1rz3zl" }],
  ["path", { d: "M12 18V6", key: "zqpxq5" }],
  ["path", { d: "M21 18h-4c0-4 4-3 4-6 0-1.5-2-2.5-4-1", key: "9jr5yi" }]
];
var Heading2 = createLucideIcon("heading-2", __iconNode786);

// ../node_modules/lucide-react/dist/esm/icons/heading-4.js
var __iconNode787 = [
  ["path", { d: "M12 18V6", key: "zqpxq5" }],
  ["path", { d: "M17 10v3a1 1 0 0 0 1 1h3", key: "tj5zdr" }],
  ["path", { d: "M21 10v8", key: "1kdml4" }],
  ["path", { d: "M4 12h8", key: "17cfdx" }],
  ["path", { d: "M4 18V6", key: "1rz3zl" }]
];
var Heading4 = createLucideIcon("heading-4", __iconNode787);

// ../node_modules/lucide-react/dist/esm/icons/heading-3.js
var __iconNode788 = [
  ["path", { d: "M4 12h8", key: "17cfdx" }],
  ["path", { d: "M4 18V6", key: "1rz3zl" }],
  ["path", { d: "M12 18V6", key: "zqpxq5" }],
  ["path", { d: "M17.5 10.5c1.7-1 3.5 0 3.5 1.5a2 2 0 0 1-2 2", key: "68ncm8" }],
  ["path", { d: "M17 17.5c2 1.5 4 .3 4-1.5a2 2 0 0 0-2-2", key: "1ejuhz" }]
];
var Heading3 = createLucideIcon("heading-3", __iconNode788);

// ../node_modules/lucide-react/dist/esm/icons/heading-5.js
var __iconNode789 = [
  ["path", { d: "M4 12h8", key: "17cfdx" }],
  ["path", { d: "M4 18V6", key: "1rz3zl" }],
  ["path", { d: "M12 18V6", key: "zqpxq5" }],
  ["path", { d: "M17 13v-3h4", key: "1nvgqp" }],
  [
    "path",
    { d: "M17 17.7c.4.2.8.3 1.3.3 1.5 0 2.7-1.1 2.7-2.5S19.8 13 18.3 13H17", key: "2nebdn" }
  ]
];
var Heading5 = createLucideIcon("heading-5", __iconNode789);

// ../node_modules/lucide-react/dist/esm/icons/heading-6.js
var __iconNode790 = [
  ["path", { d: "M4 12h8", key: "17cfdx" }],
  ["path", { d: "M4 18V6", key: "1rz3zl" }],
  ["path", { d: "M12 18V6", key: "zqpxq5" }],
  ["circle", { cx: "19", cy: "16", r: "2", key: "15mx69" }],
  ["path", { d: "M20 10c-2 2-3 3.5-3 6", key: "f35dl0" }]
];
var Heading6 = createLucideIcon("heading-6", __iconNode790);

// ../node_modules/lucide-react/dist/esm/icons/heading.js
var __iconNode791 = [
  ["path", { d: "M6 12h12", key: "8npq4p" }],
  ["path", { d: "M6 20V4", key: "1w1bmo" }],
  ["path", { d: "M18 20V4", key: "o2hl4u" }]
];
var Heading = createLucideIcon("heading", __iconNode791);

// ../node_modules/lucide-react/dist/esm/icons/headphone-off.js
var __iconNode792 = [
  ["path", { d: "M21 14h-1.343", key: "1jdnxi" }],
  ["path", { d: "M9.128 3.47A9 9 0 0 1 21 12v3.343", key: "6kipu2" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M20.414 20.414A2 2 0 0 1 19 21h-1a2 2 0 0 1-2-2v-3", key: "9x50f4" }],
  [
    "path",
    {
      d: "M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 2.636-6.364",
      key: "1bkxnm"
    }
  ]
];
var HeadphoneOff = createLucideIcon("headphone-off", __iconNode792);

// ../node_modules/lucide-react/dist/esm/icons/headphones.js
var __iconNode793 = [
  [
    "path",
    {
      d: "M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-7a9 9 0 0 1 18 0v7a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3",
      key: "1xhozi"
    }
  ]
];
var Headphones = createLucideIcon("headphones", __iconNode793);

// ../node_modules/lucide-react/dist/esm/icons/headset.js
var __iconNode794 = [
  [
    "path",
    {
      d: "M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5Zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3Z",
      key: "12oyoe"
    }
  ],
  ["path", { d: "M21 16v2a4 4 0 0 1-4 4h-5", key: "1x7m43" }]
];
var Headset = createLucideIcon("headset", __iconNode794);

// ../node_modules/lucide-react/dist/esm/icons/heart-crack.js
var __iconNode795 = [
  [
    "path",
    {
      d: "M12.409 5.824c-.702.792-1.15 1.496-1.415 2.166l2.153 2.156a.5.5 0 0 1 0 .707l-2.293 2.293a.5.5 0 0 0 0 .707L12 15",
      key: "idzbju"
    }
  ],
  [
    "path",
    {
      d: "M13.508 20.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5a5.5 5.5 0 0 1 9.591-3.677.6.6 0 0 0 .818.001A5.5 5.5 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5z",
      key: "1su70f"
    }
  ]
];
var HeartCrack = createLucideIcon("heart-crack", __iconNode795);

// ../node_modules/lucide-react/dist/esm/icons/heart-handshake.js
var __iconNode796 = [
  [
    "path",
    {
      d: "M19.414 14.414C21 12.828 22 11.5 22 9.5a5.5 5.5 0 0 0-9.591-3.676.6.6 0 0 1-.818.001A5.5 5.5 0 0 0 2 9.5c0 2.3 1.5 4 3 5.5l5.535 5.362a2 2 0 0 0 2.879.052 2.12 2.12 0 0 0-.004-3 2.124 2.124 0 1 0 3-3 2.124 2.124 0 0 0 3.004 0 2 2 0 0 0 0-2.828l-1.881-1.882a2.41 2.41 0 0 0-3.409 0l-1.71 1.71a2 2 0 0 1-2.828 0 2 2 0 0 1 0-2.828l2.823-2.762",
      key: "17lmqv"
    }
  ]
];
var HeartHandshake = createLucideIcon("heart-handshake", __iconNode796);

// ../node_modules/lucide-react/dist/esm/icons/heart-minus.js
var __iconNode797 = [
  [
    "path",
    {
      d: "m14.876 18.99-1.368 1.323a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5a5.2 5.2 0 0 1-.244 1.572",
      key: "15yztm"
    }
  ],
  ["path", { d: "M15 15h6", key: "1u4692" }]
];
var HeartMinus = createLucideIcon("heart-minus", __iconNode797);

// ../node_modules/lucide-react/dist/esm/icons/heart-off.js
var __iconNode798 = [
  [
    "path",
    {
      d: "M10.5 4.893a5.5 5.5 0 0 1 1.091.931.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 1.872-1.002 3.356-2.187 4.655",
      key: "1inpfl"
    }
  ],
  [
    "path",
    {
      d: "m16.967 16.967-3.459 3.346a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5a5.5 5.5 0 0 1 2.747-4.761",
      key: "vbc6x7"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var HeartOff = createLucideIcon("heart-off", __iconNode798);

// ../node_modules/lucide-react/dist/esm/icons/heart-pulse.js
var __iconNode799 = [
  [
    "path",
    {
      d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",
      key: "mvr1a0"
    }
  ],
  ["path", { d: "M3.22 13H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27", key: "auskq0" }]
];
var HeartPulse = createLucideIcon("heart-pulse", __iconNode799);

// ../node_modules/lucide-react/dist/esm/icons/heart-plus.js
var __iconNode800 = [
  [
    "path",
    {
      d: "m14.479 19.374-.971.939a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5a5.2 5.2 0 0 1-.219 1.49",
      key: "wg5jx"
    }
  ],
  ["path", { d: "M15 15h6", key: "1u4692" }],
  ["path", { d: "M18 12v6", key: "1houu1" }]
];
var HeartPlus = createLucideIcon("heart-plus", __iconNode800);

// ../node_modules/lucide-react/dist/esm/icons/heart.js
var __iconNode801 = [
  [
    "path",
    {
      d: "M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5",
      key: "mvr1a0"
    }
  ]
];
var Heart = createLucideIcon("heart", __iconNode801);

// ../node_modules/lucide-react/dist/esm/icons/heater.js
var __iconNode802 = [
  ["path", { d: "M11 8c2-3-2-3 0-6", key: "1ldv5m" }],
  ["path", { d: "M15.5 8c2-3-2-3 0-6", key: "1otqoz" }],
  ["path", { d: "M6 10h.01", key: "1lbq93" }],
  ["path", { d: "M6 14h.01", key: "zudwn7" }],
  ["path", { d: "M10 16v-4", key: "1c25yv" }],
  ["path", { d: "M14 16v-4", key: "1dkbt8" }],
  ["path", { d: "M18 16v-4", key: "1yg9me" }],
  [
    "path",
    { d: "M20 6a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h3", key: "1ubg90" }
  ],
  ["path", { d: "M5 20v2", key: "1abpe8" }],
  ["path", { d: "M19 20v2", key: "kqn6ft" }]
];
var Heater = createLucideIcon("heater", __iconNode802);

// ../node_modules/lucide-react/dist/esm/icons/helicopter.js
var __iconNode803 = [
  ["path", { d: "M11 17v4", key: "14wq8k" }],
  ["path", { d: "M14 3v8a2 2 0 0 0 2 2h5.865", key: "12oo5h" }],
  ["path", { d: "M17 17v4", key: "hdt4hh" }],
  [
    "path",
    { d: "M18 17a4 4 0 0 0 4-4 8 6 0 0 0-8-6 6 5 0 0 0-6 5v3a2 2 0 0 0 2 2z", key: "yynif" }
  ],
  ["path", { d: "M2 10v5", key: "sa5akn" }],
  ["path", { d: "M6 3h16", key: "27qw71" }],
  ["path", { d: "M7 21h14", key: "1ugz0u" }],
  ["path", { d: "M8 13H2", key: "1thz1o" }]
];
var Helicopter = createLucideIcon("helicopter", __iconNode803);

// ../node_modules/lucide-react/dist/esm/icons/hexagon.js
var __iconNode804 = [
  [
    "path",
    {
      d: "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z",
      key: "yt0hxn"
    }
  ]
];
var Hexagon = createLucideIcon("hexagon", __iconNode804);

// ../node_modules/lucide-react/dist/esm/icons/highlighter.js
var __iconNode805 = [
  ["path", { d: "m9 11-6 6v3h9l3-3", key: "1a3l36" }],
  ["path", { d: "m22 12-4.6 4.6a2 2 0 0 1-2.8 0l-5.2-5.2a2 2 0 0 1 0-2.8L14 4", key: "14a9rk" }]
];
var Highlighter = createLucideIcon("highlighter", __iconNode805);

// ../node_modules/lucide-react/dist/esm/icons/history.js
var __iconNode806 = [
  ["path", { d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "1357e3" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }],
  ["path", { d: "M12 7v5l4 2", key: "1fdv2h" }]
];
var History = createLucideIcon("history", __iconNode806);

// ../node_modules/lucide-react/dist/esm/icons/hop-off.js
var __iconNode807 = [
  ["path", { d: "M10.82 16.12c1.69.6 3.91.79 5.18.85.28.01.53-.09.7-.27", key: "qyzcap" }],
  [
    "path",
    {
      d: "M11.14 20.57c.52.24 2.44 1.12 4.08 1.37.46.06.86-.25.9-.71.12-1.52-.3-3.43-.5-4.28",
      key: "y078lb"
    }
  ],
  ["path", { d: "M16.13 21.05c1.65.63 3.68.84 4.87.91a.9.9 0 0 0 .7-.26", key: "1utre3" }],
  [
    "path",
    {
      d: "M17.99 5.52a20.83 20.83 0 0 1 3.15 4.5.8.8 0 0 1-.68 1.13c-1.17.1-2.5.02-3.9-.25",
      key: "17o9hm"
    }
  ],
  ["path", { d: "M20.57 11.14c.24.52 1.12 2.44 1.37 4.08.04.3-.08.59-.31.75", key: "1d1n4p" }],
  [
    "path",
    {
      d: "M4.93 4.93a10 10 0 0 0-.67 13.4c.35.43.96.4 1.17-.12.69-1.71 1.07-5.07 1.07-6.71 1.34.45 3.1.9 4.88.62a.85.85 0 0 0 .48-.24",
      key: "9uv3tt"
    }
  ],
  [
    "path",
    {
      d: "M5.52 17.99c1.05.95 2.91 2.42 4.5 3.15a.8.8 0 0 0 1.13-.68c.2-2.34-.33-5.3-1.57-8.28",
      key: "1292wz"
    }
  ],
  [
    "path",
    {
      d: "M8.35 2.68a10 10 0 0 1 9.98 1.58c.43.35.4.96-.12 1.17-1.5.6-4.3.98-6.07 1.05",
      key: "7ozu9p"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var HopOff = createLucideIcon("hop-off", __iconNode807);

// ../node_modules/lucide-react/dist/esm/icons/hop.js
var __iconNode808 = [
  [
    "path",
    {
      d: "M10.82 16.12c1.69.6 3.91.79 5.18.85.55.03 1-.42.97-.97-.06-1.27-.26-3.5-.85-5.18",
      key: "18lxf1"
    }
  ],
  [
    "path",
    {
      d: "M11.5 6.5c1.64 0 5-.38 6.71-1.07.52-.2.55-.82.12-1.17A10 10 0 0 0 4.26 18.33c.35.43.96.4 1.17-.12.69-1.71 1.07-5.07 1.07-6.71 1.34.45 3.1.9 4.88.62a.88.88 0 0 0 .73-.74c.3-2.14-.15-3.5-.61-4.88",
      key: "vtfxrw"
    }
  ],
  [
    "path",
    {
      d: "M15.62 16.95c.2.85.62 2.76.5 4.28a.77.77 0 0 1-.9.7 16.64 16.64 0 0 1-4.08-1.36",
      key: "13hl71"
    }
  ],
  [
    "path",
    {
      d: "M16.13 21.05c1.65.63 3.68.84 4.87.91a.9.9 0 0 0 .96-.96 17.68 17.68 0 0 0-.9-4.87",
      key: "1sl8oj"
    }
  ],
  [
    "path",
    {
      d: "M16.94 15.62c.86.2 2.77.62 4.29.5a.77.77 0 0 0 .7-.9 16.64 16.64 0 0 0-1.36-4.08",
      key: "19c6kt"
    }
  ],
  [
    "path",
    {
      d: "M17.99 5.52a20.82 20.82 0 0 1 3.15 4.5.8.8 0 0 1-.68 1.13c-2.33.2-5.3-.32-8.27-1.57",
      key: "85ghs3"
    }
  ],
  ["path", { d: "M4.93 4.93 3 3a.7.7 0 0 1 0-1", key: "x087yj" }],
  [
    "path",
    {
      d: "M9.58 12.18c1.24 2.98 1.77 5.95 1.57 8.28a.8.8 0 0 1-1.13.68 20.82 20.82 0 0 1-4.5-3.15",
      key: "11xdqo"
    }
  ]
];
var Hop = createLucideIcon("hop", __iconNode808);

// ../node_modules/lucide-react/dist/esm/icons/hospital.js
var __iconNode809 = [
  ["path", { d: "M12 7v4", key: "xawao1" }],
  ["path", { d: "M14 21v-3a2 2 0 0 0-4 0v3", key: "1rgiei" }],
  ["path", { d: "M14 9h-4", key: "1w2s2s" }],
  [
    "path",
    {
      d: "M18 11h2a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-9a2 2 0 0 1 2-2h2",
      key: "1tthqt"
    }
  ],
  ["path", { d: "M18 21V5a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16", key: "dw4p4i" }]
];
var Hospital = createLucideIcon("hospital", __iconNode809);

// ../node_modules/lucide-react/dist/esm/icons/hotel.js
var __iconNode810 = [
  ["path", { d: "M10 22v-6.57", key: "1wmca3" }],
  ["path", { d: "M12 11h.01", key: "z322tv" }],
  ["path", { d: "M12 7h.01", key: "1ivr5q" }],
  ["path", { d: "M14 15.43V22", key: "1q2vjd" }],
  ["path", { d: "M15 16a5 5 0 0 0-6 0", key: "o9wqvi" }],
  ["path", { d: "M16 11h.01", key: "xkw8gn" }],
  ["path", { d: "M16 7h.01", key: "1kdx03" }],
  ["path", { d: "M8 11h.01", key: "1dfujw" }],
  ["path", { d: "M8 7h.01", key: "1vti4s" }],
  ["rect", { x: "4", y: "2", width: "16", height: "20", rx: "2", key: "1uxh74" }]
];
var Hotel = createLucideIcon("hotel", __iconNode810);

// ../node_modules/lucide-react/dist/esm/icons/hourglass.js
var __iconNode811 = [
  ["path", { d: "M5 22h14", key: "ehvnwv" }],
  ["path", { d: "M5 2h14", key: "pdyrp9" }],
  [
    "path",
    {
      d: "M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22",
      key: "1d314k"
    }
  ],
  [
    "path",
    { d: "M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2", key: "1vvvr6" }
  ]
];
var Hourglass = createLucideIcon("hourglass", __iconNode811);

// ../node_modules/lucide-react/dist/esm/icons/house-heart.js
var __iconNode812 = [
  [
    "path",
    {
      d: "M8.62 13.8A2.25 2.25 0 1 1 12 10.836a2.25 2.25 0 1 1 3.38 2.966l-2.626 2.856a.998.998 0 0 1-1.507 0z",
      key: "n9s7kx"
    }
  ],
  [
    "path",
    {
      d: "M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
      key: "r6nss1"
    }
  ]
];
var HouseHeart = createLucideIcon("house-heart", __iconNode812);

// ../node_modules/lucide-react/dist/esm/icons/house-plug.js
var __iconNode813 = [
  ["path", { d: "M10 12V8.964", key: "1vll13" }],
  ["path", { d: "M14 12V8.964", key: "1x3qvg" }],
  [
    "path",
    { d: "M15 12a1 1 0 0 1 1 1v2a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2v-2a1 1 0 0 1 1-1z", key: "ppykja" }
  ],
  [
    "path",
    {
      d: "M8.5 21H5a2 2 0 0 1-2-2v-9a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2h-5a2 2 0 0 1-2-2v-2",
      key: "365xoy"
    }
  ]
];
var HousePlug = createLucideIcon("house-plug", __iconNode813);

// ../node_modules/lucide-react/dist/esm/icons/house-plus.js
var __iconNode814 = [
  [
    "path",
    {
      d: "M12.35 21H5a2 2 0 0 1-2-2v-9a2 2 0 0 1 .71-1.53l7-6a2 2 0 0 1 2.58 0l7 6A2 2 0 0 1 21 10v2.35",
      key: "8ek5ge"
    }
  ],
  ["path", { d: "M14.8 12.4A1 1 0 0 0 14 12h-4a1 1 0 0 0-1 1v8", key: "1rbg29" }],
  ["path", { d: "M15 18h6", key: "3b3c90" }],
  ["path", { d: "M18 15v6", key: "9wciyi" }]
];
var HousePlus = createLucideIcon("house-plus", __iconNode814);

// ../node_modules/lucide-react/dist/esm/icons/house.js
var __iconNode815 = [
  ["path", { d: "M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8", key: "5wwlr5" }],
  [
    "path",
    {
      d: "M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
      key: "r6nss1"
    }
  ]
];
var House = createLucideIcon("house", __iconNode815);

// ../node_modules/lucide-react/dist/esm/icons/house-wifi.js
var __iconNode816 = [
  ["path", { d: "M9.5 13.866a4 4 0 0 1 5 .01", key: "1wy54i" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }],
  [
    "path",
    {
      d: "M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
      key: "r6nss1"
    }
  ],
  ["path", { d: "M7 10.754a8 8 0 0 1 10 0", key: "exoy2g" }]
];
var HouseWifi = createLucideIcon("house-wifi", __iconNode816);

// ../node_modules/lucide-react/dist/esm/icons/ice-cream-bowl.js
var __iconNode817 = [
  [
    "path",
    {
      d: "M12 17c5 0 8-2.69 8-6H4c0 3.31 3 6 8 6m-4 4h8m-4-3v3M5.14 11a3.5 3.5 0 1 1 6.71 0",
      key: "1uxfcu"
    }
  ],
  ["path", { d: "M12.14 11a3.5 3.5 0 1 1 6.71 0", key: "4k3m1s" }],
  ["path", { d: "M15.5 6.5a3.5 3.5 0 1 0-7 0", key: "zmuahr" }]
];
var IceCreamBowl = createLucideIcon("ice-cream-bowl", __iconNode817);

// ../node_modules/lucide-react/dist/esm/icons/ice-cream-cone.js
var __iconNode818 = [
  ["path", { d: "m7 11 4.08 10.35a1 1 0 0 0 1.84 0L17 11", key: "1v6356" }],
  ["path", { d: "M17 7A5 5 0 0 0 7 7", key: "151p3v" }],
  ["path", { d: "M17 7a2 2 0 0 1 0 4H7a2 2 0 0 1 0-4", key: "1sdaij" }]
];
var IceCreamCone = createLucideIcon("ice-cream-cone", __iconNode818);

// ../node_modules/lucide-react/dist/esm/icons/id-card-lanyard.js
var __iconNode819 = [
  ["path", { d: "M13.5 8h-3", key: "xvov4w" }],
  [
    "path",
    {
      d: "m15 2-1 2h3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h3",
      key: "16uttc"
    }
  ],
  ["path", { d: "M16.899 22A5 5 0 0 0 7.1 22", key: "1d0ppr" }],
  ["path", { d: "m9 2 3 6", key: "1o7bd9" }],
  ["circle", { cx: "12", cy: "15", r: "3", key: "g36mzq" }]
];
var IdCardLanyard = createLucideIcon("id-card-lanyard", __iconNode819);

// ../node_modules/lucide-react/dist/esm/icons/id-card.js
var __iconNode820 = [
  ["path", { d: "M16 10h2", key: "8sgtl7" }],
  ["path", { d: "M16 14h2", key: "epxaof" }],
  ["path", { d: "M6.17 15a3 3 0 0 1 5.66 0", key: "n6f512" }],
  ["circle", { cx: "9", cy: "11", r: "2", key: "yxgjnd" }],
  ["rect", { x: "2", y: "5", width: "20", height: "14", rx: "2", key: "qneu4z" }]
];
var IdCard = createLucideIcon("id-card", __iconNode820);

// ../node_modules/lucide-react/dist/esm/icons/image-down.js
var __iconNode821 = [
  [
    "path",
    {
      d: "M10.3 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10l-3.1-3.1a2 2 0 0 0-2.814.014L6 21",
      key: "9csbqa"
    }
  ],
  ["path", { d: "m14 19 3 3v-5.5", key: "9ldu5r" }],
  ["path", { d: "m17 22 3-3", key: "1nkfve" }],
  ["circle", { cx: "9", cy: "9", r: "2", key: "af1f0g" }]
];
var ImageDown = createLucideIcon("image-down", __iconNode821);

// ../node_modules/lucide-react/dist/esm/icons/image-minus.js
var __iconNode822 = [
  ["path", { d: "M21 9v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7", key: "m87ecr" }],
  ["line", { x1: "16", x2: "22", y1: "5", y2: "5", key: "ez7e4s" }],
  ["circle", { cx: "9", cy: "9", r: "2", key: "af1f0g" }],
  ["path", { d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21", key: "1xmnt7" }]
];
var ImageMinus = createLucideIcon("image-minus", __iconNode822);

// ../node_modules/lucide-react/dist/esm/icons/image-off.js
var __iconNode823 = [
  ["line", { x1: "2", x2: "22", y1: "2", y2: "22", key: "a6p6uj" }],
  ["path", { d: "M10.41 10.41a2 2 0 1 1-2.83-2.83", key: "1bzlo9" }],
  ["line", { x1: "13.5", x2: "6", y1: "13.5", y2: "21", key: "1q0aeu" }],
  ["line", { x1: "18", x2: "21", y1: "12", y2: "15", key: "5mozeu" }],
  [
    "path",
    {
      d: "M3.59 3.59A1.99 1.99 0 0 0 3 5v14a2 2 0 0 0 2 2h14c.55 0 1.052-.22 1.41-.59",
      key: "mmje98"
    }
  ],
  ["path", { d: "M21 15V5a2 2 0 0 0-2-2H9", key: "43el77" }]
];
var ImageOff = createLucideIcon("image-off", __iconNode823);

// ../node_modules/lucide-react/dist/esm/icons/image-play.js
var __iconNode824 = [
  [
    "path",
    {
      d: "M15 15.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997a1 1 0 0 1-1.517-.86z",
      key: "nrt1m3"
    }
  ],
  ["path", { d: "M21 12.17V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6", key: "99hgts" }],
  ["path", { d: "m6 21 5-5", key: "1wyjai" }],
  ["circle", { cx: "9", cy: "9", r: "2", key: "af1f0g" }]
];
var ImagePlay = createLucideIcon("image-play", __iconNode824);

// ../node_modules/lucide-react/dist/esm/icons/image-plus.js
var __iconNode825 = [
  ["path", { d: "M16 5h6", key: "1vod17" }],
  ["path", { d: "M19 2v6", key: "4bpg5p" }],
  ["path", { d: "M21 11.5V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7.5", key: "1ue2ih" }],
  ["path", { d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21", key: "1xmnt7" }],
  ["circle", { cx: "9", cy: "9", r: "2", key: "af1f0g" }]
];
var ImagePlus = createLucideIcon("image-plus", __iconNode825);

// ../node_modules/lucide-react/dist/esm/icons/image-up.js
var __iconNode826 = [
  [
    "path",
    {
      d: "M10.3 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10l-3.1-3.1a2 2 0 0 0-2.814.014L6 21",
      key: "9csbqa"
    }
  ],
  ["path", { d: "m14 19.5 3-3 3 3", key: "9vmjn0" }],
  ["path", { d: "M17 22v-5.5", key: "1aa6fl" }],
  ["circle", { cx: "9", cy: "9", r: "2", key: "af1f0g" }]
];
var ImageUp = createLucideIcon("image-up", __iconNode826);

// ../node_modules/lucide-react/dist/esm/icons/image-upscale.js
var __iconNode827 = [
  ["path", { d: "M16 3h5v5", key: "1806ms" }],
  ["path", { d: "M17 21h2a2 2 0 0 0 2-2", key: "130fy9" }],
  ["path", { d: "M21 12v3", key: "1wzk3p" }],
  ["path", { d: "m21 3-5 5", key: "1g5oa7" }],
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2", key: "kk3yz1" }],
  ["path", { d: "m5 21 4.144-4.144a1.21 1.21 0 0 1 1.712 0L13 19", key: "fyekpt" }],
  ["path", { d: "M9 3h3", key: "d52fa" }],
  ["rect", { x: "3", y: "11", width: "10", height: "10", rx: "1", key: "1wpmix" }]
];
var ImageUpscale = createLucideIcon("image-upscale", __iconNode827);

// ../node_modules/lucide-react/dist/esm/icons/images.js
var __iconNode828 = [
  ["path", { d: "m22 11-1.296-1.296a2.4 2.4 0 0 0-3.408 0L11 16", key: "9kzy35" }],
  ["path", { d: "M4 8a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2", key: "1t0f0t" }],
  ["circle", { cx: "13", cy: "7", r: "1", fill: "currentColor", key: "1obus6" }],
  ["rect", { x: "8", y: "2", width: "14", height: "14", rx: "2", key: "1gvhby" }]
];
var Images = createLucideIcon("images", __iconNode828);

// ../node_modules/lucide-react/dist/esm/icons/image.js
var __iconNode829 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["circle", { cx: "9", cy: "9", r: "2", key: "af1f0g" }],
  ["path", { d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21", key: "1xmnt7" }]
];
var Image = createLucideIcon("image", __iconNode829);

// ../node_modules/lucide-react/dist/esm/icons/import.js
var __iconNode830 = [
  ["path", { d: "M12 3v12", key: "1x0j5s" }],
  ["path", { d: "m8 11 4 4 4-4", key: "1dohi6" }],
  [
    "path",
    {
      d: "M8 5H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-4",
      key: "1ywtjm"
    }
  ]
];
var Import = createLucideIcon("import", __iconNode830);

// ../node_modules/lucide-react/dist/esm/icons/inbox.js
var __iconNode831 = [
  ["polyline", { points: "22 12 16 12 14 15 10 15 8 12 2 12", key: "o97t9d" }],
  [
    "path",
    {
      d: "M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
      key: "oot6mr"
    }
  ]
];
var Inbox = createLucideIcon("inbox", __iconNode831);

// ../node_modules/lucide-react/dist/esm/icons/indian-rupee.js
var __iconNode832 = [
  ["path", { d: "M6 3h12", key: "ggurg9" }],
  ["path", { d: "M6 8h12", key: "6g4wlu" }],
  ["path", { d: "m6 13 8.5 8", key: "u1kupk" }],
  ["path", { d: "M6 13h3", key: "wdp6ag" }],
  ["path", { d: "M9 13c6.667 0 6.667-10 0-10", key: "1nkvk2" }]
];
var IndianRupee = createLucideIcon("indian-rupee", __iconNode832);

// ../node_modules/lucide-react/dist/esm/icons/infinity.js
var __iconNode833 = [
  ["path", { d: "M6 16c5 0 7-8 12-8a4 4 0 0 1 0 8c-5 0-7-8-12-8a4 4 0 1 0 0 8", key: "18ogeb" }]
];
var Infinity = createLucideIcon("infinity", __iconNode833);

// ../node_modules/lucide-react/dist/esm/icons/info.js
var __iconNode834 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 16v-4", key: "1dtifu" }],
  ["path", { d: "M12 8h.01", key: "e9boi3" }]
];
var Info = createLucideIcon("info", __iconNode834);

// ../node_modules/lucide-react/dist/esm/icons/inspection-panel.js
var __iconNode835 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M7 7h.01", key: "7u93v4" }],
  ["path", { d: "M17 7h.01", key: "14a9sn" }],
  ["path", { d: "M7 17h.01", key: "19xn7k" }],
  ["path", { d: "M17 17h.01", key: "1sd3ek" }]
];
var InspectionPanel = createLucideIcon("inspection-panel", __iconNode835);

// ../node_modules/lucide-react/dist/esm/icons/instagram.js
var __iconNode836 = [
  ["rect", { width: "20", height: "20", x: "2", y: "2", rx: "5", ry: "5", key: "2e1cvw" }],
  ["path", { d: "M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z", key: "9exkf1" }],
  ["line", { x1: "17.5", x2: "17.51", y1: "6.5", y2: "6.5", key: "r4j83e" }]
];
var Instagram = createLucideIcon("instagram", __iconNode836);

// ../node_modules/lucide-react/dist/esm/icons/italic.js
var __iconNode837 = [
  ["line", { x1: "19", x2: "10", y1: "4", y2: "4", key: "15jd3p" }],
  ["line", { x1: "14", x2: "5", y1: "20", y2: "20", key: "bu0au3" }],
  ["line", { x1: "15", x2: "9", y1: "4", y2: "20", key: "uljnxc" }]
];
var Italic = createLucideIcon("italic", __iconNode837);

// ../node_modules/lucide-react/dist/esm/icons/iteration-ccw.js
var __iconNode838 = [
  ["path", { d: "m16 14 4 4-4 4", key: "hkso8o" }],
  ["path", { d: "M20 10a8 8 0 1 0-8 8h8", key: "1bik7b" }]
];
var IterationCcw = createLucideIcon("iteration-ccw", __iconNode838);

// ../node_modules/lucide-react/dist/esm/icons/iteration-cw.js
var __iconNode839 = [
  ["path", { d: "M4 10a8 8 0 1 1 8 8H4", key: "svv66n" }],
  ["path", { d: "m8 22-4-4 4-4", key: "6g7gki" }]
];
var IterationCw = createLucideIcon("iteration-cw", __iconNode839);

// ../node_modules/lucide-react/dist/esm/icons/japanese-yen.js
var __iconNode840 = [
  ["path", { d: "M12 9.5V21m0-11.5L6 3m6 6.5L18 3", key: "2ej80x" }],
  ["path", { d: "M6 15h12", key: "1hwgt5" }],
  ["path", { d: "M6 11h12", key: "wf4gp6" }]
];
var JapaneseYen = createLucideIcon("japanese-yen", __iconNode840);

// ../node_modules/lucide-react/dist/esm/icons/joystick.js
var __iconNode841 = [
  [
    "path",
    {
      d: "M21 17a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-2Z",
      key: "jg2n2t"
    }
  ],
  ["path", { d: "M6 15v-2", key: "gd6mvg" }],
  ["path", { d: "M12 15V9", key: "8c7uyn" }],
  ["circle", { cx: "12", cy: "6", r: "3", key: "1gm2ql" }]
];
var Joystick = createLucideIcon("joystick", __iconNode841);

// ../node_modules/lucide-react/dist/esm/icons/kanban.js
var __iconNode842 = [
  ["path", { d: "M5 3v14", key: "9nsxs2" }],
  ["path", { d: "M12 3v8", key: "1h2ygw" }],
  ["path", { d: "M19 3v18", key: "1sk56x" }]
];
var Kanban = createLucideIcon("kanban", __iconNode842);

// ../node_modules/lucide-react/dist/esm/icons/kayak.js
var __iconNode843 = [
  ["path", { d: "M18 17a1 1 0 0 0-1 1v1a2 2 0 1 0 2-2z", key: "skzb1g" }],
  [
    "path",
    {
      d: "M20.97 3.61a.45.45 0 0 0-.58-.58C10.2 6.6 6.6 10.2 3.03 20.39a.45.45 0 0 0 .58.58C13.8 17.4 17.4 13.8 20.97 3.61",
      key: "cv9jm7"
    }
  ],
  ["path", { d: "m6.707 6.707 10.586 10.586", key: "d2l993" }],
  ["path", { d: "M7 5a2 2 0 1 0-2 2h1a1 1 0 0 0 1-1z", key: "i0et4n" }]
];
var Kayak = createLucideIcon("kayak", __iconNode843);

// ../node_modules/lucide-react/dist/esm/icons/key-round.js
var __iconNode844 = [
  [
    "path",
    {
      d: "M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z",
      key: "1s6t7t"
    }
  ],
  ["circle", { cx: "16.5", cy: "7.5", r: ".5", fill: "currentColor", key: "w0ekpg" }]
];
var KeyRound = createLucideIcon("key-round", __iconNode844);

// ../node_modules/lucide-react/dist/esm/icons/key-square.js
var __iconNode845 = [
  [
    "path",
    {
      d: "M12.4 2.7a2.5 2.5 0 0 1 3.4 0l5.5 5.5a2.5 2.5 0 0 1 0 3.4l-3.7 3.7a2.5 2.5 0 0 1-3.4 0L8.7 9.8a2.5 2.5 0 0 1 0-3.4z",
      key: "165ttr"
    }
  ],
  ["path", { d: "m14 7 3 3", key: "1r5n42" }],
  [
    "path",
    {
      d: "m9.4 10.6-6.814 6.814A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814",
      key: "1ubxi2"
    }
  ]
];
var KeySquare = createLucideIcon("key-square", __iconNode845);

// ../node_modules/lucide-react/dist/esm/icons/key.js
var __iconNode846 = [
  ["path", { d: "m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4", key: "g0fldk" }],
  ["path", { d: "m21 2-9.6 9.6", key: "1j0ho8" }],
  ["circle", { cx: "7.5", cy: "15.5", r: "5.5", key: "yqb3hr" }]
];
var Key = createLucideIcon("key", __iconNode846);

// ../node_modules/lucide-react/dist/esm/icons/keyboard-music.js
var __iconNode847 = [
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }],
  ["path", { d: "M6 8h4", key: "utf9t1" }],
  ["path", { d: "M14 8h.01", key: "1primd" }],
  ["path", { d: "M18 8h.01", key: "emo2bl" }],
  ["path", { d: "M2 12h20", key: "9i4pu4" }],
  ["path", { d: "M6 12v4", key: "dy92yo" }],
  ["path", { d: "M10 12v4", key: "1fxnav" }],
  ["path", { d: "M14 12v4", key: "1hft58" }],
  ["path", { d: "M18 12v4", key: "tjjnbz" }]
];
var KeyboardMusic = createLucideIcon("keyboard-music", __iconNode847);

// ../node_modules/lucide-react/dist/esm/icons/keyboard-off.js
var __iconNode848 = [
  ["path", { d: "M 20 4 A2 2 0 0 1 22 6", key: "1g1fkt" }],
  ["path", { d: "M 22 6 L 22 16.41", key: "1qjg3w" }],
  ["path", { d: "M 7 16 L 16 16", key: "n0yqwb" }],
  ["path", { d: "M 9.69 4 L 20 4", key: "kbpcgx" }],
  ["path", { d: "M14 8h.01", key: "1primd" }],
  ["path", { d: "M18 8h.01", key: "emo2bl" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M20 20H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2", key: "s23sx2" }],
  ["path", { d: "M6 8h.01", key: "x9i8wu" }],
  ["path", { d: "M8 12h.01", key: "czm47f" }]
];
var KeyboardOff = createLucideIcon("keyboard-off", __iconNode848);

// ../node_modules/lucide-react/dist/esm/icons/keyboard.js
var __iconNode849 = [
  ["path", { d: "M10 8h.01", key: "1r9ogq" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M14 8h.01", key: "1primd" }],
  ["path", { d: "M16 12h.01", key: "1l6xoz" }],
  ["path", { d: "M18 8h.01", key: "emo2bl" }],
  ["path", { d: "M6 8h.01", key: "x9i8wu" }],
  ["path", { d: "M7 16h10", key: "wp8him" }],
  ["path", { d: "M8 12h.01", key: "czm47f" }],
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }]
];
var Keyboard = createLucideIcon("keyboard", __iconNode849);

// ../node_modules/lucide-react/dist/esm/icons/lamp-ceiling.js
var __iconNode850 = [
  ["path", { d: "M12 2v5", key: "nd4vlx" }],
  ["path", { d: "M14.829 15.998a3 3 0 1 1-5.658 0", key: "1pybiy" }],
  [
    "path",
    {
      d: "M20.92 14.606A1 1 0 0 1 20 16H4a1 1 0 0 1-.92-1.394l3-7A1 1 0 0 1 7 7h10a1 1 0 0 1 .92.606z",
      key: "ma1wor"
    }
  ]
];
var LampCeiling = createLucideIcon("lamp-ceiling", __iconNode850);

// ../node_modules/lucide-react/dist/esm/icons/lamp-desk.js
var __iconNode851 = [
  [
    "path",
    {
      d: "M10.293 2.293a1 1 0 0 1 1.414 0l2.5 2.5 5.994 1.227a1 1 0 0 1 .506 1.687l-7 7a1 1 0 0 1-1.687-.506l-1.227-5.994-2.5-2.5a1 1 0 0 1 0-1.414z",
      key: "sb8slu"
    }
  ],
  ["path", { d: "m14.207 4.793-3.414 3.414", key: "m2x3oj" }],
  [
    "path",
    { d: "M3 20a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z", key: "8b3myj" }
  ],
  ["path", { d: "m9.086 6.5-4.793 4.793a1 1 0 0 0-.18 1.17L7 18", key: "43s6cu" }]
];
var LampDesk = createLucideIcon("lamp-desk", __iconNode851);

// ../node_modules/lucide-react/dist/esm/icons/lamp-wall-down.js
var __iconNode852 = [
  [
    "path",
    {
      d: "M19.929 18.629A1 1 0 0 1 19 20H9a1 1 0 0 1-.928-1.371l2-5A1 1 0 0 1 11 13h6a1 1 0 0 1 .928.629z",
      key: "u4w2d7"
    }
  ],
  [
    "path",
    { d: "M6 3a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2H5a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z", key: "15356w" }
  ],
  ["path", { d: "M8 6h4a2 2 0 0 1 2 2v5", key: "1m6m7x" }]
];
var LampWallDown = createLucideIcon("lamp-wall-down", __iconNode852);

// ../node_modules/lucide-react/dist/esm/icons/lamp-floor.js
var __iconNode853 = [
  ["path", { d: "M12 10v12", key: "6ubwww" }],
  [
    "path",
    {
      d: "M17.929 7.629A1 1 0 0 1 17 9H7a1 1 0 0 1-.928-1.371l2-5A1 1 0 0 1 9 2h6a1 1 0 0 1 .928.629z",
      key: "1o95gh"
    }
  ],
  ["path", { d: "M9 22h6", key: "1rlq3v" }]
];
var LampFloor = createLucideIcon("lamp-floor", __iconNode853);

// ../node_modules/lucide-react/dist/esm/icons/lamp-wall-up.js
var __iconNode854 = [
  [
    "path",
    {
      d: "M19.929 9.629A1 1 0 0 1 19 11H9a1 1 0 0 1-.928-1.371l2-5A1 1 0 0 1 11 4h6a1 1 0 0 1 .928.629z",
      key: "1uvrbf"
    }
  ],
  [
    "path",
    { d: "M6 15a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2H5a1 1 0 0 1-1-1v-4a1 1 0 0 1 1-1z", key: "154r2a" }
  ],
  ["path", { d: "M8 18h4a2 2 0 0 0 2-2v-5", key: "z9mbu0" }]
];
var LampWallUp = createLucideIcon("lamp-wall-up", __iconNode854);

// ../node_modules/lucide-react/dist/esm/icons/lamp.js
var __iconNode855 = [
  ["path", { d: "M12 12v6", key: "3ahymv" }],
  [
    "path",
    {
      d: "M4.077 10.615A1 1 0 0 0 5 12h14a1 1 0 0 0 .923-1.385l-3.077-7.384A2 2 0 0 0 15 2H9a2 2 0 0 0-1.846 1.23Z",
      key: "1l7kg2"
    }
  ],
  [
    "path",
    { d: "M8 20a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1z", key: "1mmzpi" }
  ]
];
var Lamp = createLucideIcon("lamp", __iconNode855);

// ../node_modules/lucide-react/dist/esm/icons/land-plot.js
var __iconNode856 = [
  ["path", { d: "m12 8 6-3-6-3v10", key: "mvpnpy" }],
  [
    "path",
    {
      d: "m8 11.99-5.5 3.14a1 1 0 0 0 0 1.74l8.5 4.86a2 2 0 0 0 2 0l8.5-4.86a1 1 0 0 0 0-1.74L16 12",
      key: "ek95tt"
    }
  ],
  ["path", { d: "m6.49 12.85 11.02 6.3", key: "1kt42w" }],
  ["path", { d: "M17.51 12.85 6.5 19.15", key: "v55bdg" }]
];
var LandPlot = createLucideIcon("land-plot", __iconNode856);

// ../node_modules/lucide-react/dist/esm/icons/landmark.js
var __iconNode857 = [
  ["path", { d: "M10 18v-7", key: "wt116b" }],
  [
    "path",
    {
      d: "M11.12 2.198a2 2 0 0 1 1.76.006l7.866 3.847c.476.233.31.949-.22.949H3.474c-.53 0-.695-.716-.22-.949z",
      key: "1m329m"
    }
  ],
  ["path", { d: "M14 18v-7", key: "vav6t3" }],
  ["path", { d: "M18 18v-7", key: "aexdmj" }],
  ["path", { d: "M3 22h18", key: "8prr45" }],
  ["path", { d: "M6 18v-7", key: "1ivflk" }]
];
var Landmark = createLucideIcon("landmark", __iconNode857);

// ../node_modules/lucide-react/dist/esm/icons/languages.js
var __iconNode858 = [
  ["path", { d: "m5 8 6 6", key: "1wu5hv" }],
  ["path", { d: "m4 14 6-6 2-3", key: "1k1g8d" }],
  ["path", { d: "M2 5h12", key: "or177f" }],
  ["path", { d: "M7 2h1", key: "1t2jsx" }],
  ["path", { d: "m22 22-5-10-5 10", key: "don7ne" }],
  ["path", { d: "M14 18h6", key: "1m8k6r" }]
];
var Languages = createLucideIcon("languages", __iconNode858);

// ../node_modules/lucide-react/dist/esm/icons/laptop-minimal-check.js
var __iconNode859 = [
  ["path", { d: "M2 20h20", key: "owomy5" }],
  ["path", { d: "m9 10 2 2 4-4", key: "1gnqz4" }],
  ["rect", { x: "3", y: "4", width: "18", height: "12", rx: "2", key: "8ur36m" }]
];
var LaptopMinimalCheck = createLucideIcon("laptop-minimal-check", __iconNode859);

// ../node_modules/lucide-react/dist/esm/icons/laptop-minimal.js
var __iconNode860 = [
  ["rect", { width: "18", height: "12", x: "3", y: "4", rx: "2", ry: "2", key: "1qhy41" }],
  ["line", { x1: "2", x2: "22", y1: "20", y2: "20", key: "ni3hll" }]
];
var LaptopMinimal = createLucideIcon("laptop-minimal", __iconNode860);

// ../node_modules/lucide-react/dist/esm/icons/laptop.js
var __iconNode861 = [
  [
    "path",
    {
      d: "M18 5a2 2 0 0 1 2 2v8.526a2 2 0 0 0 .212.897l1.068 2.127a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45l1.068-2.127A2 2 0 0 0 4 15.526V7a2 2 0 0 1 2-2z",
      key: "1pdavp"
    }
  ],
  ["path", { d: "M20.054 15.987H3.946", key: "14rxg9" }]
];
var Laptop = createLucideIcon("laptop", __iconNode861);

// ../node_modules/lucide-react/dist/esm/icons/lasso-select.js
var __iconNode862 = [
  ["path", { d: "M7 22a5 5 0 0 1-2-4", key: "umushi" }],
  ["path", { d: "M7 16.93c.96.43 1.96.74 2.99.91", key: "ybbtv3" }],
  [
    "path",
    {
      d: "M3.34 14A6.8 6.8 0 0 1 2 10c0-4.42 4.48-8 10-8s10 3.58 10 8a7.19 7.19 0 0 1-.33 2",
      key: "gt5e1w"
    }
  ],
  ["path", { d: "M5 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4z", key: "bq3ynw" }],
  [
    "path",
    {
      d: "M14.33 22h-.09a.35.35 0 0 1-.24-.32v-10a.34.34 0 0 1 .33-.34c.08 0 .15.03.21.08l7.34 6a.33.33 0 0 1-.21.59h-4.49l-2.57 3.85a.35.35 0 0 1-.28.14z",
      key: "72q637"
    }
  ]
];
var LassoSelect = createLucideIcon("lasso-select", __iconNode862);

// ../node_modules/lucide-react/dist/esm/icons/lasso.js
var __iconNode863 = [
  ["path", { d: "M3.704 14.467a10 8 0 1 1 3.115 2.375", key: "wxgc5m" }],
  ["path", { d: "M7 22a5 5 0 0 1-2-3.994", key: "1xp6a4" }],
  ["circle", { cx: "5", cy: "16", r: "2", key: "18csp3" }]
];
var Lasso = createLucideIcon("lasso", __iconNode863);

// ../node_modules/lucide-react/dist/esm/icons/laugh.js
var __iconNode864 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M18 13a6 6 0 0 1-6 5 6 6 0 0 1-6-5h12Z", key: "b2q4dd" }],
  ["line", { x1: "9", x2: "9.01", y1: "9", y2: "9", key: "yxxnd0" }],
  ["line", { x1: "15", x2: "15.01", y1: "9", y2: "9", key: "1p4y9e" }]
];
var Laugh = createLucideIcon("laugh", __iconNode864);

// ../node_modules/lucide-react/dist/esm/icons/layers-plus.js
var __iconNode865 = [
  [
    "path",
    {
      d: "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 .83.18 2 2 0 0 0 .83-.18l8.58-3.9a1 1 0 0 0 0-1.831z",
      key: "zzgyd3"
    }
  ],
  ["path", { d: "M16 17h6", key: "1ook5g" }],
  ["path", { d: "M19 14v6", key: "1ckrd5" }],
  ["path", { d: "M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 .825.178", key: "1ia9y3" }],
  ["path", { d: "M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l2.116-.962", key: "jksky3" }]
];
var LayersPlus = createLucideIcon("layers-plus", __iconNode865);

// ../node_modules/lucide-react/dist/esm/icons/layers-2.js
var __iconNode866 = [
  [
    "path",
    {
      d: "M13 13.74a2 2 0 0 1-2 0L2.5 8.87a1 1 0 0 1 0-1.74L11 2.26a2 2 0 0 1 2 0l8.5 4.87a1 1 0 0 1 0 1.74z",
      key: "15q6uc"
    }
  ],
  [
    "path",
    {
      d: "m20 14.285 1.5.845a1 1 0 0 1 0 1.74L13 21.74a2 2 0 0 1-2 0l-8.5-4.87a1 1 0 0 1 0-1.74l1.5-.845",
      key: "byia6g"
    }
  ]
];
var Layers2 = createLucideIcon("layers-2", __iconNode866);

// ../node_modules/lucide-react/dist/esm/icons/layers.js
var __iconNode867 = [
  [
    "path",
    {
      d: "M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z",
      key: "zw3jo"
    }
  ],
  [
    "path",
    {
      d: "M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12",
      key: "1wduqc"
    }
  ],
  [
    "path",
    {
      d: "M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17",
      key: "kqbvx6"
    }
  ]
];
var Layers = createLucideIcon("layers", __iconNode867);

// ../node_modules/lucide-react/dist/esm/icons/layout-dashboard.js
var __iconNode868 = [
  ["rect", { width: "7", height: "9", x: "3", y: "3", rx: "1", key: "10lvy0" }],
  ["rect", { width: "7", height: "5", x: "14", y: "3", rx: "1", key: "16une8" }],
  ["rect", { width: "7", height: "9", x: "14", y: "12", rx: "1", key: "1hutg5" }],
  ["rect", { width: "7", height: "5", x: "3", y: "16", rx: "1", key: "ldoo1y" }]
];
var LayoutDashboard = createLucideIcon("layout-dashboard", __iconNode868);

// ../node_modules/lucide-react/dist/esm/icons/layout-grid.js
var __iconNode869 = [
  ["rect", { width: "7", height: "7", x: "3", y: "3", rx: "1", key: "1g98yp" }],
  ["rect", { width: "7", height: "7", x: "14", y: "3", rx: "1", key: "6d4xhi" }],
  ["rect", { width: "7", height: "7", x: "14", y: "14", rx: "1", key: "nxv5o0" }],
  ["rect", { width: "7", height: "7", x: "3", y: "14", rx: "1", key: "1bb6yr" }]
];
var LayoutGrid = createLucideIcon("layout-grid", __iconNode869);

// ../node_modules/lucide-react/dist/esm/icons/layout-list.js
var __iconNode870 = [
  ["rect", { width: "7", height: "7", x: "3", y: "3", rx: "1", key: "1g98yp" }],
  ["rect", { width: "7", height: "7", x: "3", y: "14", rx: "1", key: "1bb6yr" }],
  ["path", { d: "M14 4h7", key: "3xa0d5" }],
  ["path", { d: "M14 9h7", key: "1icrd9" }],
  ["path", { d: "M14 15h7", key: "1mj8o2" }],
  ["path", { d: "M14 20h7", key: "11slyb" }]
];
var LayoutList = createLucideIcon("layout-list", __iconNode870);

// ../node_modules/lucide-react/dist/esm/icons/layout-panel-left.js
var __iconNode871 = [
  ["rect", { width: "7", height: "18", x: "3", y: "3", rx: "1", key: "2obqm" }],
  ["rect", { width: "7", height: "7", x: "14", y: "3", rx: "1", key: "6d4xhi" }],
  ["rect", { width: "7", height: "7", x: "14", y: "14", rx: "1", key: "nxv5o0" }]
];
var LayoutPanelLeft = createLucideIcon("layout-panel-left", __iconNode871);

// ../node_modules/lucide-react/dist/esm/icons/layout-panel-top.js
var __iconNode872 = [
  ["rect", { width: "18", height: "7", x: "3", y: "3", rx: "1", key: "f1a2em" }],
  ["rect", { width: "7", height: "7", x: "3", y: "14", rx: "1", key: "1bb6yr" }],
  ["rect", { width: "7", height: "7", x: "14", y: "14", rx: "1", key: "nxv5o0" }]
];
var LayoutPanelTop = createLucideIcon("layout-panel-top", __iconNode872);

// ../node_modules/lucide-react/dist/esm/icons/layout-template.js
var __iconNode873 = [
  ["rect", { width: "18", height: "7", x: "3", y: "3", rx: "1", key: "f1a2em" }],
  ["rect", { width: "9", height: "7", x: "3", y: "14", rx: "1", key: "jqznyg" }],
  ["rect", { width: "5", height: "7", x: "16", y: "14", rx: "1", key: "q5h2i8" }]
];
var LayoutTemplate = createLucideIcon("layout-template", __iconNode873);

// ../node_modules/lucide-react/dist/esm/icons/leaf.js
var __iconNode874 = [
  [
    "path",
    {
      d: "M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z",
      key: "nnexq3"
    }
  ],
  ["path", { d: "M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12", key: "mt58a7" }]
];
var Leaf = createLucideIcon("leaf", __iconNode874);

// ../node_modules/lucide-react/dist/esm/icons/leafy-green.js
var __iconNode875 = [
  [
    "path",
    {
      d: "M2 22c1.25-.987 2.27-1.975 3.9-2.2a5.56 5.56 0 0 1 3.8 1.5 4 4 0 0 0 6.187-2.353 3.5 3.5 0 0 0 3.69-5.116A3.5 3.5 0 0 0 20.95 8 3.5 3.5 0 1 0 16 3.05a3.5 3.5 0 0 0-5.831 1.373 3.5 3.5 0 0 0-5.116 3.69 4 4 0 0 0-2.348 6.155C3.499 15.42 4.409 16.712 4.2 18.1 3.926 19.743 3.014 20.732 2 22",
      key: "1134nt"
    }
  ],
  ["path", { d: "M2 22 17 7", key: "1q7jp2" }]
];
var LeafyGreen = createLucideIcon("leafy-green", __iconNode875);

// ../node_modules/lucide-react/dist/esm/icons/lectern.js
var __iconNode876 = [
  [
    "path",
    {
      d: "M16 12h3a2 2 0 0 0 1.902-1.38l1.056-3.333A1 1 0 0 0 21 6H3a1 1 0 0 0-.958 1.287l1.056 3.334A2 2 0 0 0 5 12h3",
      key: "13jjxg"
    }
  ],
  ["path", { d: "M18 6V3a1 1 0 0 0-1-1h-3", key: "1550fe" }],
  ["rect", { width: "8", height: "12", x: "8", y: "10", rx: "1", key: "qmu8b6" }]
];
var Lectern = createLucideIcon("lectern", __iconNode876);

// ../node_modules/lucide-react/dist/esm/icons/lens-concave.js
var __iconNode877 = [
  [
    "path",
    {
      d: "M7 2a1 1 0 0 0-.8 1.6 14 14 0 0 1 0 16.8A1 1 0 0 0 7 22h10a1 1 0 0 0 .8-1.6 14 14 0 0 1 0-16.8A1 1 0 0 0 17 2z",
      key: "109j23"
    }
  ]
];
var LensConcave = createLucideIcon("lens-concave", __iconNode877);

// ../node_modules/lucide-react/dist/esm/icons/lens-convex.js
var __iconNode878 = [
  [
    "path",
    {
      d: "M13.433 2a1 1 0 0 1 .824.448 18 18 0 0 1 0 19.104 1 1 0 0 1-.824.448h-2.866a1 1 0 0 1-.824-.448 18 18 0 0 1 0-19.104A1 1 0 0 1 10.567 2z",
      key: "cq67go"
    }
  ]
];
var LensConvex = createLucideIcon("lens-convex", __iconNode878);

// ../node_modules/lucide-react/dist/esm/icons/library-big.js
var __iconNode879 = [
  ["rect", { width: "8", height: "18", x: "3", y: "3", rx: "1", key: "oynpb5" }],
  ["path", { d: "M7 3v18", key: "bbkbws" }],
  [
    "path",
    {
      d: "M20.4 18.9c.2.5-.1 1.1-.6 1.3l-1.9.7c-.5.2-1.1-.1-1.3-.6L11.1 5.1c-.2-.5.1-1.1.6-1.3l1.9-.7c.5-.2 1.1.1 1.3.6Z",
      key: "1qboyk"
    }
  ]
];
var LibraryBig = createLucideIcon("library-big", __iconNode879);

// ../node_modules/lucide-react/dist/esm/icons/library.js
var __iconNode880 = [
  ["path", { d: "m16 6 4 14", key: "ji33uf" }],
  ["path", { d: "M12 6v14", key: "1n7gus" }],
  ["path", { d: "M8 8v12", key: "1gg7y9" }],
  ["path", { d: "M4 4v16", key: "6qkkli" }]
];
var Library = createLucideIcon("library", __iconNode880);

// ../node_modules/lucide-react/dist/esm/icons/life-buoy.js
var __iconNode881 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m4.93 4.93 4.24 4.24", key: "1ymg45" }],
  ["path", { d: "m14.83 9.17 4.24-4.24", key: "1cb5xl" }],
  ["path", { d: "m14.83 14.83 4.24 4.24", key: "q42g0n" }],
  ["path", { d: "m9.17 14.83-4.24 4.24", key: "bqpfvv" }],
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }]
];
var LifeBuoy = createLucideIcon("life-buoy", __iconNode881);

// ../node_modules/lucide-react/dist/esm/icons/ligature.js
var __iconNode882 = [
  ["path", { d: "M14 12h2v8", key: "c1fccl" }],
  ["path", { d: "M14 20h4", key: "lzx1xo" }],
  ["path", { d: "M6 12h4", key: "a4o3ry" }],
  ["path", { d: "M6 20h4", key: "1i6q5t" }],
  ["path", { d: "M8 20V8a4 4 0 0 1 7.464-2", key: "wk9t6r" }]
];
var Ligature = createLucideIcon("ligature", __iconNode882);

// ../node_modules/lucide-react/dist/esm/icons/lightbulb-off.js
var __iconNode883 = [
  ["path", { d: "M16.8 11.2c.8-.9 1.2-2 1.2-3.2a6 6 0 0 0-9.3-5", key: "1fkcox" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M6.3 6.3a4.67 4.67 0 0 0 1.2 5.2c.7.7 1.3 1.5 1.5 2.5", key: "10m8kw" }],
  ["path", { d: "M9 18h6", key: "x1upvd" }],
  ["path", { d: "M10 22h4", key: "ceow96" }]
];
var LightbulbOff = createLucideIcon("lightbulb-off", __iconNode883);

// ../node_modules/lucide-react/dist/esm/icons/lightbulb.js
var __iconNode884 = [
  [
    "path",
    {
      d: "M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5",
      key: "1gvzjb"
    }
  ],
  ["path", { d: "M9 18h6", key: "x1upvd" }],
  ["path", { d: "M10 22h4", key: "ceow96" }]
];
var Lightbulb = createLucideIcon("lightbulb", __iconNode884);

// ../node_modules/lucide-react/dist/esm/icons/line-dot-right-horizontal.js
var __iconNode885 = [
  ["path", { d: "M 3 12 L 15 12", key: "ymhu98" }],
  ["circle", { cx: "18", cy: "12", r: "3", key: "1kchzo" }]
];
var LineDotRightHorizontal = createLucideIcon("line-dot-right-horizontal", __iconNode885);

// ../node_modules/lucide-react/dist/esm/icons/line-squiggle.js
var __iconNode886 = [
  [
    "path",
    {
      d: "M7 3.5c5-2 7 2.5 3 4C1.5 10 2 15 5 16c5 2 9-10 14-7s.5 13.5-4 12c-5-2.5.5-11 6-2",
      key: "1lrphd"
    }
  ]
];
var LineSquiggle = createLucideIcon("line-squiggle", __iconNode886);

// ../node_modules/lucide-react/dist/esm/icons/link-2-off.js
var __iconNode887 = [
  ["path", { d: "M9 17H7A5 5 0 0 1 7 7", key: "10o201" }],
  ["path", { d: "M15 7h2a5 5 0 0 1 4 8", key: "1d3206" }],
  ["line", { x1: "8", x2: "12", y1: "12", y2: "12", key: "rvw6j4" }],
  ["line", { x1: "2", x2: "22", y1: "2", y2: "22", key: "a6p6uj" }]
];
var Link2Off = createLucideIcon("link-2-off", __iconNode887);

// ../node_modules/lucide-react/dist/esm/icons/link-2.js
var __iconNode888 = [
  ["path", { d: "M9 17H7A5 5 0 0 1 7 7h2", key: "8i5ue5" }],
  ["path", { d: "M15 7h2a5 5 0 1 1 0 10h-2", key: "1b9ql8" }],
  ["line", { x1: "8", x2: "16", y1: "12", y2: "12", key: "1jonct" }]
];
var Link2 = createLucideIcon("link-2", __iconNode888);

// ../node_modules/lucide-react/dist/esm/icons/link.js
var __iconNode889 = [
  ["path", { d: "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71", key: "1cjeqo" }],
  ["path", { d: "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71", key: "19qd67" }]
];
var Link = createLucideIcon("link", __iconNode889);

// ../node_modules/lucide-react/dist/esm/icons/linkedin.js
var __iconNode890 = [
  [
    "path",
    {
      d: "M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z",
      key: "c2jq9f"
    }
  ],
  ["rect", { width: "4", height: "12", x: "2", y: "9", key: "mk3on5" }],
  ["circle", { cx: "4", cy: "4", r: "2", key: "bt5ra8" }]
];
var Linkedin = createLucideIcon("linkedin", __iconNode890);

// ../node_modules/lucide-react/dist/esm/icons/list-check.js
var __iconNode891 = [
  ["path", { d: "M16 5H3", key: "m91uny" }],
  ["path", { d: "M16 12H3", key: "1a2rj7" }],
  ["path", { d: "M11 19H3", key: "zflm78" }],
  ["path", { d: "m15 18 2 2 4-4", key: "1szwhi" }]
];
var ListCheck = createLucideIcon("list-check", __iconNode891);

// ../node_modules/lucide-react/dist/esm/icons/list-checks.js
var __iconNode892 = [
  ["path", { d: "M13 5h8", key: "a7qcls" }],
  ["path", { d: "M13 12h8", key: "h98zly" }],
  ["path", { d: "M13 19h8", key: "c3s6r1" }],
  ["path", { d: "m3 17 2 2 4-4", key: "1jhpwq" }],
  ["path", { d: "m3 7 2 2 4-4", key: "1obspn" }]
];
var ListChecks = createLucideIcon("list-checks", __iconNode892);

// ../node_modules/lucide-react/dist/esm/icons/list-chevrons-down-up.js
var __iconNode893 = [
  ["path", { d: "M3 5h8", key: "18g2rq" }],
  ["path", { d: "M3 12h8", key: "1xfjp6" }],
  ["path", { d: "M3 19h8", key: "fpbke4" }],
  ["path", { d: "m15 5 3 3 3-3", key: "1t4thf" }],
  ["path", { d: "m15 19 3-3 3 3", key: "y4ckd2" }]
];
var ListChevronsDownUp = createLucideIcon("list-chevrons-down-up", __iconNode893);

// ../node_modules/lucide-react/dist/esm/icons/list-chevrons-up-down.js
var __iconNode894 = [
  ["path", { d: "M3 5h8", key: "18g2rq" }],
  ["path", { d: "M3 12h8", key: "1xfjp6" }],
  ["path", { d: "M3 19h8", key: "fpbke4" }],
  ["path", { d: "m15 8 3-3 3 3", key: "bc4io6" }],
  ["path", { d: "m15 16 3 3 3-3", key: "9wmg1l" }]
];
var ListChevronsUpDown = createLucideIcon("list-chevrons-up-down", __iconNode894);

// ../node_modules/lucide-react/dist/esm/icons/list-collapse.js
var __iconNode895 = [
  ["path", { d: "M10 5h11", key: "1hkqpe" }],
  ["path", { d: "M10 12h11", key: "6m4ad9" }],
  ["path", { d: "M10 19h11", key: "14g2nv" }],
  ["path", { d: "m3 10 3-3-3-3", key: "i7pm08" }],
  ["path", { d: "m3 20 3-3-3-3", key: "20gx1n" }]
];
var ListCollapse = createLucideIcon("list-collapse", __iconNode895);

// ../node_modules/lucide-react/dist/esm/icons/list-end.js
var __iconNode896 = [
  ["path", { d: "M16 5H3", key: "m91uny" }],
  ["path", { d: "M16 12H3", key: "1a2rj7" }],
  ["path", { d: "M9 19H3", key: "s61nz1" }],
  ["path", { d: "m16 16-3 3 3 3", key: "117b85" }],
  ["path", { d: "M21 5v12a2 2 0 0 1-2 2h-6", key: "hey24a" }]
];
var ListEnd = createLucideIcon("list-end", __iconNode896);

// ../node_modules/lucide-react/dist/esm/icons/list-filter-plus.js
var __iconNode897 = [
  ["path", { d: "M12 5H2", key: "1o22fu" }],
  ["path", { d: "M6 12h12", key: "8npq4p" }],
  ["path", { d: "M9 19h6", key: "456am0" }],
  ["path", { d: "M16 5h6", key: "1vod17" }],
  ["path", { d: "M19 8V2", key: "1wcffq" }]
];
var ListFilterPlus = createLucideIcon("list-filter-plus", __iconNode897);

// ../node_modules/lucide-react/dist/esm/icons/list-filter.js
var __iconNode898 = [
  ["path", { d: "M2 5h20", key: "1fs1ex" }],
  ["path", { d: "M6 12h12", key: "8npq4p" }],
  ["path", { d: "M9 19h6", key: "456am0" }]
];
var ListFilter = createLucideIcon("list-filter", __iconNode898);

// ../node_modules/lucide-react/dist/esm/icons/list-indent-decrease.js
var __iconNode899 = [
  ["path", { d: "M21 5H11", key: "us1j55" }],
  ["path", { d: "M21 12H11", key: "wd7e0v" }],
  ["path", { d: "M21 19H11", key: "saa85w" }],
  ["path", { d: "m7 8-4 4 4 4", key: "o5hrat" }]
];
var ListIndentDecrease = createLucideIcon("list-indent-decrease", __iconNode899);

// ../node_modules/lucide-react/dist/esm/icons/list-indent-increase.js
var __iconNode900 = [
  ["path", { d: "M21 5H11", key: "us1j55" }],
  ["path", { d: "M21 12H11", key: "wd7e0v" }],
  ["path", { d: "M21 19H11", key: "saa85w" }],
  ["path", { d: "m3 8 4 4-4 4", key: "1a3j6y" }]
];
var ListIndentIncrease = createLucideIcon("list-indent-increase", __iconNode900);

// ../node_modules/lucide-react/dist/esm/icons/list-minus.js
var __iconNode901 = [
  ["path", { d: "M16 5H3", key: "m91uny" }],
  ["path", { d: "M11 12H3", key: "51ecnj" }],
  ["path", { d: "M16 19H3", key: "zzsher" }],
  ["path", { d: "M21 12h-6", key: "bt1uis" }]
];
var ListMinus = createLucideIcon("list-minus", __iconNode901);

// ../node_modules/lucide-react/dist/esm/icons/list-music.js
var __iconNode902 = [
  ["path", { d: "M16 5H3", key: "m91uny" }],
  ["path", { d: "M11 12H3", key: "51ecnj" }],
  ["path", { d: "M11 19H3", key: "zflm78" }],
  ["path", { d: "M21 16V5", key: "yxg4q8" }],
  ["circle", { cx: "18", cy: "16", r: "3", key: "1hluhg" }]
];
var ListMusic = createLucideIcon("list-music", __iconNode902);

// ../node_modules/lucide-react/dist/esm/icons/list-ordered.js
var __iconNode903 = [
  ["path", { d: "M11 5h10", key: "1cz7ny" }],
  ["path", { d: "M11 12h10", key: "1438ji" }],
  ["path", { d: "M11 19h10", key: "11t30w" }],
  ["path", { d: "M4 4h1v5", key: "10yrso" }],
  ["path", { d: "M4 9h2", key: "r1h2o0" }],
  ["path", { d: "M6.5 20H3.4c0-1 2.6-1.925 2.6-3.5a1.5 1.5 0 0 0-2.6-1.02", key: "xtkcd5" }]
];
var ListOrdered = createLucideIcon("list-ordered", __iconNode903);

// ../node_modules/lucide-react/dist/esm/icons/list-plus.js
var __iconNode904 = [
  ["path", { d: "M16 5H3", key: "m91uny" }],
  ["path", { d: "M11 12H3", key: "51ecnj" }],
  ["path", { d: "M16 19H3", key: "zzsher" }],
  ["path", { d: "M18 9v6", key: "1twb98" }],
  ["path", { d: "M21 12h-6", key: "bt1uis" }]
];
var ListPlus = createLucideIcon("list-plus", __iconNode904);

// ../node_modules/lucide-react/dist/esm/icons/list-restart.js
var __iconNode905 = [
  ["path", { d: "M21 5H3", key: "1fi0y6" }],
  ["path", { d: "M7 12H3", key: "13ou7f" }],
  ["path", { d: "M7 19H3", key: "wbqt3n" }],
  [
    "path",
    {
      d: "M12 18a5 5 0 0 0 9-3 4.5 4.5 0 0 0-4.5-4.5c-1.33 0-2.54.54-3.41 1.41L11 14",
      key: "qth677"
    }
  ],
  ["path", { d: "M11 10v4h4", key: "172dkj" }]
];
var ListRestart = createLucideIcon("list-restart", __iconNode905);

// ../node_modules/lucide-react/dist/esm/icons/list-start.js
var __iconNode906 = [
  ["path", { d: "M3 5h6", key: "1ltk0q" }],
  ["path", { d: "M3 12h13", key: "ppymz1" }],
  ["path", { d: "M3 19h13", key: "bpdczq" }],
  ["path", { d: "m16 8-3-3 3-3", key: "1pjpp6" }],
  ["path", { d: "M21 19V7a2 2 0 0 0-2-2h-6", key: "4zzq67" }]
];
var ListStart = createLucideIcon("list-start", __iconNode906);

// ../node_modules/lucide-react/dist/esm/icons/list-todo.js
var __iconNode907 = [
  ["path", { d: "M13 5h8", key: "a7qcls" }],
  ["path", { d: "M13 12h8", key: "h98zly" }],
  ["path", { d: "M13 19h8", key: "c3s6r1" }],
  ["path", { d: "m3 17 2 2 4-4", key: "1jhpwq" }],
  ["rect", { x: "3", y: "4", width: "6", height: "6", rx: "1", key: "cif1o7" }]
];
var ListTodo = createLucideIcon("list-todo", __iconNode907);

// ../node_modules/lucide-react/dist/esm/icons/list-tree.js
var __iconNode908 = [
  ["path", { d: "M8 5h13", key: "1pao27" }],
  ["path", { d: "M13 12h8", key: "h98zly" }],
  ["path", { d: "M13 19h8", key: "c3s6r1" }],
  ["path", { d: "M3 10a2 2 0 0 0 2 2h3", key: "1npucw" }],
  ["path", { d: "M3 5v12a2 2 0 0 0 2 2h3", key: "x1gjn2" }]
];
var ListTree = createLucideIcon("list-tree", __iconNode908);

// ../node_modules/lucide-react/dist/esm/icons/list-video.js
var __iconNode909 = [
  ["path", { d: "M21 5H3", key: "1fi0y6" }],
  ["path", { d: "M10 12H3", key: "1ulcyk" }],
  ["path", { d: "M10 19H3", key: "108z41" }],
  [
    "path",
    {
      d: "M15 12.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997a1 1 0 0 1-1.517-.86z",
      key: "ms4nik"
    }
  ]
];
var ListVideo = createLucideIcon("list-video", __iconNode909);

// ../node_modules/lucide-react/dist/esm/icons/list-x.js
var __iconNode910 = [
  ["path", { d: "M16 5H3", key: "m91uny" }],
  ["path", { d: "M11 12H3", key: "51ecnj" }],
  ["path", { d: "M16 19H3", key: "zzsher" }],
  ["path", { d: "m15.5 9.5 5 5", key: "ytk86i" }],
  ["path", { d: "m20.5 9.5-5 5", key: "17o44f" }]
];
var ListX = createLucideIcon("list-x", __iconNode910);

// ../node_modules/lucide-react/dist/esm/icons/list.js
var __iconNode911 = [
  ["path", { d: "M3 5h.01", key: "18ugdj" }],
  ["path", { d: "M3 12h.01", key: "nlz23k" }],
  ["path", { d: "M3 19h.01", key: "noohij" }],
  ["path", { d: "M8 5h13", key: "1pao27" }],
  ["path", { d: "M8 12h13", key: "1za7za" }],
  ["path", { d: "M8 19h13", key: "m83p4d" }]
];
var List = createLucideIcon("list", __iconNode911);

// ../node_modules/lucide-react/dist/esm/icons/loader-circle.js
var __iconNode912 = [["path", { d: "M21 12a9 9 0 1 1-6.219-8.56", key: "13zald" }]];
var LoaderCircle = createLucideIcon("loader-circle", __iconNode912);

// ../node_modules/lucide-react/dist/esm/icons/loader-pinwheel.js
var __iconNode913 = [
  ["path", { d: "M22 12a1 1 0 0 1-10 0 1 1 0 0 0-10 0", key: "1lzz15" }],
  ["path", { d: "M7 20.7a1 1 0 1 1 5-8.7 1 1 0 1 0 5-8.6", key: "1gnrpi" }],
  ["path", { d: "M7 3.3a1 1 0 1 1 5 8.6 1 1 0 1 0 5 8.6", key: "u9yy5q" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
];
var LoaderPinwheel = createLucideIcon("loader-pinwheel", __iconNode913);

// ../node_modules/lucide-react/dist/esm/icons/loader.js
var __iconNode914 = [
  ["path", { d: "M12 2v4", key: "3427ic" }],
  ["path", { d: "m16.2 7.8 2.9-2.9", key: "r700ao" }],
  ["path", { d: "M18 12h4", key: "wj9ykh" }],
  ["path", { d: "m16.2 16.2 2.9 2.9", key: "1bxg5t" }],
  ["path", { d: "M12 18v4", key: "jadmvz" }],
  ["path", { d: "m4.9 19.1 2.9-2.9", key: "bwix9q" }],
  ["path", { d: "M2 12h4", key: "j09sii" }],
  ["path", { d: "m4.9 4.9 2.9 2.9", key: "giyufr" }]
];
var Loader = createLucideIcon("loader", __iconNode914);

// ../node_modules/lucide-react/dist/esm/icons/locate-fixed.js
var __iconNode915 = [
  ["line", { x1: "2", x2: "5", y1: "12", y2: "12", key: "bvdh0s" }],
  ["line", { x1: "19", x2: "22", y1: "12", y2: "12", key: "1tbv5k" }],
  ["line", { x1: "12", x2: "12", y1: "2", y2: "5", key: "11lu5j" }],
  ["line", { x1: "12", x2: "12", y1: "19", y2: "22", key: "x3vr5v" }],
  ["circle", { cx: "12", cy: "12", r: "7", key: "fim9np" }],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
];
var LocateFixed = createLucideIcon("locate-fixed", __iconNode915);

// ../node_modules/lucide-react/dist/esm/icons/locate-off.js
var __iconNode916 = [
  ["path", { d: "M12 19v3", key: "npa21l" }],
  ["path", { d: "M12 2v3", key: "qbqxhf" }],
  ["path", { d: "M18.89 13.24a7 7 0 0 0-8.13-8.13", key: "1v9jrh" }],
  ["path", { d: "M19 12h3", key: "osuazr" }],
  ["path", { d: "M2 12h3", key: "1wrr53" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M7.05 7.05a7 7 0 0 0 9.9 9.9", key: "rc5l2e" }]
];
var LocateOff = createLucideIcon("locate-off", __iconNode916);

// ../node_modules/lucide-react/dist/esm/icons/locate.js
var __iconNode917 = [
  ["line", { x1: "2", x2: "5", y1: "12", y2: "12", key: "bvdh0s" }],
  ["line", { x1: "19", x2: "22", y1: "12", y2: "12", key: "1tbv5k" }],
  ["line", { x1: "12", x2: "12", y1: "2", y2: "5", key: "11lu5j" }],
  ["line", { x1: "12", x2: "12", y1: "19", y2: "22", key: "x3vr5v" }],
  ["circle", { cx: "12", cy: "12", r: "7", key: "fim9np" }]
];
var Locate = createLucideIcon("locate", __iconNode917);

// ../node_modules/lucide-react/dist/esm/icons/lock-keyhole.js
var __iconNode918 = [
  ["circle", { cx: "12", cy: "16", r: "1", key: "1au0dj" }],
  ["rect", { x: "3", y: "10", width: "18", height: "12", rx: "2", key: "6s8ecr" }],
  ["path", { d: "M7 10V7a5 5 0 0 1 10 0v3", key: "1pqi11" }]
];
var LockKeyhole = createLucideIcon("lock-keyhole", __iconNode918);

// ../node_modules/lucide-react/dist/esm/icons/lock-keyhole-open.js
var __iconNode919 = [
  ["circle", { cx: "12", cy: "16", r: "1", key: "1au0dj" }],
  ["rect", { width: "18", height: "12", x: "3", y: "10", rx: "2", key: "l0tzu3" }],
  ["path", { d: "M7 10V7a5 5 0 0 1 9.33-2.5", key: "car5b7" }]
];
var LockKeyholeOpen = createLucideIcon("lock-keyhole-open", __iconNode919);

// ../node_modules/lucide-react/dist/esm/icons/lock-open.js
var __iconNode920 = [
  ["rect", { width: "18", height: "11", x: "3", y: "11", rx: "2", ry: "2", key: "1w4ew1" }],
  ["path", { d: "M7 11V7a5 5 0 0 1 9.9-1", key: "1mm8w8" }]
];
var LockOpen = createLucideIcon("lock-open", __iconNode920);

// ../node_modules/lucide-react/dist/esm/icons/lock.js
var __iconNode921 = [
  ["rect", { width: "18", height: "11", x: "3", y: "11", rx: "2", ry: "2", key: "1w4ew1" }],
  ["path", { d: "M7 11V7a5 5 0 0 1 10 0v4", key: "fwvmzm" }]
];
var Lock = createLucideIcon("lock", __iconNode921);

// ../node_modules/lucide-react/dist/esm/icons/log-in.js
var __iconNode922 = [
  ["path", { d: "m10 17 5-5-5-5", key: "1bsop3" }],
  ["path", { d: "M15 12H3", key: "6jk70r" }],
  ["path", { d: "M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4", key: "u53s6r" }]
];
var LogIn = createLucideIcon("log-in", __iconNode922);

// ../node_modules/lucide-react/dist/esm/icons/log-out.js
var __iconNode923 = [
  ["path", { d: "m16 17 5-5-5-5", key: "1bji2h" }],
  ["path", { d: "M21 12H9", key: "dn1m92" }],
  ["path", { d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", key: "1uf3rs" }]
];
var LogOut = createLucideIcon("log-out", __iconNode923);

// ../node_modules/lucide-react/dist/esm/icons/logs.js
var __iconNode924 = [
  ["path", { d: "M3 5h1", key: "1mv5vm" }],
  ["path", { d: "M3 12h1", key: "lp3yf2" }],
  ["path", { d: "M3 19h1", key: "w6f3n9" }],
  ["path", { d: "M8 5h1", key: "1nxr5w" }],
  ["path", { d: "M8 12h1", key: "1con00" }],
  ["path", { d: "M8 19h1", key: "k7p10e" }],
  ["path", { d: "M13 5h8", key: "a7qcls" }],
  ["path", { d: "M13 12h8", key: "h98zly" }],
  ["path", { d: "M13 19h8", key: "c3s6r1" }]
];
var Logs = createLucideIcon("logs", __iconNode924);

// ../node_modules/lucide-react/dist/esm/icons/lollipop.js
var __iconNode925 = [
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["path", { d: "m21 21-4.3-4.3", key: "1qie3q" }],
  ["path", { d: "M11 11a2 2 0 0 0 4 0 4 4 0 0 0-8 0 6 6 0 0 0 12 0", key: "107gwy" }]
];
var Lollipop = createLucideIcon("lollipop", __iconNode925);

// ../node_modules/lucide-react/dist/esm/icons/luggage.js
var __iconNode926 = [
  [
    "path",
    { d: "M6 20a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2", key: "1m57jg" }
  ],
  ["path", { d: "M8 18V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v14", key: "1l99gc" }],
  ["path", { d: "M10 20h4", key: "ni2waw" }],
  ["circle", { cx: "16", cy: "20", r: "2", key: "1vifvg" }],
  ["circle", { cx: "8", cy: "20", r: "2", key: "ckkr5m" }]
];
var Luggage = createLucideIcon("luggage", __iconNode926);

// ../node_modules/lucide-react/dist/esm/icons/magnet.js
var __iconNode927 = [
  ["path", { d: "m12 15 4 4", key: "lnac28" }],
  [
    "path",
    {
      d: "M2.352 10.648a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l6.029-6.029a1 1 0 1 1 3 3l-6.029 6.029a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l6.365-6.367A1 1 0 0 0 8.716 4.282z",
      key: "nlhkjb"
    }
  ],
  ["path", { d: "m5 8 4 4", key: "j6kj7e" }]
];
var Magnet = createLucideIcon("magnet", __iconNode927);

// ../node_modules/lucide-react/dist/esm/icons/mail-check.js
var __iconNode928 = [
  ["path", { d: "M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8", key: "12jkf8" }],
  ["path", { d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7", key: "1ocrg3" }],
  ["path", { d: "m16 19 2 2 4-4", key: "1b14m6" }]
];
var MailCheck = createLucideIcon("mail-check", __iconNode928);

// ../node_modules/lucide-react/dist/esm/icons/mail-minus.js
var __iconNode929 = [
  ["path", { d: "M22 15V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8", key: "fuxbkv" }],
  ["path", { d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7", key: "1ocrg3" }],
  ["path", { d: "M16 19h6", key: "xwg31i" }]
];
var MailMinus = createLucideIcon("mail-minus", __iconNode929);

// ../node_modules/lucide-react/dist/esm/icons/mail-open.js
var __iconNode930 = [
  [
    "path",
    {
      d: "M21.2 8.4c.5.38.8.97.8 1.6v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V10a2 2 0 0 1 .8-1.6l8-6a2 2 0 0 1 2.4 0l8 6Z",
      key: "1jhwl8"
    }
  ],
  ["path", { d: "m22 10-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 10", key: "1qfld7" }]
];
var MailOpen = createLucideIcon("mail-open", __iconNode930);

// ../node_modules/lucide-react/dist/esm/icons/mail-plus.js
var __iconNode931 = [
  ["path", { d: "M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8", key: "12jkf8" }],
  ["path", { d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7", key: "1ocrg3" }],
  ["path", { d: "M19 16v6", key: "tddt3s" }],
  ["path", { d: "M16 19h6", key: "xwg31i" }]
];
var MailPlus = createLucideIcon("mail-plus", __iconNode931);

// ../node_modules/lucide-react/dist/esm/icons/mail-question-mark.js
var __iconNode932 = [
  ["path", { d: "M22 10.5V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h12.5", key: "e61zoh" }],
  ["path", { d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7", key: "1ocrg3" }],
  [
    "path",
    {
      d: "M18 15.28c.2-.4.5-.8.9-1a2.1 2.1 0 0 1 2.6.4c.3.4.5.8.5 1.3 0 1.3-2 2-2 2",
      key: "7z9rxb"
    }
  ],
  ["path", { d: "M20 22v.01", key: "12bgn6" }]
];
var MailQuestionMark = createLucideIcon("mail-question-mark", __iconNode932);

// ../node_modules/lucide-react/dist/esm/icons/mail-search.js
var __iconNode933 = [
  ["path", { d: "M22 12.5V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h7.5", key: "w80f2v" }],
  ["path", { d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7", key: "1ocrg3" }],
  ["path", { d: "M18 21a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z", key: "8lzu5m" }],
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }],
  ["path", { d: "m22 22-1.5-1.5", key: "1x83k4" }]
];
var MailSearch = createLucideIcon("mail-search", __iconNode933);

// ../node_modules/lucide-react/dist/esm/icons/mail-warning.js
var __iconNode934 = [
  ["path", { d: "M22 10.5V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h12.5", key: "e61zoh" }],
  ["path", { d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7", key: "1ocrg3" }],
  ["path", { d: "M20 14v4", key: "1hm744" }],
  ["path", { d: "M20 22v.01", key: "12bgn6" }]
];
var MailWarning = createLucideIcon("mail-warning", __iconNode934);

// ../node_modules/lucide-react/dist/esm/icons/mail-x.js
var __iconNode935 = [
  ["path", { d: "M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h9", key: "1j9vog" }],
  ["path", { d: "m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7", key: "1ocrg3" }],
  ["path", { d: "m17 17 4 4", key: "1b3523" }],
  ["path", { d: "m21 17-4 4", key: "uinynz" }]
];
var MailX = createLucideIcon("mail-x", __iconNode935);

// ../node_modules/lucide-react/dist/esm/icons/mail.js
var __iconNode936 = [
  ["path", { d: "m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7", key: "132q7q" }],
  ["rect", { x: "2", y: "4", width: "20", height: "16", rx: "2", key: "izxlao" }]
];
var Mail = createLucideIcon("mail", __iconNode936);

// ../node_modules/lucide-react/dist/esm/icons/mailbox.js
var __iconNode937 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9.5C2 7 4 5 6.5 5H18c2.2 0 4 1.8 4 4v8Z",
      key: "1lbycx"
    }
  ],
  ["polyline", { points: "15,9 18,9 18,11", key: "1pm9c0" }],
  ["path", { d: "M6.5 5C9 5 11 7 11 9.5V17a2 2 0 0 1-2 2", key: "15i455" }],
  ["line", { x1: "6", x2: "7", y1: "10", y2: "10", key: "1e2scm" }]
];
var Mailbox = createLucideIcon("mailbox", __iconNode937);

// ../node_modules/lucide-react/dist/esm/icons/mails.js
var __iconNode938 = [
  ["path", { d: "M17 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 1-1.732", key: "1vyzll" }],
  ["path", { d: "m22 5.5-6.419 4.179a2 2 0 0 1-2.162 0L7 5.5", key: "k7ramc" }],
  ["rect", { x: "7", y: "3", width: "15", height: "12", rx: "2", key: "17196g" }]
];
var Mails = createLucideIcon("mails", __iconNode938);

// ../node_modules/lucide-react/dist/esm/icons/map-minus.js
var __iconNode939 = [
  [
    "path",
    {
      d: "m11 19-1.106-.552a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0l4.212 2.106a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619V14",
      key: "40pylx"
    }
  ],
  ["path", { d: "M15 5.764V14", key: "1bab71" }],
  ["path", { d: "M21 18h-6", key: "139f0c" }],
  ["path", { d: "M9 3.236v15", key: "1uimfh" }]
];
var MapMinus = createLucideIcon("map-minus", __iconNode939);

// ../node_modules/lucide-react/dist/esm/icons/map-pin-check-inside.js
var __iconNode940 = [
  [
    "path",
    {
      d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
      key: "1r0f0z"
    }
  ],
  ["path", { d: "m9 10 2 2 4-4", key: "1gnqz4" }]
];
var MapPinCheckInside = createLucideIcon("map-pin-check-inside", __iconNode940);

// ../node_modules/lucide-react/dist/esm/icons/map-pin-check.js
var __iconNode941 = [
  [
    "path",
    {
      d: "M19.43 12.935c.357-.967.57-1.955.57-2.935a8 8 0 0 0-16 0c0 4.993 5.539 10.193 7.399 11.799a1 1 0 0 0 1.202 0 32.197 32.197 0 0 0 .813-.728",
      key: "1dq61d"
    }
  ],
  ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }],
  ["path", { d: "m16 18 2 2 4-4", key: "1mkfmb" }]
];
var MapPinCheck = createLucideIcon("map-pin-check", __iconNode941);

// ../node_modules/lucide-react/dist/esm/icons/map-pin-house.js
var __iconNode942 = [
  [
    "path",
    {
      d: "M15 22a1 1 0 0 1-1-1v-4a1 1 0 0 1 .445-.832l3-2a1 1 0 0 1 1.11 0l3 2A1 1 0 0 1 22 17v4a1 1 0 0 1-1 1z",
      key: "1p1rcz"
    }
  ],
  [
    "path",
    {
      d: "M18 10a8 8 0 0 0-16 0c0 4.993 5.539 10.193 7.399 11.799a1 1 0 0 0 .601.2",
      key: "mcbcs9"
    }
  ],
  ["path", { d: "M18 22v-3", key: "1t1ugv" }],
  ["circle", { cx: "10", cy: "10", r: "3", key: "1ns7v1" }]
];
var MapPinHouse = createLucideIcon("map-pin-house", __iconNode942);

// ../node_modules/lucide-react/dist/esm/icons/map-pin-minus-inside.js
var __iconNode943 = [
  [
    "path",
    {
      d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
      key: "1r0f0z"
    }
  ],
  ["path", { d: "M9 10h6", key: "9gxzsh" }]
];
var MapPinMinusInside = createLucideIcon("map-pin-minus-inside", __iconNode943);

// ../node_modules/lucide-react/dist/esm/icons/map-pin-minus.js
var __iconNode944 = [
  [
    "path",
    {
      d: "M18.977 14C19.6 12.701 20 11.343 20 10a8 8 0 0 0-16 0c0 4.993 5.539 10.193 7.399 11.799a1 1 0 0 0 1.202 0 32 32 0 0 0 .824-.738",
      key: "11uxia"
    }
  ],
  ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }],
  ["path", { d: "M16 18h6", key: "987eiv" }]
];
var MapPinMinus = createLucideIcon("map-pin-minus", __iconNode944);

// ../node_modules/lucide-react/dist/esm/icons/map-pin-off.js
var __iconNode945 = [
  ["path", { d: "M12.75 7.09a3 3 0 0 1 2.16 2.16", key: "1d4wjd" }],
  [
    "path",
    {
      d: "M17.072 17.072c-1.634 2.17-3.527 3.912-4.471 4.727a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 1.432-4.568",
      key: "12yil7"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M8.475 2.818A8 8 0 0 1 20 10c0 1.183-.31 2.377-.81 3.533", key: "lhrkcz" }],
  ["path", { d: "M9.13 9.13a3 3 0 0 0 3.74 3.74", key: "13wojd" }]
];
var MapPinOff = createLucideIcon("map-pin-off", __iconNode945);

// ../node_modules/lucide-react/dist/esm/icons/map-pin-pen.js
var __iconNode946 = [
  ["path", { d: "M17.97 9.304A8 8 0 0 0 2 10c0 4.69 4.887 9.562 7.022 11.468", key: "1fahp3" }],
  [
    "path",
    {
      d: "M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
      key: "1817ys"
    }
  ],
  ["circle", { cx: "10", cy: "10", r: "3", key: "1ns7v1" }]
];
var MapPinPen = createLucideIcon("map-pin-pen", __iconNode946);

// ../node_modules/lucide-react/dist/esm/icons/map-pin-plus-inside.js
var __iconNode947 = [
  [
    "path",
    {
      d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
      key: "1r0f0z"
    }
  ],
  ["path", { d: "M12 7v6", key: "lw1j43" }],
  ["path", { d: "M9 10h6", key: "9gxzsh" }]
];
var MapPinPlusInside = createLucideIcon("map-pin-plus-inside", __iconNode947);

// ../node_modules/lucide-react/dist/esm/icons/map-pin-plus.js
var __iconNode948 = [
  [
    "path",
    {
      d: "M19.914 11.105A7.298 7.298 0 0 0 20 10a8 8 0 0 0-16 0c0 4.993 5.539 10.193 7.399 11.799a1 1 0 0 0 1.202 0 32 32 0 0 0 .824-.738",
      key: "fcdtly"
    }
  ],
  ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }],
  ["path", { d: "M16 18h6", key: "987eiv" }],
  ["path", { d: "M19 15v6", key: "10aioa" }]
];
var MapPinPlus = createLucideIcon("map-pin-plus", __iconNode948);

// ../node_modules/lucide-react/dist/esm/icons/map-pin-x-inside.js
var __iconNode949 = [
  [
    "path",
    {
      d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
      key: "1r0f0z"
    }
  ],
  ["path", { d: "m14.5 7.5-5 5", key: "3lb6iw" }],
  ["path", { d: "m9.5 7.5 5 5", key: "ko136h" }]
];
var MapPinXInside = createLucideIcon("map-pin-x-inside", __iconNode949);

// ../node_modules/lucide-react/dist/esm/icons/map-pin-x.js
var __iconNode950 = [
  [
    "path",
    {
      d: "M19.752 11.901A7.78 7.78 0 0 0 20 10a8 8 0 0 0-16 0c0 4.993 5.539 10.193 7.399 11.799a1 1 0 0 0 1.202 0 19 19 0 0 0 .09-.077",
      key: "y0ewhp"
    }
  ],
  ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }],
  ["path", { d: "m21.5 15.5-5 5", key: "11iqnx" }],
  ["path", { d: "m21.5 20.5-5-5", key: "1bylgx" }]
];
var MapPinX = createLucideIcon("map-pin-x", __iconNode950);

// ../node_modules/lucide-react/dist/esm/icons/map-pin.js
var __iconNode951 = [
  [
    "path",
    {
      d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
      key: "1r0f0z"
    }
  ],
  ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }]
];
var MapPin = createLucideIcon("map-pin", __iconNode951);

// ../node_modules/lucide-react/dist/esm/icons/map-pinned.js
var __iconNode952 = [
  [
    "path",
    {
      d: "M18 8c0 3.613-3.869 7.429-5.393 8.795a1 1 0 0 1-1.214 0C9.87 15.429 6 11.613 6 8a6 6 0 0 1 12 0",
      key: "11u0oz"
    }
  ],
  ["circle", { cx: "12", cy: "8", r: "2", key: "1822b1" }],
  [
    "path",
    {
      d: "M8.714 14h-3.71a1 1 0 0 0-.948.683l-2.004 6A1 1 0 0 0 3 22h18a1 1 0 0 0 .948-1.316l-2-6a1 1 0 0 0-.949-.684h-3.712",
      key: "q8zwxj"
    }
  ]
];
var MapPinned = createLucideIcon("map-pinned", __iconNode952);

// ../node_modules/lucide-react/dist/esm/icons/map-plus.js
var __iconNode953 = [
  [
    "path",
    {
      d: "m11 19-1.106-.552a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0l4.212 2.106a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619V12",
      key: "svfegj"
    }
  ],
  ["path", { d: "M15 5.764V12", key: "1ocw4k" }],
  ["path", { d: "M18 15v6", key: "9wciyi" }],
  ["path", { d: "M21 18h-6", key: "139f0c" }],
  ["path", { d: "M9 3.236v15", key: "1uimfh" }]
];
var MapPlus = createLucideIcon("map-plus", __iconNode953);

// ../node_modules/lucide-react/dist/esm/icons/map.js
var __iconNode954 = [
  [
    "path",
    {
      d: "M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z",
      key: "169xi5"
    }
  ],
  ["path", { d: "M15 5.764v15", key: "1pn4in" }],
  ["path", { d: "M9 3.236v15", key: "1uimfh" }]
];
var Map = createLucideIcon("map", __iconNode954);

// ../node_modules/lucide-react/dist/esm/icons/mars-stroke.js
var __iconNode955 = [
  ["path", { d: "m14 6 4 4", key: "1q72g9" }],
  ["path", { d: "M17 3h4v4", key: "19p9u1" }],
  ["path", { d: "m21 3-7.75 7.75", key: "1cjbfd" }],
  ["circle", { cx: "9", cy: "15", r: "6", key: "bx5svt" }]
];
var MarsStroke = createLucideIcon("mars-stroke", __iconNode955);

// ../node_modules/lucide-react/dist/esm/icons/mars.js
var __iconNode956 = [
  ["path", { d: "M16 3h5v5", key: "1806ms" }],
  ["path", { d: "m21 3-6.75 6.75", key: "pv0uzu" }],
  ["circle", { cx: "10", cy: "14", r: "6", key: "1qwbdc" }]
];
var Mars = createLucideIcon("mars", __iconNode956);

// ../node_modules/lucide-react/dist/esm/icons/martini.js
var __iconNode957 = [
  ["path", { d: "M8 22h8", key: "rmew8v" }],
  ["path", { d: "M12 11v11", key: "ur9y6a" }],
  ["path", { d: "m19 3-7 8-7-8Z", key: "1sgpiw" }]
];
var Martini = createLucideIcon("martini", __iconNode957);

// ../node_modules/lucide-react/dist/esm/icons/maximize-2.js
var __iconNode958 = [
  ["path", { d: "M15 3h6v6", key: "1q9fwt" }],
  ["path", { d: "m21 3-7 7", key: "1l2asr" }],
  ["path", { d: "m3 21 7-7", key: "tjx5ai" }],
  ["path", { d: "M9 21H3v-6", key: "wtvkvv" }]
];
var Maximize2 = createLucideIcon("maximize-2", __iconNode958);

// ../node_modules/lucide-react/dist/esm/icons/maximize.js
var __iconNode959 = [
  ["path", { d: "M8 3H5a2 2 0 0 0-2 2v3", key: "1dcmit" }],
  ["path", { d: "M21 8V5a2 2 0 0 0-2-2h-3", key: "1e4gt3" }],
  ["path", { d: "M3 16v3a2 2 0 0 0 2 2h3", key: "wsl5sc" }],
  ["path", { d: "M16 21h3a2 2 0 0 0 2-2v-3", key: "18trek" }]
];
var Maximize = createLucideIcon("maximize", __iconNode959);

// ../node_modules/lucide-react/dist/esm/icons/medal.js
var __iconNode960 = [
  [
    "path",
    {
      d: "M7.21 15 2.66 7.14a2 2 0 0 1 .13-2.2L4.4 2.8A2 2 0 0 1 6 2h12a2 2 0 0 1 1.6.8l1.6 2.14a2 2 0 0 1 .14 2.2L16.79 15",
      key: "143lza"
    }
  ],
  ["path", { d: "M11 12 5.12 2.2", key: "qhuxz6" }],
  ["path", { d: "m13 12 5.88-9.8", key: "hbye0f" }],
  ["path", { d: "M8 7h8", key: "i86dvs" }],
  ["circle", { cx: "12", cy: "17", r: "5", key: "qbz8iq" }],
  ["path", { d: "M12 18v-2h-.5", key: "fawc4q" }]
];
var Medal = createLucideIcon("medal", __iconNode960);

// ../node_modules/lucide-react/dist/esm/icons/megaphone-off.js
var __iconNode961 = [
  ["path", { d: "M11.636 6A13 13 0 0 0 19.4 3.2 1 1 0 0 1 21 4v11.344", key: "bycexp" }],
  [
    "path",
    { d: "M14.378 14.357A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h1", key: "1t17s6" }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M6 14a12 12 0 0 0 2.4 7.2 2 2 0 0 0 3.2-2.4A8 8 0 0 1 10 14", key: "1853fq" }],
  ["path", { d: "M8 8v6", key: "aieo6v" }]
];
var MegaphoneOff = createLucideIcon("megaphone-off", __iconNode961);

// ../node_modules/lucide-react/dist/esm/icons/megaphone.js
var __iconNode962 = [
  [
    "path",
    {
      d: "M11 6a13 13 0 0 0 8.4-2.8A1 1 0 0 1 21 4v12a1 1 0 0 1-1.6.8A13 13 0 0 0 11 14H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z",
      key: "q8bfy3"
    }
  ],
  ["path", { d: "M6 14a12 12 0 0 0 2.4 7.2 2 2 0 0 0 3.2-2.4A8 8 0 0 1 10 14", key: "1853fq" }],
  ["path", { d: "M8 6v8", key: "15ugcq" }]
];
var Megaphone = createLucideIcon("megaphone", __iconNode962);

// ../node_modules/lucide-react/dist/esm/icons/meh.js
var __iconNode963 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "8", x2: "16", y1: "15", y2: "15", key: "1xb1d9" }],
  ["line", { x1: "9", x2: "9.01", y1: "9", y2: "9", key: "yxxnd0" }],
  ["line", { x1: "15", x2: "15.01", y1: "9", y2: "9", key: "1p4y9e" }]
];
var Meh = createLucideIcon("meh", __iconNode963);

// ../node_modules/lucide-react/dist/esm/icons/memory-stick.js
var __iconNode964 = [
  ["path", { d: "M12 12v-2", key: "fwoke6" }],
  ["path", { d: "M12 18v-2", key: "qj6yno" }],
  ["path", { d: "M16 12v-2", key: "heuere" }],
  ["path", { d: "M16 18v-2", key: "s1ct0w" }],
  ["path", { d: "M2 11h1.5", key: "15p63e" }],
  ["path", { d: "M20 18v-2", key: "12ehxp" }],
  ["path", { d: "M20.5 11H22", key: "khsy7a" }],
  ["path", { d: "M4 18v-2", key: "1c3oqr" }],
  ["path", { d: "M8 12v-2", key: "1mwtfd" }],
  ["path", { d: "M8 18v-2", key: "qcmpov" }],
  ["rect", { x: "2", y: "6", width: "20", height: "10", rx: "2", key: "1qcswk" }]
];
var MemoryStick = createLucideIcon("memory-stick", __iconNode964);

// ../node_modules/lucide-react/dist/esm/icons/menu.js
var __iconNode965 = [
  ["path", { d: "M4 5h16", key: "1tepv9" }],
  ["path", { d: "M4 12h16", key: "1lakjw" }],
  ["path", { d: "M4 19h16", key: "1djgab" }]
];
var Menu = createLucideIcon("menu", __iconNode965);

// ../node_modules/lucide-react/dist/esm/icons/merge.js
var __iconNode966 = [
  ["path", { d: "m8 6 4-4 4 4", key: "ybng9g" }],
  ["path", { d: "M12 2v10.3a4 4 0 0 1-1.172 2.872L4 22", key: "1hyw0i" }],
  ["path", { d: "m20 22-5-5", key: "1m27yz" }]
];
var Merge = createLucideIcon("merge", __iconNode966);

// ../node_modules/lucide-react/dist/esm/icons/message-circle-check.js
var __iconNode967 = [
  [
    "path",
    {
      d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
      key: "1sd12s"
    }
  ],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
];
var MessageCircleCheck = createLucideIcon("message-circle-check", __iconNode967);

// ../node_modules/lucide-react/dist/esm/icons/message-circle-code.js
var __iconNode968 = [
  ["path", { d: "m10 9-3 3 3 3", key: "1oro0q" }],
  ["path", { d: "m14 15 3-3-3-3", key: "bz13h7" }],
  [
    "path",
    {
      d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
      key: "1sd12s"
    }
  ]
];
var MessageCircleCode = createLucideIcon("message-circle-code", __iconNode968);

// ../node_modules/lucide-react/dist/esm/icons/message-circle-dashed.js
var __iconNode969 = [
  ["path", { d: "M10.1 2.182a10 10 0 0 1 3.8 0", key: "5ilxe3" }],
  ["path", { d: "M13.9 21.818a10 10 0 0 1-3.8 0", key: "11zvb9" }],
  ["path", { d: "M17.609 3.72a10 10 0 0 1 2.69 2.7", key: "jiglxs" }],
  ["path", { d: "M2.182 13.9a10 10 0 0 1 0-3.8", key: "c0bmvh" }],
  ["path", { d: "M20.28 17.61a10 10 0 0 1-2.7 2.69", key: "elg7ff" }],
  ["path", { d: "M21.818 10.1a10 10 0 0 1 0 3.8", key: "qkgqxc" }],
  ["path", { d: "M3.721 6.391a10 10 0 0 1 2.7-2.69", key: "1mcia2" }],
  ["path", { d: "m6.163 21.117-2.906.85a1 1 0 0 1-1.236-1.169l.965-2.98", key: "1qsu07" }]
];
var MessageCircleDashed = createLucideIcon("message-circle-dashed", __iconNode969);

// ../node_modules/lucide-react/dist/esm/icons/message-circle-heart.js
var __iconNode970 = [
  [
    "path",
    {
      d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
      key: "1sd12s"
    }
  ],
  [
    "path",
    {
      d: "M7.828 13.07A3 3 0 0 1 12 8.764a3 3 0 0 1 5.004 2.224 3 3 0 0 1-.832 2.083l-3.447 3.62a1 1 0 0 1-1.45-.001z",
      key: "hoo97p"
    }
  ]
];
var MessageCircleHeart = createLucideIcon("message-circle-heart", __iconNode970);

// ../node_modules/lucide-react/dist/esm/icons/message-circle-more.js
var __iconNode971 = [
  [
    "path",
    {
      d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
      key: "1sd12s"
    }
  ],
  ["path", { d: "M8 12h.01", key: "czm47f" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M16 12h.01", key: "1l6xoz" }]
];
var MessageCircleMore = createLucideIcon("message-circle-more", __iconNode971);

// ../node_modules/lucide-react/dist/esm/icons/message-circle-off.js
var __iconNode972 = [
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    {
      d: "M4.93 4.929a10 10 0 0 0-1.938 11.412 2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 0 0 11.302-1.989",
      key: "7il5tn"
    }
  ],
  ["path", { d: "M8.35 2.69A10 10 0 0 1 21.3 15.65", key: "1pfsoa" }]
];
var MessageCircleOff = createLucideIcon("message-circle-off", __iconNode972);

// ../node_modules/lucide-react/dist/esm/icons/message-circle-plus.js
var __iconNode973 = [
  [
    "path",
    {
      d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
      key: "1sd12s"
    }
  ],
  ["path", { d: "M8 12h8", key: "1wcyev" }],
  ["path", { d: "M12 8v8", key: "napkw2" }]
];
var MessageCirclePlus = createLucideIcon("message-circle-plus", __iconNode973);

// ../node_modules/lucide-react/dist/esm/icons/message-circle-question-mark.js
var __iconNode974 = [
  [
    "path",
    {
      d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
      key: "1sd12s"
    }
  ],
  ["path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3", key: "1u773s" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
];
var MessageCircleQuestionMark = createLucideIcon("message-circle-question-mark", __iconNode974);

// ../node_modules/lucide-react/dist/esm/icons/message-circle-reply.js
var __iconNode975 = [
  [
    "path",
    {
      d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
      key: "1sd12s"
    }
  ],
  ["path", { d: "m10 15-3-3 3-3", key: "1pgupc" }],
  ["path", { d: "M7 12h8a2 2 0 0 1 2 2v1", key: "89sh1g" }]
];
var MessageCircleReply = createLucideIcon("message-circle-reply", __iconNode975);

// ../node_modules/lucide-react/dist/esm/icons/message-circle-warning.js
var __iconNode976 = [
  [
    "path",
    {
      d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
      key: "1sd12s"
    }
  ],
  ["path", { d: "M12 8v4", key: "1got3b" }],
  ["path", { d: "M12 16h.01", key: "1drbdi" }]
];
var MessageCircleWarning = createLucideIcon("message-circle-warning", __iconNode976);

// ../node_modules/lucide-react/dist/esm/icons/message-circle-x.js
var __iconNode977 = [
  [
    "path",
    {
      d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
      key: "1sd12s"
    }
  ],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "m9 9 6 6", key: "z0biqf" }]
];
var MessageCircleX = createLucideIcon("message-circle-x", __iconNode977);

// ../node_modules/lucide-react/dist/esm/icons/message-circle.js
var __iconNode978 = [
  [
    "path",
    {
      d: "M2.992 16.342a2 2 0 0 1 .094 1.167l-1.065 3.29a1 1 0 0 0 1.236 1.168l3.413-.998a2 2 0 0 1 1.099.092 10 10 0 1 0-4.777-4.719",
      key: "1sd12s"
    }
  ]
];
var MessageCircle = createLucideIcon("message-circle", __iconNode978);

// ../node_modules/lucide-react/dist/esm/icons/message-square-check.js
var __iconNode979 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.7.7 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "m0kn7k"
    }
  ],
  ["path", { d: "m9 11 2 2 4-4", key: "kz4plv" }]
];
var MessageSquareCheck = createLucideIcon("message-square-check", __iconNode979);

// ../node_modules/lucide-react/dist/esm/icons/message-square-code.js
var __iconNode980 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ],
  ["path", { d: "m10 8-3 3 3 3", key: "fp6dz7" }],
  ["path", { d: "m14 14 3-3-3-3", key: "1yrceu" }]
];
var MessageSquareCode = createLucideIcon("message-square-code", __iconNode980);

// ../node_modules/lucide-react/dist/esm/icons/message-square-dashed.js
var __iconNode981 = [
  ["path", { d: "M14 3h2", key: "1d12a5" }],
  ["path", { d: "M16 19h-2", key: "1agirb" }],
  ["path", { d: "M2 12v-2", key: "1ey295" }],
  ["path", { d: "M2 16v5.286a.71.71 0 0 0 1.212.502l1.149-1.149", key: "120k8q" }],
  ["path", { d: "M20 19a2 2 0 0 0 2-2v-1", key: "ior8tn" }],
  ["path", { d: "M22 10v2", key: "rmlecy" }],
  ["path", { d: "M22 6V5a2 2 0 0 0-2-2", key: "sp3k6r" }],
  ["path", { d: "M4 3a2 2 0 0 0-2 2v1", key: "11zt7s" }],
  ["path", { d: "M8 19h2", key: "jnunrx" }],
  ["path", { d: "M8 3h2", key: "ysbsee" }]
];
var MessageSquareDashed = createLucideIcon("message-square-dashed", __iconNode981);

// ../node_modules/lucide-react/dist/esm/icons/message-square-dot.js
var __iconNode982 = [
  [
    "path",
    {
      d: "M12.7 3H4a2 2 0 0 0-2 2v16.286a.71.71 0 0 0 1.212.502l2.202-2.202A2 2 0 0 1 6.828 19H20a2 2 0 0 0 2-2v-4.7",
      key: "wjb7ig"
    }
  ],
  ["circle", { cx: "19", cy: "6", r: "3", key: "108a5v" }]
];
var MessageSquareDot = createLucideIcon("message-square-dot", __iconNode982);

// ../node_modules/lucide-react/dist/esm/icons/message-square-diff.js
var __iconNode983 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ],
  ["path", { d: "M10 15h4", key: "192ueg" }],
  ["path", { d: "M10 9h4", key: "u4k05v" }],
  ["path", { d: "M12 7v4", key: "xawao1" }]
];
var MessageSquareDiff = createLucideIcon("message-square-diff", __iconNode983);

// ../node_modules/lucide-react/dist/esm/icons/message-square-heart.js
var __iconNode984 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ],
  [
    "path",
    {
      d: "M7.5 9.5c0 .687.265 1.383.697 1.844l3.009 3.264a1.14 1.14 0 0 0 .407.314 1 1 0 0 0 .783-.004 1.14 1.14 0 0 0 .398-.31l3.008-3.264A2.77 2.77 0 0 0 16.5 9.5 2.5 2.5 0 0 0 12 8a2.5 2.5 0 0 0-4.5 1.5",
      key: "1faxuh"
    }
  ]
];
var MessageSquareHeart = createLucideIcon("message-square-heart", __iconNode984);

// ../node_modules/lucide-react/dist/esm/icons/message-square-lock.js
var __iconNode985 = [
  [
    "path",
    {
      d: "M22 8.5V5a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v16.286a.71.71 0 0 0 1.212.502l2.202-2.202A2 2 0 0 1 6.828 19H10",
      key: "fu6chl"
    }
  ],
  ["path", { d: "M20 15v-2a2 2 0 0 0-4 0v2", key: "vl8a78" }],
  ["rect", { x: "14", y: "15", width: "8", height: "5", rx: "1", key: "37aafw" }]
];
var MessageSquareLock = createLucideIcon("message-square-lock", __iconNode985);

// ../node_modules/lucide-react/dist/esm/icons/message-square-more.js
var __iconNode986 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ],
  ["path", { d: "M12 11h.01", key: "z322tv" }],
  ["path", { d: "M16 11h.01", key: "xkw8gn" }],
  ["path", { d: "M8 11h.01", key: "1dfujw" }]
];
var MessageSquareMore = createLucideIcon("message-square-more", __iconNode986);

// ../node_modules/lucide-react/dist/esm/icons/message-square-off.js
var __iconNode987 = [
  [
    "path",
    {
      d: "M19 19H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.7.7 0 0 1 2 21.286V5a2 2 0 0 1 1.184-1.826",
      key: "1wyg69"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M8.656 3H20a2 2 0 0 1 2 2v11.344", key: "mhl4k6" }]
];
var MessageSquareOff = createLucideIcon("message-square-off", __iconNode987);

// ../node_modules/lucide-react/dist/esm/icons/message-square-plus.js
var __iconNode988 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ],
  ["path", { d: "M12 8v6", key: "1ib9pf" }],
  ["path", { d: "M9 11h6", key: "1fldmi" }]
];
var MessageSquarePlus = createLucideIcon("message-square-plus", __iconNode988);

// ../node_modules/lucide-react/dist/esm/icons/message-square-quote.js
var __iconNode989 = [
  ["path", { d: "M14 14a2 2 0 0 0 2-2V8h-2", key: "1r06pg" }],
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ],
  ["path", { d: "M8 14a2 2 0 0 0 2-2V8H8", key: "1jzu5j" }]
];
var MessageSquareQuote = createLucideIcon("message-square-quote", __iconNode989);

// ../node_modules/lucide-react/dist/esm/icons/message-square-share.js
var __iconNode990 = [
  [
    "path",
    {
      d: "M12 3H4a2 2 0 0 0-2 2v16.286a.71.71 0 0 0 1.212.502l2.202-2.202A2 2 0 0 1 6.828 19H20a2 2 0 0 0 2-2v-4",
      key: "11da1y"
    }
  ],
  ["path", { d: "M16 3h6v6", key: "1bx56c" }],
  ["path", { d: "m16 9 6-6", key: "m4dnic" }]
];
var MessageSquareShare = createLucideIcon("message-square-share", __iconNode990);

// ../node_modules/lucide-react/dist/esm/icons/message-square-reply.js
var __iconNode991 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ],
  ["path", { d: "m10 8-3 3 3 3", key: "fp6dz7" }],
  ["path", { d: "M17 14v-1a2 2 0 0 0-2-2H7", key: "1tkjnz" }]
];
var MessageSquareReply = createLucideIcon("message-square-reply", __iconNode991);

// ../node_modules/lucide-react/dist/esm/icons/message-square-text.js
var __iconNode992 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ],
  ["path", { d: "M7 11h10", key: "1twpyw" }],
  ["path", { d: "M7 15h6", key: "d9of3u" }],
  ["path", { d: "M7 7h8", key: "af5zfr" }]
];
var MessageSquareText = createLucideIcon("message-square-text", __iconNode992);

// ../node_modules/lucide-react/dist/esm/icons/message-square-warning.js
var __iconNode993 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ],
  ["path", { d: "M12 15h.01", key: "q59x07" }],
  ["path", { d: "M12 7v4", key: "xawao1" }]
];
var MessageSquareWarning = createLucideIcon("message-square-warning", __iconNode993);

// ../node_modules/lucide-react/dist/esm/icons/message-square-x.js
var __iconNode994 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ],
  ["path", { d: "m14.5 8.5-5 5", key: "19tnj2" }],
  ["path", { d: "m9.5 8.5 5 5", key: "1oa8ql" }]
];
var MessageSquareX = createLucideIcon("message-square-x", __iconNode994);

// ../node_modules/lucide-react/dist/esm/icons/messages-square.js
var __iconNode995 = [
  [
    "path",
    {
      d: "M16 10a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 14.286V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z",
      key: "1n2ejm"
    }
  ],
  [
    "path",
    {
      d: "M20 9a2 2 0 0 1 2 2v10.286a.71.71 0 0 1-1.212.502l-2.202-2.202A2 2 0 0 0 17.172 19H10a2 2 0 0 1-2-2v-1",
      key: "1qfcsi"
    }
  ]
];
var MessagesSquare = createLucideIcon("messages-square", __iconNode995);

// ../node_modules/lucide-react/dist/esm/icons/message-square.js
var __iconNode996 = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ]
];
var MessageSquare = createLucideIcon("message-square", __iconNode996);

// ../node_modules/lucide-react/dist/esm/icons/metronome.js
var __iconNode997 = [
  ["path", { d: "M12 11.4V9.1", key: "audfby" }],
  ["path", { d: "m12 17 6.59-6.59", key: "c0sb7j" }],
  [
    "path",
    {
      d: "m15.05 5.7-.218-.691a3 3 0 0 0-5.663 0L4.418 19.695A1 1 0 0 0 5.37 21h13.253a1 1 0 0 0 .951-1.31L18.45 16.2",
      key: "1pkfrk"
    }
  ],
  ["circle", { cx: "20", cy: "9", r: "2", key: "1udoqf" }]
];
var Metronome = createLucideIcon("metronome", __iconNode997);

// ../node_modules/lucide-react/dist/esm/icons/mic-off.js
var __iconNode998 = [
  ["path", { d: "M12 19v3", key: "npa21l" }],
  ["path", { d: "M15 9.34V5a3 3 0 0 0-5.68-1.33", key: "1gzdoj" }],
  ["path", { d: "M16.95 16.95A7 7 0 0 1 5 12v-2", key: "cqa7eg" }],
  ["path", { d: "M18.89 13.23A7 7 0 0 0 19 12v-2", key: "16hl24" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M9 9v3a3 3 0 0 0 5.12 2.12", key: "r2i35w" }]
];
var MicOff = createLucideIcon("mic-off", __iconNode998);

// ../node_modules/lucide-react/dist/esm/icons/mic-vocal.js
var __iconNode999 = [
  [
    "path",
    {
      d: "m11 7.601-5.994 8.19a1 1 0 0 0 .1 1.298l.817.818a1 1 0 0 0 1.314.087L15.09 12",
      key: "80a601"
    }
  ],
  [
    "path",
    {
      d: "M16.5 21.174C15.5 20.5 14.372 20 13 20c-2.058 0-3.928 2.356-6 2-2.072-.356-2.775-3.369-1.5-4.5",
      key: "j0ngtp"
    }
  ],
  ["circle", { cx: "16", cy: "7", r: "5", key: "d08jfb" }]
];
var MicVocal = createLucideIcon("mic-vocal", __iconNode999);

// ../node_modules/lucide-react/dist/esm/icons/mic.js
var __iconNode1000 = [
  ["path", { d: "M12 19v3", key: "npa21l" }],
  ["path", { d: "M19 10v2a7 7 0 0 1-14 0v-2", key: "1vc78b" }],
  ["rect", { x: "9", y: "2", width: "6", height: "13", rx: "3", key: "s6n7sd" }]
];
var Mic = createLucideIcon("mic", __iconNode1000);

// ../node_modules/lucide-react/dist/esm/icons/microchip.js
var __iconNode1001 = [
  ["path", { d: "M10 12h4", key: "a56b0p" }],
  ["path", { d: "M10 17h4", key: "pvmtpo" }],
  ["path", { d: "M10 7h4", key: "1vgcok" }],
  ["path", { d: "M18 12h2", key: "quuxs7" }],
  ["path", { d: "M18 18h2", key: "4scel" }],
  ["path", { d: "M18 6h2", key: "1ptzki" }],
  ["path", { d: "M4 12h2", key: "1ltxp0" }],
  ["path", { d: "M4 18h2", key: "1xrofg" }],
  ["path", { d: "M4 6h2", key: "1cx33n" }],
  ["rect", { x: "6", y: "2", width: "12", height: "20", rx: "2", key: "749fme" }]
];
var Microchip = createLucideIcon("microchip", __iconNode1001);

// ../node_modules/lucide-react/dist/esm/icons/microscope.js
var __iconNode1002 = [
  ["path", { d: "M6 18h8", key: "1borvv" }],
  ["path", { d: "M3 22h18", key: "8prr45" }],
  ["path", { d: "M14 22a7 7 0 1 0 0-14h-1", key: "1jwaiy" }],
  ["path", { d: "M9 14h2", key: "197e7h" }],
  ["path", { d: "M9 12a2 2 0 0 1-2-2V6h6v4a2 2 0 0 1-2 2Z", key: "1bmzmy" }],
  ["path", { d: "M12 6V3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3", key: "1drr47" }]
];
var Microscope = createLucideIcon("microscope", __iconNode1002);

// ../node_modules/lucide-react/dist/esm/icons/microwave.js
var __iconNode1003 = [
  ["rect", { width: "20", height: "15", x: "2", y: "4", rx: "2", key: "2no95f" }],
  ["rect", { width: "8", height: "7", x: "6", y: "8", rx: "1", key: "zh9wx" }],
  ["path", { d: "M18 8v7", key: "o5zi4n" }],
  ["path", { d: "M6 19v2", key: "1loha6" }],
  ["path", { d: "M18 19v2", key: "1dawf0" }]
];
var Microwave = createLucideIcon("microwave", __iconNode1003);

// ../node_modules/lucide-react/dist/esm/icons/milestone.js
var __iconNode1004 = [
  ["path", { d: "M12 13v8", key: "1l5pq0" }],
  ["path", { d: "M12 3v3", key: "1n5kay" }],
  [
    "path",
    {
      d: "M4 6a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h13a2 2 0 0 0 1.152-.365l3.424-2.317a1 1 0 0 0 0-1.635l-3.424-2.318A2 2 0 0 0 17 6z",
      key: "1btarq"
    }
  ]
];
var Milestone = createLucideIcon("milestone", __iconNode1004);

// ../node_modules/lucide-react/dist/esm/icons/milk-off.js
var __iconNode1005 = [
  ["path", { d: "M8 2h8", key: "1ssgc1" }],
  [
    "path",
    {
      d: "M9 2v1.343M15 2v2.789a4 4 0 0 0 .672 2.219l.656.984a4 4 0 0 1 .672 2.22v1.131M7.8 7.8l-.128.192A4 4 0 0 0 7 10.212V20a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-3",
      key: "y0ejgx"
    }
  ],
  ["path", { d: "M7 15a6.47 6.47 0 0 1 5 0 6.472 6.472 0 0 0 3.435.435", key: "iaxqsy" }],
  ["line", { x1: "2", x2: "22", y1: "2", y2: "22", key: "a6p6uj" }]
];
var MilkOff = createLucideIcon("milk-off", __iconNode1005);

// ../node_modules/lucide-react/dist/esm/icons/milk.js
var __iconNode1006 = [
  ["path", { d: "M8 2h8", key: "1ssgc1" }],
  [
    "path",
    {
      d: "M9 2v2.789a4 4 0 0 1-.672 2.219l-.656.984A4 4 0 0 0 7 10.212V20a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-9.789a4 4 0 0 0-.672-2.219l-.656-.984A4 4 0 0 1 15 4.788V2",
      key: "qtp12x"
    }
  ],
  ["path", { d: "M7 15a6.472 6.472 0 0 1 5 0 6.47 6.47 0 0 0 5 0", key: "ygeh44" }]
];
var Milk = createLucideIcon("milk", __iconNode1006);

// ../node_modules/lucide-react/dist/esm/icons/minimize-2.js
var __iconNode1007 = [
  ["path", { d: "m14 10 7-7", key: "oa77jy" }],
  ["path", { d: "M20 10h-6V4", key: "mjg0md" }],
  ["path", { d: "m3 21 7-7", key: "tjx5ai" }],
  ["path", { d: "M4 14h6v6", key: "rmj7iw" }]
];
var Minimize2 = createLucideIcon("minimize-2", __iconNode1007);

// ../node_modules/lucide-react/dist/esm/icons/minimize.js
var __iconNode1008 = [
  ["path", { d: "M8 3v3a2 2 0 0 1-2 2H3", key: "hohbtr" }],
  ["path", { d: "M21 8h-3a2 2 0 0 1-2-2V3", key: "5jw1f3" }],
  ["path", { d: "M3 16h3a2 2 0 0 1 2 2v3", key: "198tvr" }],
  ["path", { d: "M16 21v-3a2 2 0 0 1 2-2h3", key: "ph8mxp" }]
];
var Minimize = createLucideIcon("minimize", __iconNode1008);

// ../node_modules/lucide-react/dist/esm/icons/minus.js
var __iconNode1009 = [["path", { d: "M5 12h14", key: "1ays0h" }]];
var Minus = createLucideIcon("minus", __iconNode1009);

// ../node_modules/lucide-react/dist/esm/icons/mirror-rectangular.js
var __iconNode1010 = [
  ["path", { d: "M11 6 8 9", key: "7zt14w" }],
  ["path", { d: "m16 7-8 8", key: "tkgtvu" }],
  ["rect", { x: "4", y: "2", width: "16", height: "20", rx: "2", key: "1uxh74" }]
];
var MirrorRectangular = createLucideIcon("mirror-rectangular", __iconNode1010);

// ../node_modules/lucide-react/dist/esm/icons/mirror-round.js
var __iconNode1011 = [
  ["path", { d: "M10 6.6 8.6 8", key: "itrr7k" }],
  ["path", { d: "M12 18v4", key: "jadmvz" }],
  ["path", { d: "M15 7.5 9.5 13", key: "1vyrsv" }],
  ["path", { d: "M7 22h10", key: "10w4w3" }],
  ["circle", { cx: "12", cy: "10", r: "8", key: "1gshiw" }]
];
var MirrorRound = createLucideIcon("mirror-round", __iconNode1011);

// ../node_modules/lucide-react/dist/esm/icons/monitor-check.js
var __iconNode1012 = [
  ["path", { d: "m9 10 2 2 4-4", key: "1gnqz4" }],
  ["rect", { width: "20", height: "14", x: "2", y: "3", rx: "2", key: "48i651" }],
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }]
];
var MonitorCheck = createLucideIcon("monitor-check", __iconNode1012);

// ../node_modules/lucide-react/dist/esm/icons/monitor-cloud.js
var __iconNode1013 = [
  ["path", { d: "M11 13a3 3 0 1 1 2.83-4H14a2 2 0 0 1 0 4z", key: "1da4q6" }],
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }],
  ["rect", { x: "2", y: "3", width: "20", height: "14", rx: "2", key: "x3v2xh" }]
];
var MonitorCloud = createLucideIcon("monitor-cloud", __iconNode1013);

// ../node_modules/lucide-react/dist/esm/icons/monitor-cog.js
var __iconNode1014 = [
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "m14.305 7.53.923-.382", key: "1mlnsw" }],
  ["path", { d: "m15.228 4.852-.923-.383", key: "82mpwg" }],
  ["path", { d: "m16.852 3.228-.383-.924", key: "ln4sir" }],
  ["path", { d: "m16.852 8.772-.383.923", key: "1dejw0" }],
  ["path", { d: "m19.148 3.228.383-.924", key: "192kgf" }],
  ["path", { d: "m19.53 9.696-.382-.924", key: "fiavlr" }],
  ["path", { d: "m20.772 4.852.924-.383", key: "1j8mgp" }],
  ["path", { d: "m20.772 7.148.924.383", key: "zix9be" }],
  ["path", { d: "M22 13v2a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h7", key: "1tnzv8" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }],
  ["circle", { cx: "18", cy: "6", r: "3", key: "1h7g24" }]
];
var MonitorCog = createLucideIcon("monitor-cog", __iconNode1014);

// ../node_modules/lucide-react/dist/esm/icons/monitor-dot.js
var __iconNode1015 = [
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  [
    "path",
    { d: "M22 12.307V15a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h8.693", key: "1dx6ho" }
  ],
  ["path", { d: "M8 21h8", key: "1ev6f3" }],
  ["circle", { cx: "19", cy: "6", r: "3", key: "108a5v" }]
];
var MonitorDot = createLucideIcon("monitor-dot", __iconNode1015);

// ../node_modules/lucide-react/dist/esm/icons/monitor-down.js
var __iconNode1016 = [
  ["path", { d: "M12 13V7", key: "h0r20n" }],
  ["path", { d: "m15 10-3 3-3-3", key: "lzhmyn" }],
  ["rect", { width: "20", height: "14", x: "2", y: "3", rx: "2", key: "48i651" }],
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }]
];
var MonitorDown = createLucideIcon("monitor-down", __iconNode1016);

// ../node_modules/lucide-react/dist/esm/icons/monitor-pause.js
var __iconNode1017 = [
  ["path", { d: "M10 13V7", key: "1u13u9" }],
  ["path", { d: "M14 13V7", key: "1vj9om" }],
  ["rect", { width: "20", height: "14", x: "2", y: "3", rx: "2", key: "48i651" }],
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }]
];
var MonitorPause = createLucideIcon("monitor-pause", __iconNode1017);

// ../node_modules/lucide-react/dist/esm/icons/monitor-off.js
var __iconNode1018 = [
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "M17 17H4a2 2 0 0 1-2-2V5a2 2 0 0 1 1.184-1.826", key: "cv7jms" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }],
  ["path", { d: "M8.656 3H20a2 2 0 0 1 2 2v10a2 2 0 0 1-.293 1.042", key: "z8ni2w" }]
];
var MonitorOff = createLucideIcon("monitor-off", __iconNode1018);

// ../node_modules/lucide-react/dist/esm/icons/monitor-play.js
var __iconNode1019 = [
  [
    "path",
    {
      d: "M15.033 9.44a.647.647 0 0 1 0 1.12l-4.065 2.352a.645.645 0 0 1-.968-.56V7.648a.645.645 0 0 1 .967-.56z",
      key: "vbtd3f"
    }
  ],
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }],
  ["rect", { x: "2", y: "3", width: "20", height: "14", rx: "2", key: "x3v2xh" }]
];
var MonitorPlay = createLucideIcon("monitor-play", __iconNode1019);

// ../node_modules/lucide-react/dist/esm/icons/monitor-smartphone.js
var __iconNode1020 = [
  ["path", { d: "M18 8V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h8", key: "10dyio" }],
  ["path", { d: "M10 19v-3.96 3.15", key: "1irgej" }],
  ["path", { d: "M7 19h5", key: "qswx4l" }],
  ["rect", { width: "6", height: "10", x: "16", y: "12", rx: "2", key: "1egngj" }]
];
var MonitorSmartphone = createLucideIcon("monitor-smartphone", __iconNode1020);

// ../node_modules/lucide-react/dist/esm/icons/monitor-stop.js
var __iconNode1021 = [
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }],
  ["rect", { x: "2", y: "3", width: "20", height: "14", rx: "2", key: "x3v2xh" }],
  ["rect", { x: "9", y: "7", width: "6", height: "6", rx: "1", key: "5m2oou" }]
];
var MonitorStop = createLucideIcon("monitor-stop", __iconNode1021);

// ../node_modules/lucide-react/dist/esm/icons/monitor-speaker.js
var __iconNode1022 = [
  ["path", { d: "M5.5 20H8", key: "1k40s5" }],
  ["path", { d: "M17 9h.01", key: "1j24nn" }],
  ["rect", { width: "10", height: "16", x: "12", y: "4", rx: "2", key: "ixliua" }],
  ["path", { d: "M8 6H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h4", key: "1mp6e1" }],
  ["circle", { cx: "17", cy: "15", r: "1", key: "tqvash" }]
];
var MonitorSpeaker = createLucideIcon("monitor-speaker", __iconNode1022);

// ../node_modules/lucide-react/dist/esm/icons/monitor-up.js
var __iconNode1023 = [
  ["path", { d: "m9 10 3-3 3 3", key: "11gsxs" }],
  ["path", { d: "M12 13V7", key: "h0r20n" }],
  ["rect", { width: "20", height: "14", x: "2", y: "3", rx: "2", key: "48i651" }],
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }]
];
var MonitorUp = createLucideIcon("monitor-up", __iconNode1023);

// ../node_modules/lucide-react/dist/esm/icons/monitor-x.js
var __iconNode1024 = [
  ["path", { d: "m14.5 12.5-5-5", key: "1jahn5" }],
  ["path", { d: "m9.5 12.5 5-5", key: "1k2t7b" }],
  ["rect", { width: "20", height: "14", x: "2", y: "3", rx: "2", key: "48i651" }],
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }]
];
var MonitorX = createLucideIcon("monitor-x", __iconNode1024);

// ../node_modules/lucide-react/dist/esm/icons/monitor.js
var __iconNode1025 = [
  ["rect", { width: "20", height: "14", x: "2", y: "3", rx: "2", key: "48i651" }],
  ["line", { x1: "8", x2: "16", y1: "21", y2: "21", key: "1svkeh" }],
  ["line", { x1: "12", x2: "12", y1: "17", y2: "21", key: "vw1qmm" }]
];
var Monitor = createLucideIcon("monitor", __iconNode1025);

// ../node_modules/lucide-react/dist/esm/icons/moon-star.js
var __iconNode1026 = [
  ["path", { d: "M18 5h4", key: "1lhgn2" }],
  ["path", { d: "M20 3v4", key: "1olli1" }],
  [
    "path",
    {
      d: "M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",
      key: "kfwtm"
    }
  ]
];
var MoonStar = createLucideIcon("moon-star", __iconNode1026);

// ../node_modules/lucide-react/dist/esm/icons/moon.js
var __iconNode1027 = [
  [
    "path",
    {
      d: "M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",
      key: "kfwtm"
    }
  ]
];
var Moon = createLucideIcon("moon", __iconNode1027);

// ../node_modules/lucide-react/dist/esm/icons/motorbike.js
var __iconNode1028 = [
  ["path", { d: "m18 14-1-3", key: "bdajw9" }],
  ["path", { d: "m3 9 6 2a2 2 0 0 1 2-2h2a2 2 0 0 1 1.99 1.81", key: "f5fotj" }],
  [
    "path",
    { d: "M8 17h3a1 1 0 0 0 1-1 6 6 0 0 1 6-6 1 1 0 0 0 1-1v-.75A5 5 0 0 0 17 5", key: "3i90e2" }
  ],
  ["circle", { cx: "19", cy: "17", r: "3", key: "1otbdv" }],
  ["circle", { cx: "5", cy: "17", r: "3", key: "1d8p0c" }]
];
var Motorbike = createLucideIcon("motorbike", __iconNode1028);

// ../node_modules/lucide-react/dist/esm/icons/mountain-snow.js
var __iconNode1029 = [
  ["path", { d: "m8 3 4 8 5-5 5 15H2L8 3z", key: "otkl63" }],
  [
    "path",
    { d: "M4.14 15.08c2.62-1.57 5.24-1.43 7.86.42 2.74 1.94 5.49 2 8.23.19", key: "1pvmmp" }
  ]
];
var MountainSnow = createLucideIcon("mountain-snow", __iconNode1029);

// ../node_modules/lucide-react/dist/esm/icons/mountain.js
var __iconNode1030 = [["path", { d: "m8 3 4 8 5-5 5 15H2L8 3z", key: "otkl63" }]];
var Mountain = createLucideIcon("mountain", __iconNode1030);

// ../node_modules/lucide-react/dist/esm/icons/mouse-left.js
var __iconNode1031 = [
  ["path", { d: "M12 7.318V10", key: "17s7lh" }],
  ["path", { d: "M5 10v5a7 7 0 0 0 14 0V9c0-3.527-2.608-6.515-6-7", key: "imk5ea" }],
  ["circle", { cx: "7", cy: "4", r: "2", key: "ra7k3" }]
];
var MouseLeft = createLucideIcon("mouse-left", __iconNode1031);

// ../node_modules/lucide-react/dist/esm/icons/mouse-off.js
var __iconNode1032 = [
  ["path", { d: "M12 6v.343", key: "1gyhex" }],
  ["path", { d: "M18.218 18.218A7 7 0 0 1 5 15V9a7 7 0 0 1 .782-3.218", key: "ukzz01" }],
  ["path", { d: "M19 13.343V9A7 7 0 0 0 8.56 2.902", key: "104jy9" }],
  ["path", { d: "M22 22 2 2", key: "1r8tn9" }]
];
var MouseOff = createLucideIcon("mouse-off", __iconNode1032);

// ../node_modules/lucide-react/dist/esm/icons/mouse-pointer-2-off.js
var __iconNode1033 = [
  [
    "path",
    {
      d: "m15.55 8.45 5.138 2.087a.5.5 0 0 1-.063.947l-6.124 1.58a2 2 0 0 0-1.438 1.435l-1.579 6.126a.5.5 0 0 1-.947.063L8.45 15.551",
      key: "1qoshx"
    }
  ],
  ["path", { d: "M22 2 2 22", key: "y4kqgn" }],
  ["path", { d: "m6.816 11.528-2.779-6.84a.495.495 0 0 1 .651-.651l6.84 2.779", key: "mymuvk" }]
];
var MousePointer2Off = createLucideIcon("mouse-pointer-2-off", __iconNode1033);

// ../node_modules/lucide-react/dist/esm/icons/mouse-pointer-2.js
var __iconNode1034 = [
  [
    "path",
    {
      d: "M4.037 4.688a.495.495 0 0 1 .651-.651l16 6.5a.5.5 0 0 1-.063.947l-6.124 1.58a2 2 0 0 0-1.438 1.435l-1.579 6.126a.5.5 0 0 1-.947.063z",
      key: "edeuup"
    }
  ]
];
var MousePointer2 = createLucideIcon("mouse-pointer-2", __iconNode1034);

// ../node_modules/lucide-react/dist/esm/icons/mouse-pointer-ban.js
var __iconNode1035 = [
  [
    "path",
    {
      d: "M2.034 2.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.944L8.204 7.545a1 1 0 0 0-.66.66l-1.066 3.443a.5.5 0 0 1-.944.033z",
      key: "11pp1i"
    }
  ],
  ["circle", { cx: "16", cy: "16", r: "6", key: "qoo3c4" }],
  ["path", { d: "m11.8 11.8 8.4 8.4", key: "oogvdj" }]
];
var MousePointerBan = createLucideIcon("mouse-pointer-ban", __iconNode1035);

// ../node_modules/lucide-react/dist/esm/icons/mouse-pointer-click.js
var __iconNode1036 = [
  ["path", { d: "M14 4.1 12 6", key: "ita8i4" }],
  ["path", { d: "m5.1 8-2.9-.8", key: "1go3kf" }],
  ["path", { d: "m6 12-1.9 2", key: "mnht97" }],
  ["path", { d: "M7.2 2.2 8 5.1", key: "1cfko1" }],
  [
    "path",
    {
      d: "M9.037 9.69a.498.498 0 0 1 .653-.653l11 4.5a.5.5 0 0 1-.074.949l-4.349 1.041a1 1 0 0 0-.74.739l-1.04 4.35a.5.5 0 0 1-.95.074z",
      key: "s0h3yz"
    }
  ]
];
var MousePointerClick = createLucideIcon("mouse-pointer-click", __iconNode1036);

// ../node_modules/lucide-react/dist/esm/icons/mouse-pointer.js
var __iconNode1037 = [
  ["path", { d: "M12.586 12.586 19 19", key: "ea5xo7" }],
  [
    "path",
    {
      d: "M3.688 3.037a.497.497 0 0 0-.651.651l6.5 15.999a.501.501 0 0 0 .947-.062l1.569-6.083a2 2 0 0 1 1.448-1.479l6.124-1.579a.5.5 0 0 0 .063-.947z",
      key: "277e5u"
    }
  ]
];
var MousePointer = createLucideIcon("mouse-pointer", __iconNode1037);

// ../node_modules/lucide-react/dist/esm/icons/mouse-right.js
var __iconNode1038 = [
  ["path", { d: "M12 7.318V10", key: "17s7lh" }],
  ["path", { d: "M19 10v5a7 7 0 0 1-14 0V9c0-3.527 2.608-6.515 6-7", key: "2es5nn" }],
  ["circle", { cx: "17", cy: "4", r: "2", key: "y5j2s2" }]
];
var MouseRight = createLucideIcon("mouse-right", __iconNode1038);

// ../node_modules/lucide-react/dist/esm/icons/mouse.js
var __iconNode1039 = [
  ["rect", { x: "5", y: "2", width: "14", height: "20", rx: "7", key: "11ol66" }],
  ["path", { d: "M12 6v4", key: "16clxf" }]
];
var Mouse = createLucideIcon("mouse", __iconNode1039);

// ../node_modules/lucide-react/dist/esm/icons/move-3d.js
var __iconNode1040 = [
  ["path", { d: "M5 3v16h16", key: "1mqmf9" }],
  ["path", { d: "m5 19 6-6", key: "jh6hbb" }],
  ["path", { d: "m2 6 3-3 3 3", key: "tkyvxa" }],
  ["path", { d: "m18 16 3 3-3 3", key: "1d4glt" }]
];
var Move3d = createLucideIcon("move-3d", __iconNode1040);

// ../node_modules/lucide-react/dist/esm/icons/move-diagonal-2.js
var __iconNode1041 = [
  ["path", { d: "M19 13v6h-6", key: "1hxl6d" }],
  ["path", { d: "M5 11V5h6", key: "12e2xe" }],
  ["path", { d: "m5 5 14 14", key: "11anup" }]
];
var MoveDiagonal2 = createLucideIcon("move-diagonal-2", __iconNode1041);

// ../node_modules/lucide-react/dist/esm/icons/move-diagonal.js
var __iconNode1042 = [
  ["path", { d: "M11 19H5v-6", key: "8awifj" }],
  ["path", { d: "M13 5h6v6", key: "7voy1q" }],
  ["path", { d: "M19 5 5 19", key: "wwaj1z" }]
];
var MoveDiagonal = createLucideIcon("move-diagonal", __iconNode1042);

// ../node_modules/lucide-react/dist/esm/icons/move-down-left.js
var __iconNode1043 = [
  ["path", { d: "M11 19H5V13", key: "1akmht" }],
  ["path", { d: "M19 5L5 19", key: "72u4yj" }]
];
var MoveDownLeft = createLucideIcon("move-down-left", __iconNode1043);

// ../node_modules/lucide-react/dist/esm/icons/move-down-right.js
var __iconNode1044 = [
  ["path", { d: "M19 13V19H13", key: "10vkzq" }],
  ["path", { d: "M5 5L19 19", key: "5zm2fv" }]
];
var MoveDownRight = createLucideIcon("move-down-right", __iconNode1044);

// ../node_modules/lucide-react/dist/esm/icons/move-down.js
var __iconNode1045 = [
  ["path", { d: "M8 18L12 22L16 18", key: "cskvfv" }],
  ["path", { d: "M12 2V22", key: "r89rzk" }]
];
var MoveDown = createLucideIcon("move-down", __iconNode1045);

// ../node_modules/lucide-react/dist/esm/icons/move-horizontal.js
var __iconNode1046 = [
  ["path", { d: "m18 8 4 4-4 4", key: "1ak13k" }],
  ["path", { d: "M2 12h20", key: "9i4pu4" }],
  ["path", { d: "m6 8-4 4 4 4", key: "15zrgr" }]
];
var MoveHorizontal = createLucideIcon("move-horizontal", __iconNode1046);

// ../node_modules/lucide-react/dist/esm/icons/move-left.js
var __iconNode1047 = [
  ["path", { d: "M6 8L2 12L6 16", key: "kyvwex" }],
  ["path", { d: "M2 12H22", key: "1m8cig" }]
];
var MoveLeft = createLucideIcon("move-left", __iconNode1047);

// ../node_modules/lucide-react/dist/esm/icons/move-right.js
var __iconNode1048 = [
  ["path", { d: "M18 8L22 12L18 16", key: "1r0oui" }],
  ["path", { d: "M2 12H22", key: "1m8cig" }]
];
var MoveRight = createLucideIcon("move-right", __iconNode1048);

// ../node_modules/lucide-react/dist/esm/icons/move-up-left.js
var __iconNode1049 = [
  ["path", { d: "M5 11V5H11", key: "3q78g9" }],
  ["path", { d: "M5 5L19 19", key: "5zm2fv" }]
];
var MoveUpLeft = createLucideIcon("move-up-left", __iconNode1049);

// ../node_modules/lucide-react/dist/esm/icons/move-up-right.js
var __iconNode1050 = [
  ["path", { d: "M13 5H19V11", key: "1n1gyv" }],
  ["path", { d: "M19 5L5 19", key: "72u4yj" }]
];
var MoveUpRight = createLucideIcon("move-up-right", __iconNode1050);

// ../node_modules/lucide-react/dist/esm/icons/move-up.js
var __iconNode1051 = [
  ["path", { d: "M8 6L12 2L16 6", key: "1yvkyx" }],
  ["path", { d: "M12 2V22", key: "r89rzk" }]
];
var MoveUp = createLucideIcon("move-up", __iconNode1051);

// ../node_modules/lucide-react/dist/esm/icons/move-vertical.js
var __iconNode1052 = [
  ["path", { d: "M12 2v20", key: "t6zp3m" }],
  ["path", { d: "m8 18 4 4 4-4", key: "bh5tu3" }],
  ["path", { d: "m8 6 4-4 4 4", key: "ybng9g" }]
];
var MoveVertical = createLucideIcon("move-vertical", __iconNode1052);

// ../node_modules/lucide-react/dist/esm/icons/move.js
var __iconNode1053 = [
  ["path", { d: "M12 2v20", key: "t6zp3m" }],
  ["path", { d: "m15 19-3 3-3-3", key: "11eu04" }],
  ["path", { d: "m19 9 3 3-3 3", key: "1mg7y2" }],
  ["path", { d: "M2 12h20", key: "9i4pu4" }],
  ["path", { d: "m5 9-3 3 3 3", key: "j64kie" }],
  ["path", { d: "m9 5 3-3 3 3", key: "l8vdw6" }]
];
var Move = createLucideIcon("move", __iconNode1053);

// ../node_modules/lucide-react/dist/esm/icons/music-2.js
var __iconNode1054 = [
  ["circle", { cx: "8", cy: "18", r: "4", key: "1fc0mg" }],
  ["path", { d: "M12 18V2l7 4", key: "g04rme" }]
];
var Music2 = createLucideIcon("music-2", __iconNode1054);

// ../node_modules/lucide-react/dist/esm/icons/music-3.js
var __iconNode1055 = [
  ["circle", { cx: "12", cy: "18", r: "4", key: "m3r9ws" }],
  ["path", { d: "M16 18V2", key: "40x2m5" }]
];
var Music3 = createLucideIcon("music-3", __iconNode1055);

// ../node_modules/lucide-react/dist/esm/icons/music-4.js
var __iconNode1056 = [
  ["path", { d: "M9 18V5l12-2v13", key: "1jmyc2" }],
  ["path", { d: "m9 9 12-2", key: "1e64n2" }],
  ["circle", { cx: "6", cy: "18", r: "3", key: "fqmcym" }],
  ["circle", { cx: "18", cy: "16", r: "3", key: "1hluhg" }]
];
var Music4 = createLucideIcon("music-4", __iconNode1056);

// ../node_modules/lucide-react/dist/esm/icons/music.js
var __iconNode1057 = [
  ["path", { d: "M9 18V5l12-2v13", key: "1jmyc2" }],
  ["circle", { cx: "6", cy: "18", r: "3", key: "fqmcym" }],
  ["circle", { cx: "18", cy: "16", r: "3", key: "1hluhg" }]
];
var Music = createLucideIcon("music", __iconNode1057);

// ../node_modules/lucide-react/dist/esm/icons/navigation-2-off.js
var __iconNode1058 = [
  ["path", { d: "M9.31 9.31 5 21l7-4 7 4-1.17-3.17", key: "qoq2o2" }],
  ["path", { d: "M14.53 8.88 12 2l-1.17 3.17", key: "k3sjzy" }],
  ["line", { x1: "2", x2: "22", y1: "2", y2: "22", key: "a6p6uj" }]
];
var Navigation2Off = createLucideIcon("navigation-2-off", __iconNode1058);

// ../node_modules/lucide-react/dist/esm/icons/navigation-2.js
var __iconNode1059 = [
  ["polygon", { points: "12 2 19 21 12 17 5 21 12 2", key: "x8c0qg" }]
];
var Navigation2 = createLucideIcon("navigation-2", __iconNode1059);

// ../node_modules/lucide-react/dist/esm/icons/navigation-off.js
var __iconNode1060 = [
  ["path", { d: "M8.43 8.43 3 11l8 2 2 8 2.57-5.43", key: "1vdtb7" }],
  ["path", { d: "M17.39 11.73 22 2l-9.73 4.61", key: "tya3r6" }],
  ["line", { x1: "2", x2: "22", y1: "2", y2: "22", key: "a6p6uj" }]
];
var NavigationOff = createLucideIcon("navigation-off", __iconNode1060);

// ../node_modules/lucide-react/dist/esm/icons/navigation.js
var __iconNode1061 = [
  ["polygon", { points: "3 11 22 2 13 21 11 13 3 11", key: "1ltx0t" }]
];
var Navigation = createLucideIcon("navigation", __iconNode1061);

// ../node_modules/lucide-react/dist/esm/icons/network.js
var __iconNode1062 = [
  ["rect", { x: "16", y: "16", width: "6", height: "6", rx: "1", key: "4q2zg0" }],
  ["rect", { x: "2", y: "16", width: "6", height: "6", rx: "1", key: "8cvhb9" }],
  ["rect", { x: "9", y: "2", width: "6", height: "6", rx: "1", key: "1egb70" }],
  ["path", { d: "M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3", key: "1jsf9p" }],
  ["path", { d: "M12 12V8", key: "2874zd" }]
];
var Network = createLucideIcon("network", __iconNode1062);

// ../node_modules/lucide-react/dist/esm/icons/newspaper.js
var __iconNode1063 = [
  ["path", { d: "M15 18h-5", key: "95g1m2" }],
  ["path", { d: "M18 14h-8", key: "sponae" }],
  [
    "path",
    {
      d: "M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0v-9a2 2 0 0 1 2-2h2",
      key: "39pd36"
    }
  ],
  ["rect", { width: "8", height: "4", x: "10", y: "6", rx: "1", key: "aywv1n" }]
];
var Newspaper = createLucideIcon("newspaper", __iconNode1063);

// ../node_modules/lucide-react/dist/esm/icons/nfc.js
var __iconNode1064 = [
  ["path", { d: "M6 8.32a7.43 7.43 0 0 1 0 7.36", key: "9iaqei" }],
  ["path", { d: "M9.46 6.21a11.76 11.76 0 0 1 0 11.58", key: "1yha7l" }],
  ["path", { d: "M12.91 4.1a15.91 15.91 0 0 1 .01 15.8", key: "4iu2gk" }],
  ["path", { d: "M16.37 2a20.16 20.16 0 0 1 0 20", key: "sap9u2" }]
];
var Nfc = createLucideIcon("nfc", __iconNode1064);

// ../node_modules/lucide-react/dist/esm/icons/non-binary.js
var __iconNode1065 = [
  ["path", { d: "M12 2v10", key: "mnfbl" }],
  ["path", { d: "m8.5 4 7 4", key: "m1xjk3" }],
  ["path", { d: "m8.5 8 7-4", key: "t0m5j6" }],
  ["circle", { cx: "12", cy: "17", r: "5", key: "qbz8iq" }]
];
var NonBinary = createLucideIcon("non-binary", __iconNode1065);

// ../node_modules/lucide-react/dist/esm/icons/notebook-pen.js
var __iconNode1066 = [
  ["path", { d: "M13.4 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.4", key: "re6nr2" }],
  ["path", { d: "M2 6h4", key: "aawbzj" }],
  ["path", { d: "M2 10h4", key: "l0bgd4" }],
  ["path", { d: "M2 14h4", key: "1gsvsf" }],
  ["path", { d: "M2 18h4", key: "1bu2t1" }],
  [
    "path",
    {
      d: "M21.378 5.626a1 1 0 1 0-3.004-3.004l-5.01 5.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
      key: "pqwjuv"
    }
  ]
];
var NotebookPen = createLucideIcon("notebook-pen", __iconNode1066);

// ../node_modules/lucide-react/dist/esm/icons/notebook-tabs.js
var __iconNode1067 = [
  ["path", { d: "M2 6h4", key: "aawbzj" }],
  ["path", { d: "M2 10h4", key: "l0bgd4" }],
  ["path", { d: "M2 14h4", key: "1gsvsf" }],
  ["path", { d: "M2 18h4", key: "1bu2t1" }],
  ["rect", { width: "16", height: "20", x: "4", y: "2", rx: "2", key: "1nb95v" }],
  ["path", { d: "M15 2v20", key: "dcj49h" }],
  ["path", { d: "M15 7h5", key: "1xj5lc" }],
  ["path", { d: "M15 12h5", key: "w5shd9" }],
  ["path", { d: "M15 17h5", key: "1qaofu" }]
];
var NotebookTabs = createLucideIcon("notebook-tabs", __iconNode1067);

// ../node_modules/lucide-react/dist/esm/icons/notebook-text.js
var __iconNode1068 = [
  ["path", { d: "M2 6h4", key: "aawbzj" }],
  ["path", { d: "M2 10h4", key: "l0bgd4" }],
  ["path", { d: "M2 14h4", key: "1gsvsf" }],
  ["path", { d: "M2 18h4", key: "1bu2t1" }],
  ["rect", { width: "16", height: "20", x: "4", y: "2", rx: "2", key: "1nb95v" }],
  ["path", { d: "M9.5 8h5", key: "11mslq" }],
  ["path", { d: "M9.5 12H16", key: "ktog6x" }],
  ["path", { d: "M9.5 16H14", key: "p1seyn" }]
];
var NotebookText = createLucideIcon("notebook-text", __iconNode1068);

// ../node_modules/lucide-react/dist/esm/icons/notebook.js
var __iconNode1069 = [
  ["path", { d: "M2 6h4", key: "aawbzj" }],
  ["path", { d: "M2 10h4", key: "l0bgd4" }],
  ["path", { d: "M2 14h4", key: "1gsvsf" }],
  ["path", { d: "M2 18h4", key: "1bu2t1" }],
  ["rect", { width: "16", height: "20", x: "4", y: "2", rx: "2", key: "1nb95v" }],
  ["path", { d: "M16 2v20", key: "rotuqe" }]
];
var Notebook = createLucideIcon("notebook", __iconNode1069);

// ../node_modules/lucide-react/dist/esm/icons/notepad-text-dashed.js
var __iconNode1070 = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M12 2v4", key: "3427ic" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["path", { d: "M16 4h2a2 2 0 0 1 2 2v2", key: "j91f56" }],
  ["path", { d: "M20 12v2", key: "w8o0tu" }],
  ["path", { d: "M20 18v2a2 2 0 0 1-2 2h-1", key: "1c9ggx" }],
  ["path", { d: "M13 22h-2", key: "191ugt" }],
  ["path", { d: "M7 22H6a2 2 0 0 1-2-2v-2", key: "1rt9px" }],
  ["path", { d: "M4 14v-2", key: "1v0sqh" }],
  ["path", { d: "M4 8V6a2 2 0 0 1 2-2h2", key: "1mwabg" }],
  ["path", { d: "M8 10h6", key: "3oa6kw" }],
  ["path", { d: "M8 14h8", key: "1fgep2" }],
  ["path", { d: "M8 18h5", key: "17enja" }]
];
var NotepadTextDashed = createLucideIcon("notepad-text-dashed", __iconNode1070);

// ../node_modules/lucide-react/dist/esm/icons/notepad-text.js
var __iconNode1071 = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M12 2v4", key: "3427ic" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["rect", { width: "16", height: "18", x: "4", y: "4", rx: "2", key: "1u9h20" }],
  ["path", { d: "M8 10h6", key: "3oa6kw" }],
  ["path", { d: "M8 14h8", key: "1fgep2" }],
  ["path", { d: "M8 18h5", key: "17enja" }]
];
var NotepadText = createLucideIcon("notepad-text", __iconNode1071);

// ../node_modules/lucide-react/dist/esm/icons/nut-off.js
var __iconNode1072 = [
  ["path", { d: "M12 4V2", key: "1k5q1u" }],
  [
    "path",
    {
      d: "M5 10v4a7.004 7.004 0 0 0 5.277 6.787c.412.104.802.292 1.102.592L12 22l.621-.621c.3-.3.69-.488 1.102-.592a7.01 7.01 0 0 0 4.125-2.939",
      key: "1xcvy9"
    }
  ],
  ["path", { d: "M19 10v3.343", key: "163tfc" }],
  [
    "path",
    {
      d: "M12 12c-1.349-.573-1.905-1.005-2.5-2-.546.902-1.048 1.353-2.5 2-1.018-.644-1.46-1.08-2-2-1.028.71-1.69.918-3 1 1.081-1.048 1.757-2.03 2-3 .194-.776.84-1.551 1.79-2.21m11.654 5.997c.887-.457 1.28-.891 1.556-1.787 1.032.916 1.683 1.157 3 1-1.297-1.036-1.758-2.03-2-3-.5-2-4-4-8-4-.74 0-1.461.068-2.15.192",
      key: "17914v"
    }
  ],
  ["line", { x1: "2", x2: "22", y1: "2", y2: "22", key: "a6p6uj" }]
];
var NutOff = createLucideIcon("nut-off", __iconNode1072);

// ../node_modules/lucide-react/dist/esm/icons/nut.js
var __iconNode1073 = [
  ["path", { d: "M12 4V2", key: "1k5q1u" }],
  [
    "path",
    {
      d: "M5 10v4a7.004 7.004 0 0 0 5.277 6.787c.412.104.802.292 1.102.592L12 22l.621-.621c.3-.3.69-.488 1.102-.592A7.003 7.003 0 0 0 19 14v-4",
      key: "1tgyif"
    }
  ],
  [
    "path",
    {
      d: "M12 4C8 4 4.5 6 4 8c-.243.97-.919 1.952-2 3 1.31-.082 1.972-.29 3-1 .54.92.982 1.356 2 2 1.452-.647 1.954-1.098 2.5-2 .595.995 1.151 1.427 2.5 2 1.31-.621 1.862-1.058 2.5-2 .629.977 1.162 1.423 2.5 2 1.209-.548 1.68-.967 2-2 1.032.916 1.683 1.157 3 1-1.297-1.036-1.758-2.03-2-3-.5-2-4-4-8-4Z",
      key: "tnsqj"
    }
  ]
];
var Nut = createLucideIcon("nut", __iconNode1073);

// ../node_modules/lucide-react/dist/esm/icons/octagon-alert.js
var __iconNode1074 = [
  ["path", { d: "M12 16h.01", key: "1drbdi" }],
  ["path", { d: "M12 8v4", key: "1got3b" }],
  [
    "path",
    {
      d: "M15.312 2a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586l-4.688-4.688A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2z",
      key: "1fd625"
    }
  ]
];
var OctagonAlert = createLucideIcon("octagon-alert", __iconNode1074);

// ../node_modules/lucide-react/dist/esm/icons/octagon-minus.js
var __iconNode1075 = [
  [
    "path",
    {
      d: "M2.586 16.726A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2h6.624a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586z",
      key: "2d38gg"
    }
  ],
  ["path", { d: "M8 12h8", key: "1wcyev" }]
];
var OctagonMinus = createLucideIcon("octagon-minus", __iconNode1075);

// ../node_modules/lucide-react/dist/esm/icons/octagon-pause.js
var __iconNode1076 = [
  ["path", { d: "M10 15V9", key: "1lckn7" }],
  ["path", { d: "M14 15V9", key: "1muqhk" }],
  [
    "path",
    {
      d: "M2.586 16.726A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2h6.624a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586z",
      key: "2d38gg"
    }
  ]
];
var OctagonPause = createLucideIcon("octagon-pause", __iconNode1076);

// ../node_modules/lucide-react/dist/esm/icons/octagon-x.js
var __iconNode1077 = [
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  [
    "path",
    {
      d: "M2.586 16.726A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2h6.624a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586z",
      key: "2d38gg"
    }
  ],
  ["path", { d: "m9 9 6 6", key: "z0biqf" }]
];
var OctagonX = createLucideIcon("octagon-x", __iconNode1077);

// ../node_modules/lucide-react/dist/esm/icons/octagon.js
var __iconNode1078 = [
  [
    "path",
    {
      d: "M2.586 16.726A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2h6.624a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586z",
      key: "2d38gg"
    }
  ]
];
var Octagon = createLucideIcon("octagon", __iconNode1078);

// ../node_modules/lucide-react/dist/esm/icons/omega.js
var __iconNode1079 = [
  [
    "path",
    {
      d: "M3 20h4.5a.5.5 0 0 0 .5-.5v-.282a.52.52 0 0 0-.247-.437 8 8 0 1 1 8.494-.001.52.52 0 0 0-.247.438v.282a.5.5 0 0 0 .5.5H21",
      key: "1x94xo"
    }
  ]
];
var Omega = createLucideIcon("omega", __iconNode1079);

// ../node_modules/lucide-react/dist/esm/icons/option.js
var __iconNode1080 = [
  ["path", { d: "M3 3h6l6 18h6", key: "ph9rgk" }],
  ["path", { d: "M14 3h7", key: "16f0ms" }]
];
var Option = createLucideIcon("option", __iconNode1080);

// ../node_modules/lucide-react/dist/esm/icons/orbit.js
var __iconNode1081 = [
  ["path", { d: "M20.341 6.484A10 10 0 0 1 10.266 21.85", key: "1enhxb" }],
  ["path", { d: "M3.659 17.516A10 10 0 0 1 13.74 2.152", key: "1crzgf" }],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
  ["circle", { cx: "19", cy: "5", r: "2", key: "mhkx31" }],
  ["circle", { cx: "5", cy: "19", r: "2", key: "v8kfzx" }]
];
var Orbit = createLucideIcon("orbit", __iconNode1081);

// ../node_modules/lucide-react/dist/esm/icons/origami.js
var __iconNode1082 = [
  ["path", { d: "M12 12V4a1 1 0 0 1 1-1h6.297a1 1 0 0 1 .651 1.759l-4.696 4.025", key: "1bx4vc" }],
  [
    "path",
    {
      d: "m12 21-7.414-7.414A2 2 0 0 1 4 12.172V6.415a1.002 1.002 0 0 1 1.707-.707L20 20.009",
      key: "1h3km6"
    }
  ],
  [
    "path",
    {
      d: "m12.214 3.381 8.414 14.966a1 1 0 0 1-.167 1.199l-1.168 1.163a1 1 0 0 1-.706.291H6.351a1 1 0 0 1-.625-.219L3.25 18.8a1 1 0 0 1 .631-1.781l4.165.027",
      key: "1hj4wg"
    }
  ]
];
var Origami = createLucideIcon("origami", __iconNode1082);

// ../node_modules/lucide-react/dist/esm/icons/package-2.js
var __iconNode1083 = [
  ["path", { d: "M12 3v6", key: "1holv5" }],
  [
    "path",
    {
      d: "M16.76 3a2 2 0 0 1 1.8 1.1l2.23 4.479a2 2 0 0 1 .21.891V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9.472a2 2 0 0 1 .211-.894L5.45 4.1A2 2 0 0 1 7.24 3z",
      key: "187q7i"
    }
  ],
  ["path", { d: "M3.054 9.013h17.893", key: "grwhos" }]
];
var Package2 = createLucideIcon("package-2", __iconNode1083);

// ../node_modules/lucide-react/dist/esm/icons/package-check.js
var __iconNode1084 = [
  ["path", { d: "m16 16 2 2 4-4", key: "gfu2re" }],
  [
    "path",
    {
      d: "M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14",
      key: "e7tb2h"
    }
  ],
  ["path", { d: "m7.5 4.27 9 5.15", key: "1c824w" }],
  ["polyline", { points: "3.29 7 12 12 20.71 7", key: "ousv84" }],
  ["line", { x1: "12", x2: "12", y1: "22", y2: "12", key: "a4e8g8" }]
];
var PackageCheck = createLucideIcon("package-check", __iconNode1084);

// ../node_modules/lucide-react/dist/esm/icons/package-minus.js
var __iconNode1085 = [
  ["path", { d: "M16 16h6", key: "100bgy" }],
  [
    "path",
    {
      d: "M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14",
      key: "e7tb2h"
    }
  ],
  ["path", { d: "m7.5 4.27 9 5.15", key: "1c824w" }],
  ["polyline", { points: "3.29 7 12 12 20.71 7", key: "ousv84" }],
  ["line", { x1: "12", x2: "12", y1: "22", y2: "12", key: "a4e8g8" }]
];
var PackageMinus = createLucideIcon("package-minus", __iconNode1085);

// ../node_modules/lucide-react/dist/esm/icons/package-open.js
var __iconNode1086 = [
  ["path", { d: "M12 22v-9", key: "x3hkom" }],
  [
    "path",
    {
      d: "M15.17 2.21a1.67 1.67 0 0 1 1.63 0L21 4.57a1.93 1.93 0 0 1 0 3.36L8.82 14.79a1.655 1.655 0 0 1-1.64 0L3 12.43a1.93 1.93 0 0 1 0-3.36z",
      key: "2ntwy6"
    }
  ],
  [
    "path",
    {
      d: "M20 13v3.87a2.06 2.06 0 0 1-1.11 1.83l-6 3.08a1.93 1.93 0 0 1-1.78 0l-6-3.08A2.06 2.06 0 0 1 4 16.87V13",
      key: "1pmm1c"
    }
  ],
  [
    "path",
    {
      d: "M21 12.43a1.93 1.93 0 0 0 0-3.36L8.83 2.2a1.64 1.64 0 0 0-1.63 0L3 4.57a1.93 1.93 0 0 0 0 3.36l12.18 6.86a1.636 1.636 0 0 0 1.63 0z",
      key: "12ttoo"
    }
  ]
];
var PackageOpen = createLucideIcon("package-open", __iconNode1086);

// ../node_modules/lucide-react/dist/esm/icons/package-plus.js
var __iconNode1087 = [
  ["path", { d: "M16 16h6", key: "100bgy" }],
  ["path", { d: "M19 13v6", key: "85cyf1" }],
  [
    "path",
    {
      d: "M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14",
      key: "e7tb2h"
    }
  ],
  ["path", { d: "m7.5 4.27 9 5.15", key: "1c824w" }],
  ["polyline", { points: "3.29 7 12 12 20.71 7", key: "ousv84" }],
  ["line", { x1: "12", x2: "12", y1: "22", y2: "12", key: "a4e8g8" }]
];
var PackagePlus = createLucideIcon("package-plus", __iconNode1087);

// ../node_modules/lucide-react/dist/esm/icons/package-search.js
var __iconNode1088 = [
  [
    "path",
    {
      d: "M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14",
      key: "e7tb2h"
    }
  ],
  ["path", { d: "m7.5 4.27 9 5.15", key: "1c824w" }],
  ["polyline", { points: "3.29 7 12 12 20.71 7", key: "ousv84" }],
  ["line", { x1: "12", x2: "12", y1: "22", y2: "12", key: "a4e8g8" }],
  ["circle", { cx: "18.5", cy: "15.5", r: "2.5", key: "b5zd12" }],
  ["path", { d: "M20.27 17.27 22 19", key: "1l4muz" }]
];
var PackageSearch = createLucideIcon("package-search", __iconNode1088);

// ../node_modules/lucide-react/dist/esm/icons/package-x.js
var __iconNode1089 = [
  [
    "path",
    {
      d: "M21 10V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l2-1.14",
      key: "e7tb2h"
    }
  ],
  ["path", { d: "m7.5 4.27 9 5.15", key: "1c824w" }],
  ["polyline", { points: "3.29 7 12 12 20.71 7", key: "ousv84" }],
  ["line", { x1: "12", x2: "12", y1: "22", y2: "12", key: "a4e8g8" }],
  ["path", { d: "m17 13 5 5m-5 0 5-5", key: "im3w4b" }]
];
var PackageX = createLucideIcon("package-x", __iconNode1089);

// ../node_modules/lucide-react/dist/esm/icons/package.js
var __iconNode1090 = [
  [
    "path",
    {
      d: "M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z",
      key: "1a0edw"
    }
  ],
  ["path", { d: "M12 22V12", key: "d0xqtd" }],
  ["polyline", { points: "3.29 7 12 12 20.71 7", key: "ousv84" }],
  ["path", { d: "m7.5 4.27 9 5.15", key: "1c824w" }]
];
var Package = createLucideIcon("package", __iconNode1090);

// ../node_modules/lucide-react/dist/esm/icons/paint-bucket.js
var __iconNode1091 = [
  ["path", { d: "M11 7 6 2", key: "1jwth8" }],
  ["path", { d: "M18.992 12H2.041", key: "xw1gg" }],
  [
    "path",
    {
      d: "M21.145 18.38A3.34 3.34 0 0 1 20 16.5a3.3 3.3 0 0 1-1.145 1.88c-.575.46-.855 1.02-.855 1.595A2 2 0 0 0 20 22a2 2 0 0 0 2-2.025c0-.58-.285-1.13-.855-1.595",
      key: "1nkol4"
    }
  ],
  [
    "path",
    {
      d: "m8.5 4.5 2.148-2.148a1.205 1.205 0 0 1 1.704 0l7.296 7.296a1.205 1.205 0 0 1 0 1.704l-7.592 7.592a3.615 3.615 0 0 1-5.112 0l-3.888-3.888a3.615 3.615 0 0 1 0-5.112L5.67 7.33",
      key: "1nk1rd"
    }
  ]
];
var PaintBucket = createLucideIcon("paint-bucket", __iconNode1091);

// ../node_modules/lucide-react/dist/esm/icons/paint-roller.js
var __iconNode1092 = [
  ["rect", { width: "16", height: "6", x: "2", y: "2", rx: "2", key: "jcyz7m" }],
  ["path", { d: "M10 16v-2a2 2 0 0 1 2-2h8a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2", key: "1b9h7c" }],
  ["rect", { width: "4", height: "6", x: "8", y: "16", rx: "1", key: "d6e7yl" }]
];
var PaintRoller = createLucideIcon("paint-roller", __iconNode1092);

// ../node_modules/lucide-react/dist/esm/icons/paintbrush-vertical.js
var __iconNode1093 = [
  ["path", { d: "M10 2v2", key: "7u0qdc" }],
  ["path", { d: "M14 2v4", key: "qmzblu" }],
  ["path", { d: "M17 2a1 1 0 0 1 1 1v9H6V3a1 1 0 0 1 1-1z", key: "ycvu00" }],
  [
    "path",
    {
      d: "M6 12a1 1 0 0 0-1 1v1a2 2 0 0 0 2 2h2a1 1 0 0 1 1 1v2.9a2 2 0 1 0 4 0V17a1 1 0 0 1 1-1h2a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1",
      key: "iw4wnp"
    }
  ]
];
var PaintbrushVertical = createLucideIcon("paintbrush-vertical", __iconNode1093);

// ../node_modules/lucide-react/dist/esm/icons/paintbrush.js
var __iconNode1094 = [
  ["path", { d: "m14.622 17.897-10.68-2.913", key: "vj2p1u" }],
  [
    "path",
    {
      d: "M18.376 2.622a1 1 0 1 1 3.002 3.002L17.36 9.643a.5.5 0 0 0 0 .707l.944.944a2.41 2.41 0 0 1 0 3.408l-.944.944a.5.5 0 0 1-.707 0L8.354 7.348a.5.5 0 0 1 0-.707l.944-.944a2.41 2.41 0 0 1 3.408 0l.944.944a.5.5 0 0 0 .707 0z",
      key: "18tc5c"
    }
  ],
  [
    "path",
    {
      d: "M9 8c-1.804 2.71-3.97 3.46-6.583 3.948a.507.507 0 0 0-.302.819l7.32 8.883a1 1 0 0 0 1.185.204C12.735 20.405 16 16.792 16 15",
      key: "ytzfxy"
    }
  ]
];
var Paintbrush = createLucideIcon("paintbrush", __iconNode1094);

// ../node_modules/lucide-react/dist/esm/icons/palette.js
var __iconNode1095 = [
  [
    "path",
    {
      d: "M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z",
      key: "e79jfc"
    }
  ],
  ["circle", { cx: "13.5", cy: "6.5", r: ".5", fill: "currentColor", key: "1okk4w" }],
  ["circle", { cx: "17.5", cy: "10.5", r: ".5", fill: "currentColor", key: "f64h9f" }],
  ["circle", { cx: "6.5", cy: "12.5", r: ".5", fill: "currentColor", key: "qy21gx" }],
  ["circle", { cx: "8.5", cy: "7.5", r: ".5", fill: "currentColor", key: "fotxhn" }]
];
var Palette = createLucideIcon("palette", __iconNode1095);

// ../node_modules/lucide-react/dist/esm/icons/panda.js
var __iconNode1096 = [
  ["path", { d: "M11.25 17.25h1.5L12 18z", key: "1wmwwj" }],
  ["path", { d: "m15 12 2 2", key: "k60wz4" }],
  ["path", { d: "M18 6.5a.5.5 0 0 0-.5-.5", key: "1ch4h4" }],
  [
    "path",
    {
      d: "M20.69 9.67a4.5 4.5 0 1 0-7.04-5.5 8.35 8.35 0 0 0-3.3 0 4.5 4.5 0 1 0-7.04 5.5C2.49 11.2 2 12.88 2 14.5 2 19.47 6.48 22 12 22s10-2.53 10-7.5c0-1.62-.48-3.3-1.3-4.83",
      key: "1c660l"
    }
  ],
  ["path", { d: "M6 6.5a.495.495 0 0 1 .5-.5", key: "eviuep" }],
  ["path", { d: "m9 12-2 2", key: "326nkw" }]
];
var Panda = createLucideIcon("panda", __iconNode1096);

// ../node_modules/lucide-react/dist/esm/icons/panel-bottom-close.js
var __iconNode1097 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 15h18", key: "5xshup" }],
  ["path", { d: "m15 8-3 3-3-3", key: "1oxy1z" }]
];
var PanelBottomClose = createLucideIcon("panel-bottom-close", __iconNode1097);

// ../node_modules/lucide-react/dist/esm/icons/panel-bottom-dashed.js
var __iconNode1098 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M14 15h1", key: "171nev" }],
  ["path", { d: "M19 15h2", key: "1vnucp" }],
  ["path", { d: "M3 15h2", key: "8bym0q" }],
  ["path", { d: "M9 15h1", key: "1tg3ks" }]
];
var PanelBottomDashed = createLucideIcon("panel-bottom-dashed", __iconNode1098);

// ../node_modules/lucide-react/dist/esm/icons/panel-bottom-open.js
var __iconNode1099 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 15h18", key: "5xshup" }],
  ["path", { d: "m9 10 3-3 3 3", key: "11gsxs" }]
];
var PanelBottomOpen = createLucideIcon("panel-bottom-open", __iconNode1099);

// ../node_modules/lucide-react/dist/esm/icons/panel-bottom.js
var __iconNode1100 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 15h18", key: "5xshup" }]
];
var PanelBottom = createLucideIcon("panel-bottom", __iconNode1100);

// ../node_modules/lucide-react/dist/esm/icons/panel-left-close.js
var __iconNode1101 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }],
  ["path", { d: "m16 15-3-3 3-3", key: "14y99z" }]
];
var PanelLeftClose = createLucideIcon("panel-left-close", __iconNode1101);

// ../node_modules/lucide-react/dist/esm/icons/panel-left-dashed.js
var __iconNode1102 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M9 14v1", key: "askpd8" }],
  ["path", { d: "M9 19v2", key: "16tejx" }],
  ["path", { d: "M9 3v2", key: "1noubl" }],
  ["path", { d: "M9 9v1", key: "19ebxg" }]
];
var PanelLeftDashed = createLucideIcon("panel-left-dashed", __iconNode1102);

// ../node_modules/lucide-react/dist/esm/icons/panel-left-open.js
var __iconNode1103 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }],
  ["path", { d: "m14 9 3 3-3 3", key: "8010ee" }]
];
var PanelLeftOpen = createLucideIcon("panel-left-open", __iconNode1103);

// ../node_modules/lucide-react/dist/esm/icons/panel-left-right-dashed.js
var __iconNode1104 = [
  ["path", { d: "M15 10V9", key: "4dkmfx" }],
  ["path", { d: "M15 15v-1", key: "6a4afx" }],
  ["path", { d: "M15 21v-2", key: "1qshmc" }],
  ["path", { d: "M15 5V3", key: "1fk0mb" }],
  ["path", { d: "M9 10V9", key: "1lazqi" }],
  ["path", { d: "M9 15v-1", key: "9lx740" }],
  ["path", { d: "M9 21v-2", key: "1fwk0n" }],
  ["path", { d: "M9 5V3", key: "2q8zi6" }],
  ["rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", key: "h1oib" }]
];
var PanelLeftRightDashed = createLucideIcon("panel-left-right-dashed", __iconNode1104);

// ../node_modules/lucide-react/dist/esm/icons/panel-left.js
var __iconNode1105 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }]
];
var PanelLeft = createLucideIcon("panel-left", __iconNode1105);

// ../node_modules/lucide-react/dist/esm/icons/panel-right-close.js
var __iconNode1106 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M15 3v18", key: "14nvp0" }],
  ["path", { d: "m8 9 3 3-3 3", key: "12hl5m" }]
];
var PanelRightClose = createLucideIcon("panel-right-close", __iconNode1106);

// ../node_modules/lucide-react/dist/esm/icons/panel-right-dashed.js
var __iconNode1107 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M15 14v1", key: "ilsfch" }],
  ["path", { d: "M15 19v2", key: "1fst2f" }],
  ["path", { d: "M15 3v2", key: "z204g4" }],
  ["path", { d: "M15 9v1", key: "z2a8b1" }]
];
var PanelRightDashed = createLucideIcon("panel-right-dashed", __iconNode1107);

// ../node_modules/lucide-react/dist/esm/icons/panel-right-open.js
var __iconNode1108 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M15 3v18", key: "14nvp0" }],
  ["path", { d: "m10 15-3-3 3-3", key: "1pgupc" }]
];
var PanelRightOpen = createLucideIcon("panel-right-open", __iconNode1108);

// ../node_modules/lucide-react/dist/esm/icons/panel-right.js
var __iconNode1109 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M15 3v18", key: "14nvp0" }]
];
var PanelRight = createLucideIcon("panel-right", __iconNode1109);

// ../node_modules/lucide-react/dist/esm/icons/panel-top-close.js
var __iconNode1110 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["path", { d: "m9 16 3-3 3 3", key: "1idcnm" }]
];
var PanelTopClose = createLucideIcon("panel-top-close", __iconNode1110);

// ../node_modules/lucide-react/dist/esm/icons/panel-top-bottom-dashed.js
var __iconNode1111 = [
  ["path", { d: "M14 15h1", key: "171nev" }],
  ["path", { d: "M14 9h1", key: "l0svgy" }],
  ["path", { d: "M19 15h2", key: "1vnucp" }],
  ["path", { d: "M19 9h2", key: "te2zfg" }],
  ["path", { d: "M3 15h2", key: "8bym0q" }],
  ["path", { d: "M3 9h2", key: "1h4ldw" }],
  ["path", { d: "M9 15h1", key: "1tg3ks" }],
  ["path", { d: "M9 9h1", key: "15jzuz" }],
  ["rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", key: "h1oib" }]
];
var PanelTopBottomDashed = createLucideIcon("panel-top-bottom-dashed", __iconNode1111);

// ../node_modules/lucide-react/dist/esm/icons/panel-top-dashed.js
var __iconNode1112 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M14 9h1", key: "l0svgy" }],
  ["path", { d: "M19 9h2", key: "te2zfg" }],
  ["path", { d: "M3 9h2", key: "1h4ldw" }],
  ["path", { d: "M9 9h1", key: "15jzuz" }]
];
var PanelTopDashed = createLucideIcon("panel-top-dashed", __iconNode1112);

// ../node_modules/lucide-react/dist/esm/icons/panel-top-open.js
var __iconNode1113 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["path", { d: "m15 14-3 3-3-3", key: "g215vf" }]
];
var PanelTopOpen = createLucideIcon("panel-top-open", __iconNode1113);

// ../node_modules/lucide-react/dist/esm/icons/panel-top.js
var __iconNode1114 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 9h18", key: "1pudct" }]
];
var PanelTop = createLucideIcon("panel-top", __iconNode1114);

// ../node_modules/lucide-react/dist/esm/icons/panels-left-bottom.js
var __iconNode1115 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }],
  ["path", { d: "M9 15h12", key: "5ijen5" }]
];
var PanelsLeftBottom = createLucideIcon("panels-left-bottom", __iconNode1115);

// ../node_modules/lucide-react/dist/esm/icons/panels-right-bottom.js
var __iconNode1116 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 15h12", key: "1wkqb3" }],
  ["path", { d: "M15 3v18", key: "14nvp0" }]
];
var PanelsRightBottom = createLucideIcon("panels-right-bottom", __iconNode1116);

// ../node_modules/lucide-react/dist/esm/icons/panels-top-left.js
var __iconNode1117 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["path", { d: "M9 21V9", key: "1oto5p" }]
];
var PanelsTopLeft = createLucideIcon("panels-top-left", __iconNode1117);

// ../node_modules/lucide-react/dist/esm/icons/paperclip.js
var __iconNode1118 = [
  [
    "path",
    {
      d: "m16 6-8.414 8.586a2 2 0 0 0 2.829 2.829l8.414-8.586a4 4 0 1 0-5.657-5.657l-8.379 8.551a6 6 0 1 0 8.485 8.485l8.379-8.551",
      key: "1miecu"
    }
  ]
];
var Paperclip = createLucideIcon("paperclip", __iconNode1118);

// ../node_modules/lucide-react/dist/esm/icons/parentheses.js
var __iconNode1119 = [
  ["path", { d: "M8 21s-4-3-4-9 4-9 4-9", key: "uto9ud" }],
  ["path", { d: "M16 3s4 3 4 9-4 9-4 9", key: "4w2vsq" }]
];
var Parentheses = createLucideIcon("parentheses", __iconNode1119);

// ../node_modules/lucide-react/dist/esm/icons/parking-meter.js
var __iconNode1120 = [
  ["path", { d: "M11 15h2", key: "199qp6" }],
  ["path", { d: "M12 12v3", key: "158kv8" }],
  ["path", { d: "M12 19v3", key: "npa21l" }],
  [
    "path",
    {
      d: "M15.282 19a1 1 0 0 0 .948-.68l2.37-6.988a7 7 0 1 0-13.2 0l2.37 6.988a1 1 0 0 0 .948.68z",
      key: "1jofit"
    }
  ],
  ["path", { d: "M9 9a3 3 0 1 1 6 0", key: "jdoeu8" }]
];
var ParkingMeter = createLucideIcon("parking-meter", __iconNode1120);

// ../node_modules/lucide-react/dist/esm/icons/party-popper.js
var __iconNode1121 = [
  ["path", { d: "M5.8 11.3 2 22l10.7-3.79", key: "gwxi1d" }],
  ["path", { d: "M4 3h.01", key: "1vcuye" }],
  ["path", { d: "M22 8h.01", key: "1mrtc2" }],
  ["path", { d: "M15 2h.01", key: "1cjtqr" }],
  ["path", { d: "M22 20h.01", key: "1mrys2" }],
  [
    "path",
    {
      d: "m22 2-2.24.75a2.9 2.9 0 0 0-1.96 3.12c.1.86-.57 1.63-1.45 1.63h-.38c-.86 0-1.6.6-1.76 1.44L14 10",
      key: "hbicv8"
    }
  ],
  [
    "path",
    { d: "m22 13-.82-.33c-.86-.34-1.82.2-1.98 1.11c-.11.7-.72 1.22-1.43 1.22H17", key: "1i94pl" }
  ],
  ["path", { d: "m11 2 .33.82c.34.86-.2 1.82-1.11 1.98C9.52 4.9 9 5.52 9 6.23V7", key: "1cofks" }],
  [
    "path",
    {
      d: "M11 13c1.93 1.93 2.83 4.17 2 5-.83.83-3.07-.07-5-2-1.93-1.93-2.83-4.17-2-5 .83-.83 3.07.07 5 2Z",
      key: "4kbmks"
    }
  ]
];
var PartyPopper = createLucideIcon("party-popper", __iconNode1121);

// ../node_modules/lucide-react/dist/esm/icons/pause.js
var __iconNode1122 = [
  ["rect", { x: "14", y: "3", width: "5", height: "18", rx: "1", key: "kaeet6" }],
  ["rect", { x: "5", y: "3", width: "5", height: "18", rx: "1", key: "1wsw3u" }]
];
var Pause = createLucideIcon("pause", __iconNode1122);

// ../node_modules/lucide-react/dist/esm/icons/paw-print.js
var __iconNode1123 = [
  ["circle", { cx: "11", cy: "4", r: "2", key: "vol9p0" }],
  ["circle", { cx: "18", cy: "8", r: "2", key: "17gozi" }],
  ["circle", { cx: "20", cy: "16", r: "2", key: "1v9bxh" }],
  [
    "path",
    {
      d: "M9 10a5 5 0 0 1 5 5v3.5a3.5 3.5 0 0 1-6.84 1.045Q6.52 17.48 4.46 16.84A3.5 3.5 0 0 1 5.5 10Z",
      key: "1ydw1z"
    }
  ]
];
var PawPrint = createLucideIcon("paw-print", __iconNode1123);

// ../node_modules/lucide-react/dist/esm/icons/pc-case.js
var __iconNode1124 = [
  ["rect", { width: "14", height: "20", x: "5", y: "2", rx: "2", key: "1uq1d7" }],
  ["path", { d: "M15 14h.01", key: "1kp3bh" }],
  ["path", { d: "M9 6h6", key: "dgm16u" }],
  ["path", { d: "M9 10h6", key: "9gxzsh" }]
];
var PcCase = createLucideIcon("pc-case", __iconNode1124);

// ../node_modules/lucide-react/dist/esm/icons/pen-line.js
var __iconNode1125 = [
  ["path", { d: "M13 21h8", key: "1jsn5i" }],
  [
    "path",
    {
      d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
      key: "1a8usu"
    }
  ]
];
var PenLine = createLucideIcon("pen-line", __iconNode1125);

// ../node_modules/lucide-react/dist/esm/icons/pen-off.js
var __iconNode1126 = [
  [
    "path",
    {
      d: "m10 10-6.157 6.162a2 2 0 0 0-.5.833l-1.322 4.36a.5.5 0 0 0 .622.624l4.358-1.323a2 2 0 0 0 .83-.5L14 13.982",
      key: "bjo8r8"
    }
  ],
  ["path", { d: "m12.829 7.172 4.359-4.346a1 1 0 1 1 3.986 3.986l-4.353 4.353", key: "16h5ne" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var PenOff = createLucideIcon("pen-off", __iconNode1126);

// ../node_modules/lucide-react/dist/esm/icons/pen-tool.js
var __iconNode1127 = [
  [
    "path",
    {
      d: "M15.707 21.293a1 1 0 0 1-1.414 0l-1.586-1.586a1 1 0 0 1 0-1.414l5.586-5.586a1 1 0 0 1 1.414 0l1.586 1.586a1 1 0 0 1 0 1.414z",
      key: "nt11vn"
    }
  ],
  [
    "path",
    {
      d: "m18 13-1.375-6.874a1 1 0 0 0-.746-.776L3.235 2.028a1 1 0 0 0-1.207 1.207L5.35 15.879a1 1 0 0 0 .776.746L13 18",
      key: "15qc1e"
    }
  ],
  ["path", { d: "m2.3 2.3 7.286 7.286", key: "1wuzzi" }],
  ["circle", { cx: "11", cy: "11", r: "2", key: "xmgehs" }]
];
var PenTool = createLucideIcon("pen-tool", __iconNode1127);

// ../node_modules/lucide-react/dist/esm/icons/pencil-line.js
var __iconNode1128 = [
  ["path", { d: "M13 21h8", key: "1jsn5i" }],
  ["path", { d: "m15 5 4 4", key: "1mk7zo" }],
  [
    "path",
    {
      d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
      key: "1a8usu"
    }
  ]
];
var PencilLine = createLucideIcon("pencil-line", __iconNode1128);

// ../node_modules/lucide-react/dist/esm/icons/pen.js
var __iconNode1129 = [
  [
    "path",
    {
      d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
      key: "1a8usu"
    }
  ]
];
var Pen = createLucideIcon("pen", __iconNode1129);

// ../node_modules/lucide-react/dist/esm/icons/pencil-off.js
var __iconNode1130 = [
  [
    "path",
    {
      d: "m10 10-6.157 6.162a2 2 0 0 0-.5.833l-1.322 4.36a.5.5 0 0 0 .622.624l4.358-1.323a2 2 0 0 0 .83-.5L14 13.982",
      key: "bjo8r8"
    }
  ],
  ["path", { d: "m12.829 7.172 4.359-4.346a1 1 0 1 1 3.986 3.986l-4.353 4.353", key: "16h5ne" }],
  ["path", { d: "m15 5 4 4", key: "1mk7zo" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var PencilOff = createLucideIcon("pencil-off", __iconNode1130);

// ../node_modules/lucide-react/dist/esm/icons/pencil-ruler.js
var __iconNode1131 = [
  [
    "path",
    { d: "M13 7 8.7 2.7a2.41 2.41 0 0 0-3.4 0L2.7 5.3a2.41 2.41 0 0 0 0 3.4L7 13", key: "orapub" }
  ],
  ["path", { d: "m8 6 2-2", key: "115y1s" }],
  ["path", { d: "m18 16 2-2", key: "ee94s4" }],
  [
    "path",
    {
      d: "m17 11 4.3 4.3c.94.94.94 2.46 0 3.4l-2.6 2.6c-.94.94-2.46.94-3.4 0L11 17",
      key: "cfq27r"
    }
  ],
  [
    "path",
    {
      d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
      key: "1a8usu"
    }
  ],
  ["path", { d: "m15 5 4 4", key: "1mk7zo" }]
];
var PencilRuler = createLucideIcon("pencil-ruler", __iconNode1131);

// ../node_modules/lucide-react/dist/esm/icons/pencil.js
var __iconNode1132 = [
  [
    "path",
    {
      d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
      key: "1a8usu"
    }
  ],
  ["path", { d: "m15 5 4 4", key: "1mk7zo" }]
];
var Pencil = createLucideIcon("pencil", __iconNode1132);

// ../node_modules/lucide-react/dist/esm/icons/pentagon.js
var __iconNode1133 = [
  [
    "path",
    {
      d: "M10.83 2.38a2 2 0 0 1 2.34 0l8 5.74a2 2 0 0 1 .73 2.25l-3.04 9.26a2 2 0 0 1-1.9 1.37H7.04a2 2 0 0 1-1.9-1.37L2.1 10.37a2 2 0 0 1 .73-2.25z",
      key: "2hea0t"
    }
  ]
];
var Pentagon = createLucideIcon("pentagon", __iconNode1133);

// ../node_modules/lucide-react/dist/esm/icons/percent.js
var __iconNode1134 = [
  ["line", { x1: "19", x2: "5", y1: "5", y2: "19", key: "1x9vlm" }],
  ["circle", { cx: "6.5", cy: "6.5", r: "2.5", key: "4mh3h7" }],
  ["circle", { cx: "17.5", cy: "17.5", r: "2.5", key: "1mdrzq" }]
];
var Percent = createLucideIcon("percent", __iconNode1134);

// ../node_modules/lucide-react/dist/esm/icons/person-standing.js
var __iconNode1135 = [
  ["circle", { cx: "12", cy: "5", r: "1", key: "gxeob9" }],
  ["path", { d: "m9 20 3-6 3 6", key: "se2kox" }],
  ["path", { d: "m6 8 6 2 6-2", key: "4o3us4" }],
  ["path", { d: "M12 10v4", key: "1kjpxc" }]
];
var PersonStanding = createLucideIcon("person-standing", __iconNode1135);

// ../node_modules/lucide-react/dist/esm/icons/philippine-peso.js
var __iconNode1136 = [
  ["path", { d: "M20 11H4", key: "6ut86h" }],
  ["path", { d: "M20 7H4", key: "zbl0bi" }],
  ["path", { d: "M7 21V4a1 1 0 0 1 1-1h4a1 1 0 0 1 0 12H7", key: "1ana5r" }]
];
var PhilippinePeso = createLucideIcon("philippine-peso", __iconNode1136);

// ../node_modules/lucide-react/dist/esm/icons/phone-call.js
var __iconNode1137 = [
  ["path", { d: "M13 2a9 9 0 0 1 9 9", key: "1itnx2" }],
  ["path", { d: "M13 6a5 5 0 0 1 5 5", key: "11nki7" }],
  [
    "path",
    {
      d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
      key: "9njp5v"
    }
  ]
];
var PhoneCall = createLucideIcon("phone-call", __iconNode1137);

// ../node_modules/lucide-react/dist/esm/icons/phone-forwarded.js
var __iconNode1138 = [
  ["path", { d: "M14 6h8", key: "yd68k4" }],
  ["path", { d: "m18 2 4 4-4 4", key: "pucp1d" }],
  [
    "path",
    {
      d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
      key: "9njp5v"
    }
  ]
];
var PhoneForwarded = createLucideIcon("phone-forwarded", __iconNode1138);

// ../node_modules/lucide-react/dist/esm/icons/phone-incoming.js
var __iconNode1139 = [
  ["path", { d: "M16 2v6h6", key: "1mfrl5" }],
  ["path", { d: "m22 2-6 6", key: "6f0sa0" }],
  [
    "path",
    {
      d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
      key: "9njp5v"
    }
  ]
];
var PhoneIncoming = createLucideIcon("phone-incoming", __iconNode1139);

// ../node_modules/lucide-react/dist/esm/icons/phone-missed.js
var __iconNode1140 = [
  ["path", { d: "m16 2 6 6", key: "1gw87d" }],
  ["path", { d: "m22 2-6 6", key: "6f0sa0" }],
  [
    "path",
    {
      d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
      key: "9njp5v"
    }
  ]
];
var PhoneMissed = createLucideIcon("phone-missed", __iconNode1140);

// ../node_modules/lucide-react/dist/esm/icons/phone-off.js
var __iconNode1141 = [
  [
    "path",
    {
      d: "M10.1 13.9a14 14 0 0 0 3.732 2.668 1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2 18 18 0 0 1-12.728-5.272",
      key: "1wngk7"
    }
  ],
  ["path", { d: "M22 2 2 22", key: "y4kqgn" }],
  [
    "path",
    {
      d: "M4.76 13.582A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 .244.473",
      key: "10hv5p"
    }
  ]
];
var PhoneOff = createLucideIcon("phone-off", __iconNode1141);

// ../node_modules/lucide-react/dist/esm/icons/phone-outgoing.js
var __iconNode1142 = [
  ["path", { d: "m16 8 6-6", key: "oawc05" }],
  ["path", { d: "M22 8V2h-6", key: "oqy2zc" }],
  [
    "path",
    {
      d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
      key: "9njp5v"
    }
  ]
];
var PhoneOutgoing = createLucideIcon("phone-outgoing", __iconNode1142);

// ../node_modules/lucide-react/dist/esm/icons/phone.js
var __iconNode1143 = [
  [
    "path",
    {
      d: "M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",
      key: "9njp5v"
    }
  ]
];
var Phone = createLucideIcon("phone", __iconNode1143);

// ../node_modules/lucide-react/dist/esm/icons/pi.js
var __iconNode1144 = [
  ["line", { x1: "9", x2: "9", y1: "4", y2: "20", key: "ovs5a5" }],
  ["path", { d: "M4 7c0-1.7 1.3-3 3-3h13", key: "10pag4" }],
  ["path", { d: "M18 20c-1.7 0-3-1.3-3-3V4", key: "1gaosr" }]
];
var Pi = createLucideIcon("pi", __iconNode1144);

// ../node_modules/lucide-react/dist/esm/icons/piano.js
var __iconNode1145 = [
  [
    "path",
    {
      d: "M18.5 8c-1.4 0-2.6-.8-3.2-2A6.87 6.87 0 0 0 2 9v11a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-8.5C22 9.6 20.4 8 18.5 8",
      key: "lag0yf"
    }
  ],
  ["path", { d: "M2 14h20", key: "myj16y" }],
  ["path", { d: "M6 14v4", key: "9ng0ue" }],
  ["path", { d: "M10 14v4", key: "1v8uk5" }],
  ["path", { d: "M14 14v4", key: "1tqops" }],
  ["path", { d: "M18 14v4", key: "18uqwm" }]
];
var Piano = createLucideIcon("piano", __iconNode1145);

// ../node_modules/lucide-react/dist/esm/icons/pickaxe.js
var __iconNode1146 = [
  ["path", { d: "m14 13-8.381 8.38a1 1 0 0 1-3.001-3L11 9.999", key: "1lw9ds" }],
  [
    "path",
    {
      d: "M15.973 4.027A13 13 0 0 0 5.902 2.373c-1.398.342-1.092 2.158.277 2.601a19.9 19.9 0 0 1 5.822 3.024",
      key: "ffj4ej"
    }
  ],
  [
    "path",
    {
      d: "M16.001 11.999a19.9 19.9 0 0 1 3.024 5.824c.444 1.369 2.26 1.676 2.603.278A13 13 0 0 0 20 8.069",
      key: "8tj4zw"
    }
  ],
  [
    "path",
    {
      d: "M18.352 3.352a1.205 1.205 0 0 0-1.704 0l-5.296 5.296a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l5.296-5.296a1.205 1.205 0 0 0 0-1.704z",
      key: "hh6h97"
    }
  ]
];
var Pickaxe = createLucideIcon("pickaxe", __iconNode1146);

// ../node_modules/lucide-react/dist/esm/icons/picture-in-picture-2.js
var __iconNode1147 = [
  ["path", { d: "M21 9V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v10c0 1.1.9 2 2 2h4", key: "daa4of" }],
  ["rect", { width: "10", height: "7", x: "12", y: "13", rx: "2", key: "1nb8gs" }]
];
var PictureInPicture2 = createLucideIcon("picture-in-picture-2", __iconNode1147);

// ../node_modules/lucide-react/dist/esm/icons/picture-in-picture.js
var __iconNode1148 = [
  ["path", { d: "M2 10h6V4", key: "zwrco" }],
  ["path", { d: "m2 4 6 6", key: "ug085t" }],
  ["path", { d: "M21 10V7a2 2 0 0 0-2-2h-7", key: "git5jr" }],
  ["path", { d: "M3 14v2a2 2 0 0 0 2 2h3", key: "1f7fh3" }],
  ["rect", { x: "12", y: "14", width: "10", height: "7", rx: "1", key: "1wjs3o" }]
];
var PictureInPicture = createLucideIcon("picture-in-picture", __iconNode1148);

// ../node_modules/lucide-react/dist/esm/icons/piggy-bank.js
var __iconNode1149 = [
  [
    "path",
    {
      d: "M11 17h3v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-3a3.16 3.16 0 0 0 2-2h1a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1h-1a5 5 0 0 0-2-4V3a4 4 0 0 0-3.2 1.6l-.3.4H11a6 6 0 0 0-6 6v1a5 5 0 0 0 2 4v3a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1z",
      key: "1piglc"
    }
  ],
  ["path", { d: "M16 10h.01", key: "1m94wz" }],
  ["path", { d: "M2 8v1a2 2 0 0 0 2 2h1", key: "1env43" }]
];
var PiggyBank = createLucideIcon("piggy-bank", __iconNode1149);

// ../node_modules/lucide-react/dist/esm/icons/pilcrow-left.js
var __iconNode1150 = [
  ["path", { d: "M14 3v11", key: "mlfb7b" }],
  ["path", { d: "M14 9h-3a3 3 0 0 1 0-6h9", key: "1ulc19" }],
  ["path", { d: "M18 3v11", key: "1phi0r" }],
  ["path", { d: "M22 18H2l4-4", key: "yt65j9" }],
  ["path", { d: "m6 22-4-4", key: "6jgyf5" }]
];
var PilcrowLeft = createLucideIcon("pilcrow-left", __iconNode1150);

// ../node_modules/lucide-react/dist/esm/icons/pilcrow-right.js
var __iconNode1151 = [
  ["path", { d: "M10 3v11", key: "o3l5kj" }],
  ["path", { d: "M10 9H7a1 1 0 0 1 0-6h8", key: "1wb1nc" }],
  ["path", { d: "M14 3v11", key: "mlfb7b" }],
  ["path", { d: "m18 14 4 4H2", key: "4r8io1" }],
  ["path", { d: "m22 18-4 4", key: "1hjjrd" }]
];
var PilcrowRight = createLucideIcon("pilcrow-right", __iconNode1151);

// ../node_modules/lucide-react/dist/esm/icons/pilcrow.js
var __iconNode1152 = [
  ["path", { d: "M13 4v16", key: "8vvj80" }],
  ["path", { d: "M17 4v16", key: "7dpous" }],
  ["path", { d: "M19 4H9.5a4.5 4.5 0 0 0 0 9H13", key: "sh4n9v" }]
];
var Pilcrow = createLucideIcon("pilcrow", __iconNode1152);

// ../node_modules/lucide-react/dist/esm/icons/pill-bottle.js
var __iconNode1153 = [
  ["path", { d: "M18 11h-4a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h4", key: "17ldeb" }],
  ["path", { d: "M6 7v13a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7", key: "nc37y6" }],
  ["rect", { width: "16", height: "5", x: "4", y: "2", rx: "1", key: "3jeezo" }]
];
var PillBottle = createLucideIcon("pill-bottle", __iconNode1153);

// ../node_modules/lucide-react/dist/esm/icons/pill.js
var __iconNode1154 = [
  [
    "path",
    { d: "m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z", key: "wa1lgi" }
  ],
  ["path", { d: "m8.5 8.5 7 7", key: "rvfmvr" }]
];
var Pill = createLucideIcon("pill", __iconNode1154);

// ../node_modules/lucide-react/dist/esm/icons/pin-off.js
var __iconNode1155 = [
  ["path", { d: "M12 17v5", key: "bb1du9" }],
  ["path", { d: "M15 9.34V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H7.89", key: "znwnzq" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    {
      d: "M9 9v1.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h11",
      key: "c9qhm2"
    }
  ]
];
var PinOff = createLucideIcon("pin-off", __iconNode1155);

// ../node_modules/lucide-react/dist/esm/icons/pin.js
var __iconNode1156 = [
  ["path", { d: "M12 17v5", key: "bb1du9" }],
  [
    "path",
    {
      d: "M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z",
      key: "1nkz8b"
    }
  ]
];
var Pin = createLucideIcon("pin", __iconNode1156);

// ../node_modules/lucide-react/dist/esm/icons/pipette.js
var __iconNode1157 = [
  [
    "path",
    {
      d: "m12 9-8.414 8.414A2 2 0 0 0 3 18.828v1.344a2 2 0 0 1-.586 1.414A2 2 0 0 1 3.828 21h1.344a2 2 0 0 0 1.414-.586L15 12",
      key: "1y3wsu"
    }
  ],
  [
    "path",
    {
      d: "m18 9 .4.4a1 1 0 1 1-3 3l-3.8-3.8a1 1 0 1 1 3-3l.4.4 3.4-3.4a1 1 0 1 1 3 3z",
      key: "110lr1"
    }
  ],
  ["path", { d: "m2 22 .414-.414", key: "jhxm08" }]
];
var Pipette = createLucideIcon("pipette", __iconNode1157);

// ../node_modules/lucide-react/dist/esm/icons/plane-landing.js
var __iconNode1158 = [
  ["path", { d: "M2 22h20", key: "272qi7" }],
  [
    "path",
    {
      d: "M3.77 10.77 2 9l2-4.5 1.1.55c.55.28.9.84.9 1.45s.35 1.17.9 1.45L8 8.5l3-6 1.05.53a2 2 0 0 1 1.09 1.52l.72 5.4a2 2 0 0 0 1.09 1.52l4.4 2.2c.42.22.78.55 1.01.96l.6 1.03c.49.88-.06 1.98-1.06 2.1l-1.18.15c-.47.06-.95-.02-1.37-.24L4.29 11.15a2 2 0 0 1-.52-.38Z",
      key: "1ma21e"
    }
  ]
];
var PlaneLanding = createLucideIcon("plane-landing", __iconNode1158);

// ../node_modules/lucide-react/dist/esm/icons/pizza.js
var __iconNode1159 = [
  ["path", { d: "m12 14-1 1", key: "11onhr" }],
  ["path", { d: "m13.75 18.25-1.25 1.42", key: "1yisr3" }],
  ["path", { d: "M17.775 5.654a15.68 15.68 0 0 0-12.121 12.12", key: "1qtqk6" }],
  ["path", { d: "M18.8 9.3a1 1 0 0 0 2.1 7.7", key: "fbbbr2" }],
  [
    "path",
    {
      d: "M21.964 20.732a1 1 0 0 1-1.232 1.232l-18-5a1 1 0 0 1-.695-1.232A19.68 19.68 0 0 1 15.732 2.037a1 1 0 0 1 1.232.695z",
      key: "1hyfdd"
    }
  ]
];
var Pizza = createLucideIcon("pizza", __iconNode1159);

// ../node_modules/lucide-react/dist/esm/icons/plane-takeoff.js
var __iconNode1160 = [
  ["path", { d: "M2 22h20", key: "272qi7" }],
  [
    "path",
    {
      d: "M6.36 17.4 4 17l-2-4 1.1-.55a2 2 0 0 1 1.8 0l.17.1a2 2 0 0 0 1.8 0L8 12 5 6l.9-.45a2 2 0 0 1 2.09.2l4.02 3a2 2 0 0 0 2.1.2l4.19-2.06a2.41 2.41 0 0 1 1.73-.17L21 7a1.4 1.4 0 0 1 .87 1.99l-.38.76c-.23.46-.6.84-1.07 1.08L7.58 17.2a2 2 0 0 1-1.22.18Z",
      key: "fkigj9"
    }
  ]
];
var PlaneTakeoff = createLucideIcon("plane-takeoff", __iconNode1160);

// ../node_modules/lucide-react/dist/esm/icons/plane.js
var __iconNode1161 = [
  [
    "path",
    {
      d: "M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z",
      key: "1v9wt8"
    }
  ]
];
var Plane = createLucideIcon("plane", __iconNode1161);

// ../node_modules/lucide-react/dist/esm/icons/play.js
var __iconNode1162 = [
  [
    "path",
    {
      d: "M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",
      key: "10ikf1"
    }
  ]
];
var Play = createLucideIcon("play", __iconNode1162);

// ../node_modules/lucide-react/dist/esm/icons/plug-2.js
var __iconNode1163 = [
  ["path", { d: "M9 2v6", key: "17ngun" }],
  ["path", { d: "M15 2v6", key: "s7yy2p" }],
  ["path", { d: "M12 17v5", key: "bb1du9" }],
  ["path", { d: "M5 8h14", key: "pcz4l3" }],
  ["path", { d: "M6 11V8h12v3a6 6 0 1 1-12 0Z", key: "wtfw2c" }]
];
var Plug2 = createLucideIcon("plug-2", __iconNode1163);

// ../node_modules/lucide-react/dist/esm/icons/plug-zap.js
var __iconNode1164 = [
  [
    "path",
    { d: "M6.3 20.3a2.4 2.4 0 0 0 3.4 0L12 18l-6-6-2.3 2.3a2.4 2.4 0 0 0 0 3.4Z", key: "goz73y" }
  ],
  ["path", { d: "m2 22 3-3", key: "19mgm9" }],
  ["path", { d: "M7.5 13.5 10 11", key: "7xgeeb" }],
  ["path", { d: "M10.5 16.5 13 14", key: "10btkg" }],
  ["path", { d: "m18 3-4 4h6l-4 4", key: "16psg9" }]
];
var PlugZap = createLucideIcon("plug-zap", __iconNode1164);

// ../node_modules/lucide-react/dist/esm/icons/plug.js
var __iconNode1165 = [
  ["path", { d: "M12 22v-5", key: "1ega77" }],
  ["path", { d: "M15 8V2", key: "18g5xt" }],
  [
    "path",
    { d: "M17 8a1 1 0 0 1 1 1v4a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1z", key: "1xoxul" }
  ],
  ["path", { d: "M9 8V2", key: "14iosj" }]
];
var Plug = createLucideIcon("plug", __iconNode1165);

// ../node_modules/lucide-react/dist/esm/icons/plus.js
var __iconNode1166 = [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "M12 5v14", key: "s699le" }]
];
var Plus = createLucideIcon("plus", __iconNode1166);

// ../node_modules/lucide-react/dist/esm/icons/pocket-knife.js
var __iconNode1167 = [
  ["path", { d: "M3 2v1c0 1 2 1 2 2S3 6 3 7s2 1 2 2-2 1-2 2 2 1 2 2", key: "19w3oe" }],
  ["path", { d: "M18 6h.01", key: "1v4wsw" }],
  ["path", { d: "M6 18h.01", key: "uhywen" }],
  ["path", { d: "M20.83 8.83a4 4 0 0 0-5.66-5.66l-12 12a4 4 0 1 0 5.66 5.66Z", key: "6fykxj" }],
  ["path", { d: "M18 11.66V22a4 4 0 0 0 4-4V6", key: "1utzek" }]
];
var PocketKnife = createLucideIcon("pocket-knife", __iconNode1167);

// ../node_modules/lucide-react/dist/esm/icons/pocket.js
var __iconNode1168 = [
  ["path", { d: "M20 3a2 2 0 0 1 2 2v6a1 1 0 0 1-20 0V5a2 2 0 0 1 2-2z", key: "1uodqw" }],
  ["path", { d: "m8 10 4 4 4-4", key: "1mxd5q" }]
];
var Pocket = createLucideIcon("pocket", __iconNode1168);

// ../node_modules/lucide-react/dist/esm/icons/podcast.js
var __iconNode1169 = [
  [
    "path",
    { d: "M13 17a1 1 0 1 0-2 0l.5 4.5a0.5 0.5 0 0 0 1 0z", fill: "currentColor", key: "x1mxqr" }
  ],
  ["path", { d: "M16.85 18.58a9 9 0 1 0-9.7 0", key: "d71mpg" }],
  ["path", { d: "M8 14a5 5 0 1 1 8 0", key: "fc81rn" }],
  ["circle", { cx: "12", cy: "11", r: "1", fill: "currentColor", key: "vqiwd" }]
];
var Podcast = createLucideIcon("podcast", __iconNode1169);

// ../node_modules/lucide-react/dist/esm/icons/pointer-off.js
var __iconNode1170 = [
  ["path", { d: "M10 4.5V4a2 2 0 0 0-2.41-1.957", key: "jsi14n" }],
  ["path", { d: "M13.9 8.4a2 2 0 0 0-1.26-1.295", key: "hirc7f" }],
  [
    "path",
    { d: "M21.7 16.2A8 8 0 0 0 22 14v-3a2 2 0 1 0-4 0v-1a2 2 0 0 0-3.63-1.158", key: "1jxb2e" }
  ],
  [
    "path",
    {
      d: "m7 15-1.8-1.8a2 2 0 0 0-2.79 2.86L6 19.7a7.74 7.74 0 0 0 6 2.3h2a8 8 0 0 0 5.657-2.343",
      key: "10r7hm"
    }
  ],
  ["path", { d: "M6 6v8", key: "tv5xkp" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var PointerOff = createLucideIcon("pointer-off", __iconNode1170);

// ../node_modules/lucide-react/dist/esm/icons/pointer.js
var __iconNode1171 = [
  ["path", { d: "M22 14a8 8 0 0 1-8 8", key: "56vcr3" }],
  ["path", { d: "M18 11v-1a2 2 0 0 0-2-2a2 2 0 0 0-2 2", key: "1agjmk" }],
  ["path", { d: "M14 10V9a2 2 0 0 0-2-2a2 2 0 0 0-2 2v1", key: "wdbh2u" }],
  ["path", { d: "M10 9.5V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v10", key: "1ibuk9" }],
  [
    "path",
    {
      d: "M18 11a2 2 0 1 1 4 0v3a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15",
      key: "g6ys72"
    }
  ]
];
var Pointer = createLucideIcon("pointer", __iconNode1171);

// ../node_modules/lucide-react/dist/esm/icons/popcorn.js
var __iconNode1172 = [
  [
    "path",
    {
      d: "M18 8a2 2 0 0 0 0-4 2 2 0 0 0-4 0 2 2 0 0 0-4 0 2 2 0 0 0-4 0 2 2 0 0 0 0 4",
      key: "10td1f"
    }
  ],
  ["path", { d: "M10 22 9 8", key: "yjptiv" }],
  ["path", { d: "m14 22 1-14", key: "8jwc8b" }],
  [
    "path",
    {
      d: "M20 8c.5 0 .9.4.8 1l-2.6 12c-.1.5-.7 1-1.2 1H7c-.6 0-1.1-.4-1.2-1L3.2 9c-.1-.6.3-1 .8-1Z",
      key: "1qo33t"
    }
  ]
];
var Popcorn = createLucideIcon("popcorn", __iconNode1172);

// ../node_modules/lucide-react/dist/esm/icons/popsicle.js
var __iconNode1173 = [
  [
    "path",
    {
      d: "M18.6 14.4c.8-.8.8-2 0-2.8l-8.1-8.1a4.95 4.95 0 1 0-7.1 7.1l8.1 8.1c.9.7 2.1.7 2.9-.1Z",
      key: "1o68ps"
    }
  ],
  ["path", { d: "m22 22-5.5-5.5", key: "17o70y" }]
];
var Popsicle = createLucideIcon("popsicle", __iconNode1173);

// ../node_modules/lucide-react/dist/esm/icons/pound-sterling.js
var __iconNode1174 = [
  ["path", { d: "M18 7c0-5.333-8-5.333-8 0", key: "1prm2n" }],
  ["path", { d: "M10 7v14", key: "18tmcs" }],
  ["path", { d: "M6 21h12", key: "4dkmi1" }],
  ["path", { d: "M6 13h10", key: "ybwr4a" }]
];
var PoundSterling = createLucideIcon("pound-sterling", __iconNode1174);

// ../node_modules/lucide-react/dist/esm/icons/power-off.js
var __iconNode1175 = [
  ["path", { d: "M18.36 6.64A9 9 0 0 1 20.77 15", key: "dxknvb" }],
  ["path", { d: "M6.16 6.16a9 9 0 1 0 12.68 12.68", key: "1x7qb5" }],
  ["path", { d: "M12 2v4", key: "3427ic" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var PowerOff = createLucideIcon("power-off", __iconNode1175);

// ../node_modules/lucide-react/dist/esm/icons/power.js
var __iconNode1176 = [
  ["path", { d: "M12 2v10", key: "mnfbl" }],
  ["path", { d: "M18.4 6.6a9 9 0 1 1-12.77.04", key: "obofu9" }]
];
var Power = createLucideIcon("power", __iconNode1176);

// ../node_modules/lucide-react/dist/esm/icons/presentation.js
var __iconNode1177 = [
  ["path", { d: "M2 3h20", key: "91anmk" }],
  ["path", { d: "M21 3v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V3", key: "2k9sn8" }],
  ["path", { d: "m7 21 5-5 5 5", key: "bip4we" }]
];
var Presentation = createLucideIcon("presentation", __iconNode1177);

// ../node_modules/lucide-react/dist/esm/icons/printer-check.js
var __iconNode1178 = [
  ["path", { d: "M13.5 22H7a1 1 0 0 1-1-1v-6a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v.5", key: "qeb09x" }],
  ["path", { d: "m16 19 2 2 4-4", key: "1b14m6" }],
  ["path", { d: "M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v2", key: "1md90i" }],
  ["path", { d: "M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6", key: "1itne7" }]
];
var PrinterCheck = createLucideIcon("printer-check", __iconNode1178);

// ../node_modules/lucide-react/dist/esm/icons/printer.js
var __iconNode1179 = [
  [
    "path",
    {
      d: "M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",
      key: "143wyd"
    }
  ],
  ["path", { d: "M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6", key: "1itne7" }],
  ["rect", { x: "6", y: "14", width: "12", height: "8", rx: "1", key: "1ue0tg" }]
];
var Printer = createLucideIcon("printer", __iconNode1179);

// ../node_modules/lucide-react/dist/esm/icons/printer-x.js
var __iconNode1180 = [
  ["path", { d: "M12.531 22H7a1 1 0 0 1-1-1v-6a1 1 0 0 1 1-1h6.377", key: "1w39xo" }],
  ["path", { d: "m16.5 16.5 5 5", key: "zc9lw7" }],
  ["path", { d: "m16.5 21.5 5-5", key: "1fr29m" }],
  ["path", { d: "M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v1.5", key: "18he39" }],
  ["path", { d: "M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6", key: "1itne7" }]
];
var PrinterX = createLucideIcon("printer-x", __iconNode1180);

// ../node_modules/lucide-react/dist/esm/icons/projector.js
var __iconNode1181 = [
  ["path", { d: "M5 7 3 5", key: "1yys58" }],
  ["path", { d: "M9 6V3", key: "1ptz9u" }],
  ["path", { d: "m13 7 2-2", key: "1w3vmq" }],
  ["circle", { cx: "9", cy: "13", r: "3", key: "1mma13" }],
  [
    "path",
    {
      d: "M11.83 12H20a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h2.17",
      key: "2frwzc"
    }
  ],
  ["path", { d: "M16 16h2", key: "dnq2od" }]
];
var Projector = createLucideIcon("projector", __iconNode1181);

// ../node_modules/lucide-react/dist/esm/icons/proportions.js
var __iconNode1182 = [
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }],
  ["path", { d: "M12 9v11", key: "1fnkrn" }],
  ["path", { d: "M2 9h13a2 2 0 0 1 2 2v9", key: "11z3ex" }]
];
var Proportions = createLucideIcon("proportions", __iconNode1182);

// ../node_modules/lucide-react/dist/esm/icons/pyramid.js
var __iconNode1183 = [
  [
    "path",
    {
      d: "M2.5 16.88a1 1 0 0 1-.32-1.43l9-13.02a1 1 0 0 1 1.64 0l9 13.01a1 1 0 0 1-.32 1.44l-8.51 4.86a2 2 0 0 1-1.98 0Z",
      key: "aenxs0"
    }
  ],
  ["path", { d: "M12 2v20", key: "t6zp3m" }]
];
var Pyramid = createLucideIcon("pyramid", __iconNode1183);

// ../node_modules/lucide-react/dist/esm/icons/puzzle.js
var __iconNode1184 = [
  [
    "path",
    {
      d: "M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z",
      key: "w46dr5"
    }
  ]
];
var Puzzle = createLucideIcon("puzzle", __iconNode1184);

// ../node_modules/lucide-react/dist/esm/icons/qr-code.js
var __iconNode1185 = [
  ["rect", { width: "5", height: "5", x: "3", y: "3", rx: "1", key: "1tu5fj" }],
  ["rect", { width: "5", height: "5", x: "16", y: "3", rx: "1", key: "1v8r4q" }],
  ["rect", { width: "5", height: "5", x: "3", y: "16", rx: "1", key: "1x03jg" }],
  ["path", { d: "M21 16h-3a2 2 0 0 0-2 2v3", key: "177gqh" }],
  ["path", { d: "M21 21v.01", key: "ents32" }],
  ["path", { d: "M12 7v3a2 2 0 0 1-2 2H7", key: "8crl2c" }],
  ["path", { d: "M3 12h.01", key: "nlz23k" }],
  ["path", { d: "M12 3h.01", key: "n36tog" }],
  ["path", { d: "M12 16v.01", key: "133mhm" }],
  ["path", { d: "M16 12h1", key: "1slzba" }],
  ["path", { d: "M21 12v.01", key: "1lwtk9" }],
  ["path", { d: "M12 21v-1", key: "1880an" }]
];
var QrCode = createLucideIcon("qr-code", __iconNode1185);

// ../node_modules/lucide-react/dist/esm/icons/quote.js
var __iconNode1186 = [
  [
    "path",
    {
      d: "M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z",
      key: "rib7q0"
    }
  ],
  [
    "path",
    {
      d: "M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z",
      key: "1ymkrd"
    }
  ]
];
var Quote = createLucideIcon("quote", __iconNode1186);

// ../node_modules/lucide-react/dist/esm/icons/rabbit.js
var __iconNode1187 = [
  ["path", { d: "M13 16a3 3 0 0 1 2.24 5", key: "1epib5" }],
  ["path", { d: "M18 12h.01", key: "yjnet6" }],
  [
    "path",
    {
      d: "M18 21h-8a4 4 0 0 1-4-4 7 7 0 0 1 7-7h.2L9.6 6.4a1 1 0 1 1 2.8-2.8L15.8 7h.2c3.3 0 6 2.7 6 6v1a2 2 0 0 1-2 2h-1a3 3 0 0 0-3 3",
      key: "ue9ozu"
    }
  ],
  ["path", { d: "M20 8.54V4a2 2 0 1 0-4 0v3", key: "49iql8" }],
  ["path", { d: "M7.612 12.524a3 3 0 1 0-1.6 4.3", key: "1e33i0" }]
];
var Rabbit = createLucideIcon("rabbit", __iconNode1187);

// ../node_modules/lucide-react/dist/esm/icons/radar.js
var __iconNode1188 = [
  ["path", { d: "M19.07 4.93A10 10 0 0 0 6.99 3.34", key: "z3du51" }],
  ["path", { d: "M4 6h.01", key: "oypzma" }],
  ["path", { d: "M2.29 9.62A10 10 0 1 0 21.31 8.35", key: "qzzz0" }],
  ["path", { d: "M16.24 7.76A6 6 0 1 0 8.23 16.67", key: "1yjesh" }],
  ["path", { d: "M12 18h.01", key: "mhygvu" }],
  ["path", { d: "M17.99 11.66A6 6 0 0 1 15.77 16.67", key: "1u2y91" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }],
  ["path", { d: "m13.41 10.59 5.66-5.66", key: "mhq4k0" }]
];
var Radar = createLucideIcon("radar", __iconNode1188);

// ../node_modules/lucide-react/dist/esm/icons/radiation.js
var __iconNode1189 = [
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  [
    "path",
    {
      d: "M14 15.4641a4 4 0 0 1-4 0L7.52786 19.74597 A 1 1 0 0 0 7.99303 21.16211 10 10 0 0 0 16.00697 21.16211 1 1 0 0 0 16.47214 19.74597z",
      key: "1y4lzb"
    }
  ],
  [
    "path",
    {
      d: "M16 12a4 4 0 0 0-2-3.464l2.472-4.282a1 1 0 0 1 1.46-.305 10 10 0 0 1 4.006 6.94A1 1 0 0 1 21 12z",
      key: "163ggk"
    }
  ],
  [
    "path",
    {
      d: "M8 12a4 4 0 0 1 2-3.464L7.528 4.254a1 1 0 0 0-1.46-.305 10 10 0 0 0-4.006 6.94A1 1 0 0 0 3 12z",
      key: "1l9i0b"
    }
  ]
];
var Radiation = createLucideIcon("radiation", __iconNode1189);

// ../node_modules/lucide-react/dist/esm/icons/radical.js
var __iconNode1190 = [
  [
    "path",
    {
      d: "M3 12h3.28a1 1 0 0 1 .948.684l2.298 7.934a.5.5 0 0 0 .96-.044L13.82 4.771A1 1 0 0 1 14.792 4H21",
      key: "1mqj8i"
    }
  ]
];
var Radical = createLucideIcon("radical", __iconNode1190);

// ../node_modules/lucide-react/dist/esm/icons/radio-receiver.js
var __iconNode1191 = [
  ["path", { d: "M5 16v2", key: "g5qcv5" }],
  ["path", { d: "M19 16v2", key: "1gbaio" }],
  ["rect", { width: "20", height: "8", x: "2", y: "8", rx: "2", key: "vjsjur" }],
  ["path", { d: "M18 12h.01", key: "yjnet6" }]
];
var RadioReceiver = createLucideIcon("radio-receiver", __iconNode1191);

// ../node_modules/lucide-react/dist/esm/icons/radio-tower.js
var __iconNode1192 = [
  ["path", { d: "M4.9 16.1C1 12.2 1 5.8 4.9 1.9", key: "s0qx1y" }],
  ["path", { d: "M7.8 4.7a6.14 6.14 0 0 0-.8 7.5", key: "1idnkw" }],
  ["circle", { cx: "12", cy: "9", r: "2", key: "1092wv" }],
  ["path", { d: "M16.2 4.8c2 2 2.26 5.11.8 7.47", key: "ojru2q" }],
  ["path", { d: "M19.1 1.9a9.96 9.96 0 0 1 0 14.1", key: "rhi7fg" }],
  ["path", { d: "M9.5 18h5", key: "mfy3pd" }],
  ["path", { d: "m8 22 4-11 4 11", key: "25yftu" }]
];
var RadioTower = createLucideIcon("radio-tower", __iconNode1192);

// ../node_modules/lucide-react/dist/esm/icons/radio.js
var __iconNode1193 = [
  ["path", { d: "M16.247 7.761a6 6 0 0 1 0 8.478", key: "1fwjs5" }],
  ["path", { d: "M19.075 4.933a10 10 0 0 1 0 14.134", key: "ehdyv1" }],
  ["path", { d: "M4.925 19.067a10 10 0 0 1 0-14.134", key: "1q22gi" }],
  ["path", { d: "M7.753 16.239a6 6 0 0 1 0-8.478", key: "r2q7qm" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }]
];
var Radio = createLucideIcon("radio", __iconNode1193);

// ../node_modules/lucide-react/dist/esm/icons/radius.js
var __iconNode1194 = [
  ["path", { d: "M20.34 17.52a10 10 0 1 0-2.82 2.82", key: "fydyku" }],
  ["circle", { cx: "19", cy: "19", r: "2", key: "17f5cg" }],
  ["path", { d: "m13.41 13.41 4.18 4.18", key: "1gqbwc" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }]
];
var Radius = createLucideIcon("radius", __iconNode1194);

// ../node_modules/lucide-react/dist/esm/icons/rail-symbol.js
var __iconNode1195 = [
  ["path", { d: "M5 15h14", key: "m0yey3" }],
  ["path", { d: "M5 9h14", key: "7tsvo6" }],
  ["path", { d: "m14 20-5-5 6-6-5-5", key: "1jo42i" }]
];
var RailSymbol = createLucideIcon("rail-symbol", __iconNode1195);

// ../node_modules/lucide-react/dist/esm/icons/rainbow.js
var __iconNode1196 = [
  ["path", { d: "M22 17a10 10 0 0 0-20 0", key: "ozegv" }],
  ["path", { d: "M6 17a6 6 0 0 1 12 0", key: "5giftw" }],
  ["path", { d: "M10 17a2 2 0 0 1 4 0", key: "gnsikk" }]
];
var Rainbow = createLucideIcon("rainbow", __iconNode1196);

// ../node_modules/lucide-react/dist/esm/icons/rat.js
var __iconNode1197 = [
  ["path", { d: "M13 22H4a2 2 0 0 1 0-4h12", key: "bt3f23" }],
  ["path", { d: "M13.236 18a3 3 0 0 0-2.2-5", key: "1tbvmo" }],
  ["path", { d: "M16 9h.01", key: "1bdo4e" }],
  [
    "path",
    {
      d: "M16.82 3.94a3 3 0 1 1 3.237 4.868l1.815 2.587a1.5 1.5 0 0 1-1.5 2.1l-2.872-.453a3 3 0 0 0-3.5 3",
      key: "9ch7kn"
    }
  ],
  ["path", { d: "M17 4.988a3 3 0 1 0-5.2 2.052A7 7 0 0 0 4 14.015 4 4 0 0 0 8 18", key: "3s7e9i" }]
];
var Rat = createLucideIcon("rat", __iconNode1197);

// ../node_modules/lucide-react/dist/esm/icons/ratio.js
var __iconNode1198 = [
  ["rect", { width: "12", height: "20", x: "6", y: "2", rx: "2", key: "1oxtiu" }],
  ["rect", { width: "20", height: "12", x: "2", y: "6", rx: "2", key: "9lu3g6" }]
];
var Ratio = createLucideIcon("ratio", __iconNode1198);

// ../node_modules/lucide-react/dist/esm/icons/receipt-cent.js
var __iconNode1199 = [
  [
    "path",
    { d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z", key: "q3az6g" }
  ],
  ["path", { d: "M12 6.5v11", key: "ecfhkf" }],
  ["path", { d: "M15 9.4a4 4 0 1 0 0 5.2", key: "1makmb" }]
];
var ReceiptCent = createLucideIcon("receipt-cent", __iconNode1199);

// ../node_modules/lucide-react/dist/esm/icons/receipt-indian-rupee.js
var __iconNode1200 = [
  [
    "path",
    { d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z", key: "q3az6g" }
  ],
  ["path", { d: "M8 7h8", key: "i86dvs" }],
  ["path", { d: "M12 17.5 8 15h1a4 4 0 0 0 0-8", key: "grpkl4" }],
  ["path", { d: "M8 11h8", key: "vwpz6n" }]
];
var ReceiptIndianRupee = createLucideIcon("receipt-indian-rupee", __iconNode1200);

// ../node_modules/lucide-react/dist/esm/icons/receipt-euro.js
var __iconNode1201 = [
  [
    "path",
    { d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z", key: "q3az6g" }
  ],
  ["path", { d: "M8 12h5", key: "1g6qi8" }],
  ["path", { d: "M16 9.5a4 4 0 1 0 0 5.2", key: "b2px4r" }]
];
var ReceiptEuro = createLucideIcon("receipt-euro", __iconNode1201);

// ../node_modules/lucide-react/dist/esm/icons/receipt-japanese-yen.js
var __iconNode1202 = [
  [
    "path",
    { d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z", key: "q3az6g" }
  ],
  ["path", { d: "m12 10 3-3", key: "1mc12w" }],
  ["path", { d: "m9 7 3 3v7.5", key: "39i0xv" }],
  ["path", { d: "M9 11h6", key: "1fldmi" }],
  ["path", { d: "M9 15h6", key: "cctwl0" }]
];
var ReceiptJapaneseYen = createLucideIcon("receipt-japanese-yen", __iconNode1202);

// ../node_modules/lucide-react/dist/esm/icons/receipt-pound-sterling.js
var __iconNode1203 = [
  [
    "path",
    { d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z", key: "q3az6g" }
  ],
  ["path", { d: "M8 13h5", key: "1k9z8w" }],
  ["path", { d: "M10 17V9.5a2.5 2.5 0 0 1 5 0", key: "1dzgp0" }],
  ["path", { d: "M8 17h7", key: "8mjdqu" }]
];
var ReceiptPoundSterling = createLucideIcon("receipt-pound-sterling", __iconNode1203);

// ../node_modules/lucide-react/dist/esm/icons/receipt-russian-ruble.js
var __iconNode1204 = [
  [
    "path",
    { d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z", key: "q3az6g" }
  ],
  ["path", { d: "M8 15h5", key: "vxg57a" }],
  ["path", { d: "M8 11h5a2 2 0 1 0 0-4h-3v10", key: "1usi5u" }]
];
var ReceiptRussianRuble = createLucideIcon("receipt-russian-ruble", __iconNode1204);

// ../node_modules/lucide-react/dist/esm/icons/receipt-swiss-franc.js
var __iconNode1205 = [
  [
    "path",
    { d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z", key: "q3az6g" }
  ],
  ["path", { d: "M10 17V7h5", key: "k7jq18" }],
  ["path", { d: "M10 11h4", key: "1i0mka" }],
  ["path", { d: "M8 15h5", key: "vxg57a" }]
];
var ReceiptSwissFranc = createLucideIcon("receipt-swiss-franc", __iconNode1205);

// ../node_modules/lucide-react/dist/esm/icons/receipt.js
var __iconNode1206 = [
  [
    "path",
    { d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z", key: "q3az6g" }
  ],
  ["path", { d: "M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8", key: "1h4pet" }],
  ["path", { d: "M12 17.5v-11", key: "1jc1ny" }]
];
var Receipt = createLucideIcon("receipt", __iconNode1206);

// ../node_modules/lucide-react/dist/esm/icons/receipt-turkish-lira.js
var __iconNode1207 = [
  ["path", { d: "M10 6.5v11a5.5 5.5 0 0 0 5.5-5.5", key: "nw10mp" }],
  ["path", { d: "m14 8-6 3", key: "2tb98i" }],
  [
    "path",
    { d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1z", key: "io9ry0" }
  ]
];
var ReceiptTurkishLira = createLucideIcon("receipt-turkish-lira", __iconNode1207);

// ../node_modules/lucide-react/dist/esm/icons/receipt-text.js
var __iconNode1208 = [
  ["path", { d: "M13 16H8", key: "wsln4y" }],
  ["path", { d: "M14 8H8", key: "1l3xfs" }],
  ["path", { d: "M16 12H8", key: "1fr5h0" }],
  [
    "path",
    {
      d: "M4 3a1 1 0 0 1 1-1 1.3 1.3 0 0 1 .7.2l.933.6a1.3 1.3 0 0 0 1.4 0l.934-.6a1.3 1.3 0 0 1 1.4 0l.933.6a1.3 1.3 0 0 0 1.4 0l.933-.6a1.3 1.3 0 0 1 1.4 0l.934.6a1.3 1.3 0 0 0 1.4 0l.933-.6A1.3 1.3 0 0 1 19 2a1 1 0 0 1 1 1v18a1 1 0 0 1-1 1 1.3 1.3 0 0 1-.7-.2l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.934.6a1.3 1.3 0 0 1-1.4 0l-.933-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-1.4 0l-.934-.6a1.3 1.3 0 0 0-1.4 0l-.933.6a1.3 1.3 0 0 1-.7.2 1 1 0 0 1-1-1z",
      key: "ycz6yz"
    }
  ]
];
var ReceiptText = createLucideIcon("receipt-text", __iconNode1208);

// ../node_modules/lucide-react/dist/esm/icons/rectangle-ellipsis.js
var __iconNode1209 = [
  ["rect", { width: "20", height: "12", x: "2", y: "6", rx: "2", key: "9lu3g6" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M17 12h.01", key: "1m0b6t" }],
  ["path", { d: "M7 12h.01", key: "eqddd0" }]
];
var RectangleEllipsis = createLucideIcon("rectangle-ellipsis", __iconNode1209);

// ../node_modules/lucide-react/dist/esm/icons/rectangle-circle.js
var __iconNode1210 = [
  ["path", { d: "M14 4v16H3a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z", key: "1m5n7q" }],
  ["circle", { cx: "14", cy: "12", r: "8", key: "1pag6k" }]
];
var RectangleCircle = createLucideIcon("rectangle-circle", __iconNode1210);

// ../node_modules/lucide-react/dist/esm/icons/rectangle-horizontal.js
var __iconNode1211 = [
  ["rect", { width: "20", height: "12", x: "2", y: "6", rx: "2", key: "9lu3g6" }]
];
var RectangleHorizontal = createLucideIcon("rectangle-horizontal", __iconNode1211);

// ../node_modules/lucide-react/dist/esm/icons/rectangle-goggles.js
var __iconNode1212 = [
  [
    "path",
    {
      d: "M20 6a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-4a2 2 0 0 1-1.6-.8l-1.6-2.13a1 1 0 0 0-1.6 0L9.6 17.2A2 2 0 0 1 8 18H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z",
      key: "d5y1f"
    }
  ]
];
var RectangleGoggles = createLucideIcon("rectangle-goggles", __iconNode1212);

// ../node_modules/lucide-react/dist/esm/icons/rectangle-vertical.js
var __iconNode1213 = [
  ["rect", { width: "12", height: "20", x: "6", y: "2", rx: "2", key: "1oxtiu" }]
];
var RectangleVertical = createLucideIcon("rectangle-vertical", __iconNode1213);

// ../node_modules/lucide-react/dist/esm/icons/recycle.js
var __iconNode1214 = [
  [
    "path",
    {
      d: "M7 19H4.815a1.83 1.83 0 0 1-1.57-.881 1.785 1.785 0 0 1-.004-1.784L7.196 9.5",
      key: "x6z5xu"
    }
  ],
  [
    "path",
    {
      d: "M11 19h8.203a1.83 1.83 0 0 0 1.556-.89 1.784 1.784 0 0 0 0-1.775l-1.226-2.12",
      key: "1x4zh5"
    }
  ],
  ["path", { d: "m14 16-3 3 3 3", key: "f6jyew" }],
  ["path", { d: "M8.293 13.596 7.196 9.5 3.1 10.598", key: "wf1obh" }],
  [
    "path",
    {
      d: "m9.344 5.811 1.093-1.892A1.83 1.83 0 0 1 11.985 3a1.784 1.784 0 0 1 1.546.888l3.943 6.843",
      key: "9tzpgr"
    }
  ],
  ["path", { d: "m13.378 9.633 4.096 1.098 1.097-4.096", key: "1oe83g" }]
];
var Recycle = createLucideIcon("recycle", __iconNode1214);

// ../node_modules/lucide-react/dist/esm/icons/redo-2.js
var __iconNode1215 = [
  ["path", { d: "m15 14 5-5-5-5", key: "12vg1m" }],
  ["path", { d: "M20 9H9.5A5.5 5.5 0 0 0 4 14.5A5.5 5.5 0 0 0 9.5 20H13", key: "6uklza" }]
];
var Redo2 = createLucideIcon("redo-2", __iconNode1215);

// ../node_modules/lucide-react/dist/esm/icons/redo-dot.js
var __iconNode1216 = [
  ["circle", { cx: "12", cy: "17", r: "1", key: "1ixnty" }],
  ["path", { d: "M21 7v6h-6", key: "3ptur4" }],
  ["path", { d: "M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3l3 2.7", key: "1kgawr" }]
];
var RedoDot = createLucideIcon("redo-dot", __iconNode1216);

// ../node_modules/lucide-react/dist/esm/icons/redo.js
var __iconNode1217 = [
  ["path", { d: "M21 7v6h-6", key: "3ptur4" }],
  ["path", { d: "M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3l3 2.7", key: "1kgawr" }]
];
var Redo = createLucideIcon("redo", __iconNode1217);

// ../node_modules/lucide-react/dist/esm/icons/refresh-ccw-dot.js
var __iconNode1218 = [
  ["path", { d: "M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "14sxne" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }],
  ["path", { d: "M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16", key: "1hlbsb" }],
  ["path", { d: "M16 16h5v5", key: "ccwih5" }],
  ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }]
];
var RefreshCcwDot = createLucideIcon("refresh-ccw-dot", __iconNode1218);

// ../node_modules/lucide-react/dist/esm/icons/refresh-ccw.js
var __iconNode1219 = [
  ["path", { d: "M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "14sxne" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }],
  ["path", { d: "M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16", key: "1hlbsb" }],
  ["path", { d: "M16 16h5v5", key: "ccwih5" }]
];
var RefreshCcw = createLucideIcon("refresh-ccw", __iconNode1219);

// ../node_modules/lucide-react/dist/esm/icons/refresh-cw-off.js
var __iconNode1220 = [
  ["path", { d: "M21 8L18.74 5.74A9.75 9.75 0 0 0 12 3C11 3 10.03 3.16 9.13 3.47", key: "1krf6h" }],
  ["path", { d: "M8 16H3v5", key: "1cv678" }],
  ["path", { d: "M3 12C3 9.51 4 7.26 5.64 5.64", key: "ruvoct" }],
  ["path", { d: "m3 16 2.26 2.26A9.75 9.75 0 0 0 12 21c2.49 0 4.74-1 6.36-2.64", key: "19q130" }],
  ["path", { d: "M21 12c0 1-.16 1.97-.47 2.87", key: "4w8emr" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }],
  ["path", { d: "M22 22 2 2", key: "1r8tn9" }]
];
var RefreshCwOff = createLucideIcon("refresh-cw-off", __iconNode1220);

// ../node_modules/lucide-react/dist/esm/icons/refresh-cw.js
var __iconNode1221 = [
  ["path", { d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8", key: "v9h5vc" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }],
  ["path", { d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16", key: "3uifl3" }],
  ["path", { d: "M8 16H3v5", key: "1cv678" }]
];
var RefreshCw = createLucideIcon("refresh-cw", __iconNode1221);

// ../node_modules/lucide-react/dist/esm/icons/refrigerator.js
var __iconNode1222 = [
  [
    "path",
    { d: "M5 6a4 4 0 0 1 4-4h6a4 4 0 0 1 4 4v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6Z", key: "fpq118" }
  ],
  ["path", { d: "M5 10h14", key: "elsbfy" }],
  ["path", { d: "M15 7v6", key: "1nx30x" }]
];
var Refrigerator = createLucideIcon("refrigerator", __iconNode1222);

// ../node_modules/lucide-react/dist/esm/icons/regex.js
var __iconNode1223 = [
  ["path", { d: "M17 3v10", key: "15fgeh" }],
  ["path", { d: "m12.67 5.5 8.66 5", key: "1gpheq" }],
  ["path", { d: "m12.67 10.5 8.66-5", key: "1dkfa6" }],
  [
    "path",
    { d: "M9 17a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v2a2 2 0 0 0 2 2h2a2 2 0 0 0 2-2v-2z", key: "swwfx4" }
  ]
];
var Regex = createLucideIcon("regex", __iconNode1223);

// ../node_modules/lucide-react/dist/esm/icons/remove-formatting.js
var __iconNode1224 = [
  ["path", { d: "M4 7V4h16v3", key: "9msm58" }],
  ["path", { d: "M5 20h6", key: "1h6pxn" }],
  ["path", { d: "M13 4 8 20", key: "kqq6aj" }],
  ["path", { d: "m15 15 5 5", key: "me55sn" }],
  ["path", { d: "m20 15-5 5", key: "11p7ol" }]
];
var RemoveFormatting = createLucideIcon("remove-formatting", __iconNode1224);

// ../node_modules/lucide-react/dist/esm/icons/repeat-1.js
var __iconNode1225 = [
  ["path", { d: "m17 2 4 4-4 4", key: "nntrym" }],
  ["path", { d: "M3 11v-1a4 4 0 0 1 4-4h14", key: "84bu3i" }],
  ["path", { d: "m7 22-4-4 4-4", key: "1wqhfi" }],
  ["path", { d: "M21 13v1a4 4 0 0 1-4 4H3", key: "1rx37r" }],
  ["path", { d: "M11 10h1v4", key: "70cz1p" }]
];
var Repeat1 = createLucideIcon("repeat-1", __iconNode1225);

// ../node_modules/lucide-react/dist/esm/icons/repeat-2.js
var __iconNode1226 = [
  ["path", { d: "m2 9 3-3 3 3", key: "1ltn5i" }],
  ["path", { d: "M13 18H7a2 2 0 0 1-2-2V6", key: "1r6tfw" }],
  ["path", { d: "m22 15-3 3-3-3", key: "4rnwn2" }],
  ["path", { d: "M11 6h6a2 2 0 0 1 2 2v10", key: "2f72bc" }]
];
var Repeat2 = createLucideIcon("repeat-2", __iconNode1226);

// ../node_modules/lucide-react/dist/esm/icons/repeat.js
var __iconNode1227 = [
  ["path", { d: "m17 2 4 4-4 4", key: "nntrym" }],
  ["path", { d: "M3 11v-1a4 4 0 0 1 4-4h14", key: "84bu3i" }],
  ["path", { d: "m7 22-4-4 4-4", key: "1wqhfi" }],
  ["path", { d: "M21 13v1a4 4 0 0 1-4 4H3", key: "1rx37r" }]
];
var Repeat = createLucideIcon("repeat", __iconNode1227);

// ../node_modules/lucide-react/dist/esm/icons/replace-all.js
var __iconNode1228 = [
  ["path", { d: "M14 14a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1", key: "zg1ipl" }],
  ["path", { d: "M14 4a1 1 0 0 1 1-1", key: "dhj8ez" }],
  ["path", { d: "M15 10a1 1 0 0 1-1-1", key: "1mnyi5" }],
  ["path", { d: "M19 14a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1", key: "txt6k4" }],
  ["path", { d: "M21 4a1 1 0 0 0-1-1", key: "sfs9ap" }],
  ["path", { d: "M21 9a1 1 0 0 1-1 1", key: "mp6qeo" }],
  ["path", { d: "m3 7 3 3 3-3", key: "x25e72" }],
  ["path", { d: "M6 10V5a2 2 0 0 1 2-2h2", key: "15xut4" }],
  ["rect", { x: "3", y: "14", width: "7", height: "7", rx: "1", key: "1bkyp8" }]
];
var ReplaceAll = createLucideIcon("replace-all", __iconNode1228);

// ../node_modules/lucide-react/dist/esm/icons/replace.js
var __iconNode1229 = [
  ["path", { d: "M14 4a1 1 0 0 1 1-1", key: "dhj8ez" }],
  ["path", { d: "M15 10a1 1 0 0 1-1-1", key: "1mnyi5" }],
  ["path", { d: "M21 4a1 1 0 0 0-1-1", key: "sfs9ap" }],
  ["path", { d: "M21 9a1 1 0 0 1-1 1", key: "mp6qeo" }],
  ["path", { d: "m3 7 3 3 3-3", key: "x25e72" }],
  ["path", { d: "M6 10V5a2 2 0 0 1 2-2h2", key: "15xut4" }],
  ["rect", { x: "3", y: "14", width: "7", height: "7", rx: "1", key: "1bkyp8" }]
];
var Replace = createLucideIcon("replace", __iconNode1229);

// ../node_modules/lucide-react/dist/esm/icons/reply-all.js
var __iconNode1230 = [
  ["path", { d: "m12 17-5-5 5-5", key: "1s3y5u" }],
  ["path", { d: "M22 18v-2a4 4 0 0 0-4-4H7", key: "1fcyog" }],
  ["path", { d: "m7 17-5-5 5-5", key: "1ed8i2" }]
];
var ReplyAll = createLucideIcon("reply-all", __iconNode1230);

// ../node_modules/lucide-react/dist/esm/icons/reply.js
var __iconNode1231 = [
  ["path", { d: "M20 18v-2a4 4 0 0 0-4-4H4", key: "5vmcpk" }],
  ["path", { d: "m9 17-5-5 5-5", key: "nvlc11" }]
];
var Reply = createLucideIcon("reply", __iconNode1231);

// ../node_modules/lucide-react/dist/esm/icons/rewind.js
var __iconNode1232 = [
  [
    "path",
    { d: "M12 6a2 2 0 0 0-3.414-1.414l-6 6a2 2 0 0 0 0 2.828l6 6A2 2 0 0 0 12 18z", key: "2a1g8i" }
  ],
  [
    "path",
    { d: "M22 6a2 2 0 0 0-3.414-1.414l-6 6a2 2 0 0 0 0 2.828l6 6A2 2 0 0 0 22 18z", key: "rg3s36" }
  ]
];
var Rewind = createLucideIcon("rewind", __iconNode1232);

// ../node_modules/lucide-react/dist/esm/icons/ribbon.js
var __iconNode1233 = [
  [
    "path",
    { d: "M12 11.22C11 9.997 10 9 10 8a2 2 0 0 1 4 0c0 1-.998 2.002-2.01 3.22", key: "1rnhq3" }
  ],
  ["path", { d: "m12 18 2.57-3.5", key: "116vt7" }],
  ["path", { d: "M6.243 9.016a7 7 0 0 1 11.507-.009", key: "10dq0b" }],
  ["path", { d: "M9.35 14.53 12 11.22", key: "tdsyp2" }],
  [
    "path",
    {
      d: "M9.35 14.53C7.728 12.246 6 10.221 6 7a6 5 0 0 1 12 0c-.005 3.22-1.778 5.235-3.43 7.5l3.557 4.527a1 1 0 0 1-.203 1.43l-1.894 1.36a1 1 0 0 1-1.384-.215L12 18l-2.679 3.593a1 1 0 0 1-1.39.213l-1.865-1.353a1 1 0 0 1-.203-1.422z",
      key: "nmifey"
    }
  ]
];
var Ribbon = createLucideIcon("ribbon", __iconNode1233);

// ../node_modules/lucide-react/dist/esm/icons/rocket.js
var __iconNode1234 = [
  ["path", { d: "M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5", key: "qeys4" }],
  [
    "path",
    {
      d: "M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09",
      key: "u4xsad"
    }
  ],
  [
    "path",
    {
      d: "M9 12a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.4 22.4 0 0 1-4 2z",
      key: "676m9"
    }
  ],
  ["path", { d: "M9 12H4s.55-3.03 2-4c1.62-1.08 5 .05 5 .05", key: "92ym6u" }]
];
var Rocket = createLucideIcon("rocket", __iconNode1234);

// ../node_modules/lucide-react/dist/esm/icons/rocking-chair.js
var __iconNode1235 = [
  ["path", { d: "m15 13 3.708 7.416", key: "1edxn9" }],
  ["path", { d: "M3 19a15 15 0 0 0 18 0", key: "d0d1c4" }],
  ["path", { d: "m3 2 3.21 9.633A2 2 0 0 0 8.109 13H18", key: "tpa4et" }],
  ["path", { d: "m9 13-3.708 7.416", key: "1oplxx" }]
];
var RockingChair = createLucideIcon("rocking-chair", __iconNode1235);

// ../node_modules/lucide-react/dist/esm/icons/roller-coaster.js
var __iconNode1236 = [
  ["path", { d: "M6 19V5", key: "1r845m" }],
  ["path", { d: "M10 19V6.8", key: "9j2tfs" }],
  ["path", { d: "M14 19v-7.8", key: "10s8qv" }],
  ["path", { d: "M18 5v4", key: "1tajlv" }],
  ["path", { d: "M18 19v-6", key: "ielfq3" }],
  ["path", { d: "M22 19V9", key: "158nzp" }],
  ["path", { d: "M2 19V9a4 4 0 0 1 4-4c2 0 4 1.33 6 4s4 4 6 4a4 4 0 1 0-3-6.65", key: "1930oh" }]
];
var RollerCoaster = createLucideIcon("roller-coaster", __iconNode1236);

// ../node_modules/lucide-react/dist/esm/icons/rose.js
var __iconNode1237 = [
  ["path", { d: "M17 10h-1a4 4 0 1 1 4-4v.534", key: "7qf5zm" }],
  [
    "path",
    { d: "M17 6h1a4 4 0 0 1 1.42 7.74l-2.29.87a6 6 0 0 1-5.339-10.68l2.069-1.31", key: "1et29u" }
  ],
  [
    "path",
    {
      d: "M4.5 17c2.8-.5 4.4 0 5.5.8s1.8 2.2 2.3 3.7c-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2",
      key: "kiv2lz"
    }
  ],
  ["path", { d: "M9.77 12C4 15 2 22 2 22", key: "h28rw0" }],
  ["circle", { cx: "17", cy: "8", r: "2", key: "1330xn" }]
];
var Rose = createLucideIcon("rose", __iconNode1237);

// ../node_modules/lucide-react/dist/esm/icons/rotate-3d.js
var __iconNode1238 = [
  [
    "path",
    {
      d: "M16.466 7.5C15.643 4.237 13.952 2 12 2 9.239 2 7 6.477 7 12s2.239 10 5 10c.342 0 .677-.069 1-.2",
      key: "10n0gc"
    }
  ],
  ["path", { d: "m15.194 13.707 3.814 1.86-1.86 3.814", key: "16shm9" }],
  [
    "path",
    {
      d: "M19 15.57c-1.804.885-4.274 1.43-7 1.43-5.523 0-10-2.239-10-5s4.477-5 10-5c4.838 0 8.873 1.718 9.8 4",
      key: "1lxi77"
    }
  ]
];
var Rotate3d = createLucideIcon("rotate-3d", __iconNode1238);

// ../node_modules/lucide-react/dist/esm/icons/rotate-ccw-key.js
var __iconNode1239 = [
  ["path", { d: "M12 7v6", key: "lw1j43" }],
  ["path", { d: "M12 9h2", key: "1lpap9" }],
  ["path", { d: "M3 12a9 9 0 1 0 9-9 9.74 9.74 0 0 0-6.74 2.74L3 8", key: "g2jlw" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }],
  ["circle", { cx: "12", cy: "15", r: "2", key: "1vpstw" }]
];
var RotateCcwKey = createLucideIcon("rotate-ccw-key", __iconNode1239);

// ../node_modules/lucide-react/dist/esm/icons/rotate-ccw-square.js
var __iconNode1240 = [
  ["path", { d: "M20 9V7a2 2 0 0 0-2-2h-6", key: "19z8uc" }],
  ["path", { d: "m15 2-3 3 3 3", key: "177bxs" }],
  ["path", { d: "M20 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h2", key: "d36hnl" }]
];
var RotateCcwSquare = createLucideIcon("rotate-ccw-square", __iconNode1240);

// ../node_modules/lucide-react/dist/esm/icons/rotate-cw-square.js
var __iconNode1241 = [
  ["path", { d: "M12 5H6a2 2 0 0 0-2 2v3", key: "l96uqu" }],
  ["path", { d: "m9 8 3-3-3-3", key: "1gzgc3" }],
  ["path", { d: "M4 14v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2", key: "1w2k5h" }]
];
var RotateCwSquare = createLucideIcon("rotate-cw-square", __iconNode1241);

// ../node_modules/lucide-react/dist/esm/icons/rotate-ccw.js
var __iconNode1242 = [
  ["path", { d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "1357e3" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }]
];
var RotateCcw = createLucideIcon("rotate-ccw", __iconNode1242);

// ../node_modules/lucide-react/dist/esm/icons/rotate-cw.js
var __iconNode1243 = [
  ["path", { d: "M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8", key: "1p45f6" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }]
];
var RotateCw = createLucideIcon("rotate-cw", __iconNode1243);

// ../node_modules/lucide-react/dist/esm/icons/route.js
var __iconNode1244 = [
  ["circle", { cx: "6", cy: "19", r: "3", key: "1kj8tv" }],
  ["path", { d: "M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15", key: "1d8sl" }],
  ["circle", { cx: "18", cy: "5", r: "3", key: "gq8acd" }]
];
var Route = createLucideIcon("route", __iconNode1244);

// ../node_modules/lucide-react/dist/esm/icons/route-off.js
var __iconNode1245 = [
  ["circle", { cx: "6", cy: "19", r: "3", key: "1kj8tv" }],
  ["path", { d: "M9 19h8.5c.4 0 .9-.1 1.3-.2", key: "1effex" }],
  ["path", { d: "M5.2 5.2A3.5 3.53 0 0 0 6.5 12H12", key: "k9y2ds" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M21 15.3a3.5 3.5 0 0 0-3.3-3.3", key: "11nlu2" }],
  ["path", { d: "M15 5h-4.3", key: "6537je" }],
  ["circle", { cx: "18", cy: "5", r: "3", key: "gq8acd" }]
];
var RouteOff = createLucideIcon("route-off", __iconNode1245);

// ../node_modules/lucide-react/dist/esm/icons/router.js
var __iconNode1246 = [
  ["rect", { width: "20", height: "8", x: "2", y: "14", rx: "2", key: "w68u3i" }],
  ["path", { d: "M6.01 18H6", key: "19vcac" }],
  ["path", { d: "M10.01 18H10", key: "uamcmx" }],
  ["path", { d: "M15 10v4", key: "qjz1xs" }],
  ["path", { d: "M17.84 7.17a4 4 0 0 0-5.66 0", key: "1rif40" }],
  ["path", { d: "M20.66 4.34a8 8 0 0 0-11.31 0", key: "6a5xfq" }]
];
var Router = createLucideIcon("router", __iconNode1246);

// ../node_modules/lucide-react/dist/esm/icons/rows-2.js
var __iconNode1247 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 12h18", key: "1i2n21" }]
];
var Rows2 = createLucideIcon("rows-2", __iconNode1247);

// ../node_modules/lucide-react/dist/esm/icons/rows-3.js
var __iconNode1248 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M21 9H3", key: "1338ky" }],
  ["path", { d: "M21 15H3", key: "9uk58r" }]
];
var Rows3 = createLucideIcon("rows-3", __iconNode1248);

// ../node_modules/lucide-react/dist/esm/icons/rows-4.js
var __iconNode1249 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M21 7.5H3", key: "1hm9pq" }],
  ["path", { d: "M21 12H3", key: "2avoz0" }],
  ["path", { d: "M21 16.5H3", key: "n7jzkj" }]
];
var Rows4 = createLucideIcon("rows-4", __iconNode1249);

// ../node_modules/lucide-react/dist/esm/icons/rss.js
var __iconNode1250 = [
  ["path", { d: "M4 11a9 9 0 0 1 9 9", key: "pv89mb" }],
  ["path", { d: "M4 4a16 16 0 0 1 16 16", key: "k0647b" }],
  ["circle", { cx: "5", cy: "19", r: "1", key: "bfqh0e" }]
];
var Rss = createLucideIcon("rss", __iconNode1250);

// ../node_modules/lucide-react/dist/esm/icons/ruler-dimension-line.js
var __iconNode1251 = [
  ["path", { d: "M10 15v-3", key: "1pjskw" }],
  ["path", { d: "M14 15v-3", key: "1o1mqj" }],
  ["path", { d: "M18 15v-3", key: "cws6he" }],
  ["path", { d: "M2 8V4", key: "3jv1jz" }],
  ["path", { d: "M22 6H2", key: "1iqbfk" }],
  ["path", { d: "M22 8V4", key: "16f4ou" }],
  ["path", { d: "M6 15v-3", key: "1ij1qe" }],
  ["rect", { x: "2", y: "12", width: "20", height: "8", rx: "2", key: "1tqiko" }]
];
var RulerDimensionLine = createLucideIcon("ruler-dimension-line", __iconNode1251);

// ../node_modules/lucide-react/dist/esm/icons/ruler.js
var __iconNode1252 = [
  [
    "path",
    {
      d: "M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z",
      key: "icamh8"
    }
  ],
  ["path", { d: "m14.5 12.5 2-2", key: "inckbg" }],
  ["path", { d: "m11.5 9.5 2-2", key: "fmmyf7" }],
  ["path", { d: "m8.5 6.5 2-2", key: "vc6u1g" }],
  ["path", { d: "m17.5 15.5 2-2", key: "wo5hmg" }]
];
var Ruler = createLucideIcon("ruler", __iconNode1252);

// ../node_modules/lucide-react/dist/esm/icons/russian-ruble.js
var __iconNode1253 = [
  ["path", { d: "M6 11h8a4 4 0 0 0 0-8H9v18", key: "18ai8t" }],
  ["path", { d: "M6 15h8", key: "1y8f6l" }]
];
var RussianRuble = createLucideIcon("russian-ruble", __iconNode1253);

// ../node_modules/lucide-react/dist/esm/icons/sailboat.js
var __iconNode1254 = [
  ["path", { d: "M10 2v15", key: "1qf71f" }],
  [
    "path",
    { d: "M7 22a4 4 0 0 1-4-4 1 1 0 0 1 1-1h16a1 1 0 0 1 1 1 4 4 0 0 1-4 4z", key: "1pxcvx" }
  ],
  [
    "path",
    {
      d: "M9.159 2.46a1 1 0 0 1 1.521-.193l9.977 8.98A1 1 0 0 1 20 13H4a1 1 0 0 1-.824-1.567z",
      key: "5oog16"
    }
  ]
];
var Sailboat = createLucideIcon("sailboat", __iconNode1254);

// ../node_modules/lucide-react/dist/esm/icons/salad.js
var __iconNode1255 = [
  ["path", { d: "M7 21h10", key: "1b0cd5" }],
  ["path", { d: "M12 21a9 9 0 0 0 9-9H3a9 9 0 0 0 9 9Z", key: "4rw317" }],
  [
    "path",
    {
      d: "M11.38 12a2.4 2.4 0 0 1-.4-4.77 2.4 2.4 0 0 1 3.2-2.77 2.4 2.4 0 0 1 3.47-.63 2.4 2.4 0 0 1 3.37 3.37 2.4 2.4 0 0 1-1.1 3.7 2.51 2.51 0 0 1 .03 1.1",
      key: "10xrj0"
    }
  ],
  ["path", { d: "m13 12 4-4", key: "1hckqy" }],
  ["path", { d: "M10.9 7.25A3.99 3.99 0 0 0 4 10c0 .73.2 1.41.54 2", key: "1p4srx" }]
];
var Salad = createLucideIcon("salad", __iconNode1255);

// ../node_modules/lucide-react/dist/esm/icons/sandwich.js
var __iconNode1256 = [
  ["path", { d: "m2.37 11.223 8.372-6.777a2 2 0 0 1 2.516 0l8.371 6.777", key: "f1wd0e" }],
  ["path", { d: "M21 15a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-5.25", key: "1pfu07" }],
  ["path", { d: "M3 15a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h9", key: "1oq9qw" }],
  ["path", { d: "m6.67 15 6.13 4.6a2 2 0 0 0 2.8-.4l3.15-4.2", key: "1fnwu5" }],
  ["rect", { width: "20", height: "4", x: "2", y: "11", rx: "1", key: "itshg" }]
];
var Sandwich = createLucideIcon("sandwich", __iconNode1256);

// ../node_modules/lucide-react/dist/esm/icons/satellite-dish.js
var __iconNode1257 = [
  ["path", { d: "M4 10a7.31 7.31 0 0 0 10 10Z", key: "1fzpp3" }],
  ["path", { d: "m9 15 3-3", key: "88sc13" }],
  ["path", { d: "M17 13a6 6 0 0 0-6-6", key: "15cc6u" }],
  ["path", { d: "M21 13A10 10 0 0 0 11 3", key: "11nf8s" }]
];
var SatelliteDish = createLucideIcon("satellite-dish", __iconNode1257);

// ../node_modules/lucide-react/dist/esm/icons/satellite.js
var __iconNode1258 = [
  [
    "path",
    {
      d: "m13.5 6.5-3.148-3.148a1.205 1.205 0 0 0-1.704 0L6.352 5.648a1.205 1.205 0 0 0 0 1.704L9.5 10.5",
      key: "dzhfyz"
    }
  ],
  ["path", { d: "M16.5 7.5 19 5", key: "1ltcjm" }],
  [
    "path",
    {
      d: "m17.5 10.5 3.148 3.148a1.205 1.205 0 0 1 0 1.704l-2.296 2.296a1.205 1.205 0 0 1-1.704 0L13.5 14.5",
      key: "nfoymv"
    }
  ],
  ["path", { d: "M9 21a6 6 0 0 0-6-6", key: "1iajcf" }],
  [
    "path",
    {
      d: "M9.352 10.648a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l4.296-4.296a1.205 1.205 0 0 0 0-1.704l-2.296-2.296a1.205 1.205 0 0 0-1.704 0z",
      key: "nv9zqy"
    }
  ]
];
var Satellite = createLucideIcon("satellite", __iconNode1258);

// ../node_modules/lucide-react/dist/esm/icons/saudi-riyal.js
var __iconNode1259 = [
  ["path", { d: "m20 19.5-5.5 1.2", key: "1aenhr" }],
  ["path", { d: "M14.5 4v11.22a1 1 0 0 0 1.242.97L20 15.2", key: "2rtezt" }],
  ["path", { d: "m2.978 19.351 5.549-1.363A2 2 0 0 0 10 16V2", key: "1kbm92" }],
  ["path", { d: "M20 10 4 13.5", key: "8nums9" }]
];
var SaudiRiyal = createLucideIcon("saudi-riyal", __iconNode1259);

// ../node_modules/lucide-react/dist/esm/icons/save-all.js
var __iconNode1260 = [
  ["path", { d: "M10 2v3a1 1 0 0 0 1 1h5", key: "1xspal" }],
  ["path", { d: "M18 18v-6a1 1 0 0 0-1-1h-6a1 1 0 0 0-1 1v6", key: "1ra60u" }],
  ["path", { d: "M18 22H4a2 2 0 0 1-2-2V6", key: "pblm9e" }],
  [
    "path",
    {
      d: "M8 18a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9.172a2 2 0 0 1 1.414.586l2.828 2.828A2 2 0 0 1 22 6.828V16a2 2 0 0 1-2.01 2z",
      key: "1yve0x"
    }
  ]
];
var SaveAll = createLucideIcon("save-all", __iconNode1260);

// ../node_modules/lucide-react/dist/esm/icons/save-off.js
var __iconNode1261 = [
  ["path", { d: "M13 13H8a1 1 0 0 0-1 1v7", key: "h8g396" }],
  ["path", { d: "M14 8h1", key: "1lfen6" }],
  ["path", { d: "M17 21v-4", key: "1yknxs" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    { d: "M20.41 20.41A2 2 0 0 1 19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 .59-1.41", key: "1t4vdl" }
  ],
  ["path", { d: "M29.5 11.5s5 5 4 5", key: "zzn4i6" }],
  ["path", { d: "M9 3h6.2a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V15", key: "24cby9" }]
];
var SaveOff = createLucideIcon("save-off", __iconNode1261);

// ../node_modules/lucide-react/dist/esm/icons/scale-3d.js
var __iconNode1262 = [
  ["path", { d: "M5 7v11a1 1 0 0 0 1 1h11", key: "13dt1j" }],
  ["path", { d: "M5.293 18.707 11 13", key: "ezgbsx" }],
  ["circle", { cx: "19", cy: "19", r: "2", key: "17f5cg" }],
  ["circle", { cx: "5", cy: "5", r: "2", key: "1gwv83" }]
];
var Scale3d = createLucideIcon("scale-3d", __iconNode1262);

// ../node_modules/lucide-react/dist/esm/icons/save.js
var __iconNode1263 = [
  [
    "path",
    {
      d: "M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
      key: "1c8476"
    }
  ],
  ["path", { d: "M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7", key: "1ydtos" }],
  ["path", { d: "M7 3v4a1 1 0 0 0 1 1h7", key: "t51u73" }]
];
var Save = createLucideIcon("save", __iconNode1263);

// ../node_modules/lucide-react/dist/esm/icons/scale.js
var __iconNode1264 = [
  ["path", { d: "M12 3v18", key: "108xh3" }],
  ["path", { d: "m19 8 3 8a5 5 0 0 1-6 0zV7", key: "zcdpyk" }],
  ["path", { d: "M3 7h1a17 17 0 0 0 8-2 17 17 0 0 0 8 2h1", key: "1yorad" }],
  ["path", { d: "m5 8 3 8a5 5 0 0 1-6 0zV7", key: "eua70x" }],
  ["path", { d: "M7 21h10", key: "1b0cd5" }]
];
var Scale = createLucideIcon("scale", __iconNode1264);

// ../node_modules/lucide-react/dist/esm/icons/scaling.js
var __iconNode1265 = [
  ["path", { d: "M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7", key: "1m0v6g" }],
  ["path", { d: "M14 15H9v-5", key: "pi4jk9" }],
  ["path", { d: "M16 3h5v5", key: "1806ms" }],
  ["path", { d: "M21 3 9 15", key: "15kdhq" }]
];
var Scaling = createLucideIcon("scaling", __iconNode1265);

// ../node_modules/lucide-react/dist/esm/icons/scan-barcode.js
var __iconNode1266 = [
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
  ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
  ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }],
  ["path", { d: "M8 7v10", key: "23sfjj" }],
  ["path", { d: "M12 7v10", key: "jspqdw" }],
  ["path", { d: "M17 7v10", key: "578dap" }]
];
var ScanBarcode = createLucideIcon("scan-barcode", __iconNode1266);

// ../node_modules/lucide-react/dist/esm/icons/scan-eye.js
var __iconNode1267 = [
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
  ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
  ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }],
  ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }],
  [
    "path",
    {
      d: "M18.944 12.33a1 1 0 0 0 0-.66 7.5 7.5 0 0 0-13.888 0 1 1 0 0 0 0 .66 7.5 7.5 0 0 0 13.888 0",
      key: "11ak4c"
    }
  ]
];
var ScanEye = createLucideIcon("scan-eye", __iconNode1267);

// ../node_modules/lucide-react/dist/esm/icons/scan-face.js
var __iconNode1268 = [
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
  ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
  ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }],
  ["path", { d: "M8 14s1.5 2 4 2 4-2 4-2", key: "1y1vjs" }],
  ["path", { d: "M9 9h.01", key: "1q5me6" }],
  ["path", { d: "M15 9h.01", key: "x1ddxp" }]
];
var ScanFace = createLucideIcon("scan-face", __iconNode1268);

// ../node_modules/lucide-react/dist/esm/icons/scan-heart.js
var __iconNode1269 = [
  ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
  ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }],
  [
    "path",
    {
      d: "M7.828 13.07A3 3 0 0 1 12 8.764a3 3 0 0 1 4.172 4.306l-3.447 3.62a1 1 0 0 1-1.449 0z",
      key: "1ak1ef"
    }
  ]
];
var ScanHeart = createLucideIcon("scan-heart", __iconNode1269);

// ../node_modules/lucide-react/dist/esm/icons/scan-line.js
var __iconNode1270 = [
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
  ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
  ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }],
  ["path", { d: "M7 12h10", key: "b7w52i" }]
];
var ScanLine = createLucideIcon("scan-line", __iconNode1270);

// ../node_modules/lucide-react/dist/esm/icons/scan-search.js
var __iconNode1271 = [
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
  ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
  ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
  ["path", { d: "m16 16-1.9-1.9", key: "1dq9hf" }]
];
var ScanSearch = createLucideIcon("scan-search", __iconNode1271);

// ../node_modules/lucide-react/dist/esm/icons/scan-qr-code.js
var __iconNode1272 = [
  ["path", { d: "M17 12v4a1 1 0 0 1-1 1h-4", key: "uk4fdo" }],
  ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
  ["path", { d: "M17 8V7", key: "q2g9wo" }],
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
  ["path", { d: "M7 17h.01", key: "19xn7k" }],
  ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }],
  ["rect", { x: "7", y: "7", width: "5", height: "5", rx: "1", key: "m9kyts" }]
];
var ScanQrCode = createLucideIcon("scan-qr-code", __iconNode1272);

// ../node_modules/lucide-react/dist/esm/icons/scan-text.js
var __iconNode1273 = [
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
  ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
  ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }],
  ["path", { d: "M7 8h8", key: "1jbsf9" }],
  ["path", { d: "M7 12h10", key: "b7w52i" }],
  ["path", { d: "M7 16h6", key: "1vyc9m" }]
];
var ScanText = createLucideIcon("scan-text", __iconNode1273);

// ../node_modules/lucide-react/dist/esm/icons/scan.js
var __iconNode1274 = [
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
  ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
  ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }]
];
var Scan = createLucideIcon("scan", __iconNode1274);

// ../node_modules/lucide-react/dist/esm/icons/school.js
var __iconNode1275 = [
  ["path", { d: "M14 21v-3a2 2 0 0 0-4 0v3", key: "1rgiei" }],
  ["path", { d: "M18 5v16", key: "1ethyx" }],
  ["path", { d: "m4 6 7.106-3.79a2 2 0 0 1 1.788 0L20 6", key: "zywc2d" }],
  [
    "path",
    {
      d: "m6 11-3.52 2.147a1 1 0 0 0-.48.854V19a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5a1 1 0 0 0-.48-.853L18 11",
      key: "1d4ql0"
    }
  ],
  ["path", { d: "M6 5v16", key: "1sn0nx" }],
  ["circle", { cx: "12", cy: "9", r: "2", key: "1092wv" }]
];
var School = createLucideIcon("school", __iconNode1275);

// ../node_modules/lucide-react/dist/esm/icons/scissors-line-dashed.js
var __iconNode1276 = [
  ["path", { d: "M5.42 9.42 8 12", key: "12pkuq" }],
  ["circle", { cx: "4", cy: "8", r: "2", key: "107mxr" }],
  ["path", { d: "m14 6-8.58 8.58", key: "gvzu5l" }],
  ["circle", { cx: "4", cy: "16", r: "2", key: "1ehqvc" }],
  ["path", { d: "M10.8 14.8 14 18", key: "ax7m9r" }],
  ["path", { d: "M16 12h-2", key: "10asgb" }],
  ["path", { d: "M22 12h-2", key: "14jgyd" }]
];
var ScissorsLineDashed = createLucideIcon("scissors-line-dashed", __iconNode1276);

// ../node_modules/lucide-react/dist/esm/icons/scissors.js
var __iconNode1277 = [
  ["circle", { cx: "6", cy: "6", r: "3", key: "1lh9wr" }],
  ["path", { d: "M8.12 8.12 12 12", key: "1alkpv" }],
  ["path", { d: "M20 4 8.12 15.88", key: "xgtan2" }],
  ["circle", { cx: "6", cy: "18", r: "3", key: "fqmcym" }],
  ["path", { d: "M14.8 14.8 20 20", key: "ptml3r" }]
];
var Scissors = createLucideIcon("scissors", __iconNode1277);

// ../node_modules/lucide-react/dist/esm/icons/scooter.js
var __iconNode1278 = [
  ["path", { d: "M21 4h-3.5l2 11.05", key: "1gktiw" }],
  [
    "path",
    { d: "M6.95 17h5.142c.523 0 .95-.406 1.063-.916a6.5 6.5 0 0 1 5.345-5.009", key: "1bq3u3" }
  ],
  ["circle", { cx: "19.5", cy: "17.5", r: "2.5", key: "e4zhv9" }],
  ["circle", { cx: "4.5", cy: "17.5", r: "2.5", key: "50vk4p" }]
];
var Scooter = createLucideIcon("scooter", __iconNode1278);

// ../node_modules/lucide-react/dist/esm/icons/screen-share-off.js
var __iconNode1279 = [
  ["path", { d: "M13 3H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-3", key: "i8wdob" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }],
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "m22 3-5 5", key: "12jva0" }],
  ["path", { d: "m17 3 5 5", key: "k36vhe" }]
];
var ScreenShareOff = createLucideIcon("screen-share-off", __iconNode1279);

// ../node_modules/lucide-react/dist/esm/icons/screen-share.js
var __iconNode1280 = [
  ["path", { d: "M13 3H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-3", key: "i8wdob" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }],
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "m17 8 5-5", key: "fqif7o" }],
  ["path", { d: "M17 3h5v5", key: "1o3tu8" }]
];
var ScreenShare = createLucideIcon("screen-share", __iconNode1280);

// ../node_modules/lucide-react/dist/esm/icons/scroll.js
var __iconNode1281 = [
  ["path", { d: "M19 17V5a2 2 0 0 0-2-2H4", key: "zz82l3" }],
  [
    "path",
    {
      d: "M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3",
      key: "1ph1d7"
    }
  ]
];
var Scroll = createLucideIcon("scroll", __iconNode1281);

// ../node_modules/lucide-react/dist/esm/icons/scroll-text.js
var __iconNode1282 = [
  ["path", { d: "M15 12h-5", key: "r7krc0" }],
  ["path", { d: "M15 8h-5", key: "1khuty" }],
  ["path", { d: "M19 17V5a2 2 0 0 0-2-2H4", key: "zz82l3" }],
  [
    "path",
    {
      d: "M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3",
      key: "1ph1d7"
    }
  ]
];
var ScrollText = createLucideIcon("scroll-text", __iconNode1282);

// ../node_modules/lucide-react/dist/esm/icons/search-alert.js
var __iconNode1283 = [
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["path", { d: "m21 21-4.3-4.3", key: "1qie3q" }],
  ["path", { d: "M11 7v4", key: "m2edmq" }],
  ["path", { d: "M11 15h.01", key: "k85uqc" }]
];
var SearchAlert = createLucideIcon("search-alert", __iconNode1283);

// ../node_modules/lucide-react/dist/esm/icons/search-check.js
var __iconNode1284 = [
  ["path", { d: "m8 11 2 2 4-4", key: "1sed1v" }],
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["path", { d: "m21 21-4.3-4.3", key: "1qie3q" }]
];
var SearchCheck = createLucideIcon("search-check", __iconNode1284);

// ../node_modules/lucide-react/dist/esm/icons/search-code.js
var __iconNode1285 = [
  ["path", { d: "m13 13.5 2-2.5-2-2.5", key: "1rvxrh" }],
  ["path", { d: "m21 21-4.3-4.3", key: "1qie3q" }],
  ["path", { d: "M9 8.5 7 11l2 2.5", key: "6ffwbx" }],
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }]
];
var SearchCode = createLucideIcon("search-code", __iconNode1285);

// ../node_modules/lucide-react/dist/esm/icons/search-slash.js
var __iconNode1286 = [
  ["path", { d: "m13.5 8.5-5 5", key: "1cs55j" }],
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["path", { d: "m21 21-4.3-4.3", key: "1qie3q" }]
];
var SearchSlash = createLucideIcon("search-slash", __iconNode1286);

// ../node_modules/lucide-react/dist/esm/icons/search-x.js
var __iconNode1287 = [
  ["path", { d: "m13.5 8.5-5 5", key: "1cs55j" }],
  ["path", { d: "m8.5 8.5 5 5", key: "a8mexj" }],
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["path", { d: "m21 21-4.3-4.3", key: "1qie3q" }]
];
var SearchX = createLucideIcon("search-x", __iconNode1287);

// ../node_modules/lucide-react/dist/esm/icons/search.js
var __iconNode1288 = [
  ["path", { d: "m21 21-4.34-4.34", key: "14j7rj" }],
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }]
];
var Search = createLucideIcon("search", __iconNode1288);

// ../node_modules/lucide-react/dist/esm/icons/section.js
var __iconNode1289 = [
  ["path", { d: "M16 5a4 3 0 0 0-8 0c0 4 8 3 8 7a4 3 0 0 1-8 0", key: "vqan6v" }],
  ["path", { d: "M8 19a4 3 0 0 0 8 0c0-4-8-3-8-7a4 3 0 0 1 8 0", key: "wdjd8o" }]
];
var Section = createLucideIcon("section", __iconNode1289);

// ../node_modules/lucide-react/dist/esm/icons/send-horizontal.js
var __iconNode1290 = [
  [
    "path",
    {
      d: "M3.714 3.048a.498.498 0 0 0-.683.627l2.843 7.627a2 2 0 0 1 0 1.396l-2.842 7.627a.498.498 0 0 0 .682.627l18-8.5a.5.5 0 0 0 0-.904z",
      key: "117uat"
    }
  ],
  ["path", { d: "M6 12h16", key: "s4cdu5" }]
];
var SendHorizontal = createLucideIcon("send-horizontal", __iconNode1290);

// ../node_modules/lucide-react/dist/esm/icons/send.js
var __iconNode1291 = [
  [
    "path",
    {
      d: "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",
      key: "1ffxy3"
    }
  ],
  ["path", { d: "m21.854 2.147-10.94 10.939", key: "12cjpa" }]
];
var Send = createLucideIcon("send", __iconNode1291);

// ../node_modules/lucide-react/dist/esm/icons/send-to-back.js
var __iconNode1292 = [
  ["rect", { x: "14", y: "14", width: "8", height: "8", rx: "2", key: "1b0bso" }],
  ["rect", { x: "2", y: "2", width: "8", height: "8", rx: "2", key: "1x09vl" }],
  ["path", { d: "M7 14v1a2 2 0 0 0 2 2h1", key: "pao6x6" }],
  ["path", { d: "M14 7h1a2 2 0 0 1 2 2v1", key: "19tdru" }]
];
var SendToBack = createLucideIcon("send-to-back", __iconNode1292);

// ../node_modules/lucide-react/dist/esm/icons/separator-horizontal.js
var __iconNode1293 = [
  ["path", { d: "m16 16-4 4-4-4", key: "3dv8je" }],
  ["path", { d: "M3 12h18", key: "1i2n21" }],
  ["path", { d: "m8 8 4-4 4 4", key: "2bscm2" }]
];
var SeparatorHorizontal = createLucideIcon("separator-horizontal", __iconNode1293);

// ../node_modules/lucide-react/dist/esm/icons/separator-vertical.js
var __iconNode1294 = [
  ["path", { d: "M12 3v18", key: "108xh3" }],
  ["path", { d: "m16 16 4-4-4-4", key: "1js579" }],
  ["path", { d: "m8 8-4 4 4 4", key: "1whems" }]
];
var SeparatorVertical = createLucideIcon("separator-vertical", __iconNode1294);

// ../node_modules/lucide-react/dist/esm/icons/server-cog.js
var __iconNode1295 = [
  ["path", { d: "m10.852 14.772-.383.923", key: "11vil6" }],
  ["path", { d: "M13.148 14.772a3 3 0 1 0-2.296-5.544l-.383-.923", key: "1v3clb" }],
  ["path", { d: "m13.148 9.228.383-.923", key: "t2zzyc" }],
  ["path", { d: "m13.53 15.696-.382-.924a3 3 0 1 1-2.296-5.544", key: "1bxfiv" }],
  ["path", { d: "m14.772 10.852.923-.383", key: "k9m8cz" }],
  ["path", { d: "m14.772 13.148.923.383", key: "1xvhww" }],
  [
    "path",
    {
      d: "M4.5 10H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-.5",
      key: "tn8das"
    }
  ],
  [
    "path",
    {
      d: "M4.5 14H4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-.5",
      key: "1g2pve"
    }
  ],
  ["path", { d: "M6 18h.01", key: "uhywen" }],
  ["path", { d: "M6 6h.01", key: "1utrut" }],
  ["path", { d: "m9.228 10.852-.923-.383", key: "1wtb30" }],
  ["path", { d: "m9.228 13.148-.923.383", key: "1a830x" }]
];
var ServerCog = createLucideIcon("server-cog", __iconNode1295);

// ../node_modules/lucide-react/dist/esm/icons/server-crash.js
var __iconNode1296 = [
  [
    "path",
    {
      d: "M6 10H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2",
      key: "4b9dqc"
    }
  ],
  [
    "path",
    {
      d: "M6 14H4a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-4a2 2 0 0 0-2-2h-2",
      key: "22nnkd"
    }
  ],
  ["path", { d: "M6 6h.01", key: "1utrut" }],
  ["path", { d: "M6 18h.01", key: "uhywen" }],
  ["path", { d: "m13 6-4 6h6l-4 6", key: "14hqih" }]
];
var ServerCrash = createLucideIcon("server-crash", __iconNode1296);

// ../node_modules/lucide-react/dist/esm/icons/server-off.js
var __iconNode1297 = [
  ["path", { d: "M7 2h13a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-5", key: "bt2siv" }],
  ["path", { d: "M10 10 2.5 2.5C2 2 2 2.5 2 5v3a2 2 0 0 0 2 2h6z", key: "1hjrv1" }],
  ["path", { d: "M22 17v-1a2 2 0 0 0-2-2h-1", key: "1iynyr" }],
  ["path", { d: "M4 14a2 2 0 0 0-2 2v4a2 2 0 0 0 2 2h16.5l1-.5.5.5-8-8H4z", key: "161ggg" }],
  ["path", { d: "M6 18h.01", key: "uhywen" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var ServerOff = createLucideIcon("server-off", __iconNode1297);

// ../node_modules/lucide-react/dist/esm/icons/server.js
var __iconNode1298 = [
  ["rect", { width: "20", height: "8", x: "2", y: "2", rx: "2", ry: "2", key: "ngkwjq" }],
  ["rect", { width: "20", height: "8", x: "2", y: "14", rx: "2", ry: "2", key: "iecqi9" }],
  ["line", { x1: "6", x2: "6.01", y1: "6", y2: "6", key: "16zg32" }],
  ["line", { x1: "6", x2: "6.01", y1: "18", y2: "18", key: "nzw8ys" }]
];
var Server = createLucideIcon("server", __iconNode1298);

// ../node_modules/lucide-react/dist/esm/icons/settings-2.js
var __iconNode1299 = [
  ["path", { d: "M14 17H5", key: "gfn3mx" }],
  ["path", { d: "M19 7h-9", key: "6i9tg" }],
  ["circle", { cx: "17", cy: "17", r: "3", key: "18b49y" }],
  ["circle", { cx: "7", cy: "7", r: "3", key: "dfmy0x" }]
];
var Settings2 = createLucideIcon("settings-2", __iconNode1299);

// ../node_modules/lucide-react/dist/esm/icons/settings.js
var __iconNode1300 = [
  [
    "path",
    {
      d: "M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",
      key: "1i5ecw"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
];
var Settings = createLucideIcon("settings", __iconNode1300);

// ../node_modules/lucide-react/dist/esm/icons/shapes.js
var __iconNode1301 = [
  [
    "path",
    {
      d: "M8.3 10a.7.7 0 0 1-.626-1.079L11.4 3a.7.7 0 0 1 1.198-.043L16.3 8.9a.7.7 0 0 1-.572 1.1Z",
      key: "1bo67w"
    }
  ],
  ["rect", { x: "3", y: "14", width: "7", height: "7", rx: "1", key: "1bkyp8" }],
  ["circle", { cx: "17.5", cy: "17.5", r: "3.5", key: "w3z12y" }]
];
var Shapes = createLucideIcon("shapes", __iconNode1301);

// ../node_modules/lucide-react/dist/esm/icons/share-2.js
var __iconNode1302 = [
  ["circle", { cx: "18", cy: "5", r: "3", key: "gq8acd" }],
  ["circle", { cx: "6", cy: "12", r: "3", key: "w7nqdw" }],
  ["circle", { cx: "18", cy: "19", r: "3", key: "1xt0gg" }],
  ["line", { x1: "8.59", x2: "15.42", y1: "13.51", y2: "17.49", key: "47mynk" }],
  ["line", { x1: "15.41", x2: "8.59", y1: "6.51", y2: "10.49", key: "1n3mei" }]
];
var Share2 = createLucideIcon("share-2", __iconNode1302);

// ../node_modules/lucide-react/dist/esm/icons/share.js
var __iconNode1303 = [
  ["path", { d: "M12 2v13", key: "1km8f5" }],
  ["path", { d: "m16 6-4-4-4 4", key: "13yo43" }],
  ["path", { d: "M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8", key: "1b2hhj" }]
];
var Share = createLucideIcon("share", __iconNode1303);

// ../node_modules/lucide-react/dist/esm/icons/sheet.js
var __iconNode1304 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["line", { x1: "3", x2: "21", y1: "9", y2: "9", key: "1vqk6q" }],
  ["line", { x1: "3", x2: "21", y1: "15", y2: "15", key: "o2sbyz" }],
  ["line", { x1: "9", x2: "9", y1: "9", y2: "21", key: "1ib60c" }],
  ["line", { x1: "15", x2: "15", y1: "9", y2: "21", key: "1n26ft" }]
];
var Sheet = createLucideIcon("sheet", __iconNode1304);

// ../node_modules/lucide-react/dist/esm/icons/shell.js
var __iconNode1305 = [
  [
    "path",
    {
      d: "M14 11a2 2 0 1 1-4 0 4 4 0 0 1 8 0 6 6 0 0 1-12 0 8 8 0 0 1 16 0 10 10 0 1 1-20 0 11.93 11.93 0 0 1 2.42-7.22 2 2 0 1 1 3.16 2.44",
      key: "1cn552"
    }
  ]
];
var Shell = createLucideIcon("shell", __iconNode1305);

// ../node_modules/lucide-react/dist/esm/icons/shelving-unit.js
var __iconNode1306 = [
  ["path", { d: "M12 12V9a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3", key: "wiz68x" }],
  ["path", { d: "M16 20v-3a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v3", key: "1b59c4" }],
  ["path", { d: "M20 22V2", key: "1bnhr8" }],
  ["path", { d: "M4 12h16", key: "1lakjw" }],
  ["path", { d: "M4 20h16", key: "14thso" }],
  ["path", { d: "M4 2v20", key: "gtpd5x" }],
  ["path", { d: "M4 4h16", key: "1bkgr1" }]
];
var ShelvingUnit = createLucideIcon("shelving-unit", __iconNode1306);

// ../node_modules/lucide-react/dist/esm/icons/shield-alert.js
var __iconNode1307 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "M12 8v4", key: "1got3b" }],
  ["path", { d: "M12 16h.01", key: "1drbdi" }]
];
var ShieldAlert = createLucideIcon("shield-alert", __iconNode1307);

// ../node_modules/lucide-react/dist/esm/icons/shield-ban.js
var __iconNode1308 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "m4.243 5.21 14.39 12.472", key: "1c9a7c" }]
];
var ShieldBan = createLucideIcon("shield-ban", __iconNode1308);

// ../node_modules/lucide-react/dist/esm/icons/shield-check.js
var __iconNode1309 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
];
var ShieldCheck = createLucideIcon("shield-check", __iconNode1309);

// ../node_modules/lucide-react/dist/esm/icons/shield-ellipsis.js
var __iconNode1310 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "M8 12h.01", key: "czm47f" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M16 12h.01", key: "1l6xoz" }]
];
var ShieldEllipsis = createLucideIcon("shield-ellipsis", __iconNode1310);

// ../node_modules/lucide-react/dist/esm/icons/shield-half.js
var __iconNode1311 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "M12 22V2", key: "zs6s6o" }]
];
var ShieldHalf = createLucideIcon("shield-half", __iconNode1311);

// ../node_modules/lucide-react/dist/esm/icons/shield-minus.js
var __iconNode1312 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "M9 12h6", key: "1c52cq" }]
];
var ShieldMinus = createLucideIcon("shield-minus", __iconNode1312);

// ../node_modules/lucide-react/dist/esm/icons/shield-off.js
var __iconNode1313 = [
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    {
      d: "M5 5a1 1 0 0 0-1 1v7c0 5 3.5 7.5 7.67 8.94a1 1 0 0 0 .67.01c2.35-.82 4.48-1.97 5.9-3.71",
      key: "1jlk70"
    }
  ],
  [
    "path",
    {
      d: "M9.309 3.652A12.252 12.252 0 0 0 11.24 2.28a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1v7a9.784 9.784 0 0 1-.08 1.264",
      key: "18rp1v"
    }
  ]
];
var ShieldOff = createLucideIcon("shield-off", __iconNode1313);

// ../node_modules/lucide-react/dist/esm/icons/shield-plus.js
var __iconNode1314 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "M9 12h6", key: "1c52cq" }],
  ["path", { d: "M12 9v6", key: "199k2o" }]
];
var ShieldPlus = createLucideIcon("shield-plus", __iconNode1314);

// ../node_modules/lucide-react/dist/esm/icons/shield-question-mark.js
var __iconNode1315 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "M9.1 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3", key: "mhlwft" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
];
var ShieldQuestionMark = createLucideIcon("shield-question-mark", __iconNode1315);

// ../node_modules/lucide-react/dist/esm/icons/shield-user.js
var __iconNode1316 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "M6.376 18.91a6 6 0 0 1 11.249.003", key: "hnjrf2" }],
  ["circle", { cx: "12", cy: "11", r: "4", key: "1gt34v" }]
];
var ShieldUser = createLucideIcon("shield-user", __iconNode1316);

// ../node_modules/lucide-react/dist/esm/icons/shield-x.js
var __iconNode1317 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ],
  ["path", { d: "m14.5 9.5-5 5", key: "17q4r4" }],
  ["path", { d: "m9.5 9.5 5 5", key: "18nt4w" }]
];
var ShieldX = createLucideIcon("shield-x", __iconNode1317);

// ../node_modules/lucide-react/dist/esm/icons/shield.js
var __iconNode1318 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ]
];
var Shield = createLucideIcon("shield", __iconNode1318);

// ../node_modules/lucide-react/dist/esm/icons/ship.js
var __iconNode1319 = [
  ["path", { d: "M12 10.189V14", key: "1p8cqu" }],
  ["path", { d: "M12 2v3", key: "qbqxhf" }],
  ["path", { d: "M19 13V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6", key: "qpkstq" }],
  [
    "path",
    {
      d: "M19.38 20A11.6 11.6 0 0 0 21 14l-8.188-3.639a2 2 0 0 0-1.624 0L3 14a11.6 11.6 0 0 0 2.81 7.76",
      key: "7tigtc"
    }
  ],
  [
    "path",
    {
      d: "M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1s1.2 1 2.5 1c2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "1924j5"
    }
  ]
];
var Ship = createLucideIcon("ship", __iconNode1319);

// ../node_modules/lucide-react/dist/esm/icons/ship-wheel.js
var __iconNode1320 = [
  ["circle", { cx: "12", cy: "12", r: "8", key: "46899m" }],
  ["path", { d: "M12 2v7.5", key: "1e5rl5" }],
  ["path", { d: "m19 5-5.23 5.23", key: "1ezxxf" }],
  ["path", { d: "M22 12h-7.5", key: "le1719" }],
  ["path", { d: "m19 19-5.23-5.23", key: "p3fmgn" }],
  ["path", { d: "M12 14.5V22", key: "dgcmos" }],
  ["path", { d: "M10.23 13.77 5 19", key: "qwopd4" }],
  ["path", { d: "M9.5 12H2", key: "r7bup8" }],
  ["path", { d: "M10.23 10.23 5 5", key: "k2y7lj" }],
  ["circle", { cx: "12", cy: "12", r: "2.5", key: "ix0uyj" }]
];
var ShipWheel = createLucideIcon("ship-wheel", __iconNode1320);

// ../node_modules/lucide-react/dist/esm/icons/shirt.js
var __iconNode1321 = [
  [
    "path",
    {
      d: "M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z",
      key: "1wgbhj"
    }
  ]
];
var Shirt = createLucideIcon("shirt", __iconNode1321);

// ../node_modules/lucide-react/dist/esm/icons/shopping-bag.js
var __iconNode1322 = [
  ["path", { d: "M16 10a4 4 0 0 1-8 0", key: "1ltviw" }],
  ["path", { d: "M3.103 6.034h17.794", key: "awc11p" }],
  [
    "path",
    {
      d: "M3.4 5.467a2 2 0 0 0-.4 1.2V20a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6.667a2 2 0 0 0-.4-1.2l-2-2.667A2 2 0 0 0 17 2H7a2 2 0 0 0-1.6.8z",
      key: "o988cm"
    }
  ]
];
var ShoppingBag = createLucideIcon("shopping-bag", __iconNode1322);

// ../node_modules/lucide-react/dist/esm/icons/shopping-cart.js
var __iconNode1323 = [
  ["circle", { cx: "8", cy: "21", r: "1", key: "jimo8o" }],
  ["circle", { cx: "19", cy: "21", r: "1", key: "13723u" }],
  [
    "path",
    {
      d: "M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12",
      key: "9zh506"
    }
  ]
];
var ShoppingCart = createLucideIcon("shopping-cart", __iconNode1323);

// ../node_modules/lucide-react/dist/esm/icons/shopping-basket.js
var __iconNode1324 = [
  ["path", { d: "m15 11-1 9", key: "5wnq3a" }],
  ["path", { d: "m19 11-4-7", key: "cnml18" }],
  ["path", { d: "M2 11h20", key: "3eubbj" }],
  ["path", { d: "m3.5 11 1.6 7.4a2 2 0 0 0 2 1.6h9.8a2 2 0 0 0 2-1.6l1.7-7.4", key: "yiazzp" }],
  ["path", { d: "M4.5 15.5h15", key: "13mye1" }],
  ["path", { d: "m5 11 4-7", key: "116ra9" }],
  ["path", { d: "m9 11 1 9", key: "1ojof7" }]
];
var ShoppingBasket = createLucideIcon("shopping-basket", __iconNode1324);

// ../node_modules/lucide-react/dist/esm/icons/shovel.js
var __iconNode1325 = [
  [
    "path",
    {
      d: "M21.56 4.56a1.5 1.5 0 0 1 0 2.122l-.47.47a3 3 0 0 1-4.212-.03 3 3 0 0 1 0-4.243l.44-.44a1.5 1.5 0 0 1 2.121 0z",
      key: "1gcedi"
    }
  ],
  [
    "path",
    {
      d: "M3 22a1 1 0 0 1-1-1v-3.586a1 1 0 0 1 .293-.707l3.355-3.355a1.205 1.205 0 0 1 1.704 0l3.296 3.296a1.205 1.205 0 0 1 0 1.704l-3.355 3.355a1 1 0 0 1-.707.293z",
      key: "pg9kv3"
    }
  ],
  ["path", { d: "m9 15 7.879-7.878", key: "1o1zgh" }]
];
var Shovel = createLucideIcon("shovel", __iconNode1325);

// ../node_modules/lucide-react/dist/esm/icons/shower-head.js
var __iconNode1326 = [
  ["path", { d: "m4 4 2.5 2.5", key: "uv2vmf" }],
  ["path", { d: "M13.5 6.5a4.95 4.95 0 0 0-7 7", key: "frdkwv" }],
  ["path", { d: "M15 5 5 15", key: "1ag8rq" }],
  ["path", { d: "M14 17v.01", key: "eokfpp" }],
  ["path", { d: "M10 16v.01", key: "14uyyl" }],
  ["path", { d: "M13 13v.01", key: "1v1k97" }],
  ["path", { d: "M16 10v.01", key: "5169yg" }],
  ["path", { d: "M11 20v.01", key: "cj92p8" }],
  ["path", { d: "M17 14v.01", key: "11cswd" }],
  ["path", { d: "M20 11v.01", key: "19e0od" }]
];
var ShowerHead = createLucideIcon("shower-head", __iconNode1326);

// ../node_modules/lucide-react/dist/esm/icons/shrimp.js
var __iconNode1327 = [
  ["path", { d: "M11 12h.01", key: "1lr4k6" }],
  ["path", { d: "M13 22c.5-.5 1.12-1 2.5-1-1.38 0-2-.5-2.5-1", key: "fatpdi" }],
  [
    "path",
    {
      d: "M14 2a3.28 3.28 0 0 1-3.227 1.798l-6.17-.561A2.387 2.387 0 1 0 4.387 8H15.5a1 1 0 0 1 0 13 1 1 0 0 0 0-5H12a7 7 0 0 1-7-7V8",
      key: "kehrqe"
    }
  ],
  ["path", { d: "M14 8a8.5 8.5 0 0 1 0 8", key: "1imjx2" }],
  ["path", { d: "M16 16c2 0 4.5-4 4-6", key: "z0nejz" }]
];
var Shrimp = createLucideIcon("shrimp", __iconNode1327);

// ../node_modules/lucide-react/dist/esm/icons/shredder.js
var __iconNode1328 = [
  [
    "path",
    {
      d: "M4 13V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v5",
      key: "1eob4r"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M10 22v-5", key: "sfixh4" }],
  ["path", { d: "M14 19v-2", key: "pdve8j" }],
  ["path", { d: "M18 20v-3", key: "uox2gk" }],
  ["path", { d: "M2 13h20", key: "5evz65" }],
  ["path", { d: "M6 20v-3", key: "c6pdcb" }]
];
var Shredder = createLucideIcon("shredder", __iconNode1328);

// ../node_modules/lucide-react/dist/esm/icons/shrink.js
var __iconNode1329 = [
  ["path", { d: "m15 15 6 6m-6-6v4.8m0-4.8h4.8", key: "17vawe" }],
  ["path", { d: "M9 19.8V15m0 0H4.2M9 15l-6 6", key: "chjx8e" }],
  ["path", { d: "M15 4.2V9m0 0h4.8M15 9l6-6", key: "lav6yq" }],
  ["path", { d: "M9 4.2V9m0 0H4.2M9 9 3 3", key: "1pxi2q" }]
];
var Shrink = createLucideIcon("shrink", __iconNode1329);

// ../node_modules/lucide-react/dist/esm/icons/shrub.js
var __iconNode1330 = [
  ["path", { d: "M12 22v-5.172a2 2 0 0 0-.586-1.414L9.5 13.5", key: "1p17fm" }],
  ["path", { d: "M14.5 14.5 12 17", key: "dy5w4y" }],
  ["path", { d: "M17 8.8A6 6 0 0 1 13.8 20H10A6.5 6.5 0 0 1 7 8a5 5 0 0 1 10 0z", key: "6z7b3o" }]
];
var Shrub = createLucideIcon("shrub", __iconNode1330);

// ../node_modules/lucide-react/dist/esm/icons/shuffle.js
var __iconNode1331 = [
  ["path", { d: "m18 14 4 4-4 4", key: "10pe0f" }],
  ["path", { d: "m18 2 4 4-4 4", key: "pucp1d" }],
  ["path", { d: "M2 18h1.973a4 4 0 0 0 3.3-1.7l5.454-8.6a4 4 0 0 1 3.3-1.7H22", key: "1ailkh" }],
  ["path", { d: "M2 6h1.972a4 4 0 0 1 3.6 2.2", key: "km57vx" }],
  ["path", { d: "M22 18h-6.041a4 4 0 0 1-3.3-1.8l-.359-.45", key: "os18l9" }]
];
var Shuffle = createLucideIcon("shuffle", __iconNode1331);

// ../node_modules/lucide-react/dist/esm/icons/sigma.js
var __iconNode1332 = [
  [
    "path",
    {
      d: "M18 7V5a1 1 0 0 0-1-1H6.5a.5.5 0 0 0-.4.8l4.5 6a2 2 0 0 1 0 2.4l-4.5 6a.5.5 0 0 0 .4.8H17a1 1 0 0 0 1-1v-2",
      key: "wuwx1p"
    }
  ]
];
var Sigma = createLucideIcon("sigma", __iconNode1332);

// ../node_modules/lucide-react/dist/esm/icons/signal-high.js
var __iconNode1333 = [
  ["path", { d: "M2 20h.01", key: "4haj6o" }],
  ["path", { d: "M7 20v-4", key: "j294jx" }],
  ["path", { d: "M12 20v-8", key: "i3yub9" }],
  ["path", { d: "M17 20V8", key: "1tkaf5" }]
];
var SignalHigh = createLucideIcon("signal-high", __iconNode1333);

// ../node_modules/lucide-react/dist/esm/icons/signal-low.js
var __iconNode1334 = [
  ["path", { d: "M2 20h.01", key: "4haj6o" }],
  ["path", { d: "M7 20v-4", key: "j294jx" }]
];
var SignalLow = createLucideIcon("signal-low", __iconNode1334);

// ../node_modules/lucide-react/dist/esm/icons/signal-medium.js
var __iconNode1335 = [
  ["path", { d: "M2 20h.01", key: "4haj6o" }],
  ["path", { d: "M7 20v-4", key: "j294jx" }],
  ["path", { d: "M12 20v-8", key: "i3yub9" }]
];
var SignalMedium = createLucideIcon("signal-medium", __iconNode1335);

// ../node_modules/lucide-react/dist/esm/icons/signal-zero.js
var __iconNode1336 = [["path", { d: "M2 20h.01", key: "4haj6o" }]];
var SignalZero = createLucideIcon("signal-zero", __iconNode1336);

// ../node_modules/lucide-react/dist/esm/icons/signal.js
var __iconNode1337 = [
  ["path", { d: "M2 20h.01", key: "4haj6o" }],
  ["path", { d: "M7 20v-4", key: "j294jx" }],
  ["path", { d: "M12 20v-8", key: "i3yub9" }],
  ["path", { d: "M17 20V8", key: "1tkaf5" }],
  ["path", { d: "M22 4v16", key: "sih9yq" }]
];
var Signal = createLucideIcon("signal", __iconNode1337);

// ../node_modules/lucide-react/dist/esm/icons/signature.js
var __iconNode1338 = [
  [
    "path",
    {
      d: "m21 17-2.156-1.868A.5.5 0 0 0 18 15.5v.5a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1c0-2.545-3.991-3.97-8.5-4a1 1 0 0 0 0 5c4.153 0 4.745-11.295 5.708-13.5a2.5 2.5 0 1 1 3.31 3.284",
      key: "y32ogt"
    }
  ],
  ["path", { d: "M3 21h18", key: "itz85i" }]
];
var Signature = createLucideIcon("signature", __iconNode1338);

// ../node_modules/lucide-react/dist/esm/icons/signpost.js
var __iconNode1339 = [
  ["path", { d: "M12 13v8", key: "1l5pq0" }],
  ["path", { d: "M12 3v3", key: "1n5kay" }],
  [
    "path",
    {
      d: "M18 6a2 2 0 0 1 1.387.56l2.307 2.22a1 1 0 0 1 0 1.44l-2.307 2.22A2 2 0 0 1 18 13H6a2 2 0 0 1-1.387-.56l-2.306-2.22a1 1 0 0 1 0-1.44l2.306-2.22A2 2 0 0 1 6 6z",
      key: "gqqp9m"
    }
  ]
];
var Signpost = createLucideIcon("signpost", __iconNode1339);

// ../node_modules/lucide-react/dist/esm/icons/signpost-big.js
var __iconNode1340 = [
  ["path", { d: "M10 9H4L2 7l2-2h6", key: "1hq7x2" }],
  ["path", { d: "M14 5h6l2 2-2 2h-6", key: "bv62ej" }],
  ["path", { d: "M10 22V4a2 2 0 1 1 4 0v18", key: "eqpcf2" }],
  ["path", { d: "M8 22h8", key: "rmew8v" }]
];
var SignpostBig = createLucideIcon("signpost-big", __iconNode1340);

// ../node_modules/lucide-react/dist/esm/icons/siren.js
var __iconNode1341 = [
  ["path", { d: "M7 18v-6a5 5 0 1 1 10 0v6", key: "pcx96s" }],
  [
    "path",
    { d: "M5 21a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-1a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2z", key: "1b4s83" }
  ],
  ["path", { d: "M21 12h1", key: "jtio3y" }],
  ["path", { d: "M18.5 4.5 18 5", key: "g5sp9y" }],
  ["path", { d: "M2 12h1", key: "1uaihz" }],
  ["path", { d: "M12 2v1", key: "11qlp1" }],
  ["path", { d: "m4.929 4.929.707.707", key: "1i51kw" }],
  ["path", { d: "M12 12v6", key: "3ahymv" }]
];
var Siren = createLucideIcon("siren", __iconNode1341);

// ../node_modules/lucide-react/dist/esm/icons/skip-back.js
var __iconNode1342 = [
  [
    "path",
    {
      d: "M17.971 4.285A2 2 0 0 1 21 6v12a2 2 0 0 1-3.029 1.715l-9.997-5.998a2 2 0 0 1-.003-3.432z",
      key: "15892j"
    }
  ],
  ["path", { d: "M3 20V4", key: "1ptbpl" }]
];
var SkipBack = createLucideIcon("skip-back", __iconNode1342);

// ../node_modules/lucide-react/dist/esm/icons/skip-forward.js
var __iconNode1343 = [
  ["path", { d: "M21 4v16", key: "7j8fe9" }],
  [
    "path",
    {
      d: "M6.029 4.285A2 2 0 0 0 3 6v12a2 2 0 0 0 3.029 1.715l9.997-5.998a2 2 0 0 0 .003-3.432z",
      key: "zs4d6"
    }
  ]
];
var SkipForward = createLucideIcon("skip-forward", __iconNode1343);

// ../node_modules/lucide-react/dist/esm/icons/slack.js
var __iconNode1344 = [
  ["rect", { width: "3", height: "8", x: "13", y: "2", rx: "1.5", key: "diqz80" }],
  ["path", { d: "M19 8.5V10h1.5A1.5 1.5 0 1 0 19 8.5", key: "183iwg" }],
  ["rect", { width: "3", height: "8", x: "8", y: "14", rx: "1.5", key: "hqg7r1" }],
  ["path", { d: "M5 15.5V14H3.5A1.5 1.5 0 1 0 5 15.5", key: "76g71w" }],
  ["rect", { width: "8", height: "3", x: "14", y: "13", rx: "1.5", key: "1kmz0a" }],
  ["path", { d: "M15.5 19H14v1.5a1.5 1.5 0 1 0 1.5-1.5", key: "jc4sz0" }],
  ["rect", { width: "8", height: "3", x: "2", y: "8", rx: "1.5", key: "1omvl4" }],
  ["path", { d: "M8.5 5H10V3.5A1.5 1.5 0 1 0 8.5 5", key: "16f3cl" }]
];
var Slack = createLucideIcon("slack", __iconNode1344);

// ../node_modules/lucide-react/dist/esm/icons/slash.js
var __iconNode1345 = [["path", { d: "M22 2 2 22", key: "y4kqgn" }]];
var Slash = createLucideIcon("slash", __iconNode1345);

// ../node_modules/lucide-react/dist/esm/icons/skull.js
var __iconNode1346 = [
  ["path", { d: "m12.5 17-.5-1-.5 1h1z", key: "3me087" }],
  [
    "path",
    {
      d: "M15 22a1 1 0 0 0 1-1v-1a2 2 0 0 0 1.56-3.25 8 8 0 1 0-11.12 0A2 2 0 0 0 8 20v1a1 1 0 0 0 1 1z",
      key: "1o5pge"
    }
  ],
  ["circle", { cx: "15", cy: "12", r: "1", key: "1tmaij" }],
  ["circle", { cx: "9", cy: "12", r: "1", key: "1vctgf" }]
];
var Skull = createLucideIcon("skull", __iconNode1346);

// ../node_modules/lucide-react/dist/esm/icons/slice.js
var __iconNode1347 = [
  [
    "path",
    {
      d: "M11 16.586V19a1 1 0 0 1-1 1H2L18.37 3.63a1 1 0 1 1 3 3l-9.663 9.663a1 1 0 0 1-1.414 0L8 14",
      key: "1sllp5"
    }
  ]
];
var Slice = createLucideIcon("slice", __iconNode1347);

// ../node_modules/lucide-react/dist/esm/icons/sliders-horizontal.js
var __iconNode1348 = [
  ["path", { d: "M10 5H3", key: "1qgfaw" }],
  ["path", { d: "M12 19H3", key: "yhmn1j" }],
  ["path", { d: "M14 3v4", key: "1sua03" }],
  ["path", { d: "M16 17v4", key: "1q0r14" }],
  ["path", { d: "M21 12h-9", key: "1o4lsq" }],
  ["path", { d: "M21 19h-5", key: "1rlt1p" }],
  ["path", { d: "M21 5h-7", key: "1oszz2" }],
  ["path", { d: "M8 10v4", key: "tgpxqk" }],
  ["path", { d: "M8 12H3", key: "a7s4jb" }]
];
var SlidersHorizontal = createLucideIcon("sliders-horizontal", __iconNode1348);

// ../node_modules/lucide-react/dist/esm/icons/sliders-vertical.js
var __iconNode1349 = [
  ["path", { d: "M10 8h4", key: "1sr2af" }],
  ["path", { d: "M12 21v-9", key: "17s77i" }],
  ["path", { d: "M12 8V3", key: "13r4qs" }],
  ["path", { d: "M17 16h4", key: "h1uq16" }],
  ["path", { d: "M19 12V3", key: "o1uvq1" }],
  ["path", { d: "M19 21v-5", key: "qua636" }],
  ["path", { d: "M3 14h4", key: "bcjad9" }],
  ["path", { d: "M5 10V3", key: "cb8scm" }],
  ["path", { d: "M5 21v-7", key: "1w1uti" }]
];
var SlidersVertical = createLucideIcon("sliders-vertical", __iconNode1349);

// ../node_modules/lucide-react/dist/esm/icons/smartphone-charging.js
var __iconNode1350 = [
  ["rect", { width: "14", height: "20", x: "5", y: "2", rx: "2", ry: "2", key: "1yt0o3" }],
  ["path", { d: "M12.667 8 10 12h4l-2.667 4", key: "h9lk2d" }]
];
var SmartphoneCharging = createLucideIcon("smartphone-charging", __iconNode1350);

// ../node_modules/lucide-react/dist/esm/icons/smartphone-nfc.js
var __iconNode1351 = [
  ["rect", { width: "7", height: "12", x: "2", y: "6", rx: "1", key: "5nje8w" }],
  ["path", { d: "M13 8.32a7.43 7.43 0 0 1 0 7.36", key: "1g306n" }],
  ["path", { d: "M16.46 6.21a11.76 11.76 0 0 1 0 11.58", key: "uqvjvo" }],
  ["path", { d: "M19.91 4.1a15.91 15.91 0 0 1 .01 15.8", key: "ujntz3" }]
];
var SmartphoneNfc = createLucideIcon("smartphone-nfc", __iconNode1351);

// ../node_modules/lucide-react/dist/esm/icons/smile-plus.js
var __iconNode1352 = [
  ["path", { d: "M22 11v1a10 10 0 1 1-9-10", key: "ew0xw9" }],
  ["path", { d: "M8 14s1.5 2 4 2 4-2 4-2", key: "1y1vjs" }],
  ["line", { x1: "9", x2: "9.01", y1: "9", y2: "9", key: "yxxnd0" }],
  ["line", { x1: "15", x2: "15.01", y1: "9", y2: "9", key: "1p4y9e" }],
  ["path", { d: "M16 5h6", key: "1vod17" }],
  ["path", { d: "M19 2v6", key: "4bpg5p" }]
];
var SmilePlus = createLucideIcon("smile-plus", __iconNode1352);

// ../node_modules/lucide-react/dist/esm/icons/smartphone.js
var __iconNode1353 = [
  ["rect", { width: "14", height: "20", x: "5", y: "2", rx: "2", ry: "2", key: "1yt0o3" }],
  ["path", { d: "M12 18h.01", key: "mhygvu" }]
];
var Smartphone = createLucideIcon("smartphone", __iconNode1353);

// ../node_modules/lucide-react/dist/esm/icons/smile.js
var __iconNode1354 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M8 14s1.5 2 4 2 4-2 4-2", key: "1y1vjs" }],
  ["line", { x1: "9", x2: "9.01", y1: "9", y2: "9", key: "yxxnd0" }],
  ["line", { x1: "15", x2: "15.01", y1: "9", y2: "9", key: "1p4y9e" }]
];
var Smile = createLucideIcon("smile", __iconNode1354);

// ../node_modules/lucide-react/dist/esm/icons/snail.js
var __iconNode1355 = [
  ["path", { d: "M2 13a6 6 0 1 0 12 0 4 4 0 1 0-8 0 2 2 0 0 0 4 0", key: "hneq2s" }],
  ["circle", { cx: "10", cy: "13", r: "8", key: "194lz3" }],
  ["path", { d: "M2 21h12c4.4 0 8-3.6 8-8V7a2 2 0 1 0-4 0v6", key: "ixqyt7" }],
  ["path", { d: "M18 3 19.1 5.2", key: "9tjm43" }],
  ["path", { d: "M22 3 20.9 5.2", key: "j3odrs" }]
];
var Snail = createLucideIcon("snail", __iconNode1355);

// ../node_modules/lucide-react/dist/esm/icons/snowflake.js
var __iconNode1356 = [
  ["path", { d: "m10 20-1.25-2.5L6 18", key: "18frcb" }],
  ["path", { d: "M10 4 8.75 6.5 6 6", key: "7mghy3" }],
  ["path", { d: "m14 20 1.25-2.5L18 18", key: "1chtki" }],
  ["path", { d: "m14 4 1.25 2.5L18 6", key: "1b4wsy" }],
  ["path", { d: "m17 21-3-6h-4", key: "15hhxa" }],
  ["path", { d: "m17 3-3 6 1.5 3", key: "11697g" }],
  ["path", { d: "M2 12h6.5L10 9", key: "kv9z4n" }],
  ["path", { d: "m20 10-1.5 2 1.5 2", key: "1swlpi" }],
  ["path", { d: "M22 12h-6.5L14 15", key: "1mxi28" }],
  ["path", { d: "m4 10 1.5 2L4 14", key: "k9enpj" }],
  ["path", { d: "m7 21 3-6-1.5-3", key: "j8hb9u" }],
  ["path", { d: "m7 3 3 6h4", key: "1otusx" }]
];
var Snowflake = createLucideIcon("snowflake", __iconNode1356);

// ../node_modules/lucide-react/dist/esm/icons/soap-dispenser-droplet.js
var __iconNode1357 = [
  ["path", { d: "M10.5 2v4", key: "1xt6in" }],
  ["path", { d: "M14 2H7a2 2 0 0 0-2 2", key: "e6xig3" }],
  [
    "path",
    {
      d: "M19.29 14.76A6.67 6.67 0 0 1 17 11a6.6 6.6 0 0 1-2.29 3.76c-1.15.92-1.71 2.04-1.71 3.19 0 2.22 1.8 4.05 4 4.05s4-1.83 4-4.05c0-1.16-.57-2.26-1.71-3.19",
      key: "adq7uc"
    }
  ],
  [
    "path",
    {
      d: "M9.607 21H6a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h7V7a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3",
      key: "t9hm96"
    }
  ]
];
var SoapDispenserDroplet = createLucideIcon("soap-dispenser-droplet", __iconNode1357);

// ../node_modules/lucide-react/dist/esm/icons/sofa.js
var __iconNode1358 = [
  ["path", { d: "M20 9V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v3", key: "1dgpiv" }],
  [
    "path",
    {
      d: "M2 16a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v1.5a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5V11a2 2 0 0 0-4 0z",
      key: "xacw8m"
    }
  ],
  ["path", { d: "M4 18v2", key: "jwo5n2" }],
  ["path", { d: "M20 18v2", key: "1ar1qi" }],
  ["path", { d: "M12 4v9", key: "oqhhn3" }]
];
var Sofa = createLucideIcon("sofa", __iconNode1358);

// ../node_modules/lucide-react/dist/esm/icons/solar-panel.js
var __iconNode1359 = [
  ["path", { d: "M11 2h2", key: "isr7bz" }],
  ["path", { d: "m14.28 14-4.56 8", key: "4anwcf" }],
  ["path", { d: "m21 22-1.558-4H4.558", key: "enk13h" }],
  ["path", { d: "M3 10v2", key: "w8mti9" }],
  [
    "path",
    {
      d: "M6.245 15.04A2 2 0 0 1 8 14h12a1 1 0 0 1 .864 1.505l-3.11 5.457A2 2 0 0 1 16 22H4a1 1 0 0 1-.863-1.506z",
      key: "pouggg"
    }
  ],
  ["path", { d: "M7 2a4 4 0 0 1-4 4", key: "78s8of" }],
  ["path", { d: "m8.66 7.66 1.41 1.41", key: "1vaqj8" }]
];
var SolarPanel = createLucideIcon("solar-panel", __iconNode1359);

// ../node_modules/lucide-react/dist/esm/icons/space.js
var __iconNode1360 = [
  ["path", { d: "M22 17v1c0 .5-.5 1-1 1H3c-.5 0-1-.5-1-1v-1", key: "lt2kga" }]
];
var Space = createLucideIcon("space", __iconNode1360);

// ../node_modules/lucide-react/dist/esm/icons/soup.js
var __iconNode1361 = [
  ["path", { d: "M12 21a9 9 0 0 0 9-9H3a9 9 0 0 0 9 9Z", key: "4rw317" }],
  ["path", { d: "M7 21h10", key: "1b0cd5" }],
  ["path", { d: "M19.5 12 22 6", key: "shfsr5" }],
  [
    "path",
    {
      d: "M16.25 3c.27.1.8.53.75 1.36-.06.83-.93 1.2-1 2.02-.05.78.34 1.24.73 1.62",
      key: "rpc6vp"
    }
  ],
  [
    "path",
    {
      d: "M11.25 3c.27.1.8.53.74 1.36-.05.83-.93 1.2-.98 2.02-.06.78.33 1.24.72 1.62",
      key: "1lf63m"
    }
  ],
  [
    "path",
    { d: "M6.25 3c.27.1.8.53.75 1.36-.06.83-.93 1.2-1 2.02-.05.78.34 1.24.74 1.62", key: "97tijn" }
  ]
];
var Soup = createLucideIcon("soup", __iconNode1361);

// ../node_modules/lucide-react/dist/esm/icons/spade.js
var __iconNode1362 = [
  ["path", { d: "M12 18v4", key: "jadmvz" }],
  [
    "path",
    {
      d: "M2 14.499a5.5 5.5 0 0 0 9.591 3.675.6.6 0 0 1 .818.001A5.5 5.5 0 0 0 22 14.5c0-2.29-1.5-4-3-5.5l-5.492-5.312a2 2 0 0 0-3-.02L5 8.999c-1.5 1.5-3 3.2-3 5.5",
      key: "1aw2pz"
    }
  ]
];
var Spade = createLucideIcon("spade", __iconNode1362);

// ../node_modules/lucide-react/dist/esm/icons/sparkle.js
var __iconNode1363 = [
  [
    "path",
    {
      d: "M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",
      key: "1s2grr"
    }
  ]
];
var Sparkle = createLucideIcon("sparkle", __iconNode1363);

// ../node_modules/lucide-react/dist/esm/icons/sparkles.js
var __iconNode1364 = [
  [
    "path",
    {
      d: "M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",
      key: "1s2grr"
    }
  ],
  ["path", { d: "M20 2v4", key: "1rf3ol" }],
  ["path", { d: "M22 4h-4", key: "gwowj6" }],
  ["circle", { cx: "4", cy: "20", r: "2", key: "6kqj1y" }]
];
var Sparkles = createLucideIcon("sparkles", __iconNode1364);

// ../node_modules/lucide-react/dist/esm/icons/speaker.js
var __iconNode1365 = [
  ["rect", { width: "16", height: "20", x: "4", y: "2", rx: "2", key: "1nb95v" }],
  ["path", { d: "M12 6h.01", key: "1vi96p" }],
  ["circle", { cx: "12", cy: "14", r: "4", key: "1jruaj" }],
  ["path", { d: "M12 14h.01", key: "1etili" }]
];
var Speaker = createLucideIcon("speaker", __iconNode1365);

// ../node_modules/lucide-react/dist/esm/icons/speech.js
var __iconNode1366 = [
  [
    "path",
    {
      d: "M8.8 20v-4.1l1.9.2a2.3 2.3 0 0 0 2.164-2.1V8.3A5.37 5.37 0 0 0 2 8.25c0 2.8.656 3.054 1 4.55a5.77 5.77 0 0 1 .029 2.758L2 20",
      key: "11atix"
    }
  ],
  ["path", { d: "M19.8 17.8a7.5 7.5 0 0 0 .003-10.603", key: "yol142" }],
  ["path", { d: "M17 15a3.5 3.5 0 0 0-.025-4.975", key: "ssbmkc" }]
];
var Speech = createLucideIcon("speech", __iconNode1366);

// ../node_modules/lucide-react/dist/esm/icons/spell-check-2.js
var __iconNode1367 = [
  ["path", { d: "m6 16 6-12 6 12", key: "1b4byz" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }],
  [
    "path",
    {
      d: "M4 21c1.1 0 1.1-1 2.3-1s1.1 1 2.3 1c1.1 0 1.1-1 2.3-1 1.1 0 1.1 1 2.3 1 1.1 0 1.1-1 2.3-1 1.1 0 1.1 1 2.3 1 1.1 0 1.1-1 2.3-1",
      key: "8mdmtu"
    }
  ]
];
var SpellCheck2 = createLucideIcon("spell-check-2", __iconNode1367);

// ../node_modules/lucide-react/dist/esm/icons/spell-check.js
var __iconNode1368 = [
  ["path", { d: "m6 16 6-12 6 12", key: "1b4byz" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }],
  ["path", { d: "m16 20 2 2 4-4", key: "13tcca" }]
];
var SpellCheck = createLucideIcon("spell-check", __iconNode1368);

// ../node_modules/lucide-react/dist/esm/icons/spline-pointer.js
var __iconNode1369 = [
  [
    "path",
    {
      d: "M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z",
      key: "xwnzip"
    }
  ],
  ["path", { d: "M5 17A12 12 0 0 1 17 5", key: "1okkup" }],
  ["circle", { cx: "19", cy: "5", r: "2", key: "mhkx31" }],
  ["circle", { cx: "5", cy: "19", r: "2", key: "v8kfzx" }]
];
var SplinePointer = createLucideIcon("spline-pointer", __iconNode1369);

// ../node_modules/lucide-react/dist/esm/icons/spline.js
var __iconNode1370 = [
  ["circle", { cx: "19", cy: "5", r: "2", key: "mhkx31" }],
  ["circle", { cx: "5", cy: "19", r: "2", key: "v8kfzx" }],
  ["path", { d: "M5 17A12 12 0 0 1 17 5", key: "1okkup" }]
];
var Spline = createLucideIcon("spline", __iconNode1370);

// ../node_modules/lucide-react/dist/esm/icons/split.js
var __iconNode1371 = [
  ["path", { d: "M16 3h5v5", key: "1806ms" }],
  ["path", { d: "M8 3H3v5", key: "15dfkv" }],
  ["path", { d: "M12 22v-8.3a4 4 0 0 0-1.172-2.872L3 3", key: "1qrqzj" }],
  ["path", { d: "m15 9 6-6", key: "ko1vev" }]
];
var Split = createLucideIcon("split", __iconNode1371);

// ../node_modules/lucide-react/dist/esm/icons/spool.js
var __iconNode1372 = [
  [
    "path",
    {
      d: "M17 13.44 4.442 17.082A2 2 0 0 0 4.982 21H19a2 2 0 0 0 .558-3.921l-1.115-.32A2 2 0 0 1 17 14.837V7.66",
      key: "13vns8"
    }
  ],
  [
    "path",
    {
      d: "m7 10.56 12.558-3.642A2 2 0 0 0 19.018 3H5a2 2 0 0 0-.558 3.921l1.115.32A2 2 0 0 1 7 9.163v7.178",
      key: "s8x3u0"
    }
  ]
];
var Spool = createLucideIcon("spool", __iconNode1372);

// ../node_modules/lucide-react/dist/esm/icons/spotlight.js
var __iconNode1373 = [
  ["path", { d: "M15.295 19.562 16 22", key: "31jsb7" }],
  ["path", { d: "m17 16 3.758 2.098", key: "121ar7" }],
  ["path", { d: "m19 12.5 3.026-.598", key: "19ukd3" }],
  [
    "path",
    {
      d: "M7.61 6.3a3 3 0 0 0-3.92 1.3l-1.38 2.79a3 3 0 0 0 1.3 3.91l6.89 3.597a1 1 0 0 0 1.342-.447l3.106-6.211a1 1 0 0 0-.447-1.341z",
      key: "lwb9l9"
    }
  ],
  ["path", { d: "M8 9V2", key: "1xa0v7" }]
];
var Spotlight = createLucideIcon("spotlight", __iconNode1373);

// ../node_modules/lucide-react/dist/esm/icons/spray-can.js
var __iconNode1374 = [
  ["path", { d: "M3 3h.01", key: "159qn6" }],
  ["path", { d: "M7 5h.01", key: "1hq22a" }],
  ["path", { d: "M11 7h.01", key: "1osv80" }],
  ["path", { d: "M3 7h.01", key: "1xzrh3" }],
  ["path", { d: "M7 9h.01", key: "19b3jx" }],
  ["path", { d: "M3 11h.01", key: "1eifu7" }],
  ["rect", { width: "4", height: "4", x: "15", y: "5", key: "mri9e4" }],
  ["path", { d: "m19 9 2 2v10c0 .6-.4 1-1 1h-6c-.6 0-1-.4-1-1V11l2-2", key: "aib6hk" }],
  ["path", { d: "m13 14 8-2", key: "1d7bmk" }],
  ["path", { d: "m13 19 8-2", key: "1y2vml" }]
];
var SprayCan = createLucideIcon("spray-can", __iconNode1374);

// ../node_modules/lucide-react/dist/esm/icons/sprout.js
var __iconNode1375 = [
  [
    "path",
    {
      d: "M14 9.536V7a4 4 0 0 1 4-4h1.5a.5.5 0 0 1 .5.5V5a4 4 0 0 1-4 4 4 4 0 0 0-4 4c0 2 1 3 1 5a5 5 0 0 1-1 3",
      key: "139s4v"
    }
  ],
  ["path", { d: "M4 9a5 5 0 0 1 8 4 5 5 0 0 1-8-4", key: "1dlkgp" }],
  ["path", { d: "M5 21h14", key: "11awu3" }]
];
var Sprout = createLucideIcon("sprout", __iconNode1375);

// ../node_modules/lucide-react/dist/esm/icons/square-activity.js
var __iconNode1376 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M17 12h-2l-2 5-2-10-2 5H7", key: "15hlnc" }]
];
var SquareActivity = createLucideIcon("square-activity", __iconNode1376);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-down-left.js
var __iconNode1377 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "m16 8-8 8", key: "166keh" }],
  ["path", { d: "M16 16H8V8", key: "1w2ppm" }]
];
var SquareArrowDownLeft = createLucideIcon("square-arrow-down-left", __iconNode1377);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-down-right.js
var __iconNode1378 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "m8 8 8 8", key: "1imecy" }],
  ["path", { d: "M16 8v8H8", key: "1lbpgo" }]
];
var SquareArrowDownRight = createLucideIcon("square-arrow-down-right", __iconNode1378);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-down.js
var __iconNode1379 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M12 8v8", key: "napkw2" }],
  ["path", { d: "m8 12 4 4 4-4", key: "k98ssh" }]
];
var SquareArrowDown = createLucideIcon("square-arrow-down", __iconNode1379);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-left.js
var __iconNode1380 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "m12 8-4 4 4 4", key: "15vm53" }],
  ["path", { d: "M16 12H8", key: "1fr5h0" }]
];
var SquareArrowLeft = createLucideIcon("square-arrow-left", __iconNode1380);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-out-down-left.js
var __iconNode1381 = [
  ["path", { d: "M13 21h6a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v6", key: "14qz4y" }],
  ["path", { d: "m3 21 9-9", key: "1jfql5" }],
  ["path", { d: "M9 21H3v-6", key: "wtvkvv" }]
];
var SquareArrowOutDownLeft = createLucideIcon("square-arrow-out-down-left", __iconNode1381);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-out-down-right.js
var __iconNode1382 = [
  ["path", { d: "M21 11V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6", key: "14rsvq" }],
  ["path", { d: "m21 21-9-9", key: "1et2py" }],
  ["path", { d: "M21 15v6h-6", key: "1jko0i" }]
];
var SquareArrowOutDownRight = createLucideIcon("square-arrow-out-down-right", __iconNode1382);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-out-up-left.js
var __iconNode1383 = [
  ["path", { d: "M13 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-6", key: "14mv1t" }],
  ["path", { d: "m3 3 9 9", key: "rks13r" }],
  ["path", { d: "M3 9V3h6", key: "ira0h2" }]
];
var SquareArrowOutUpLeft = createLucideIcon("square-arrow-out-up-left", __iconNode1383);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-right-enter.js
var __iconNode1384 = [
  ["path", { d: "m10 16 4-4-4-4", key: "w9835o" }],
  ["path", { d: "M3 12h11", key: "pmja8f" }],
  [
    "path",
    {
      d: "M3 8V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3",
      key: "1bqs5q"
    }
  ]
];
var SquareArrowRightEnter = createLucideIcon("square-arrow-right-enter", __iconNode1384);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-out-up-right.js
var __iconNode1385 = [
  ["path", { d: "M21 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h6", key: "y09zxi" }],
  ["path", { d: "m21 3-9 9", key: "mpx6sq" }],
  ["path", { d: "M15 3h6v6", key: "1q9fwt" }]
];
var SquareArrowOutUpRight = createLucideIcon("square-arrow-out-up-right", __iconNode1385);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-right-exit.js
var __iconNode1386 = [
  ["path", { d: "M10 12h11", key: "6m4ad9" }],
  ["path", { d: "m17 16 4-4-4-4", key: "iin4zf" }],
  [
    "path",
    {
      d: "M21 6.344V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-1.344",
      key: "1ojbhp"
    }
  ]
];
var SquareArrowRightExit = createLucideIcon("square-arrow-right-exit", __iconNode1386);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-right.js
var __iconNode1387 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }],
  ["path", { d: "m12 16 4-4-4-4", key: "1i9zcv" }]
];
var SquareArrowRight = createLucideIcon("square-arrow-right", __iconNode1387);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-up-left.js
var __iconNode1388 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M8 16V8h8", key: "19xb1h" }],
  ["path", { d: "M16 16 8 8", key: "1qdy8n" }]
];
var SquareArrowUpLeft = createLucideIcon("square-arrow-up-left", __iconNode1388);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-up-right.js
var __iconNode1389 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M8 8h8v8", key: "b65dnt" }],
  ["path", { d: "m8 16 8-8", key: "13b9ih" }]
];
var SquareArrowUpRight = createLucideIcon("square-arrow-up-right", __iconNode1389);

// ../node_modules/lucide-react/dist/esm/icons/square-arrow-up.js
var __iconNode1390 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "m16 12-4-4-4 4", key: "177agl" }],
  ["path", { d: "M12 16V8", key: "1sbj14" }]
];
var SquareArrowUp = createLucideIcon("square-arrow-up", __iconNode1390);

// ../node_modules/lucide-react/dist/esm/icons/square-bottom-dashed-scissors.js
var __iconNode1391 = [
  ["line", { x1: "5", y1: "3", x2: "19", y2: "3", key: "x74652" }],
  ["line", { x1: "3", y1: "5", x2: "3", y2: "19", key: "31ivqu" }],
  ["line", { x1: "21", y1: "5", x2: "21", y2: "19", key: "1am4cd" }],
  ["line", { x1: "9", y1: "21", x2: "10", y2: "21", key: "sb02er" }],
  ["line", { x1: "14", y1: "21", x2: "15", y2: "21", key: "1bvb1m" }],
  ["path", { d: "M 3 5 A2 2 0 0 1 5 3", key: "dbypyf" }],
  ["path", { d: "M 19 3 A2 2 0 0 1 21 5", key: "y6haui" }],
  ["path", { d: "M 5 21 A2 2 0 0 1 3 19", key: "kb75wq" }],
  ["path", { d: "M 21 19 A2 2 0 0 1 19 21", key: "1p3zbf" }],
  ["circle", { cx: "8.5", cy: "8.5", r: "1.5", key: "cn5opk" }],
  ["line", { x1: "9.56066", y1: "9.56066", x2: "12", y2: "12", key: "mksg6j" }],
  ["line", { x1: "17", y1: "17", x2: "14.82", y2: "14.82", key: "1lwi1d" }],
  ["circle", { cx: "8.5", cy: "15.5", r: "1.5", key: "12hfy1" }],
  ["line", { x1: "9.56066", y1: "14.43934", x2: "17", y2: "7", key: "4jyfgs" }]
];
var SquareBottomDashedScissors = createLucideIcon("square-bottom-dashed-scissors", __iconNode1391);

// ../node_modules/lucide-react/dist/esm/icons/square-asterisk.js
var __iconNode1392 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M12 8v8", key: "napkw2" }],
  ["path", { d: "m8.5 14 7-4", key: "12hpby" }],
  ["path", { d: "m8.5 10 7 4", key: "wwy2dy" }]
];
var SquareAsterisk = createLucideIcon("square-asterisk", __iconNode1392);

// ../node_modules/lucide-react/dist/esm/icons/square-centerline-dashed-horizontal.js
var __iconNode1393 = [
  ["path", { d: "M8 3H5a2 2 0 0 0-2 2v14c0 1.1.9 2 2 2h3", key: "1i73f7" }],
  ["path", { d: "M16 3h3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-3", key: "saxlbk" }],
  ["path", { d: "M12 20v2", key: "1lh1kg" }],
  ["path", { d: "M12 14v2", key: "8jcxud" }],
  ["path", { d: "M12 8v2", key: "1woqiv" }],
  ["path", { d: "M12 2v2", key: "tus03m" }]
];
var SquareCenterlineDashedHorizontal = createLucideIcon(
  "square-centerline-dashed-horizontal",
  __iconNode1393
);

// ../node_modules/lucide-react/dist/esm/icons/square-centerline-dashed-vertical.js
var __iconNode1394 = [
  ["path", { d: "M21 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v3", key: "14bfxa" }],
  ["path", { d: "M21 16v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3", key: "14rx03" }],
  ["path", { d: "M4 12H2", key: "rhcxmi" }],
  ["path", { d: "M10 12H8", key: "s88cx1" }],
  ["path", { d: "M16 12h-2", key: "10asgb" }],
  ["path", { d: "M22 12h-2", key: "14jgyd" }]
];
var SquareCenterlineDashedVertical = createLucideIcon(
  "square-centerline-dashed-vertical",
  __iconNode1394
);

// ../node_modules/lucide-react/dist/esm/icons/square-chart-gantt.js
var __iconNode1395 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M9 8h7", key: "kbo1nt" }],
  ["path", { d: "M8 12h6", key: "ikassy" }],
  ["path", { d: "M11 16h5", key: "oq65wt" }]
];
var SquareChartGantt = createLucideIcon("square-chart-gantt", __iconNode1395);

// ../node_modules/lucide-react/dist/esm/icons/square-check-big.js
var __iconNode1396 = [
  [
    "path",
    { d: "M21 10.656V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12.344", key: "2acyp4" }
  ],
  ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }]
];
var SquareCheckBig = createLucideIcon("square-check-big", __iconNode1396);

// ../node_modules/lucide-react/dist/esm/icons/square-check.js
var __iconNode1397 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
];
var SquareCheck = createLucideIcon("square-check", __iconNode1397);

// ../node_modules/lucide-react/dist/esm/icons/square-chevron-down.js
var __iconNode1398 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "m16 10-4 4-4-4", key: "894hmk" }]
];
var SquareChevronDown = createLucideIcon("square-chevron-down", __iconNode1398);

// ../node_modules/lucide-react/dist/esm/icons/square-chevron-left.js
var __iconNode1399 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "m14 16-4-4 4-4", key: "ojs7w8" }]
];
var SquareChevronLeft = createLucideIcon("square-chevron-left", __iconNode1399);

// ../node_modules/lucide-react/dist/esm/icons/square-chevron-right.js
var __iconNode1400 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "m10 8 4 4-4 4", key: "1wy4r4" }]
];
var SquareChevronRight = createLucideIcon("square-chevron-right", __iconNode1400);

// ../node_modules/lucide-react/dist/esm/icons/square-chevron-up.js
var __iconNode1401 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "m8 14 4-4 4 4", key: "fy2ptz" }]
];
var SquareChevronUp = createLucideIcon("square-chevron-up", __iconNode1401);

// ../node_modules/lucide-react/dist/esm/icons/square-code.js
var __iconNode1402 = [
  ["path", { d: "m10 9-3 3 3 3", key: "1oro0q" }],
  ["path", { d: "m14 15 3-3-3-3", key: "bz13h7" }],
  ["rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", key: "h1oib" }]
];
var SquareCode = createLucideIcon("square-code", __iconNode1402);

// ../node_modules/lucide-react/dist/esm/icons/square-dashed-bottom.js
var __iconNode1403 = [
  [
    "path",
    { d: "M5 21a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2", key: "as5y1o" }
  ],
  ["path", { d: "M9 21h1", key: "15o7lz" }],
  ["path", { d: "M14 21h1", key: "v9vybs" }]
];
var SquareDashedBottom = createLucideIcon("square-dashed-bottom", __iconNode1403);

// ../node_modules/lucide-react/dist/esm/icons/square-dashed-bottom-code.js
var __iconNode1404 = [
  ["path", { d: "M10 9.5 8 12l2 2.5", key: "3mjy60" }],
  ["path", { d: "M14 21h1", key: "v9vybs" }],
  ["path", { d: "m14 9.5 2 2.5-2 2.5", key: "1bir2l" }],
  [
    "path",
    { d: "M5 21a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2", key: "as5y1o" }
  ],
  ["path", { d: "M9 21h1", key: "15o7lz" }]
];
var SquareDashedBottomCode = createLucideIcon("square-dashed-bottom-code", __iconNode1404);

// ../node_modules/lucide-react/dist/esm/icons/square-dashed-kanban.js
var __iconNode1405 = [
  ["path", { d: "M8 7v7", key: "1x2jlm" }],
  ["path", { d: "M12 7v4", key: "xawao1" }],
  ["path", { d: "M16 7v9", key: "1hp2iy" }],
  ["path", { d: "M5 3a2 2 0 0 0-2 2", key: "y57alp" }],
  ["path", { d: "M9 3h1", key: "1yesri" }],
  ["path", { d: "M14 3h1", key: "1ec4yj" }],
  ["path", { d: "M19 3a2 2 0 0 1 2 2", key: "18rm91" }],
  ["path", { d: "M21 9v1", key: "mxsmne" }],
  ["path", { d: "M21 14v1", key: "169vum" }],
  ["path", { d: "M21 19a2 2 0 0 1-2 2", key: "1j7049" }],
  ["path", { d: "M14 21h1", key: "v9vybs" }],
  ["path", { d: "M9 21h1", key: "15o7lz" }],
  ["path", { d: "M5 21a2 2 0 0 1-2-2", key: "sbafld" }],
  ["path", { d: "M3 14v1", key: "vnatye" }],
  ["path", { d: "M3 9v1", key: "1r0deq" }]
];
var SquareDashedKanban = createLucideIcon("square-dashed-kanban", __iconNode1405);

// ../node_modules/lucide-react/dist/esm/icons/square-dashed-mouse-pointer.js
var __iconNode1406 = [
  [
    "path",
    {
      d: "M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z",
      key: "xwnzip"
    }
  ],
  ["path", { d: "M5 3a2 2 0 0 0-2 2", key: "y57alp" }],
  ["path", { d: "M19 3a2 2 0 0 1 2 2", key: "18rm91" }],
  ["path", { d: "M5 21a2 2 0 0 1-2-2", key: "sbafld" }],
  ["path", { d: "M9 3h1", key: "1yesri" }],
  ["path", { d: "M9 21h2", key: "1qve2z" }],
  ["path", { d: "M14 3h1", key: "1ec4yj" }],
  ["path", { d: "M3 9v1", key: "1r0deq" }],
  ["path", { d: "M21 9v2", key: "p14lih" }],
  ["path", { d: "M3 14v1", key: "vnatye" }]
];
var SquareDashedMousePointer = createLucideIcon("square-dashed-mouse-pointer", __iconNode1406);

// ../node_modules/lucide-react/dist/esm/icons/square-dashed-top-solid.js
var __iconNode1407 = [
  ["path", { d: "M14 21h1", key: "v9vybs" }],
  ["path", { d: "M21 14v1", key: "169vum" }],
  ["path", { d: "M21 19a2 2 0 0 1-2 2", key: "1j7049" }],
  ["path", { d: "M21 9v1", key: "mxsmne" }],
  ["path", { d: "M3 14v1", key: "vnatye" }],
  ["path", { d: "M3 5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2", key: "89voep" }],
  ["path", { d: "M3 9v1", key: "1r0deq" }],
  ["path", { d: "M5 21a2 2 0 0 1-2-2", key: "sbafld" }],
  ["path", { d: "M9 21h1", key: "15o7lz" }]
];
var SquareDashedTopSolid = createLucideIcon("square-dashed-top-solid", __iconNode1407);

// ../node_modules/lucide-react/dist/esm/icons/square-dashed.js
var __iconNode1408 = [
  ["path", { d: "M5 3a2 2 0 0 0-2 2", key: "y57alp" }],
  ["path", { d: "M19 3a2 2 0 0 1 2 2", key: "18rm91" }],
  ["path", { d: "M21 19a2 2 0 0 1-2 2", key: "1j7049" }],
  ["path", { d: "M5 21a2 2 0 0 1-2-2", key: "sbafld" }],
  ["path", { d: "M9 3h1", key: "1yesri" }],
  ["path", { d: "M9 21h1", key: "15o7lz" }],
  ["path", { d: "M14 3h1", key: "1ec4yj" }],
  ["path", { d: "M14 21h1", key: "v9vybs" }],
  ["path", { d: "M3 9v1", key: "1r0deq" }],
  ["path", { d: "M21 9v1", key: "mxsmne" }],
  ["path", { d: "M3 14v1", key: "vnatye" }],
  ["path", { d: "M21 14v1", key: "169vum" }]
];
var SquareDashed = createLucideIcon("square-dashed", __iconNode1408);

// ../node_modules/lucide-react/dist/esm/icons/square-divide.js
var __iconNode1409 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["line", { x1: "8", x2: "16", y1: "12", y2: "12", key: "1jonct" }],
  ["line", { x1: "12", x2: "12", y1: "16", y2: "16", key: "aqc6ln" }],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "8", key: "1mkcni" }]
];
var SquareDivide = createLucideIcon("square-divide", __iconNode1409);

// ../node_modules/lucide-react/dist/esm/icons/square-dot.js
var __iconNode1410 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }]
];
var SquareDot = createLucideIcon("square-dot", __iconNode1410);

// ../node_modules/lucide-react/dist/esm/icons/square-equal.js
var __iconNode1411 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M7 10h10", key: "1101jm" }],
  ["path", { d: "M7 14h10", key: "1mhdw3" }]
];
var SquareEqual = createLucideIcon("square-equal", __iconNode1411);

// ../node_modules/lucide-react/dist/esm/icons/square-function.js
var __iconNode1412 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["path", { d: "M9 17c2 0 2.8-1 2.8-2.8V10c0-2 1-3.3 3.2-3", key: "m1af9g" }],
  ["path", { d: "M9 11.2h5.7", key: "3zgcl2" }]
];
var SquareFunction = createLucideIcon("square-function", __iconNode1412);

// ../node_modules/lucide-react/dist/esm/icons/square-kanban.js
var __iconNode1413 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M8 7v7", key: "1x2jlm" }],
  ["path", { d: "M12 7v4", key: "xawao1" }],
  ["path", { d: "M16 7v9", key: "1hp2iy" }]
];
var SquareKanban = createLucideIcon("square-kanban", __iconNode1413);

// ../node_modules/lucide-react/dist/esm/icons/square-library.js
var __iconNode1414 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M7 7v10", key: "d5nglc" }],
  ["path", { d: "M11 7v10", key: "pptsnr" }],
  ["path", { d: "m15 7 2 10", key: "1m7qm5" }]
];
var SquareLibrary = createLucideIcon("square-library", __iconNode1414);

// ../node_modules/lucide-react/dist/esm/icons/square-m.js
var __iconNode1415 = [
  [
    "path",
    {
      d: "M8 16V8.5a.5.5 0 0 1 .9-.3l2.7 3.599a.5.5 0 0 0 .8 0l2.7-3.6a.5.5 0 0 1 .9.3V16",
      key: "1ywlsj"
    }
  ],
  ["rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", key: "h1oib" }]
];
var SquareM = createLucideIcon("square-m", __iconNode1415);

// ../node_modules/lucide-react/dist/esm/icons/square-menu.js
var __iconNode1416 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M7 8h10", key: "1jw688" }],
  ["path", { d: "M7 12h10", key: "b7w52i" }],
  ["path", { d: "M7 16h10", key: "wp8him" }]
];
var SquareMenu = createLucideIcon("square-menu", __iconNode1416);

// ../node_modules/lucide-react/dist/esm/icons/square-minus.js
var __iconNode1417 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }]
];
var SquareMinus = createLucideIcon("square-minus", __iconNode1417);

// ../node_modules/lucide-react/dist/esm/icons/square-mouse-pointer.js
var __iconNode1418 = [
  [
    "path",
    {
      d: "M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z",
      key: "xwnzip"
    }
  ],
  ["path", { d: "M21 11V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6", key: "14rsvq" }]
];
var SquareMousePointer = createLucideIcon("square-mouse-pointer", __iconNode1418);

// ../node_modules/lucide-react/dist/esm/icons/square-parking-off.js
var __iconNode1419 = [
  ["path", { d: "M3.6 3.6A2 2 0 0 1 5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-.59 1.41", key: "9l1ft6" }],
  ["path", { d: "M3 8.7V19a2 2 0 0 0 2 2h10.3", key: "17knke" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M13 13a3 3 0 1 0 0-6H9v2", key: "uoagbd" }],
  ["path", { d: "M9 17v-2.3", key: "1jxgo2" }]
];
var SquareParkingOff = createLucideIcon("square-parking-off", __iconNode1419);

// ../node_modules/lucide-react/dist/esm/icons/square-parking.js
var __iconNode1420 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M9 17V7h4a3 3 0 0 1 0 6H9", key: "1dfk2c" }]
];
var SquareParking = createLucideIcon("square-parking", __iconNode1420);

// ../node_modules/lucide-react/dist/esm/icons/square-pause.js
var __iconNode1421 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["line", { x1: "10", x2: "10", y1: "15", y2: "9", key: "c1nkhi" }],
  ["line", { x1: "14", x2: "14", y1: "15", y2: "9", key: "h65svq" }]
];
var SquarePause = createLucideIcon("square-pause", __iconNode1421);

// ../node_modules/lucide-react/dist/esm/icons/square-pen.js
var __iconNode1422 = [
  ["path", { d: "M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7", key: "1m0v6g" }],
  [
    "path",
    {
      d: "M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z",
      key: "ohrbg2"
    }
  ]
];
var SquarePen = createLucideIcon("square-pen", __iconNode1422);

// ../node_modules/lucide-react/dist/esm/icons/square-percent.js
var __iconNode1423 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "M9 9h.01", key: "1q5me6" }],
  ["path", { d: "M15 15h.01", key: "lqbp3k" }]
];
var SquarePercent = createLucideIcon("square-percent", __iconNode1423);

// ../node_modules/lucide-react/dist/esm/icons/square-pi.js
var __iconNode1424 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M7 7h10", key: "udp07y" }],
  ["path", { d: "M10 7v10", key: "i1d9ee" }],
  ["path", { d: "M16 17a2 2 0 0 1-2-2V7", key: "ftwdc7" }]
];
var SquarePi = createLucideIcon("square-pi", __iconNode1424);

// ../node_modules/lucide-react/dist/esm/icons/square-pilcrow.js
var __iconNode1425 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M12 12H9.5a2.5 2.5 0 0 1 0-5H17", key: "1l9586" }],
  ["path", { d: "M12 7v10", key: "jspqdw" }],
  ["path", { d: "M16 7v10", key: "lavkr4" }]
];
var SquarePilcrow = createLucideIcon("square-pilcrow", __iconNode1425);

// ../node_modules/lucide-react/dist/esm/icons/square-play.js
var __iconNode1426 = [
  ["rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", key: "h1oib" }],
  [
    "path",
    {
      d: "M9 9.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997A1 1 0 0 1 9 14.996z",
      key: "kmsa83"
    }
  ]
];
var SquarePlay = createLucideIcon("square-play", __iconNode1426);

// ../node_modules/lucide-react/dist/esm/icons/square-plus.js
var __iconNode1427 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }],
  ["path", { d: "M12 8v8", key: "napkw2" }]
];
var SquarePlus = createLucideIcon("square-plus", __iconNode1427);

// ../node_modules/lucide-react/dist/esm/icons/square-power.js
var __iconNode1428 = [
  ["path", { d: "M12 7v4", key: "xawao1" }],
  ["path", { d: "M7.998 9.003a5 5 0 1 0 8-.005", key: "1pek45" }],
  ["rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", key: "h1oib" }]
];
var SquarePower = createLucideIcon("square-power", __iconNode1428);

// ../node_modules/lucide-react/dist/esm/icons/square-radical.js
var __iconNode1429 = [
  ["path", { d: "M7 12h2l2 5 2-10h4", key: "1fxv6h" }],
  ["rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", key: "h1oib" }]
];
var SquareRadical = createLucideIcon("square-radical", __iconNode1429);

// ../node_modules/lucide-react/dist/esm/icons/square-round-corner.js
var __iconNode1430 = [
  ["path", { d: "M21 11a8 8 0 0 0-8-8", key: "1lxwo5" }],
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", key: "1dv2y5" }]
];
var SquareRoundCorner = createLucideIcon("square-round-corner", __iconNode1430);

// ../node_modules/lucide-react/dist/esm/icons/square-scissors.js
var __iconNode1431 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["circle", { cx: "8.5", cy: "8.5", r: "1.5", key: "cn5opk" }],
  ["line", { x1: "9.56066", y1: "9.56066", x2: "12", y2: "12", key: "mksg6j" }],
  ["line", { x1: "17", y1: "17", x2: "14.82", y2: "14.82", key: "1lwi1d" }],
  ["circle", { cx: "8.5", cy: "15.5", r: "1.5", key: "12hfy1" }],
  ["line", { x1: "9.56066", y1: "14.43934", x2: "17", y2: "7", key: "4jyfgs" }]
];
var SquareScissors = createLucideIcon("square-scissors", __iconNode1431);

// ../node_modules/lucide-react/dist/esm/icons/square-sigma.js
var __iconNode1432 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M16 8.9V7H8l4 5-4 5h8v-1.9", key: "9nih0i" }]
];
var SquareSigma = createLucideIcon("square-sigma", __iconNode1432);

// ../node_modules/lucide-react/dist/esm/icons/square-slash.js
var __iconNode1433 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["line", { x1: "9", x2: "15", y1: "15", y2: "9", key: "1dfufj" }]
];
var SquareSlash = createLucideIcon("square-slash", __iconNode1433);

// ../node_modules/lucide-react/dist/esm/icons/square-split-horizontal.js
var __iconNode1434 = [
  ["path", { d: "M8 19H5c-1 0-2-1-2-2V7c0-1 1-2 2-2h3", key: "lubmu8" }],
  ["path", { d: "M16 5h3c1 0 2 1 2 2v10c0 1-1 2-2 2h-3", key: "1ag34g" }],
  ["line", { x1: "12", x2: "12", y1: "4", y2: "20", key: "1tx1rr" }]
];
var SquareSplitHorizontal = createLucideIcon("square-split-horizontal", __iconNode1434);

// ../node_modules/lucide-react/dist/esm/icons/square-split-vertical.js
var __iconNode1435 = [
  ["path", { d: "M5 8V5c0-1 1-2 2-2h10c1 0 2 1 2 2v3", key: "1pi83i" }],
  ["path", { d: "M19 16v3c0 1-1 2-2 2H7c-1 0-2-1-2-2v-3", key: "ido5k7" }],
  ["line", { x1: "4", x2: "20", y1: "12", y2: "12", key: "1e0a9i" }]
];
var SquareSplitVertical = createLucideIcon("square-split-vertical", __iconNode1435);

// ../node_modules/lucide-react/dist/esm/icons/square-square.js
var __iconNode1436 = [
  ["rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", key: "h1oib" }],
  ["rect", { x: "8", y: "8", width: "8", height: "8", rx: "1", key: "z9xiuo" }]
];
var SquareSquare = createLucideIcon("square-square", __iconNode1436);

// ../node_modules/lucide-react/dist/esm/icons/square-stack.js
var __iconNode1437 = [
  ["path", { d: "M4 10c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h4c1.1 0 2 .9 2 2", key: "4i38lg" }],
  ["path", { d: "M10 16c-1.1 0-2-.9-2-2v-4c0-1.1.9-2 2-2h4c1.1 0 2 .9 2 2", key: "mlte4a" }],
  ["rect", { width: "8", height: "8", x: "14", y: "14", rx: "2", key: "1fa9i4" }]
];
var SquareStack = createLucideIcon("square-stack", __iconNode1437);

// ../node_modules/lucide-react/dist/esm/icons/square-star.js
var __iconNode1438 = [
  [
    "path",
    {
      d: "M11.035 7.69a1 1 0 0 1 1.909.024l.737 1.452a1 1 0 0 0 .737.535l1.634.256a1 1 0 0 1 .588 1.806l-1.172 1.168a1 1 0 0 0-.282.866l.259 1.613a1 1 0 0 1-1.541 1.134l-1.465-.75a1 1 0 0 0-.912 0l-1.465.75a1 1 0 0 1-1.539-1.133l.258-1.613a1 1 0 0 0-.282-.866l-1.156-1.153a1 1 0 0 1 .572-1.822l1.633-.256a1 1 0 0 0 .737-.535z",
      key: "13edca"
    }
  ],
  ["rect", { x: "3", y: "3", width: "18", height: "18", rx: "2", key: "h1oib" }]
];
var SquareStar = createLucideIcon("square-star", __iconNode1438);

// ../node_modules/lucide-react/dist/esm/icons/square-stop.js
var __iconNode1439 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["rect", { x: "9", y: "9", width: "6", height: "6", rx: "1", key: "1ssd4o" }]
];
var SquareStop = createLucideIcon("square-stop", __iconNode1439);

// ../node_modules/lucide-react/dist/esm/icons/square-terminal.js
var __iconNode1440 = [
  ["path", { d: "m7 11 2-2-2-2", key: "1lz0vl" }],
  ["path", { d: "M11 13h4", key: "1p7l4v" }],
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }]
];
var SquareTerminal = createLucideIcon("square-terminal", __iconNode1440);

// ../node_modules/lucide-react/dist/esm/icons/square-user-round.js
var __iconNode1441 = [
  ["path", { d: "M18 21a6 6 0 0 0-12 0", key: "kaz2du" }],
  ["circle", { cx: "12", cy: "11", r: "4", key: "1gt34v" }],
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }]
];
var SquareUserRound = createLucideIcon("square-user-round", __iconNode1441);

// ../node_modules/lucide-react/dist/esm/icons/square-user.js
var __iconNode1442 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }],
  ["path", { d: "M7 21v-2a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v2", key: "1m6ac2" }]
];
var SquareUser = createLucideIcon("square-user", __iconNode1442);

// ../node_modules/lucide-react/dist/esm/icons/square-x.js
var __iconNode1443 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "m9 9 6 6", key: "z0biqf" }]
];
var SquareX = createLucideIcon("square-x", __iconNode1443);

// ../node_modules/lucide-react/dist/esm/icons/squares-exclude.js
var __iconNode1444 = [
  [
    "path",
    {
      d: "M16 12v2a2 2 0 0 1-2 2H9a1 1 0 0 0-1 1v3a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2h0",
      key: "1mcohs"
    }
  ],
  [
    "path",
    {
      d: "M4 16a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v3a1 1 0 0 1-1 1h-5a2 2 0 0 0-2 2v2",
      key: "1r1efp"
    }
  ]
];
var SquaresExclude = createLucideIcon("squares-exclude", __iconNode1444);

// ../node_modules/lucide-react/dist/esm/icons/squares-intersect.js
var __iconNode1445 = [
  ["path", { d: "M10 22a2 2 0 0 1-2-2", key: "i7yj1i" }],
  ["path", { d: "M14 2a2 2 0 0 1 2 2", key: "170a0m" }],
  ["path", { d: "M16 22h-2", key: "18d249" }],
  ["path", { d: "M2 10V8", key: "7yj4fe" }],
  ["path", { d: "M2 4a2 2 0 0 1 2-2", key: "ddgnws" }],
  ["path", { d: "M20 8a2 2 0 0 1 2 2", key: "1770vt" }],
  ["path", { d: "M22 14v2", key: "iot8ja" }],
  ["path", { d: "M22 20a2 2 0 0 1-2 2", key: "qj8q6g" }],
  ["path", { d: "M4 16a2 2 0 0 1-2-2", key: "1dnafg" }],
  [
    "path",
    { d: "M8 10a2 2 0 0 1 2-2h5a1 1 0 0 1 1 1v5a2 2 0 0 1-2 2H9a1 1 0 0 1-1-1z", key: "ci6f0b" }
  ],
  ["path", { d: "M8 2h2", key: "1gmkwm" }]
];
var SquaresIntersect = createLucideIcon("squares-intersect", __iconNode1445);

// ../node_modules/lucide-react/dist/esm/icons/square.js
var __iconNode1446 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }]
];
var Square = createLucideIcon("square", __iconNode1446);

// ../node_modules/lucide-react/dist/esm/icons/squares-subtract.js
var __iconNode1447 = [
  ["path", { d: "M10 22a2 2 0 0 1-2-2", key: "i7yj1i" }],
  ["path", { d: "M16 22h-2", key: "18d249" }],
  [
    "path",
    {
      d: "M16 4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-5a2 2 0 0 1 2-2h5a1 1 0 0 0 1-1z",
      key: "1njgbb"
    }
  ],
  ["path", { d: "M20 8a2 2 0 0 1 2 2", key: "1770vt" }],
  ["path", { d: "M22 14v2", key: "iot8ja" }],
  ["path", { d: "M22 20a2 2 0 0 1-2 2", key: "qj8q6g" }]
];
var SquaresSubtract = createLucideIcon("squares-subtract", __iconNode1447);

// ../node_modules/lucide-react/dist/esm/icons/squares-unite.js
var __iconNode1448 = [
  [
    "path",
    {
      d: "M4 16a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v3a1 1 0 0 0 1 1h3a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H10a2 2 0 0 1-2-2v-3a1 1 0 0 0-1-1z",
      key: "17jnth"
    }
  ]
];
var SquaresUnite = createLucideIcon("squares-unite", __iconNode1448);

// ../node_modules/lucide-react/dist/esm/icons/squircle-dashed.js
var __iconNode1449 = [
  ["path", { d: "M13.77 3.043a34 34 0 0 0-3.54 0", key: "1oaobr" }],
  ["path", { d: "M13.771 20.956a33 33 0 0 1-3.541.001", key: "95iq0j" }],
  ["path", { d: "M20.18 17.74c-.51 1.15-1.29 1.93-2.439 2.44", key: "1u6qty" }],
  ["path", { d: "M20.18 6.259c-.51-1.148-1.291-1.929-2.44-2.438", key: "1ew6g6" }],
  ["path", { d: "M20.957 10.23a33 33 0 0 1 0 3.54", key: "1l9npr" }],
  ["path", { d: "M3.043 10.23a34 34 0 0 0 .001 3.541", key: "1it6jm" }],
  ["path", { d: "M6.26 20.179c-1.15-.508-1.93-1.29-2.44-2.438", key: "14uchd" }],
  ["path", { d: "M6.26 3.82c-1.149.51-1.93 1.291-2.44 2.44", key: "8k4agb" }]
];
var SquircleDashed = createLucideIcon("squircle-dashed", __iconNode1449);

// ../node_modules/lucide-react/dist/esm/icons/squircle.js
var __iconNode1450 = [
  ["path", { d: "M12 3c7.2 0 9 1.8 9 9s-1.8 9-9 9-9-1.8-9-9 1.8-9 9-9", key: "garfkc" }]
];
var Squircle = createLucideIcon("squircle", __iconNode1450);

// ../node_modules/lucide-react/dist/esm/icons/squirrel.js
var __iconNode1451 = [
  ["path", { d: "M15.236 22a3 3 0 0 0-2.2-5", key: "21bitc" }],
  ["path", { d: "M16 20a3 3 0 0 1 3-3h1a2 2 0 0 0 2-2v-2a4 4 0 0 0-4-4V4", key: "oh0fg0" }],
  ["path", { d: "M18 13h.01", key: "9veqaj" }],
  [
    "path",
    {
      d: "M18 6a4 4 0 0 0-4 4 7 7 0 0 0-7 7c0-5 4-5 4-10.5a4.5 4.5 0 1 0-9 0 2.5 2.5 0 0 0 5 0C7 10 3 11 3 17c0 2.8 2.2 5 5 5h10",
      key: "980v8a"
    }
  ]
];
var Squirrel = createLucideIcon("squirrel", __iconNode1451);

// ../node_modules/lucide-react/dist/esm/icons/stamp.js
var __iconNode1452 = [
  ["path", { d: "M14 13V8.5C14 7 15 7 15 5a3 3 0 0 0-6 0c0 2 1 2 1 3.5V13", key: "i9gjdv" }],
  [
    "path",
    {
      d: "M20 15.5a2.5 2.5 0 0 0-2.5-2.5h-11A2.5 2.5 0 0 0 4 15.5V17a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1z",
      key: "1vzg3v"
    }
  ],
  ["path", { d: "M5 22h14", key: "ehvnwv" }]
];
var Stamp = createLucideIcon("stamp", __iconNode1452);

// ../node_modules/lucide-react/dist/esm/icons/star-half.js
var __iconNode1453 = [
  [
    "path",
    {
      d: "M12 18.338a2.1 2.1 0 0 0-.987.244L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.12 2.12 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.12 2.12 0 0 0 1.597-1.16l2.309-4.679A.53.53 0 0 1 12 2",
      key: "2ksp49"
    }
  ]
];
var StarHalf = createLucideIcon("star-half", __iconNode1453);

// ../node_modules/lucide-react/dist/esm/icons/star-off.js
var __iconNode1454 = [
  [
    "path",
    {
      d: "m10.344 4.688 1.181-2.393a.53.53 0 0 1 .95 0l2.31 4.679a2.12 2.12 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.237 3.152",
      key: "19ctli"
    }
  ],
  [
    "path",
    {
      d: "m17.945 17.945.43 2.505a.53.53 0 0 1-.771.56l-4.618-2.428a2.12 2.12 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.12 2.12 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a8 8 0 0 0 .4-.099",
      key: "ptqqvy"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var StarOff = createLucideIcon("star-off", __iconNode1454);

// ../node_modules/lucide-react/dist/esm/icons/star.js
var __iconNode1455 = [
  [
    "path",
    {
      d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
      key: "r04s7s"
    }
  ]
];
var Star = createLucideIcon("star", __iconNode1455);

// ../node_modules/lucide-react/dist/esm/icons/step-back.js
var __iconNode1456 = [
  [
    "path",
    {
      d: "M13.971 4.285A2 2 0 0 1 17 6v12a2 2 0 0 1-3.029 1.715l-9.997-5.998a2 2 0 0 1-.003-3.432z",
      key: "19qhus"
    }
  ],
  ["path", { d: "M21 20V4", key: "cb8qj8" }]
];
var StepBack = createLucideIcon("step-back", __iconNode1456);

// ../node_modules/lucide-react/dist/esm/icons/step-forward.js
var __iconNode1457 = [
  [
    "path",
    {
      d: "M10.029 4.285A2 2 0 0 0 7 6v12a2 2 0 0 0 3.029 1.715l9.997-5.998a2 2 0 0 0 .003-3.432z",
      key: "1ystz2"
    }
  ],
  ["path", { d: "M3 4v16", key: "1ph11n" }]
];
var StepForward = createLucideIcon("step-forward", __iconNode1457);

// ../node_modules/lucide-react/dist/esm/icons/stethoscope.js
var __iconNode1458 = [
  ["path", { d: "M11 2v2", key: "1539x4" }],
  ["path", { d: "M5 2v2", key: "1yf1q8" }],
  ["path", { d: "M5 3H4a2 2 0 0 0-2 2v4a6 6 0 0 0 12 0V5a2 2 0 0 0-2-2h-1", key: "rb5t3r" }],
  ["path", { d: "M8 15a6 6 0 0 0 12 0v-3", key: "x18d4x" }],
  ["circle", { cx: "20", cy: "10", r: "2", key: "ts1r5v" }]
];
var Stethoscope = createLucideIcon("stethoscope", __iconNode1458);

// ../node_modules/lucide-react/dist/esm/icons/sticker.js
var __iconNode1459 = [
  [
    "path",
    {
      d: "M21 9a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 15 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2z",
      key: "1dfntj"
    }
  ],
  ["path", { d: "M15 3v5a1 1 0 0 0 1 1h5", key: "6s6qgf" }],
  ["path", { d: "M8 13h.01", key: "1sbv64" }],
  ["path", { d: "M16 13h.01", key: "wip0gl" }],
  ["path", { d: "M10 16s.8 1 2 1c1.3 0 2-1 2-1", key: "1vvgv3" }]
];
var Sticker = createLucideIcon("sticker", __iconNode1459);

// ../node_modules/lucide-react/dist/esm/icons/sticky-note.js
var __iconNode1460 = [
  [
    "path",
    {
      d: "M21 9a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 15 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2z",
      key: "1dfntj"
    }
  ],
  ["path", { d: "M15 3v5a1 1 0 0 0 1 1h5", key: "6s6qgf" }]
];
var StickyNote = createLucideIcon("sticky-note", __iconNode1460);

// ../node_modules/lucide-react/dist/esm/icons/stone.js
var __iconNode1461 = [
  [
    "path",
    {
      d: "M11.264 2.205A4 4 0 0 0 6.42 4.211l-4 8a4 4 0 0 0 1.359 5.117l6 4a4 4 0 0 0 4.438 0l6-4a4 4 0 0 0 1.576-4.592l-2-6a4 4 0 0 0-2.53-2.53z",
      key: "1si4ox"
    }
  ],
  ["path", { d: "M11.99 22 14 12l7.822 3.184", key: "1u8to0" }],
  ["path", { d: "M14 12 8.47 2.302", key: "guo3d5" }]
];
var Stone = createLucideIcon("stone", __iconNode1461);

// ../node_modules/lucide-react/dist/esm/icons/store.js
var __iconNode1462 = [
  ["path", { d: "M15 21v-5a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v5", key: "slp6dd" }],
  [
    "path",
    {
      d: "M17.774 10.31a1.12 1.12 0 0 0-1.549 0 2.5 2.5 0 0 1-3.451 0 1.12 1.12 0 0 0-1.548 0 2.5 2.5 0 0 1-3.452 0 1.12 1.12 0 0 0-1.549 0 2.5 2.5 0 0 1-3.77-3.248l2.889-4.184A2 2 0 0 1 7 2h10a2 2 0 0 1 1.653.873l2.895 4.192a2.5 2.5 0 0 1-3.774 3.244",
      key: "o0xfot"
    }
  ],
  ["path", { d: "M4 10.95V19a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8.05", key: "wn3emo" }]
];
var Store = createLucideIcon("store", __iconNode1462);

// ../node_modules/lucide-react/dist/esm/icons/stretch-horizontal.js
var __iconNode1463 = [
  ["rect", { width: "20", height: "6", x: "2", y: "4", rx: "2", key: "qdearl" }],
  ["rect", { width: "20", height: "6", x: "2", y: "14", rx: "2", key: "1xrn6j" }]
];
var StretchHorizontal = createLucideIcon("stretch-horizontal", __iconNode1463);

// ../node_modules/lucide-react/dist/esm/icons/stretch-vertical.js
var __iconNode1464 = [
  ["rect", { width: "6", height: "20", x: "4", y: "2", rx: "2", key: "19qu7m" }],
  ["rect", { width: "6", height: "20", x: "14", y: "2", rx: "2", key: "24v0nk" }]
];
var StretchVertical = createLucideIcon("stretch-vertical", __iconNode1464);

// ../node_modules/lucide-react/dist/esm/icons/strikethrough.js
var __iconNode1465 = [
  ["path", { d: "M16 4H9a3 3 0 0 0-2.83 4", key: "43sutm" }],
  ["path", { d: "M14 12a4 4 0 0 1 0 8H6", key: "nlfj13" }],
  ["line", { x1: "4", x2: "20", y1: "12", y2: "12", key: "1e0a9i" }]
];
var Strikethrough = createLucideIcon("strikethrough", __iconNode1465);

// ../node_modules/lucide-react/dist/esm/icons/subscript.js
var __iconNode1466 = [
  ["path", { d: "m4 5 8 8", key: "1eunvl" }],
  ["path", { d: "m12 5-8 8", key: "1ah0jp" }],
  [
    "path",
    {
      d: "M20 19h-4c0-1.5.44-2 1.5-2.5S20 15.33 20 14c0-.47-.17-.93-.48-1.29a2.11 2.11 0 0 0-2.62-.44c-.42.24-.74.62-.9 1.07",
      key: "e8ta8j"
    }
  ]
];
var Subscript = createLucideIcon("subscript", __iconNode1466);

// ../node_modules/lucide-react/dist/esm/icons/sun-dim.js
var __iconNode1467 = [
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }],
  ["path", { d: "M12 4h.01", key: "1ujb9j" }],
  ["path", { d: "M20 12h.01", key: "1ykeid" }],
  ["path", { d: "M12 20h.01", key: "zekei9" }],
  ["path", { d: "M4 12h.01", key: "158zrr" }],
  ["path", { d: "M17.657 6.343h.01", key: "31pqzk" }],
  ["path", { d: "M17.657 17.657h.01", key: "jehnf4" }],
  ["path", { d: "M6.343 17.657h.01", key: "gdk6ow" }],
  ["path", { d: "M6.343 6.343h.01", key: "1uurf0" }]
];
var SunDim = createLucideIcon("sun-dim", __iconNode1467);

// ../node_modules/lucide-react/dist/esm/icons/sun-medium.js
var __iconNode1468 = [
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }],
  ["path", { d: "M12 3v1", key: "1asbbs" }],
  ["path", { d: "M12 20v1", key: "1wcdkc" }],
  ["path", { d: "M3 12h1", key: "lp3yf2" }],
  ["path", { d: "M20 12h1", key: "1vloll" }],
  ["path", { d: "m18.364 5.636-.707.707", key: "1hakh0" }],
  ["path", { d: "m6.343 17.657-.707.707", key: "18m9nf" }],
  ["path", { d: "m5.636 5.636.707.707", key: "1xv1c5" }],
  ["path", { d: "m17.657 17.657.707.707", key: "vl76zb" }]
];
var SunMedium = createLucideIcon("sun-medium", __iconNode1468);

// ../node_modules/lucide-react/dist/esm/icons/sun-moon.js
var __iconNode1469 = [
  ["path", { d: "M12 2v2", key: "tus03m" }],
  [
    "path",
    {
      d: "M14.837 16.385a6 6 0 1 1-7.223-7.222c.624-.147.97.66.715 1.248a4 4 0 0 0 5.26 5.259c.589-.255 1.396.09 1.248.715",
      key: "xlf6rm"
    }
  ],
  ["path", { d: "M16 12a4 4 0 0 0-4-4", key: "6vsxu" }],
  ["path", { d: "m19 5-1.256 1.256", key: "1yg6a6" }],
  ["path", { d: "M20 12h2", key: "1q8mjw" }]
];
var SunMoon = createLucideIcon("sun-moon", __iconNode1469);

// ../node_modules/lucide-react/dist/esm/icons/sun-snow.js
var __iconNode1470 = [
  ["path", { d: "M10 21v-1", key: "1u8rkd" }],
  ["path", { d: "M10 4V3", key: "pkzwkn" }],
  ["path", { d: "M10 9a3 3 0 0 0 0 6", key: "gv75dk" }],
  ["path", { d: "m14 20 1.25-2.5L18 18", key: "1chtki" }],
  ["path", { d: "m14 4 1.25 2.5L18 6", key: "1b4wsy" }],
  ["path", { d: "m17 21-3-6 1.5-3H22", key: "o5qa3v" }],
  ["path", { d: "m17 3-3 6 1.5 3", key: "11697g" }],
  ["path", { d: "M2 12h1", key: "1uaihz" }],
  ["path", { d: "m20 10-1.5 2 1.5 2", key: "1swlpi" }],
  ["path", { d: "m3.64 18.36.7-.7", key: "105rm9" }],
  ["path", { d: "m4.34 6.34-.7-.7", key: "d3unjp" }]
];
var SunSnow = createLucideIcon("sun-snow", __iconNode1470);

// ../node_modules/lucide-react/dist/esm/icons/sun.js
var __iconNode1471 = [
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }],
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "M12 20v2", key: "1lh1kg" }],
  ["path", { d: "m4.93 4.93 1.41 1.41", key: "149t6j" }],
  ["path", { d: "m17.66 17.66 1.41 1.41", key: "ptbguv" }],
  ["path", { d: "M2 12h2", key: "1t8f8n" }],
  ["path", { d: "M20 12h2", key: "1q8mjw" }],
  ["path", { d: "m6.34 17.66-1.41 1.41", key: "1m8zz5" }],
  ["path", { d: "m19.07 4.93-1.41 1.41", key: "1shlcs" }]
];
var Sun = createLucideIcon("sun", __iconNode1471);

// ../node_modules/lucide-react/dist/esm/icons/sunrise.js
var __iconNode1472 = [
  ["path", { d: "M12 2v8", key: "1q4o3n" }],
  ["path", { d: "m4.93 10.93 1.41 1.41", key: "2a7f42" }],
  ["path", { d: "M2 18h2", key: "j10viu" }],
  ["path", { d: "M20 18h2", key: "wocana" }],
  ["path", { d: "m19.07 10.93-1.41 1.41", key: "15zs5n" }],
  ["path", { d: "M22 22H2", key: "19qnx5" }],
  ["path", { d: "m8 6 4-4 4 4", key: "ybng9g" }],
  ["path", { d: "M16 18a4 4 0 0 0-8 0", key: "1lzouq" }]
];
var Sunrise = createLucideIcon("sunrise", __iconNode1472);

// ../node_modules/lucide-react/dist/esm/icons/sunset.js
var __iconNode1473 = [
  ["path", { d: "M12 10V2", key: "16sf7g" }],
  ["path", { d: "m4.93 10.93 1.41 1.41", key: "2a7f42" }],
  ["path", { d: "M2 18h2", key: "j10viu" }],
  ["path", { d: "M20 18h2", key: "wocana" }],
  ["path", { d: "m19.07 10.93-1.41 1.41", key: "15zs5n" }],
  ["path", { d: "M22 22H2", key: "19qnx5" }],
  ["path", { d: "m16 6-4 4-4-4", key: "6wukr" }],
  ["path", { d: "M16 18a4 4 0 0 0-8 0", key: "1lzouq" }]
];
var Sunset = createLucideIcon("sunset", __iconNode1473);

// ../node_modules/lucide-react/dist/esm/icons/superscript.js
var __iconNode1474 = [
  ["path", { d: "m4 19 8-8", key: "hr47gm" }],
  ["path", { d: "m12 19-8-8", key: "1dhhmo" }],
  [
    "path",
    {
      d: "M20 12h-4c0-1.5.442-2 1.5-2.5S20 8.334 20 7.002c0-.472-.17-.93-.484-1.29a2.105 2.105 0 0 0-2.617-.436c-.42.239-.738.614-.899 1.06",
      key: "1dfcux"
    }
  ]
];
var Superscript = createLucideIcon("superscript", __iconNode1474);

// ../node_modules/lucide-react/dist/esm/icons/swatch-book.js
var __iconNode1475 = [
  ["path", { d: "M11 17a4 4 0 0 1-8 0V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2Z", key: "1ldrpk" }],
  ["path", { d: "M16.7 13H19a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2H7", key: "11i5po" }],
  ["path", { d: "M 7 17h.01", key: "1euzgo" }],
  [
    "path",
    {
      d: "m11 8 2.3-2.3a2.4 2.4 0 0 1 3.404.004L18.6 7.6a2.4 2.4 0 0 1 .026 3.434L9.9 19.8",
      key: "o2gii7"
    }
  ]
];
var SwatchBook = createLucideIcon("swatch-book", __iconNode1475);

// ../node_modules/lucide-react/dist/esm/icons/swiss-franc.js
var __iconNode1476 = [
  ["path", { d: "M10 21V3h8", key: "br2l0g" }],
  ["path", { d: "M6 16h9", key: "2py0wn" }],
  ["path", { d: "M10 9.5h7", key: "13dmhz" }]
];
var SwissFranc = createLucideIcon("swiss-franc", __iconNode1476);

// ../node_modules/lucide-react/dist/esm/icons/switch-camera.js
var __iconNode1477 = [
  ["path", { d: "M11 19H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h5", key: "mtk2lu" }],
  ["path", { d: "M13 5h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-5", key: "120jsl" }],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }],
  ["path", { d: "m18 22-3-3 3-3", key: "kgdoj7" }],
  ["path", { d: "m6 2 3 3-3 3", key: "1fnbkv" }]
];
var SwitchCamera = createLucideIcon("switch-camera", __iconNode1477);

// ../node_modules/lucide-react/dist/esm/icons/sword.js
var __iconNode1478 = [
  ["path", { d: "m11 19-6-6", key: "s7kpr" }],
  ["path", { d: "m5 21-2-2", key: "1kw20b" }],
  ["path", { d: "m8 16-4 4", key: "1oqv8h" }],
  ["path", { d: "M9.5 17.5 21 6V3h-3L6.5 14.5", key: "pkxemp" }]
];
var Sword = createLucideIcon("sword", __iconNode1478);

// ../node_modules/lucide-react/dist/esm/icons/swords.js
var __iconNode1479 = [
  ["polyline", { points: "14.5 17.5 3 6 3 3 6 3 17.5 14.5", key: "1hfsw2" }],
  ["line", { x1: "13", x2: "19", y1: "19", y2: "13", key: "1vrmhu" }],
  ["line", { x1: "16", x2: "20", y1: "16", y2: "20", key: "1bron3" }],
  ["line", { x1: "19", x2: "21", y1: "21", y2: "19", key: "13pww6" }],
  ["polyline", { points: "14.5 6.5 18 3 21 3 21 6 17.5 9.5", key: "hbey2j" }],
  ["line", { x1: "5", x2: "9", y1: "14", y2: "18", key: "1hf58s" }],
  ["line", { x1: "7", x2: "4", y1: "17", y2: "20", key: "pidxm4" }],
  ["line", { x1: "3", x2: "5", y1: "19", y2: "21", key: "1pehsh" }]
];
var Swords = createLucideIcon("swords", __iconNode1479);

// ../node_modules/lucide-react/dist/esm/icons/syringe.js
var __iconNode1480 = [
  ["path", { d: "m18 2 4 4", key: "22kx64" }],
  ["path", { d: "m17 7 3-3", key: "1w1zoj" }],
  ["path", { d: "M19 9 8.7 19.3c-1 1-2.5 1-3.4 0l-.6-.6c-1-1-1-2.5 0-3.4L15 5", key: "1exhtz" }],
  ["path", { d: "m9 11 4 4", key: "rovt3i" }],
  ["path", { d: "m5 19-3 3", key: "59f2uf" }],
  ["path", { d: "m14 4 6 6", key: "yqp9t2" }]
];
var Syringe = createLucideIcon("syringe", __iconNode1480);

// ../node_modules/lucide-react/dist/esm/icons/table-2.js
var __iconNode1481 = [
  [
    "path",
    {
      d: "M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18m0 0h10a2 2 0 0 0 2-2V9M9 21H5a2 2 0 0 1-2-2V9m0 0h18",
      key: "gugj83"
    }
  ]
];
var Table2 = createLucideIcon("table-2", __iconNode1481);

// ../node_modules/lucide-react/dist/esm/icons/table-cells-merge.js
var __iconNode1482 = [
  ["path", { d: "M12 21v-6", key: "lihzve" }],
  ["path", { d: "M12 9V3", key: "da5inc" }],
  ["path", { d: "M3 15h18", key: "5xshup" }],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }]
];
var TableCellsMerge = createLucideIcon("table-cells-merge", __iconNode1482);

// ../node_modules/lucide-react/dist/esm/icons/table-cells-split.js
var __iconNode1483 = [
  ["path", { d: "M12 15V9", key: "8c7uyn" }],
  ["path", { d: "M3 15h18", key: "5xshup" }],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }]
];
var TableCellsSplit = createLucideIcon("table-cells-split", __iconNode1483);

// ../node_modules/lucide-react/dist/esm/icons/table-columns-split.js
var __iconNode1484 = [
  ["path", { d: "M14 14v2", key: "w2a1xv" }],
  ["path", { d: "M14 20v2", key: "1lq872" }],
  ["path", { d: "M14 2v2", key: "6buw04" }],
  ["path", { d: "M14 8v2", key: "i67w9a" }],
  ["path", { d: "M2 15h8", key: "82wtch" }],
  ["path", { d: "M2 3h6a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H2", key: "up0l64" }],
  ["path", { d: "M2 9h8", key: "yelfik" }],
  ["path", { d: "M22 15h-4", key: "1es58f" }],
  ["path", { d: "M22 3h-2a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h2", key: "pdjoqf" }],
  ["path", { d: "M22 9h-4", key: "1luja7" }],
  ["path", { d: "M5 3v18", key: "14hmio" }]
];
var TableColumnsSplit = createLucideIcon("table-columns-split", __iconNode1484);

// ../node_modules/lucide-react/dist/esm/icons/table-properties.js
var __iconNode1485 = [
  ["path", { d: "M15 3v18", key: "14nvp0" }],
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M21 9H3", key: "1338ky" }],
  ["path", { d: "M21 15H3", key: "9uk58r" }]
];
var TableProperties = createLucideIcon("table-properties", __iconNode1485);

// ../node_modules/lucide-react/dist/esm/icons/table-of-contents.js
var __iconNode1486 = [
  ["path", { d: "M16 5H3", key: "m91uny" }],
  ["path", { d: "M16 12H3", key: "1a2rj7" }],
  ["path", { d: "M16 19H3", key: "zzsher" }],
  ["path", { d: "M21 5h.01", key: "wa75ra" }],
  ["path", { d: "M21 12h.01", key: "msek7k" }],
  ["path", { d: "M21 19h.01", key: "qvbq2j" }]
];
var TableOfContents = createLucideIcon("table-of-contents", __iconNode1486);

// ../node_modules/lucide-react/dist/esm/icons/table-rows-split.js
var __iconNode1487 = [
  ["path", { d: "M14 10h2", key: "1lstlu" }],
  ["path", { d: "M15 22v-8", key: "1fwwgm" }],
  ["path", { d: "M15 2v4", key: "1044rn" }],
  ["path", { d: "M2 10h2", key: "1r8dkt" }],
  ["path", { d: "M20 10h2", key: "1ug425" }],
  ["path", { d: "M3 19h18", key: "awlh7x" }],
  ["path", { d: "M3 22v-6a2 2 135 0 1 2-2h14a2 2 45 0 1 2 2v6", key: "ibqhof" }],
  ["path", { d: "M3 2v2a2 2 45 0 0 2 2h14a2 2 135 0 0 2-2V2", key: "1uenja" }],
  ["path", { d: "M8 10h2", key: "66od0" }],
  ["path", { d: "M9 22v-8", key: "fmnu31" }],
  ["path", { d: "M9 2v4", key: "j1yeou" }]
];
var TableRowsSplit = createLucideIcon("table-rows-split", __iconNode1487);

// ../node_modules/lucide-react/dist/esm/icons/table.js
var __iconNode1488 = [
  ["path", { d: "M12 3v18", key: "108xh3" }],
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["path", { d: "M3 15h18", key: "5xshup" }]
];
var Table = createLucideIcon("table", __iconNode1488);

// ../node_modules/lucide-react/dist/esm/icons/tablet-smartphone.js
var __iconNode1489 = [
  ["rect", { width: "10", height: "14", x: "3", y: "8", rx: "2", key: "1vrsiq" }],
  ["path", { d: "M5 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2h-2.4", key: "1j4zmg" }],
  ["path", { d: "M8 18h.01", key: "lrp35t" }]
];
var TabletSmartphone = createLucideIcon("tablet-smartphone", __iconNode1489);

// ../node_modules/lucide-react/dist/esm/icons/tablet.js
var __iconNode1490 = [
  ["rect", { width: "16", height: "20", x: "4", y: "2", rx: "2", ry: "2", key: "76otgf" }],
  ["line", { x1: "12", x2: "12.01", y1: "18", y2: "18", key: "1dp563" }]
];
var Tablet = createLucideIcon("tablet", __iconNode1490);

// ../node_modules/lucide-react/dist/esm/icons/tablets.js
var __iconNode1491 = [
  ["circle", { cx: "7", cy: "7", r: "5", key: "x29byf" }],
  ["circle", { cx: "17", cy: "17", r: "5", key: "1op1d2" }],
  ["path", { d: "M12 17h10", key: "ls21zv" }],
  ["path", { d: "m3.46 10.54 7.08-7.08", key: "1rehiu" }]
];
var Tablets = createLucideIcon("tablets", __iconNode1491);

// ../node_modules/lucide-react/dist/esm/icons/tag.js
var __iconNode1492 = [
  [
    "path",
    {
      d: "M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z",
      key: "vktsd0"
    }
  ],
  ["circle", { cx: "7.5", cy: "7.5", r: ".5", fill: "currentColor", key: "kqv944" }]
];
var Tag = createLucideIcon("tag", __iconNode1492);

// ../node_modules/lucide-react/dist/esm/icons/tags.js
var __iconNode1493 = [
  [
    "path",
    {
      d: "M13.172 2a2 2 0 0 1 1.414.586l6.71 6.71a2.4 2.4 0 0 1 0 3.408l-4.592 4.592a2.4 2.4 0 0 1-3.408 0l-6.71-6.71A2 2 0 0 1 6 9.172V3a1 1 0 0 1 1-1z",
      key: "16rjxf"
    }
  ],
  [
    "path",
    { d: "M2 7v6.172a2 2 0 0 0 .586 1.414l6.71 6.71a2.4 2.4 0 0 0 3.191.193", key: "178nd4" }
  ],
  ["circle", { cx: "10.5", cy: "6.5", r: ".5", fill: "currentColor", key: "12ikhr" }]
];
var Tags = createLucideIcon("tags", __iconNode1493);

// ../node_modules/lucide-react/dist/esm/icons/tally-1.js
var __iconNode1494 = [["path", { d: "M4 4v16", key: "6qkkli" }]];
var Tally1 = createLucideIcon("tally-1", __iconNode1494);

// ../node_modules/lucide-react/dist/esm/icons/tally-2.js
var __iconNode1495 = [
  ["path", { d: "M4 4v16", key: "6qkkli" }],
  ["path", { d: "M9 4v16", key: "81ygyz" }]
];
var Tally2 = createLucideIcon("tally-2", __iconNode1495);

// ../node_modules/lucide-react/dist/esm/icons/tally-4.js
var __iconNode1496 = [
  ["path", { d: "M4 4v16", key: "6qkkli" }],
  ["path", { d: "M9 4v16", key: "81ygyz" }],
  ["path", { d: "M14 4v16", key: "12vmem" }],
  ["path", { d: "M19 4v16", key: "8ij5ei" }]
];
var Tally4 = createLucideIcon("tally-4", __iconNode1496);

// ../node_modules/lucide-react/dist/esm/icons/tally-3.js
var __iconNode1497 = [
  ["path", { d: "M4 4v16", key: "6qkkli" }],
  ["path", { d: "M9 4v16", key: "81ygyz" }],
  ["path", { d: "M14 4v16", key: "12vmem" }]
];
var Tally3 = createLucideIcon("tally-3", __iconNode1497);

// ../node_modules/lucide-react/dist/esm/icons/tally-5.js
var __iconNode1498 = [
  ["path", { d: "M4 4v16", key: "6qkkli" }],
  ["path", { d: "M9 4v16", key: "81ygyz" }],
  ["path", { d: "M14 4v16", key: "12vmem" }],
  ["path", { d: "M19 4v16", key: "8ij5ei" }],
  ["path", { d: "M22 6 2 18", key: "h9moai" }]
];
var Tally5 = createLucideIcon("tally-5", __iconNode1498);

// ../node_modules/lucide-react/dist/esm/icons/tangent.js
var __iconNode1499 = [
  ["circle", { cx: "17", cy: "4", r: "2", key: "y5j2s2" }],
  ["path", { d: "M15.59 5.41 5.41 15.59", key: "l0vprr" }],
  ["circle", { cx: "4", cy: "17", r: "2", key: "9p4efm" }],
  ["path", { d: "M12 22s-4-9-1.5-11.5S22 12 22 12", key: "1twk4o" }]
];
var Tangent = createLucideIcon("tangent", __iconNode1499);

// ../node_modules/lucide-react/dist/esm/icons/target.js
var __iconNode1500 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["circle", { cx: "12", cy: "12", r: "6", key: "1vlfrh" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }]
];
var Target = createLucideIcon("target", __iconNode1500);

// ../node_modules/lucide-react/dist/esm/icons/telescope.js
var __iconNode1501 = [
  [
    "path",
    {
      d: "m10.065 12.493-6.18 1.318a.934.934 0 0 1-1.108-.702l-.537-2.15a1.07 1.07 0 0 1 .691-1.265l13.504-4.44",
      key: "k4qptu"
    }
  ],
  ["path", { d: "m13.56 11.747 4.332-.924", key: "19l80z" }],
  ["path", { d: "m16 21-3.105-6.21", key: "7oh9d" }],
  [
    "path",
    {
      d: "M16.485 5.94a2 2 0 0 1 1.455-2.425l1.09-.272a1 1 0 0 1 1.212.727l1.515 6.06a1 1 0 0 1-.727 1.213l-1.09.272a2 2 0 0 1-2.425-1.455z",
      key: "m7xp4m"
    }
  ],
  ["path", { d: "m6.158 8.633 1.114 4.456", key: "74o979" }],
  ["path", { d: "m8 21 3.105-6.21", key: "1fvxut" }],
  ["circle", { cx: "12", cy: "13", r: "2", key: "1c1ljs" }]
];
var Telescope = createLucideIcon("telescope", __iconNode1501);

// ../node_modules/lucide-react/dist/esm/icons/tent-tree.js
var __iconNode1502 = [
  ["circle", { cx: "4", cy: "4", r: "2", key: "bt5ra8" }],
  ["path", { d: "m14 5 3-3 3 3", key: "1sorif" }],
  ["path", { d: "m14 10 3-3 3 3", key: "1jyi9h" }],
  ["path", { d: "M17 14V2", key: "8ymqnk" }],
  ["path", { d: "M17 14H7l-5 8h20Z", key: "13ar7p" }],
  ["path", { d: "M8 14v8", key: "1ghmqk" }],
  ["path", { d: "m9 14 5 8", key: "13pgi6" }]
];
var TentTree = createLucideIcon("tent-tree", __iconNode1502);

// ../node_modules/lucide-react/dist/esm/icons/tent.js
var __iconNode1503 = [
  ["path", { d: "M3.5 21 14 3", key: "1szst5" }],
  ["path", { d: "M20.5 21 10 3", key: "1310c3" }],
  ["path", { d: "M15.5 21 12 15l-3.5 6", key: "1ddtfw" }],
  ["path", { d: "M2 21h20", key: "1nyx9w" }]
];
var Tent = createLucideIcon("tent", __iconNode1503);

// ../node_modules/lucide-react/dist/esm/icons/terminal.js
var __iconNode1504 = [
  ["path", { d: "M12 19h8", key: "baeox8" }],
  ["path", { d: "m4 17 6-6-6-6", key: "1yngyt" }]
];
var Terminal = createLucideIcon("terminal", __iconNode1504);

// ../node_modules/lucide-react/dist/esm/icons/test-tube-diagonal.js
var __iconNode1505 = [
  [
    "path",
    { d: "M21 7 6.82 21.18a2.83 2.83 0 0 1-3.99-.01a2.83 2.83 0 0 1 0-4L17 3", key: "1ub6xw" }
  ],
  ["path", { d: "m16 2 6 6", key: "1gw87d" }],
  ["path", { d: "M12 16H4", key: "1cjfip" }]
];
var TestTubeDiagonal = createLucideIcon("test-tube-diagonal", __iconNode1505);

// ../node_modules/lucide-react/dist/esm/icons/test-tube.js
var __iconNode1506 = [
  ["path", { d: "M14.5 2v17.5c0 1.4-1.1 2.5-2.5 2.5c-1.4 0-2.5-1.1-2.5-2.5V2", key: "125lnx" }],
  ["path", { d: "M8.5 2h7", key: "csnxdl" }],
  ["path", { d: "M14.5 16h-5", key: "1ox875" }]
];
var TestTube = createLucideIcon("test-tube", __iconNode1506);

// ../node_modules/lucide-react/dist/esm/icons/test-tubes.js
var __iconNode1507 = [
  ["path", { d: "M9 2v17.5A2.5 2.5 0 0 1 6.5 22A2.5 2.5 0 0 1 4 19.5V2", key: "1hjrqt" }],
  ["path", { d: "M20 2v17.5a2.5 2.5 0 0 1-2.5 2.5a2.5 2.5 0 0 1-2.5-2.5V2", key: "16lc8n" }],
  ["path", { d: "M3 2h7", key: "7s29d5" }],
  ["path", { d: "M14 2h7", key: "7sicin" }],
  ["path", { d: "M9 16H4", key: "1bfye3" }],
  ["path", { d: "M20 16h-5", key: "ddnjpe" }]
];
var TestTubes = createLucideIcon("test-tubes", __iconNode1507);

// ../node_modules/lucide-react/dist/esm/icons/text-align-center.js
var __iconNode1508 = [
  ["path", { d: "M21 5H3", key: "1fi0y6" }],
  ["path", { d: "M17 12H7", key: "16if0g" }],
  ["path", { d: "M19 19H5", key: "vjpgq2" }]
];
var TextAlignCenter = createLucideIcon("text-align-center", __iconNode1508);

// ../node_modules/lucide-react/dist/esm/icons/text-align-end.js
var __iconNode1509 = [
  ["path", { d: "M21 5H3", key: "1fi0y6" }],
  ["path", { d: "M21 12H9", key: "dn1m92" }],
  ["path", { d: "M21 19H7", key: "4cu937" }]
];
var TextAlignEnd = createLucideIcon("text-align-end", __iconNode1509);

// ../node_modules/lucide-react/dist/esm/icons/text-align-justify.js
var __iconNode1510 = [
  ["path", { d: "M3 5h18", key: "1u36vt" }],
  ["path", { d: "M3 12h18", key: "1i2n21" }],
  ["path", { d: "M3 19h18", key: "awlh7x" }]
];
var TextAlignJustify = createLucideIcon("text-align-justify", __iconNode1510);

// ../node_modules/lucide-react/dist/esm/icons/text-align-start.js
var __iconNode1511 = [
  ["path", { d: "M21 5H3", key: "1fi0y6" }],
  ["path", { d: "M15 12H3", key: "6jk70r" }],
  ["path", { d: "M17 19H3", key: "z6ezky" }]
];
var TextAlignStart = createLucideIcon("text-align-start", __iconNode1511);

// ../node_modules/lucide-react/dist/esm/icons/text-cursor-input.js
var __iconNode1512 = [
  ["path", { d: "M12 20h-1a2 2 0 0 1-2-2 2 2 0 0 1-2 2H6", key: "1528k5" }],
  ["path", { d: "M13 8h7a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-7", key: "13ksps" }],
  ["path", { d: "M5 16H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h1", key: "1n9rhb" }],
  ["path", { d: "M6 4h1a2 2 0 0 1 2 2 2 2 0 0 1 2-2h1", key: "1mj8rg" }],
  ["path", { d: "M9 6v12", key: "velyjx" }]
];
var TextCursorInput = createLucideIcon("text-cursor-input", __iconNode1512);

// ../node_modules/lucide-react/dist/esm/icons/text-cursor.js
var __iconNode1513 = [
  ["path", { d: "M17 22h-1a4 4 0 0 1-4-4V6a4 4 0 0 1 4-4h1", key: "uvaxm9" }],
  ["path", { d: "M7 22h1a4 4 0 0 0 4-4v-1", key: "11xy8d" }],
  ["path", { d: "M7 2h1a4 4 0 0 1 4 4v1", key: "1uw06m" }]
];
var TextCursor = createLucideIcon("text-cursor", __iconNode1513);

// ../node_modules/lucide-react/dist/esm/icons/text-initial.js
var __iconNode1514 = [
  ["path", { d: "M15 5h6", key: "1pr8yx" }],
  ["path", { d: "M15 12h6", key: "upa0zy" }],
  ["path", { d: "M3 19h18", key: "awlh7x" }],
  ["path", { d: "m3 12 3.553-7.724a.5.5 0 0 1 .894 0L11 12", key: "6lvno8" }],
  ["path", { d: "M3.92 10h6.16", key: "1tl8ex" }]
];
var TextInitial = createLucideIcon("text-initial", __iconNode1514);

// ../node_modules/lucide-react/dist/esm/icons/text-quote.js
var __iconNode1515 = [
  ["path", { d: "M17 5H3", key: "1cn7zz" }],
  ["path", { d: "M21 12H8", key: "scolzb" }],
  ["path", { d: "M21 19H8", key: "13qgcb" }],
  ["path", { d: "M3 12v7", key: "1ri8j3" }]
];
var TextQuote = createLucideIcon("text-quote", __iconNode1515);

// ../node_modules/lucide-react/dist/esm/icons/text-search.js
var __iconNode1516 = [
  ["path", { d: "M21 5H3", key: "1fi0y6" }],
  ["path", { d: "M10 12H3", key: "1ulcyk" }],
  ["path", { d: "M10 19H3", key: "108z41" }],
  ["circle", { cx: "17", cy: "15", r: "3", key: "1upz2a" }],
  ["path", { d: "m21 19-1.9-1.9", key: "dwi7p8" }]
];
var TextSearch = createLucideIcon("text-search", __iconNode1516);

// ../node_modules/lucide-react/dist/esm/icons/text-select.js
var __iconNode1517 = [
  ["path", { d: "M14 21h1", key: "v9vybs" }],
  ["path", { d: "M14 3h1", key: "1ec4yj" }],
  ["path", { d: "M19 3a2 2 0 0 1 2 2", key: "18rm91" }],
  ["path", { d: "M21 14v1", key: "169vum" }],
  ["path", { d: "M21 19a2 2 0 0 1-2 2", key: "1j7049" }],
  ["path", { d: "M21 9v1", key: "mxsmne" }],
  ["path", { d: "M3 14v1", key: "vnatye" }],
  ["path", { d: "M3 9v1", key: "1r0deq" }],
  ["path", { d: "M5 21a2 2 0 0 1-2-2", key: "sbafld" }],
  ["path", { d: "M5 3a2 2 0 0 0-2 2", key: "y57alp" }],
  ["path", { d: "M7 12h10", key: "b7w52i" }],
  ["path", { d: "M7 16h6", key: "1vyc9m" }],
  ["path", { d: "M7 8h8", key: "1jbsf9" }],
  ["path", { d: "M9 21h1", key: "15o7lz" }],
  ["path", { d: "M9 3h1", key: "1yesri" }]
];
var TextSelect = createLucideIcon("text-select", __iconNode1517);

// ../node_modules/lucide-react/dist/esm/icons/text-wrap.js
var __iconNode1518 = [
  ["path", { d: "m16 16-3 3 3 3", key: "117b85" }],
  ["path", { d: "M3 12h14.5a1 1 0 0 1 0 7H13", key: "18xa6z" }],
  ["path", { d: "M3 19h6", key: "1ygdsz" }],
  ["path", { d: "M3 5h18", key: "1u36vt" }]
];
var TextWrap = createLucideIcon("text-wrap", __iconNode1518);

// ../node_modules/lucide-react/dist/esm/icons/theater.js
var __iconNode1519 = [
  ["path", { d: "M2 10s3-3 3-8", key: "3xiif0" }],
  ["path", { d: "M22 10s-3-3-3-8", key: "ioaa5q" }],
  ["path", { d: "M10 2c0 4.4-3.6 8-8 8", key: "16fkpi" }],
  ["path", { d: "M14 2c0 4.4 3.6 8 8 8", key: "b9eulq" }],
  ["path", { d: "M2 10s2 2 2 5", key: "1au1lb" }],
  ["path", { d: "M22 10s-2 2-2 5", key: "qi2y5e" }],
  ["path", { d: "M8 15h8", key: "45n4r" }],
  ["path", { d: "M2 22v-1a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1", key: "1vsc2m" }],
  ["path", { d: "M14 22v-1a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v1", key: "hrha4u" }]
];
var Theater = createLucideIcon("theater", __iconNode1519);

// ../node_modules/lucide-react/dist/esm/icons/thermometer-snowflake.js
var __iconNode1520 = [
  ["path", { d: "m10 20-1.25-2.5L6 18", key: "18frcb" }],
  ["path", { d: "M10 4 8.75 6.5 6 6", key: "7mghy3" }],
  ["path", { d: "M10.585 15H10", key: "4nqulp" }],
  ["path", { d: "M2 12h6.5L10 9", key: "kv9z4n" }],
  ["path", { d: "M20 14.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0z", key: "yu0u2z" }],
  ["path", { d: "m4 10 1.5 2L4 14", key: "k9enpj" }],
  ["path", { d: "m7 21 3-6-1.5-3", key: "j8hb9u" }],
  ["path", { d: "m7 3 3 6h2", key: "1bbqgq" }]
];
var ThermometerSnowflake = createLucideIcon("thermometer-snowflake", __iconNode1520);

// ../node_modules/lucide-react/dist/esm/icons/thermometer-sun.js
var __iconNode1521 = [
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "M12 8a4 4 0 0 0-1.645 7.647", key: "wz5p04" }],
  ["path", { d: "M2 12h2", key: "1t8f8n" }],
  ["path", { d: "M20 14.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0z", key: "yu0u2z" }],
  ["path", { d: "m4.93 4.93 1.41 1.41", key: "149t6j" }],
  ["path", { d: "m6.34 17.66-1.41 1.41", key: "1m8zz5" }]
];
var ThermometerSun = createLucideIcon("thermometer-sun", __iconNode1521);

// ../node_modules/lucide-react/dist/esm/icons/thermometer.js
var __iconNode1522 = [
  ["path", { d: "M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z", key: "17jzev" }]
];
var Thermometer = createLucideIcon("thermometer", __iconNode1522);

// ../node_modules/lucide-react/dist/esm/icons/thumbs-down.js
var __iconNode1523 = [
  [
    "path",
    {
      d: "M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22a3.13 3.13 0 0 1-3-3.88Z",
      key: "m61m77"
    }
  ],
  ["path", { d: "M17 14V2", key: "8ymqnk" }]
];
var ThumbsDown = createLucideIcon("thumbs-down", __iconNode1523);

// ../node_modules/lucide-react/dist/esm/icons/thumbs-up.js
var __iconNode1524 = [
  [
    "path",
    {
      d: "M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z",
      key: "emmmcr"
    }
  ],
  ["path", { d: "M7 10v12", key: "1qc93n" }]
];
var ThumbsUp = createLucideIcon("thumbs-up", __iconNode1524);

// ../node_modules/lucide-react/dist/esm/icons/ticket-check.js
var __iconNode1525 = [
  [
    "path",
    {
      d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
      key: "qn84l0"
    }
  ],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
];
var TicketCheck = createLucideIcon("ticket-check", __iconNode1525);

// ../node_modules/lucide-react/dist/esm/icons/ticket-minus.js
var __iconNode1526 = [
  [
    "path",
    {
      d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
      key: "qn84l0"
    }
  ],
  ["path", { d: "M9 12h6", key: "1c52cq" }]
];
var TicketMinus = createLucideIcon("ticket-minus", __iconNode1526);

// ../node_modules/lucide-react/dist/esm/icons/ticket-percent.js
var __iconNode1527 = [
  [
    "path",
    {
      d: "M2 9a3 3 0 1 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 1 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
      key: "1l48ns"
    }
  ],
  ["path", { d: "M9 9h.01", key: "1q5me6" }],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "M15 15h.01", key: "lqbp3k" }]
];
var TicketPercent = createLucideIcon("ticket-percent", __iconNode1527);

// ../node_modules/lucide-react/dist/esm/icons/ticket-plus.js
var __iconNode1528 = [
  [
    "path",
    {
      d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
      key: "qn84l0"
    }
  ],
  ["path", { d: "M9 12h6", key: "1c52cq" }],
  ["path", { d: "M12 9v6", key: "199k2o" }]
];
var TicketPlus = createLucideIcon("ticket-plus", __iconNode1528);

// ../node_modules/lucide-react/dist/esm/icons/ticket-slash.js
var __iconNode1529 = [
  [
    "path",
    {
      d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
      key: "qn84l0"
    }
  ],
  ["path", { d: "m9.5 14.5 5-5", key: "qviqfa" }]
];
var TicketSlash = createLucideIcon("ticket-slash", __iconNode1529);

// ../node_modules/lucide-react/dist/esm/icons/ticket-x.js
var __iconNode1530 = [
  [
    "path",
    {
      d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
      key: "qn84l0"
    }
  ],
  ["path", { d: "m9.5 14.5 5-5", key: "qviqfa" }],
  ["path", { d: "m9.5 9.5 5 5", key: "18nt4w" }]
];
var TicketX = createLucideIcon("ticket-x", __iconNode1530);

// ../node_modules/lucide-react/dist/esm/icons/ticket.js
var __iconNode1531 = [
  [
    "path",
    {
      d: "M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z",
      key: "qn84l0"
    }
  ],
  ["path", { d: "M13 5v2", key: "dyzc3o" }],
  ["path", { d: "M13 17v2", key: "1ont0d" }],
  ["path", { d: "M13 11v2", key: "1wjjxi" }]
];
var Ticket = createLucideIcon("ticket", __iconNode1531);

// ../node_modules/lucide-react/dist/esm/icons/tickets-plane.js
var __iconNode1532 = [
  ["path", { d: "M10.5 17h1.227a2 2 0 0 0 1.345-.52L18 12", key: "16muxl" }],
  ["path", { d: "m12 13.5 3.794.506", key: "6v5z87" }],
  ["path", { d: "m3.173 8.18 11-5a2 2 0 0 1 2.647.993L18.56 8", key: "15hfpj" }],
  ["path", { d: "M6 10V8", key: "1y41hn" }],
  ["path", { d: "M6 14v1", key: "cao2tf" }],
  ["path", { d: "M6 19v2", key: "1loha6" }],
  ["rect", { x: "2", y: "8", width: "20", height: "13", rx: "2", key: "p3bz5l" }]
];
var TicketsPlane = createLucideIcon("tickets-plane", __iconNode1532);

// ../node_modules/lucide-react/dist/esm/icons/tickets.js
var __iconNode1533 = [
  ["path", { d: "m3.173 8.18 11-5a2 2 0 0 1 2.647.993L18.56 8", key: "15hfpj" }],
  ["path", { d: "M6 10V8", key: "1y41hn" }],
  ["path", { d: "M6 14v1", key: "cao2tf" }],
  ["path", { d: "M6 19v2", key: "1loha6" }],
  ["rect", { x: "2", y: "8", width: "20", height: "13", rx: "2", key: "p3bz5l" }]
];
var Tickets = createLucideIcon("tickets", __iconNode1533);

// ../node_modules/lucide-react/dist/esm/icons/timer-reset.js
var __iconNode1534 = [
  ["path", { d: "M10 2h4", key: "n1abiw" }],
  ["path", { d: "M12 14v-4", key: "1evpnu" }],
  ["path", { d: "M4 13a8 8 0 0 1 8-7 8 8 0 1 1-5.3 14L4 17.6", key: "1ts96g" }],
  ["path", { d: "M9 17H4v5", key: "8t5av" }]
];
var TimerReset = createLucideIcon("timer-reset", __iconNode1534);

// ../node_modules/lucide-react/dist/esm/icons/timer-off.js
var __iconNode1535 = [
  ["path", { d: "M10 2h4", key: "n1abiw" }],
  ["path", { d: "M4.6 11a8 8 0 0 0 1.7 8.7 8 8 0 0 0 8.7 1.7", key: "10he05" }],
  ["path", { d: "M7.4 7.4a8 8 0 0 1 10.3 1 8 8 0 0 1 .9 10.2", key: "15f7sh" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M12 12v-2", key: "fwoke6" }]
];
var TimerOff = createLucideIcon("timer-off", __iconNode1535);

// ../node_modules/lucide-react/dist/esm/icons/timer.js
var __iconNode1536 = [
  ["line", { x1: "10", x2: "14", y1: "2", y2: "2", key: "14vaq8" }],
  ["line", { x1: "12", x2: "15", y1: "14", y2: "11", key: "17fdiu" }],
  ["circle", { cx: "12", cy: "14", r: "8", key: "1e1u0o" }]
];
var Timer = createLucideIcon("timer", __iconNode1536);

// ../node_modules/lucide-react/dist/esm/icons/toggle-left.js
var __iconNode1537 = [
  ["circle", { cx: "9", cy: "12", r: "3", key: "u3jwor" }],
  ["rect", { width: "20", height: "14", x: "2", y: "5", rx: "7", key: "g7kal2" }]
];
var ToggleLeft = createLucideIcon("toggle-left", __iconNode1537);

// ../node_modules/lucide-react/dist/esm/icons/toggle-right.js
var __iconNode1538 = [
  ["circle", { cx: "15", cy: "12", r: "3", key: "1afu0r" }],
  ["rect", { width: "20", height: "14", x: "2", y: "5", rx: "7", key: "g7kal2" }]
];
var ToggleRight = createLucideIcon("toggle-right", __iconNode1538);

// ../node_modules/lucide-react/dist/esm/icons/toilet.js
var __iconNode1539 = [
  [
    "path",
    {
      d: "M7 12h13a1 1 0 0 1 1 1 5 5 0 0 1-5 5h-.598a.5.5 0 0 0-.424.765l1.544 2.47a.5.5 0 0 1-.424.765H5.402a.5.5 0 0 1-.424-.765L7 18",
      key: "kc4kqr"
    }
  ],
  ["path", { d: "M8 18a5 5 0 0 1-5-5V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v8", key: "1tqs57" }]
];
var Toilet = createLucideIcon("toilet", __iconNode1539);

// ../node_modules/lucide-react/dist/esm/icons/tool-case.js
var __iconNode1540 = [
  ["path", { d: "M10 15h4", key: "192ueg" }],
  [
    "path",
    {
      d: "m14.817 10.995-.971-1.45 1.034-1.232a2 2 0 0 0-2.025-3.238l-1.82.364L9.91 3.885a2 2 0 0 0-3.625.748L6.141 6.55l-1.725.426a2 2 0 0 0-.19 3.756l.657.27",
      key: "xbnumr"
    }
  ],
  [
    "path",
    {
      d: "m18.822 10.995 2.26-5.38a1 1 0 0 0-.557-1.318L16.954 2.9a1 1 0 0 0-1.281.533l-.924 2.122",
      key: "eaw7gc"
    }
  ],
  [
    "path",
    {
      d: "M4 12.006A1 1 0 0 1 4.994 11H19a1 1 0 0 1 1 1v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z",
      key: "1vaooh"
    }
  ]
];
var ToolCase = createLucideIcon("tool-case", __iconNode1540);

// ../node_modules/lucide-react/dist/esm/icons/toolbox.js
var __iconNode1541 = [
  ["path", { d: "M16 12v4", key: "vf1vip" }],
  [
    "path",
    {
      d: "M16 6a2 2 0 0 1 1.414.586l4 4A2 2 0 0 1 22 12v7a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 .586-1.414l4-4A2 2 0 0 1 8 6z",
      key: "1h1rvn"
    }
  ],
  ["path", { d: "M16 6V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2", key: "1ksdt3" }],
  ["path", { d: "M2 14h20", key: "myj16y" }],
  ["path", { d: "M8 12v4", key: "1w4uao" }]
];
var Toolbox = createLucideIcon("toolbox", __iconNode1541);

// ../node_modules/lucide-react/dist/esm/icons/tornado.js
var __iconNode1542 = [
  ["path", { d: "M21 4H3", key: "1hwok0" }],
  ["path", { d: "M18 8H6", key: "41n648" }],
  ["path", { d: "M19 12H9", key: "1g4lpz" }],
  ["path", { d: "M16 16h-6", key: "1j5d54" }],
  ["path", { d: "M11 20H9", key: "39obr8" }]
];
var Tornado = createLucideIcon("tornado", __iconNode1542);

// ../node_modules/lucide-react/dist/esm/icons/torus.js
var __iconNode1543 = [
  ["ellipse", { cx: "12", cy: "11", rx: "3", ry: "2", key: "1b2qxu" }],
  ["ellipse", { cx: "12", cy: "12.5", rx: "10", ry: "8.5", key: "h8emeu" }]
];
var Torus = createLucideIcon("torus", __iconNode1543);

// ../node_modules/lucide-react/dist/esm/icons/touchpad-off.js
var __iconNode1544 = [
  ["path", { d: "M12 20v-6", key: "1rm09r" }],
  ["path", { d: "M19.656 14H22", key: "170xzr" }],
  ["path", { d: "M2 14h12", key: "d8icqz" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M20 20H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2", key: "s23sx2" }],
  ["path", { d: "M9.656 4H20a2 2 0 0 1 2 2v10.344", key: "ovjcvl" }]
];
var TouchpadOff = createLucideIcon("touchpad-off", __iconNode1544);

// ../node_modules/lucide-react/dist/esm/icons/touchpad.js
var __iconNode1545 = [
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }],
  ["path", { d: "M2 14h20", key: "myj16y" }],
  ["path", { d: "M12 20v-6", key: "1rm09r" }]
];
var Touchpad = createLucideIcon("touchpad", __iconNode1545);

// ../node_modules/lucide-react/dist/esm/icons/towel-rack.js
var __iconNode1546 = [
  ["path", { d: "M22 7h-2", key: "1okbx2" }],
  [
    "path",
    {
      d: "M6.5 3h11A2.5 2.5 0 0 1 20 5.5V20a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1V5.5a1 1 0 0 0-5 0V17a1 1 0 0 0 1 1h4",
      key: "kc32tg"
    }
  ],
  ["path", { d: "M9 7H2", key: "ahf7b7" }]
];
var TowelRack = createLucideIcon("towel-rack", __iconNode1546);

// ../node_modules/lucide-react/dist/esm/icons/tower-control.js
var __iconNode1547 = [
  [
    "path",
    { d: "M18.2 12.27 20 6H4l1.8 6.27a1 1 0 0 0 .95.73h10.5a1 1 0 0 0 .96-.73Z", key: "1pledb" }
  ],
  ["path", { d: "M8 13v9", key: "hmv0ci" }],
  ["path", { d: "M16 22v-9", key: "ylnf1u" }],
  ["path", { d: "m9 6 1 7", key: "dpdgam" }],
  ["path", { d: "m15 6-1 7", key: "ls7zgu" }],
  ["path", { d: "M12 6V2", key: "1pj48d" }],
  ["path", { d: "M13 2h-2", key: "mj6ths" }]
];
var TowerControl = createLucideIcon("tower-control", __iconNode1547);

// ../node_modules/lucide-react/dist/esm/icons/toy-brick.js
var __iconNode1548 = [
  ["rect", { width: "18", height: "12", x: "3", y: "8", rx: "1", key: "158fvp" }],
  ["path", { d: "M10 8V5c0-.6-.4-1-1-1H6a1 1 0 0 0-1 1v3", key: "s0042v" }],
  ["path", { d: "M19 8V5c0-.6-.4-1-1-1h-3a1 1 0 0 0-1 1v3", key: "9wmeh2" }]
];
var ToyBrick = createLucideIcon("toy-brick", __iconNode1548);

// ../node_modules/lucide-react/dist/esm/icons/tractor.js
var __iconNode1549 = [
  ["path", { d: "m10 11 11 .9a1 1 0 0 1 .8 1.1l-.665 4.158a1 1 0 0 1-.988.842H20", key: "she1j9" }],
  ["path", { d: "M16 18h-5", key: "bq60fd" }],
  ["path", { d: "M18 5a1 1 0 0 0-1 1v5.573", key: "1kv8ia" }],
  ["path", { d: "M3 4h8.129a1 1 0 0 1 .99.863L13 11.246", key: "1q1ert" }],
  ["path", { d: "M4 11V4", key: "9ft8pt" }],
  ["path", { d: "M7 15h.01", key: "k5ht0j" }],
  ["path", { d: "M8 10.1V4", key: "1jgyzo" }],
  ["circle", { cx: "18", cy: "18", r: "2", key: "1emm8v" }],
  ["circle", { cx: "7", cy: "15", r: "5", key: "ddtuc" }]
];
var Tractor = createLucideIcon("tractor", __iconNode1549);

// ../node_modules/lucide-react/dist/esm/icons/traffic-cone.js
var __iconNode1550 = [
  ["path", { d: "M16.05 10.966a5 2.5 0 0 1-8.1 0", key: "m5jpwb" }],
  [
    "path",
    {
      d: "m16.923 14.049 4.48 2.04a1 1 0 0 1 .001 1.831l-8.574 3.9a2 2 0 0 1-1.66 0l-8.574-3.91a1 1 0 0 1 0-1.83l4.484-2.04",
      key: "rbg3g8"
    }
  ],
  ["path", { d: "M16.949 14.14a5 2.5 0 1 1-9.9 0L10.063 3.5a2 2 0 0 1 3.874 0z", key: "vap8c8" }],
  ["path", { d: "M9.194 6.57a5 2.5 0 0 0 5.61 0", key: "15hn5c" }]
];
var TrafficCone = createLucideIcon("traffic-cone", __iconNode1550);

// ../node_modules/lucide-react/dist/esm/icons/train-front-tunnel.js
var __iconNode1551 = [
  ["path", { d: "M2 22V12a10 10 0 1 1 20 0v10", key: "o0fyp0" }],
  ["path", { d: "M15 6.8v1.4a3 2.8 0 1 1-6 0V6.8", key: "m8q3n9" }],
  ["path", { d: "M10 15h.01", key: "44in9x" }],
  ["path", { d: "M14 15h.01", key: "5mohn5" }],
  ["path", { d: "M10 19a4 4 0 0 1-4-4v-3a6 6 0 1 1 12 0v3a4 4 0 0 1-4 4Z", key: "hckbmu" }],
  ["path", { d: "m9 19-2 3", key: "iij7hm" }],
  ["path", { d: "m15 19 2 3", key: "npx8sa" }]
];
var TrainFrontTunnel = createLucideIcon("train-front-tunnel", __iconNode1551);

// ../node_modules/lucide-react/dist/esm/icons/train-front.js
var __iconNode1552 = [
  ["path", { d: "M8 3.1V7a4 4 0 0 0 8 0V3.1", key: "1v71zp" }],
  ["path", { d: "m9 15-1-1", key: "1yrq24" }],
  ["path", { d: "m15 15 1-1", key: "1t0d6s" }],
  ["path", { d: "M9 19c-2.8 0-5-2.2-5-5v-4a8 8 0 0 1 16 0v4c0 2.8-2.2 5-5 5Z", key: "1p0hjs" }],
  ["path", { d: "m8 19-2 3", key: "13i0xs" }],
  ["path", { d: "m16 19 2 3", key: "xo31yx" }]
];
var TrainFront = createLucideIcon("train-front", __iconNode1552);

// ../node_modules/lucide-react/dist/esm/icons/train-track.js
var __iconNode1553 = [
  ["path", { d: "M2 17 17 2", key: "18b09t" }],
  ["path", { d: "m2 14 8 8", key: "1gv9hu" }],
  ["path", { d: "m5 11 8 8", key: "189pqp" }],
  ["path", { d: "m8 8 8 8", key: "1imecy" }],
  ["path", { d: "m11 5 8 8", key: "ummqn6" }],
  ["path", { d: "m14 2 8 8", key: "1vk7dn" }],
  ["path", { d: "M7 22 22 7", key: "15mb1i" }]
];
var TrainTrack = createLucideIcon("train-track", __iconNode1553);

// ../node_modules/lucide-react/dist/esm/icons/tram-front.js
var __iconNode1554 = [
  ["rect", { width: "16", height: "16", x: "4", y: "3", rx: "2", key: "1wxw4b" }],
  ["path", { d: "M4 11h16", key: "mpoxn0" }],
  ["path", { d: "M12 3v8", key: "1h2ygw" }],
  ["path", { d: "m8 19-2 3", key: "13i0xs" }],
  ["path", { d: "m18 22-2-3", key: "1p0ohu" }],
  ["path", { d: "M8 15h.01", key: "a7atzg" }],
  ["path", { d: "M16 15h.01", key: "rnfrdf" }]
];
var TramFront = createLucideIcon("tram-front", __iconNode1554);

// ../node_modules/lucide-react/dist/esm/icons/transgender.js
var __iconNode1555 = [
  ["path", { d: "M12 16v6", key: "c8a4gj" }],
  ["path", { d: "M14 20h-4", key: "m8m19d" }],
  ["path", { d: "M18 2h4v4", key: "1341mj" }],
  ["path", { d: "m2 2 7.17 7.17", key: "13q8l2" }],
  ["path", { d: "M2 5.355V2h3.357", key: "18136r" }],
  ["path", { d: "m22 2-7.17 7.17", key: "1epvy4" }],
  ["path", { d: "M8 5 5 8", key: "mgbjhz" }],
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }]
];
var Transgender = createLucideIcon("transgender", __iconNode1555);

// ../node_modules/lucide-react/dist/esm/icons/trash-2.js
var __iconNode1556 = [
  ["path", { d: "M10 11v6", key: "nco0om" }],
  ["path", { d: "M14 11v6", key: "outv1u" }],
  ["path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6", key: "miytrc" }],
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", key: "e791ji" }]
];
var Trash2 = createLucideIcon("trash-2", __iconNode1556);

// ../node_modules/lucide-react/dist/esm/icons/trash.js
var __iconNode1557 = [
  ["path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6", key: "miytrc" }],
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", key: "e791ji" }]
];
var Trash = createLucideIcon("trash", __iconNode1557);

// ../node_modules/lucide-react/dist/esm/icons/tree-deciduous.js
var __iconNode1558 = [
  [
    "path",
    {
      d: "M8 19a4 4 0 0 1-2.24-7.32A3.5 3.5 0 0 1 9 6.03V6a3 3 0 1 1 6 0v.04a3.5 3.5 0 0 1 3.24 5.65A4 4 0 0 1 16 19Z",
      key: "oadzkq"
    }
  ],
  ["path", { d: "M12 19v3", key: "npa21l" }]
];
var TreeDeciduous = createLucideIcon("tree-deciduous", __iconNode1558);

// ../node_modules/lucide-react/dist/esm/icons/tree-palm.js
var __iconNode1559 = [
  ["path", { d: "M13 8c0-2.76-2.46-5-5.5-5S2 5.24 2 8h2l1-1 1 1h4", key: "foxbe7" }],
  [
    "path",
    { d: "M13 7.14A5.82 5.82 0 0 1 16.5 6c3.04 0 5.5 2.24 5.5 5h-3l-1-1-1 1h-3", key: "18arnh" }
  ],
  [
    "path",
    {
      d: "M5.89 9.71c-2.15 2.15-2.3 5.47-.35 7.43l4.24-4.25.7-.7.71-.71 2.12-2.12c-1.95-1.96-5.27-1.8-7.42.35",
      key: "ywahnh"
    }
  ],
  ["path", { d: "M11 15.5c.5 2.5-.17 4.5-1 6.5h4c2-5.5-.5-12-1-14", key: "ft0feo" }]
];
var TreePalm = createLucideIcon("tree-palm", __iconNode1559);

// ../node_modules/lucide-react/dist/esm/icons/tree-pine.js
var __iconNode1560 = [
  [
    "path",
    {
      d: "m17 14 3 3.3a1 1 0 0 1-.7 1.7H4.7a1 1 0 0 1-.7-1.7L7 14h-.3a1 1 0 0 1-.7-1.7L9 9h-.2A1 1 0 0 1 8 7.3L12 3l4 4.3a1 1 0 0 1-.8 1.7H15l3 3.3a1 1 0 0 1-.7 1.7H17Z",
      key: "cpyugq"
    }
  ],
  ["path", { d: "M12 22v-3", key: "kmzjlo" }]
];
var TreePine = createLucideIcon("tree-pine", __iconNode1560);

// ../node_modules/lucide-react/dist/esm/icons/trees.js
var __iconNode1561 = [
  ["path", { d: "M10 10v.2A3 3 0 0 1 8.9 16H5a3 3 0 0 1-1-5.8V10a3 3 0 0 1 6 0Z", key: "1l6gj6" }],
  ["path", { d: "M7 16v6", key: "1a82de" }],
  ["path", { d: "M13 19v3", key: "13sx9i" }],
  [
    "path",
    {
      d: "M12 19h8.3a1 1 0 0 0 .7-1.7L18 14h.3a1 1 0 0 0 .7-1.7L16 9h.2a1 1 0 0 0 .8-1.7L13 3l-1.4 1.5",
      key: "1sj9kv"
    }
  ]
];
var Trees = createLucideIcon("trees", __iconNode1561);

// ../node_modules/lucide-react/dist/esm/icons/trello.js
var __iconNode1562 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", ry: "2", key: "1m3agn" }],
  ["rect", { width: "3", height: "9", x: "7", y: "7", key: "14n3xi" }],
  ["rect", { width: "3", height: "5", x: "14", y: "7", key: "s4azjd" }]
];
var Trello = createLucideIcon("trello", __iconNode1562);

// ../node_modules/lucide-react/dist/esm/icons/trending-down.js
var __iconNode1563 = [
  ["path", { d: "M16 17h6v-6", key: "t6n2it" }],
  ["path", { d: "m22 17-8.5-8.5-5 5L2 7", key: "x473p" }]
];
var TrendingDown = createLucideIcon("trending-down", __iconNode1563);

// ../node_modules/lucide-react/dist/esm/icons/trending-up-down.js
var __iconNode1564 = [
  ["path", { d: "M14.828 14.828 21 21", key: "ar5fw7" }],
  ["path", { d: "M21 16v5h-5", key: "1ck2sf" }],
  ["path", { d: "m21 3-9 9-4-4-6 6", key: "1h02xo" }],
  ["path", { d: "M21 8V3h-5", key: "1qoq8a" }]
];
var TrendingUpDown = createLucideIcon("trending-up-down", __iconNode1564);

// ../node_modules/lucide-react/dist/esm/icons/trending-up.js
var __iconNode1565 = [
  ["path", { d: "M16 7h6v6", key: "box55l" }],
  ["path", { d: "m22 7-8.5 8.5-5-5L2 17", key: "1t1m79" }]
];
var TrendingUp = createLucideIcon("trending-up", __iconNode1565);

// ../node_modules/lucide-react/dist/esm/icons/triangle-alert.js
var __iconNode1566 = [
  [
    "path",
    {
      d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
      key: "wmoenq"
    }
  ],
  ["path", { d: "M12 9v4", key: "juzpu7" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
];
var TriangleAlert = createLucideIcon("triangle-alert", __iconNode1566);

// ../node_modules/lucide-react/dist/esm/icons/triangle-dashed.js
var __iconNode1567 = [
  ["path", { d: "M10.17 4.193a2 2 0 0 1 3.666.013", key: "pltmmw" }],
  ["path", { d: "M14 21h2", key: "v4qezv" }],
  ["path", { d: "m15.874 7.743 1 1.732", key: "10m0iw" }],
  ["path", { d: "m18.849 12.952 1 1.732", key: "zadnam" }],
  ["path", { d: "M21.824 18.18a2 2 0 0 1-1.835 2.824", key: "fvwuk4" }],
  ["path", { d: "M4.024 21a2 2 0 0 1-1.839-2.839", key: "1e1kah" }],
  ["path", { d: "m5.136 12.952-1 1.732", key: "1u4ldi" }],
  ["path", { d: "M8 21h2", key: "i9zjee" }],
  ["path", { d: "m8.102 7.743-1 1.732", key: "1zzo4u" }]
];
var TriangleDashed = createLucideIcon("triangle-dashed", __iconNode1567);

// ../node_modules/lucide-react/dist/esm/icons/triangle-right.js
var __iconNode1568 = [
  [
    "path",
    {
      d: "M22 18a2 2 0 0 1-2 2H3c-1.1 0-1.3-.6-.4-1.3L20.4 4.3c.9-.7 1.6-.4 1.6.7Z",
      key: "183wce"
    }
  ]
];
var TriangleRight = createLucideIcon("triangle-right", __iconNode1568);

// ../node_modules/lucide-react/dist/esm/icons/triangle.js
var __iconNode1569 = [
  [
    "path",
    { d: "M13.73 4a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z", key: "14u9p9" }
  ]
];
var Triangle = createLucideIcon("triangle", __iconNode1569);

// ../node_modules/lucide-react/dist/esm/icons/truck-electric.js
var __iconNode1570 = [
  ["path", { d: "M14 19V7a2 2 0 0 0-2-2H9", key: "15peso" }],
  ["path", { d: "M15 19H9", key: "18q6dt" }],
  [
    "path",
    {
      d: "M19 19h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.62L18.3 9.38a1 1 0 0 0-.78-.38H14",
      key: "1dkp3j"
    }
  ],
  ["path", { d: "M2 13v5a1 1 0 0 0 1 1h2", key: "pkmmzz" }],
  [
    "path",
    { d: "M4 3 2.15 5.15a.495.495 0 0 0 .35.86h2.15a.47.47 0 0 1 .35.86L3 9.02", key: "1n26pd" }
  ],
  ["circle", { cx: "17", cy: "19", r: "2", key: "1nxcgd" }],
  ["circle", { cx: "7", cy: "19", r: "2", key: "gzo7y7" }]
];
var TruckElectric = createLucideIcon("truck-electric", __iconNode1570);

// ../node_modules/lucide-react/dist/esm/icons/truck.js
var __iconNode1571 = [
  ["path", { d: "M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2", key: "wrbu53" }],
  ["path", { d: "M15 18H9", key: "1lyqi6" }],
  [
    "path",
    {
      d: "M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14",
      key: "lysw3i"
    }
  ],
  ["circle", { cx: "17", cy: "18", r: "2", key: "332jqn" }],
  ["circle", { cx: "7", cy: "18", r: "2", key: "19iecd" }]
];
var Truck = createLucideIcon("truck", __iconNode1571);

// ../node_modules/lucide-react/dist/esm/icons/trophy.js
var __iconNode1572 = [
  ["path", { d: "M10 14.66v1.626a2 2 0 0 1-.976 1.696A5 5 0 0 0 7 21.978", key: "1n3hpd" }],
  ["path", { d: "M14 14.66v1.626a2 2 0 0 0 .976 1.696A5 5 0 0 1 17 21.978", key: "rfe1zi" }],
  ["path", { d: "M18 9h1.5a1 1 0 0 0 0-5H18", key: "7xy6bh" }],
  ["path", { d: "M4 22h16", key: "57wxv0" }],
  ["path", { d: "M6 9a6 6 0 0 0 12 0V3a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1z", key: "1mhfuq" }],
  ["path", { d: "M6 9H4.5a1 1 0 0 1 0-5H6", key: "tex48p" }]
];
var Trophy = createLucideIcon("trophy", __iconNode1572);

// ../node_modules/lucide-react/dist/esm/icons/turkish-lira.js
var __iconNode1573 = [
  ["path", { d: "M15 4 5 9", key: "14bkc9" }],
  ["path", { d: "m15 8.5-10 5", key: "1grtsx" }],
  ["path", { d: "M18 12a9 9 0 0 1-9 9V3", key: "1sst7f" }]
];
var TurkishLira = createLucideIcon("turkish-lira", __iconNode1573);

// ../node_modules/lucide-react/dist/esm/icons/turntable.js
var __iconNode1574 = [
  ["path", { d: "M10 12.01h.01", key: "7rp0yl" }],
  ["path", { d: "M18 8v4a8 8 0 0 1-1.07 4", key: "1st48v" }],
  ["circle", { cx: "10", cy: "12", r: "4", key: "19levz" }],
  ["rect", { x: "2", y: "4", width: "20", height: "16", rx: "2", key: "izxlao" }]
];
var Turntable = createLucideIcon("turntable", __iconNode1574);

// ../node_modules/lucide-react/dist/esm/icons/turtle.js
var __iconNode1575 = [
  [
    "path",
    {
      d: "m12 10 2 4v3a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-3a8 8 0 1 0-16 0v3a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-3l2-4h4Z",
      key: "1lbbv7"
    }
  ],
  ["path", { d: "M4.82 7.9 8 10", key: "m9wose" }],
  ["path", { d: "M15.18 7.9 12 10", key: "p8dp2u" }],
  ["path", { d: "M16.93 10H20a2 2 0 0 1 0 4H2", key: "12nsm7" }]
];
var Turtle = createLucideIcon("turtle", __iconNode1575);

// ../node_modules/lucide-react/dist/esm/icons/tv-minimal-play.js
var __iconNode1576 = [
  [
    "path",
    {
      d: "M15.033 9.44a.647.647 0 0 1 0 1.12l-4.065 2.352a.645.645 0 0 1-.968-.56V7.648a.645.645 0 0 1 .967-.56z",
      key: "vbtd3f"
    }
  ],
  ["path", { d: "M7 21h10", key: "1b0cd5" }],
  ["rect", { width: "20", height: "14", x: "2", y: "3", rx: "2", key: "48i651" }]
];
var TvMinimalPlay = createLucideIcon("tv-minimal-play", __iconNode1576);

// ../node_modules/lucide-react/dist/esm/icons/tv-minimal.js
var __iconNode1577 = [
  ["path", { d: "M7 21h10", key: "1b0cd5" }],
  ["rect", { width: "20", height: "14", x: "2", y: "3", rx: "2", key: "48i651" }]
];
var TvMinimal = createLucideIcon("tv-minimal", __iconNode1577);

// ../node_modules/lucide-react/dist/esm/icons/tv.js
var __iconNode1578 = [
  ["path", { d: "m17 2-5 5-5-5", key: "16satq" }],
  ["rect", { width: "20", height: "15", x: "2", y: "7", rx: "2", key: "1e6viu" }]
];
var Tv = createLucideIcon("tv", __iconNode1578);

// ../node_modules/lucide-react/dist/esm/icons/twitch.js
var __iconNode1579 = [
  ["path", { d: "M21 2H3v16h5v4l4-4h5l4-4V2zm-10 9V7m5 4V7", key: "c0yzno" }]
];
var Twitch = createLucideIcon("twitch", __iconNode1579);

// ../node_modules/lucide-react/dist/esm/icons/twitter.js
var __iconNode1580 = [
  [
    "path",
    {
      d: "M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z",
      key: "pff0z6"
    }
  ]
];
var Twitter = createLucideIcon("twitter", __iconNode1580);

// ../node_modules/lucide-react/dist/esm/icons/type-outline.js
var __iconNode1581 = [
  [
    "path",
    {
      d: "M14 16.5a.5.5 0 0 0 .5.5h.5a2 2 0 0 1 0 4H9a2 2 0 0 1 0-4h.5a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5V8a2 2 0 0 1-4 0V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v3a2 2 0 0 1-4 0v-.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5Z",
      key: "1reda3"
    }
  ]
];
var TypeOutline = createLucideIcon("type-outline", __iconNode1581);

// ../node_modules/lucide-react/dist/esm/icons/type.js
var __iconNode1582 = [
  ["path", { d: "M12 4v16", key: "1654pz" }],
  ["path", { d: "M4 7V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2", key: "e0r10z" }],
  ["path", { d: "M9 20h6", key: "s66wpe" }]
];
var Type = createLucideIcon("type", __iconNode1582);

// ../node_modules/lucide-react/dist/esm/icons/umbrella-off.js
var __iconNode1583 = [
  ["path", { d: "M12 13v7a2 2 0 0 0 4 0", key: "rpgb42" }],
  ["path", { d: "M12 2v2", key: "tus03m" }],
  [
    "path",
    { d: "M18.656 13h2.336a1 1 0 0 0 .97-1.274 10.284 10.284 0 0 0-12.07-7.51", key: "yawknk" }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  ["path", { d: "M5.961 5.957a10.28 10.28 0 0 0-3.922 5.769A1 1 0 0 0 3 13h10", key: "5sfalc" }]
];
var UmbrellaOff = createLucideIcon("umbrella-off", __iconNode1583);

// ../node_modules/lucide-react/dist/esm/icons/umbrella.js
var __iconNode1584 = [
  ["path", { d: "M12 13v7a2 2 0 0 0 4 0", key: "rpgb42" }],
  ["path", { d: "M12 2v2", key: "tus03m" }],
  [
    "path",
    {
      d: "M20.992 13a1 1 0 0 0 .97-1.274 10.284 10.284 0 0 0-19.923 0A1 1 0 0 0 3 13z",
      key: "124nyo"
    }
  ]
];
var Umbrella = createLucideIcon("umbrella", __iconNode1584);

// ../node_modules/lucide-react/dist/esm/icons/underline.js
var __iconNode1585 = [
  ["path", { d: "M6 4v6a6 6 0 0 0 12 0V4", key: "9kb039" }],
  ["line", { x1: "4", x2: "20", y1: "20", y2: "20", key: "nun2al" }]
];
var Underline = createLucideIcon("underline", __iconNode1585);

// ../node_modules/lucide-react/dist/esm/icons/undo-2.js
var __iconNode1586 = [
  ["path", { d: "M9 14 4 9l5-5", key: "102s5s" }],
  ["path", { d: "M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11", key: "f3b9sd" }]
];
var Undo2 = createLucideIcon("undo-2", __iconNode1586);

// ../node_modules/lucide-react/dist/esm/icons/undo-dot.js
var __iconNode1587 = [
  ["path", { d: "M21 17a9 9 0 0 0-15-6.7L3 13", key: "8mp6z9" }],
  ["path", { d: "M3 7v6h6", key: "1v2h90" }],
  ["circle", { cx: "12", cy: "17", r: "1", key: "1ixnty" }]
];
var UndoDot = createLucideIcon("undo-dot", __iconNode1587);

// ../node_modules/lucide-react/dist/esm/icons/undo.js
var __iconNode1588 = [
  ["path", { d: "M3 7v6h6", key: "1v2h90" }],
  ["path", { d: "M21 17a9 9 0 0 0-9-9 9 9 0 0 0-6 2.3L3 13", key: "1r6uu6" }]
];
var Undo = createLucideIcon("undo", __iconNode1588);

// ../node_modules/lucide-react/dist/esm/icons/unfold-horizontal.js
var __iconNode1589 = [
  ["path", { d: "M16 12h6", key: "15xry1" }],
  ["path", { d: "M8 12H2", key: "1jqql6" }],
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "M12 8v2", key: "1woqiv" }],
  ["path", { d: "M12 14v2", key: "8jcxud" }],
  ["path", { d: "M12 20v2", key: "1lh1kg" }],
  ["path", { d: "m19 15 3-3-3-3", key: "wjy7rq" }],
  ["path", { d: "m5 9-3 3 3 3", key: "j64kie" }]
];
var UnfoldHorizontal = createLucideIcon("unfold-horizontal", __iconNode1589);

// ../node_modules/lucide-react/dist/esm/icons/unfold-vertical.js
var __iconNode1590 = [
  ["path", { d: "M12 22v-6", key: "6o8u61" }],
  ["path", { d: "M12 8V2", key: "1wkif3" }],
  ["path", { d: "M4 12H2", key: "rhcxmi" }],
  ["path", { d: "M10 12H8", key: "s88cx1" }],
  ["path", { d: "M16 12h-2", key: "10asgb" }],
  ["path", { d: "M22 12h-2", key: "14jgyd" }],
  ["path", { d: "m15 19-3 3-3-3", key: "11eu04" }],
  ["path", { d: "m15 5-3-3-3 3", key: "itvq4r" }]
];
var UnfoldVertical = createLucideIcon("unfold-vertical", __iconNode1590);

// ../node_modules/lucide-react/dist/esm/icons/ungroup.js
var __iconNode1591 = [
  ["rect", { width: "8", height: "6", x: "5", y: "4", rx: "1", key: "nzclkv" }],
  ["rect", { width: "8", height: "6", x: "11", y: "14", rx: "1", key: "4tytwb" }]
];
var Ungroup = createLucideIcon("ungroup", __iconNode1591);

// ../node_modules/lucide-react/dist/esm/icons/university.js
var __iconNode1592 = [
  ["path", { d: "M14 21v-3a2 2 0 0 0-4 0v3", key: "1rgiei" }],
  ["path", { d: "M18 12h.01", key: "yjnet6" }],
  ["path", { d: "M18 16h.01", key: "plv8zi" }],
  [
    "path",
    {
      d: "M22 7a1 1 0 0 0-1-1h-2a2 2 0 0 1-1.143-.359L13.143 2.36a2 2 0 0 0-2.286-.001L6.143 5.64A2 2 0 0 1 5 6H3a1 1 0 0 0-1 1v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2z",
      key: "1ogmi3"
    }
  ],
  ["path", { d: "M6 12h.01", key: "c2rlol" }],
  ["path", { d: "M6 16h.01", key: "1pmjb7" }],
  ["circle", { cx: "12", cy: "10", r: "2", key: "1yojzk" }]
];
var University = createLucideIcon("university", __iconNode1592);

// ../node_modules/lucide-react/dist/esm/icons/unlink-2.js
var __iconNode1593 = [
  ["path", { d: "M15 7h2a5 5 0 0 1 0 10h-2m-6 0H7A5 5 0 0 1 7 7h2", key: "1re2ne" }]
];
var Unlink2 = createLucideIcon("unlink-2", __iconNode1593);

// ../node_modules/lucide-react/dist/esm/icons/unlink.js
var __iconNode1594 = [
  [
    "path",
    {
      d: "m18.84 12.25 1.72-1.71h-.02a5.004 5.004 0 0 0-.12-7.07 5.006 5.006 0 0 0-6.95 0l-1.72 1.71",
      key: "yqzxt4"
    }
  ],
  [
    "path",
    {
      d: "m5.17 11.75-1.71 1.71a5.004 5.004 0 0 0 .12 7.07 5.006 5.006 0 0 0 6.95 0l1.71-1.71",
      key: "4qinb0"
    }
  ],
  ["line", { x1: "8", x2: "8", y1: "2", y2: "5", key: "1041cp" }],
  ["line", { x1: "2", x2: "5", y1: "8", y2: "8", key: "14m1p5" }],
  ["line", { x1: "16", x2: "16", y1: "19", y2: "22", key: "rzdirn" }],
  ["line", { x1: "19", x2: "22", y1: "16", y2: "16", key: "ox905f" }]
];
var Unlink = createLucideIcon("unlink", __iconNode1594);

// ../node_modules/lucide-react/dist/esm/icons/unplug.js
var __iconNode1595 = [
  ["path", { d: "m19 5 3-3", key: "yk6iyv" }],
  ["path", { d: "m2 22 3-3", key: "19mgm9" }],
  [
    "path",
    { d: "M6.3 20.3a2.4 2.4 0 0 0 3.4 0L12 18l-6-6-2.3 2.3a2.4 2.4 0 0 0 0 3.4Z", key: "goz73y" }
  ],
  ["path", { d: "M7.5 13.5 10 11", key: "7xgeeb" }],
  ["path", { d: "M10.5 16.5 13 14", key: "10btkg" }],
  [
    "path",
    { d: "m12 6 6 6 2.3-2.3a2.4 2.4 0 0 0 0-3.4l-2.6-2.6a2.4 2.4 0 0 0-3.4 0Z", key: "1snsnr" }
  ]
];
var Unplug = createLucideIcon("unplug", __iconNode1595);

// ../node_modules/lucide-react/dist/esm/icons/usb.js
var __iconNode1596 = [
  ["circle", { cx: "10", cy: "7", r: "1", key: "dypaad" }],
  ["circle", { cx: "4", cy: "20", r: "1", key: "22iqad" }],
  ["path", { d: "M4.7 19.3 19 5", key: "1enqfc" }],
  ["path", { d: "m21 3-3 1 2 2Z", key: "d3ov82" }],
  ["path", { d: "M9.26 7.68 5 12l2 5", key: "1esawj" }],
  ["path", { d: "m10 14 5 2 3.5-3.5", key: "v8oal5" }],
  ["path", { d: "m18 12 1-1 1 1-1 1Z", key: "1bh22v" }]
];
var Usb = createLucideIcon("usb", __iconNode1596);

// ../node_modules/lucide-react/dist/esm/icons/upload.js
var __iconNode1597 = [
  ["path", { d: "M12 3v12", key: "1x0j5s" }],
  ["path", { d: "m17 8-5-5-5 5", key: "7q97r8" }],
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }]
];
var Upload = createLucideIcon("upload", __iconNode1597);

// ../node_modules/lucide-react/dist/esm/icons/user-check.js
var __iconNode1598 = [
  ["path", { d: "m16 11 2 2 4-4", key: "9rsbq5" }],
  ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }]
];
var UserCheck = createLucideIcon("user-check", __iconNode1598);

// ../node_modules/lucide-react/dist/esm/icons/user-cog.js
var __iconNode1599 = [
  ["path", { d: "M10 15H6a4 4 0 0 0-4 4v2", key: "1nfge6" }],
  ["path", { d: "m14.305 16.53.923-.382", key: "1itpsq" }],
  ["path", { d: "m15.228 13.852-.923-.383", key: "eplpkm" }],
  ["path", { d: "m16.852 12.228-.383-.923", key: "13v3q0" }],
  ["path", { d: "m16.852 17.772-.383.924", key: "1i8mnm" }],
  ["path", { d: "m19.148 12.228.383-.923", key: "1q8j1v" }],
  ["path", { d: "m19.53 18.696-.382-.924", key: "vk1qj3" }],
  ["path", { d: "m20.772 13.852.924-.383", key: "n880s0" }],
  ["path", { d: "m20.772 16.148.924.383", key: "1g6xey" }],
  ["circle", { cx: "18", cy: "15", r: "3", key: "gjjjvw" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }]
];
var UserCog = createLucideIcon("user-cog", __iconNode1599);

// ../node_modules/lucide-react/dist/esm/icons/user-key.js
var __iconNode1600 = [
  ["path", { d: "M20 11v6", key: "d77pzp" }],
  ["path", { d: "M20 13h2", key: "16rner" }],
  ["path", { d: "M3 21v-2a4 4 0 0 1 4-4h6a4 4 0 0 1 2.072.578", key: "1yxgtw" }],
  ["circle", { cx: "10", cy: "7", r: "4", key: "e45bow" }],
  ["circle", { cx: "20", cy: "19", r: "2", key: "1obnsp" }]
];
var UserKey = createLucideIcon("user-key", __iconNode1600);

// ../node_modules/lucide-react/dist/esm/icons/user-lock.js
var __iconNode1601 = [
  ["path", { d: "M19 16v-2a2 2 0 0 0-4 0v2", key: "17sujf" }],
  ["path", { d: "M9.5 15H7a4 4 0 0 0-4 4v2", key: "9it25y" }],
  ["circle", { cx: "10", cy: "7", r: "4", key: "e45bow" }],
  ["rect", { x: "13", y: "16", width: "8", height: "5", rx: ".899", key: "ur80nz" }]
];
var UserLock = createLucideIcon("user-lock", __iconNode1601);

// ../node_modules/lucide-react/dist/esm/icons/user-minus.js
var __iconNode1602 = [
  ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }],
  ["line", { x1: "22", x2: "16", y1: "11", y2: "11", key: "1shjgl" }]
];
var UserMinus = createLucideIcon("user-minus", __iconNode1602);

// ../node_modules/lucide-react/dist/esm/icons/user-pen.js
var __iconNode1603 = [
  ["path", { d: "M11.5 15H7a4 4 0 0 0-4 4v2", key: "15lzij" }],
  [
    "path",
    {
      d: "M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
      key: "1817ys"
    }
  ],
  ["circle", { cx: "10", cy: "7", r: "4", key: "e45bow" }]
];
var UserPen = createLucideIcon("user-pen", __iconNode1603);

// ../node_modules/lucide-react/dist/esm/icons/user-round-check.js
var __iconNode1604 = [
  ["path", { d: "M2 21a8 8 0 0 1 13.292-6", key: "bjp14o" }],
  ["circle", { cx: "10", cy: "8", r: "5", key: "o932ke" }],
  ["path", { d: "m16 19 2 2 4-4", key: "1b14m6" }]
];
var UserRoundCheck = createLucideIcon("user-round-check", __iconNode1604);

// ../node_modules/lucide-react/dist/esm/icons/user-round-cog.js
var __iconNode1605 = [
  ["path", { d: "m14.305 19.53.923-.382", key: "3m78fa" }],
  ["path", { d: "m15.228 16.852-.923-.383", key: "npixar" }],
  ["path", { d: "m16.852 15.228-.383-.923", key: "5xggr7" }],
  ["path", { d: "m16.852 20.772-.383.924", key: "dpfhf9" }],
  ["path", { d: "m19.148 15.228.383-.923", key: "1reyyz" }],
  ["path", { d: "m19.53 21.696-.382-.924", key: "1goivc" }],
  ["path", { d: "M2 21a8 8 0 0 1 10.434-7.62", key: "1yezr2" }],
  ["path", { d: "m20.772 16.852.924-.383", key: "htqkph" }],
  ["path", { d: "m20.772 19.148.924.383", key: "9w9pjp" }],
  ["circle", { cx: "10", cy: "8", r: "5", key: "o932ke" }],
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }]
];
var UserRoundCog = createLucideIcon("user-round-cog", __iconNode1605);

// ../node_modules/lucide-react/dist/esm/icons/user-plus.js
var __iconNode1606 = [
  ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }],
  ["line", { x1: "19", x2: "19", y1: "8", y2: "14", key: "1bvyxn" }],
  ["line", { x1: "22", x2: "16", y1: "11", y2: "11", key: "1shjgl" }]
];
var UserPlus = createLucideIcon("user-plus", __iconNode1606);

// ../node_modules/lucide-react/dist/esm/icons/user-round-key.js
var __iconNode1607 = [
  ["path", { d: "M19 11v6", key: "rcqigv" }],
  ["path", { d: "M19 13h2", key: "1gch44" }],
  ["path", { d: "M2 21a8 8 0 0 1 12.868-6.349", key: "1lryzn" }],
  ["circle", { cx: "10", cy: "8", r: "5", key: "o932ke" }],
  ["circle", { cx: "19", cy: "19", r: "2", key: "17f5cg" }]
];
var UserRoundKey = createLucideIcon("user-round-key", __iconNode1607);

// ../node_modules/lucide-react/dist/esm/icons/user-round-pen.js
var __iconNode1608 = [
  ["path", { d: "M2 21a8 8 0 0 1 10.821-7.487", key: "1c8h7z" }],
  [
    "path",
    {
      d: "M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
      key: "1817ys"
    }
  ],
  ["circle", { cx: "10", cy: "8", r: "5", key: "o932ke" }]
];
var UserRoundPen = createLucideIcon("user-round-pen", __iconNode1608);

// ../node_modules/lucide-react/dist/esm/icons/user-round-minus.js
var __iconNode1609 = [
  ["path", { d: "M2 21a8 8 0 0 1 13.292-6", key: "bjp14o" }],
  ["circle", { cx: "10", cy: "8", r: "5", key: "o932ke" }],
  ["path", { d: "M22 19h-6", key: "vcuq98" }]
];
var UserRoundMinus = createLucideIcon("user-round-minus", __iconNode1609);

// ../node_modules/lucide-react/dist/esm/icons/user-round-plus.js
var __iconNode1610 = [
  ["path", { d: "M2 21a8 8 0 0 1 13.292-6", key: "bjp14o" }],
  ["circle", { cx: "10", cy: "8", r: "5", key: "o932ke" }],
  ["path", { d: "M19 16v6", key: "tddt3s" }],
  ["path", { d: "M22 19h-6", key: "vcuq98" }]
];
var UserRoundPlus = createLucideIcon("user-round-plus", __iconNode1610);

// ../node_modules/lucide-react/dist/esm/icons/user-round-search.js
var __iconNode1611 = [
  ["circle", { cx: "10", cy: "8", r: "5", key: "o932ke" }],
  ["path", { d: "M2 21a8 8 0 0 1 10.434-7.62", key: "1yezr2" }],
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }],
  ["path", { d: "m22 22-1.9-1.9", key: "1e5ubv" }]
];
var UserRoundSearch = createLucideIcon("user-round-search", __iconNode1611);

// ../node_modules/lucide-react/dist/esm/icons/user-round-x.js
var __iconNode1612 = [
  ["path", { d: "M2 21a8 8 0 0 1 11.873-7", key: "74fkxq" }],
  ["circle", { cx: "10", cy: "8", r: "5", key: "o932ke" }],
  ["path", { d: "m17 17 5 5", key: "p7ous7" }],
  ["path", { d: "m22 17-5 5", key: "gqnmv0" }]
];
var UserRoundX = createLucideIcon("user-round-x", __iconNode1612);

// ../node_modules/lucide-react/dist/esm/icons/user-round.js
var __iconNode1613 = [
  ["circle", { cx: "12", cy: "8", r: "5", key: "1hypcn" }],
  ["path", { d: "M20 21a8 8 0 0 0-16 0", key: "rfgkzh" }]
];
var UserRound = createLucideIcon("user-round", __iconNode1613);

// ../node_modules/lucide-react/dist/esm/icons/user-search.js
var __iconNode1614 = [
  ["circle", { cx: "10", cy: "7", r: "4", key: "e45bow" }],
  ["path", { d: "M10.3 15H7a4 4 0 0 0-4 4v2", key: "3bnktk" }],
  ["circle", { cx: "17", cy: "17", r: "3", key: "18b49y" }],
  ["path", { d: "m21 21-1.9-1.9", key: "1g2n9r" }]
];
var UserSearch = createLucideIcon("user-search", __iconNode1614);

// ../node_modules/lucide-react/dist/esm/icons/user-star.js
var __iconNode1615 = [
  [
    "path",
    {
      d: "M16.051 12.616a1 1 0 0 1 1.909.024l.737 1.452a1 1 0 0 0 .737.535l1.634.256a1 1 0 0 1 .588 1.806l-1.172 1.168a1 1 0 0 0-.282.866l.259 1.613a1 1 0 0 1-1.541 1.134l-1.465-.75a1 1 0 0 0-.912 0l-1.465.75a1 1 0 0 1-1.539-1.133l.258-1.613a1 1 0 0 0-.282-.866l-1.156-1.153a1 1 0 0 1 .572-1.822l1.633-.256a1 1 0 0 0 .737-.535z",
      key: "1m8t9f"
    }
  ],
  ["path", { d: "M8 15H7a4 4 0 0 0-4 4v2", key: "l9tmp8" }],
  ["circle", { cx: "10", cy: "7", r: "4", key: "e45bow" }]
];
var UserStar = createLucideIcon("user-star", __iconNode1615);

// ../node_modules/lucide-react/dist/esm/icons/user-x.js
var __iconNode1616 = [
  ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }],
  ["line", { x1: "17", x2: "22", y1: "8", y2: "13", key: "3nzzx3" }],
  ["line", { x1: "22", x2: "17", y1: "8", y2: "13", key: "1swrse" }]
];
var UserX = createLucideIcon("user-x", __iconNode1616);

// ../node_modules/lucide-react/dist/esm/icons/user.js
var __iconNode1617 = [
  ["path", { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", key: "975kel" }],
  ["circle", { cx: "12", cy: "7", r: "4", key: "17ys0d" }]
];
var User = createLucideIcon("user", __iconNode1617);

// ../node_modules/lucide-react/dist/esm/icons/users-round.js
var __iconNode1618 = [
  ["path", { d: "M18 21a8 8 0 0 0-16 0", key: "3ypg7q" }],
  ["circle", { cx: "10", cy: "8", r: "5", key: "o932ke" }],
  ["path", { d: "M22 20c0-3.37-2-6.5-4-8a5 5 0 0 0-.45-8.3", key: "10s06x" }]
];
var UsersRound = createLucideIcon("users-round", __iconNode1618);

// ../node_modules/lucide-react/dist/esm/icons/users.js
var __iconNode1619 = [
  ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
  ["path", { d: "M16 3.128a4 4 0 0 1 0 7.744", key: "16gr8j" }],
  ["path", { d: "M22 21v-2a4 4 0 0 0-3-3.87", key: "kshegd" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }]
];
var Users = createLucideIcon("users", __iconNode1619);

// ../node_modules/lucide-react/dist/esm/icons/utensils-crossed.js
var __iconNode1620 = [
  ["path", { d: "m16 2-2.3 2.3a3 3 0 0 0 0 4.2l1.8 1.8a3 3 0 0 0 4.2 0L22 8", key: "n7qcjb" }],
  [
    "path",
    { d: "M15 15 3.3 3.3a4.2 4.2 0 0 0 0 6l7.3 7.3c.7.7 2 .7 2.8 0L15 15Zm0 0 7 7", key: "d0u48b" }
  ],
  ["path", { d: "m2.1 21.8 6.4-6.3", key: "yn04lh" }],
  ["path", { d: "m19 5-7 7", key: "194lzd" }]
];
var UtensilsCrossed = createLucideIcon("utensils-crossed", __iconNode1620);

// ../node_modules/lucide-react/dist/esm/icons/utensils.js
var __iconNode1621 = [
  ["path", { d: "M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2", key: "cjf0a3" }],
  ["path", { d: "M7 2v20", key: "1473qp" }],
  ["path", { d: "M21 15V2a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7", key: "j28e5" }]
];
var Utensils = createLucideIcon("utensils", __iconNode1621);

// ../node_modules/lucide-react/dist/esm/icons/utility-pole.js
var __iconNode1622 = [
  ["path", { d: "M12 2v20", key: "t6zp3m" }],
  ["path", { d: "M2 5h20", key: "1fs1ex" }],
  ["path", { d: "M3 3v2", key: "9imdir" }],
  ["path", { d: "M7 3v2", key: "n0os7" }],
  ["path", { d: "M17 3v2", key: "1l2re6" }],
  ["path", { d: "M21 3v2", key: "1duuac" }],
  ["path", { d: "m19 5-7 7-7-7", key: "133zxf" }]
];
var UtilityPole = createLucideIcon("utility-pole", __iconNode1622);

// ../node_modules/lucide-react/dist/esm/icons/van.js
var __iconNode1623 = [
  [
    "path",
    {
      d: "M13 6v5a1 1 0 0 0 1 1h6.102a1 1 0 0 1 .712.298l.898.91a1 1 0 0 1 .288.702V17a1 1 0 0 1-1 1h-3",
      key: "k3s650"
    }
  ],
  [
    "path",
    { d: "M5 18H3a1 1 0 0 1-1-1V8a2 2 0 0 1 2-2h12c1.1 0 2.1.8 2.4 1.8l1.176 4.2", key: "fnd93u" }
  ],
  ["path", { d: "M9 18h5", key: "lrx6i" }],
  ["circle", { cx: "16", cy: "18", r: "2", key: "1v4tcr" }],
  ["circle", { cx: "7", cy: "18", r: "2", key: "19iecd" }]
];
var Van = createLucideIcon("van", __iconNode1623);

// ../node_modules/lucide-react/dist/esm/icons/variable.js
var __iconNode1624 = [
  ["path", { d: "M8 21s-4-3-4-9 4-9 4-9", key: "uto9ud" }],
  ["path", { d: "M16 3s4 3 4 9-4 9-4 9", key: "4w2vsq" }],
  ["line", { x1: "15", x2: "9", y1: "9", y2: "15", key: "f7djnv" }],
  ["line", { x1: "9", x2: "15", y1: "9", y2: "15", key: "1shsy8" }]
];
var Variable = createLucideIcon("variable", __iconNode1624);

// ../node_modules/lucide-react/dist/esm/icons/vault.js
var __iconNode1625 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["circle", { cx: "7.5", cy: "7.5", r: ".5", fill: "currentColor", key: "kqv944" }],
  ["path", { d: "m7.9 7.9 2.7 2.7", key: "hpeyl3" }],
  ["circle", { cx: "16.5", cy: "7.5", r: ".5", fill: "currentColor", key: "w0ekpg" }],
  ["path", { d: "m13.4 10.6 2.7-2.7", key: "264c1n" }],
  ["circle", { cx: "7.5", cy: "16.5", r: ".5", fill: "currentColor", key: "nkw3mc" }],
  ["path", { d: "m7.9 16.1 2.7-2.7", key: "p81g5e" }],
  ["circle", { cx: "16.5", cy: "16.5", r: ".5", fill: "currentColor", key: "fubopw" }],
  ["path", { d: "m13.4 13.4 2.7 2.7", key: "abhel3" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }]
];
var Vault = createLucideIcon("vault", __iconNode1625);

// ../node_modules/lucide-react/dist/esm/icons/vector-square.js
var __iconNode1626 = [
  ["path", { d: "M19.5 7a24 24 0 0 1 0 10", key: "8n60xe" }],
  ["path", { d: "M4.5 7a24 24 0 0 0 0 10", key: "2lmadr" }],
  ["path", { d: "M7 19.5a24 24 0 0 0 10 0", key: "1q94o2" }],
  ["path", { d: "M7 4.5a24 24 0 0 1 10 0", key: "2z8ypa" }],
  ["rect", { x: "17", y: "17", width: "5", height: "5", rx: "1", key: "1ac74s" }],
  ["rect", { x: "17", y: "2", width: "5", height: "5", rx: "1", key: "1e7h5j" }],
  ["rect", { x: "2", y: "17", width: "5", height: "5", rx: "1", key: "1t4eah" }],
  ["rect", { x: "2", y: "2", width: "5", height: "5", rx: "1", key: "940dhs" }]
];
var VectorSquare = createLucideIcon("vector-square", __iconNode1626);

// ../node_modules/lucide-react/dist/esm/icons/vegan.js
var __iconNode1627 = [
  ["path", { d: "M16 8q6 0 6-6-6 0-6 6", key: "qsyyc4" }],
  ["path", { d: "M17.41 3.59a10 10 0 1 0 3 3", key: "41m9h7" }],
  ["path", { d: "M2 2a26.6 26.6 0 0 1 10 20c.9-6.82 1.5-9.5 4-14", key: "qiv7li" }]
];
var Vegan = createLucideIcon("vegan", __iconNode1627);

// ../node_modules/lucide-react/dist/esm/icons/venetian-mask.js
var __iconNode1628 = [
  ["path", { d: "M18 11c-1.5 0-2.5.5-3 2", key: "1fod00" }],
  [
    "path",
    {
      d: "M4 6a2 2 0 0 0-2 2v4a5 5 0 0 0 5 5 8 8 0 0 1 5 2 8 8 0 0 1 5-2 5 5 0 0 0 5-5V8a2 2 0 0 0-2-2h-3a8 8 0 0 0-5 2 8 8 0 0 0-5-2z",
      key: "d70hit"
    }
  ],
  ["path", { d: "M6 11c1.5 0 2.5.5 3 2", key: "136fht" }]
];
var VenetianMask = createLucideIcon("venetian-mask", __iconNode1628);

// ../node_modules/lucide-react/dist/esm/icons/venus-and-mars.js
var __iconNode1629 = [
  ["path", { d: "M10 20h4", key: "ni2waw" }],
  ["path", { d: "M12 16v6", key: "c8a4gj" }],
  ["path", { d: "M17 2h4v4", key: "vhe59" }],
  ["path", { d: "m21 2-5.46 5.46", key: "19kypf" }],
  ["circle", { cx: "12", cy: "11", r: "5", key: "16gxyc" }]
];
var VenusAndMars = createLucideIcon("venus-and-mars", __iconNode1629);

// ../node_modules/lucide-react/dist/esm/icons/venus.js
var __iconNode1630 = [
  ["path", { d: "M12 15v7", key: "t2xh3l" }],
  ["path", { d: "M9 19h6", key: "456am0" }],
  ["circle", { cx: "12", cy: "9", r: "6", key: "1nw4tq" }]
];
var Venus = createLucideIcon("venus", __iconNode1630);

// ../node_modules/lucide-react/dist/esm/icons/vibrate-off.js
var __iconNode1631 = [
  ["path", { d: "m2 8 2 2-2 2 2 2-2 2", key: "sv1b1" }],
  ["path", { d: "m22 8-2 2 2 2-2 2 2 2", key: "101i4y" }],
  ["path", { d: "M8 8v10c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2", key: "1hbad5" }],
  ["path", { d: "M16 10.34V6c0-.55-.45-1-1-1h-4.34", key: "1x5tf0" }],
  ["line", { x1: "2", x2: "22", y1: "2", y2: "22", key: "a6p6uj" }]
];
var VibrateOff = createLucideIcon("vibrate-off", __iconNode1631);

// ../node_modules/lucide-react/dist/esm/icons/vibrate.js
var __iconNode1632 = [
  ["path", { d: "m2 8 2 2-2 2 2 2-2 2", key: "sv1b1" }],
  ["path", { d: "m22 8-2 2 2 2-2 2 2 2", key: "101i4y" }],
  ["rect", { width: "8", height: "14", x: "8", y: "5", rx: "1", key: "1oyrl4" }]
];
var Vibrate = createLucideIcon("vibrate", __iconNode1632);

// ../node_modules/lucide-react/dist/esm/icons/video-off.js
var __iconNode1633 = [
  [
    "path",
    { d: "M10.66 6H14a2 2 0 0 1 2 2v2.5l5.248-3.062A.5.5 0 0 1 22 7.87v8.196", key: "w8jjjt" }
  ],
  ["path", { d: "M16 16a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h2", key: "1xawa7" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var VideoOff = createLucideIcon("video-off", __iconNode1633);

// ../node_modules/lucide-react/dist/esm/icons/video.js
var __iconNode1634 = [
  [
    "path",
    {
      d: "m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5",
      key: "ftymec"
    }
  ],
  ["rect", { x: "2", y: "6", width: "14", height: "12", rx: "2", key: "158x01" }]
];
var Video = createLucideIcon("video", __iconNode1634);

// ../node_modules/lucide-react/dist/esm/icons/view.js
var __iconNode1635 = [
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2", key: "mrq65r" }],
  ["path", { d: "M21 7V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v2", key: "be3xqs" }],
  ["circle", { cx: "12", cy: "12", r: "1", key: "41hilf" }],
  [
    "path",
    {
      d: "M18.944 12.33a1 1 0 0 0 0-.66 7.5 7.5 0 0 0-13.888 0 1 1 0 0 0 0 .66 7.5 7.5 0 0 0 13.888 0",
      key: "11ak4c"
    }
  ]
];
var View = createLucideIcon("view", __iconNode1635);

// ../node_modules/lucide-react/dist/esm/icons/videotape.js
var __iconNode1636 = [
  ["rect", { width: "20", height: "16", x: "2", y: "4", rx: "2", key: "18n3k1" }],
  ["path", { d: "M2 8h20", key: "d11cs7" }],
  ["circle", { cx: "8", cy: "14", r: "2", key: "1k2qr5" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }],
  ["circle", { cx: "16", cy: "14", r: "2", key: "14k7lr" }]
];
var Videotape = createLucideIcon("videotape", __iconNode1636);

// ../node_modules/lucide-react/dist/esm/icons/voicemail.js
var __iconNode1637 = [
  ["circle", { cx: "6", cy: "12", r: "4", key: "1ehtga" }],
  ["circle", { cx: "18", cy: "12", r: "4", key: "4vafl8" }],
  ["line", { x1: "6", x2: "18", y1: "16", y2: "16", key: "pmt8us" }]
];
var Voicemail = createLucideIcon("voicemail", __iconNode1637);

// ../node_modules/lucide-react/dist/esm/icons/volleyball.js
var __iconNode1638 = [
  ["path", { d: "M11.1 7.1a16.55 16.55 0 0 1 10.9 4", key: "2880wi" }],
  ["path", { d: "M12 12a12.6 12.6 0 0 1-8.7 5", key: "113sja" }],
  ["path", { d: "M16.8 13.6a16.55 16.55 0 0 1-9 7.5", key: "1qmsgl" }],
  ["path", { d: "M20.7 17a12.8 12.8 0 0 0-8.7-5 13.3 13.3 0 0 1 0-10", key: "1bmeqp" }],
  ["path", { d: "M6.3 3.8a16.55 16.55 0 0 0 1.9 11.5", key: "iekzv9" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
];
var Volleyball = createLucideIcon("volleyball", __iconNode1638);

// ../node_modules/lucide-react/dist/esm/icons/volume-1.js
var __iconNode1639 = [
  [
    "path",
    {
      d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
      key: "uqj9uw"
    }
  ],
  ["path", { d: "M16 9a5 5 0 0 1 0 6", key: "1q6k2b" }]
];
var Volume1 = createLucideIcon("volume-1", __iconNode1639);

// ../node_modules/lucide-react/dist/esm/icons/volume-2.js
var __iconNode1640 = [
  [
    "path",
    {
      d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
      key: "uqj9uw"
    }
  ],
  ["path", { d: "M16 9a5 5 0 0 1 0 6", key: "1q6k2b" }],
  ["path", { d: "M19.364 18.364a9 9 0 0 0 0-12.728", key: "ijwkga" }]
];
var Volume2 = createLucideIcon("volume-2", __iconNode1640);

// ../node_modules/lucide-react/dist/esm/icons/volume-off.js
var __iconNode1641 = [
  ["path", { d: "M16 9a5 5 0 0 1 .95 2.293", key: "1fgyg8" }],
  ["path", { d: "M19.364 5.636a9 9 0 0 1 1.889 9.96", key: "l3zxae" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    {
      d: "m7 7-.587.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298V11",
      key: "1gbwow"
    }
  ],
  ["path", { d: "M9.828 4.172A.686.686 0 0 1 11 4.657v.686", key: "s2je0y" }]
];
var VolumeOff = createLucideIcon("volume-off", __iconNode1641);

// ../node_modules/lucide-react/dist/esm/icons/volume-x.js
var __iconNode1642 = [
  [
    "path",
    {
      d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
      key: "uqj9uw"
    }
  ],
  ["line", { x1: "22", x2: "16", y1: "9", y2: "15", key: "1ewh16" }],
  ["line", { x1: "16", x2: "22", y1: "9", y2: "15", key: "5ykzw1" }]
];
var VolumeX = createLucideIcon("volume-x", __iconNode1642);

// ../node_modules/lucide-react/dist/esm/icons/volume.js
var __iconNode1643 = [
  [
    "path",
    {
      d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
      key: "uqj9uw"
    }
  ]
];
var Volume = createLucideIcon("volume", __iconNode1643);

// ../node_modules/lucide-react/dist/esm/icons/vote.js
var __iconNode1644 = [
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }],
  ["path", { d: "M5 7c0-1.1.9-2 2-2h10a2 2 0 0 1 2 2v12H5V7Z", key: "1ezoue" }],
  ["path", { d: "M22 19H2", key: "nuriw5" }]
];
var Vote = createLucideIcon("vote", __iconNode1644);

// ../node_modules/lucide-react/dist/esm/icons/wallet-cards.js
var __iconNode1645 = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 9a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2", key: "4125el" }],
  [
    "path",
    {
      d: "M3 11h3c.8 0 1.6.3 2.1.9l1.1.9c1.6 1.6 4.1 1.6 5.7 0l1.1-.9c.5-.5 1.3-.9 2.1-.9H21",
      key: "1dpki6"
    }
  ]
];
var WalletCards = createLucideIcon("wallet-cards", __iconNode1645);

// ../node_modules/lucide-react/dist/esm/icons/wallet-minimal.js
var __iconNode1646 = [
  ["path", { d: "M17 14h.01", key: "7oqj8z" }],
  [
    "path",
    {
      d: "M7 7h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14",
      key: "u1rqew"
    }
  ]
];
var WalletMinimal = createLucideIcon("wallet-minimal", __iconNode1646);

// ../node_modules/lucide-react/dist/esm/icons/wallet.js
var __iconNode1647 = [
  [
    "path",
    {
      d: "M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1",
      key: "18etb6"
    }
  ],
  ["path", { d: "M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4", key: "xoc0q4" }]
];
var Wallet = createLucideIcon("wallet", __iconNode1647);

// ../node_modules/lucide-react/dist/esm/icons/wand-sparkles.js
var __iconNode1648 = [
  [
    "path",
    {
      d: "m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72",
      key: "ul74o6"
    }
  ],
  ["path", { d: "m14 7 3 3", key: "1r5n42" }],
  ["path", { d: "M5 6v4", key: "ilb8ba" }],
  ["path", { d: "M19 14v4", key: "blhpug" }],
  ["path", { d: "M10 2v2", key: "7u0qdc" }],
  ["path", { d: "M7 8H3", key: "zfb6yr" }],
  ["path", { d: "M21 16h-4", key: "1cnmox" }],
  ["path", { d: "M11 3H9", key: "1obp7u" }]
];
var WandSparkles = createLucideIcon("wand-sparkles", __iconNode1648);

// ../node_modules/lucide-react/dist/esm/icons/wallpaper.js
var __iconNode1649 = [
  ["path", { d: "M12 17v4", key: "1riwvh" }],
  ["path", { d: "M8 21h8", key: "1ev6f3" }],
  ["path", { d: "m9 17 6.1-6.1a2 2 0 0 1 2.81.01L22 15", key: "1sl52q" }],
  ["circle", { cx: "8", cy: "9", r: "2", key: "gjzl9d" }],
  ["rect", { x: "2", y: "3", width: "20", height: "14", rx: "2", key: "x3v2xh" }]
];
var Wallpaper = createLucideIcon("wallpaper", __iconNode1649);

// ../node_modules/lucide-react/dist/esm/icons/wand.js
var __iconNode1650 = [
  ["path", { d: "M15 4V2", key: "z1p9b7" }],
  ["path", { d: "M15 16v-2", key: "px0unx" }],
  ["path", { d: "M8 9h2", key: "1g203m" }],
  ["path", { d: "M20 9h2", key: "19tzq7" }],
  ["path", { d: "M17.8 11.8 19 13", key: "yihg8r" }],
  ["path", { d: "M15 9h.01", key: "x1ddxp" }],
  ["path", { d: "M17.8 6.2 19 5", key: "fd4us0" }],
  ["path", { d: "m3 21 9-9", key: "1jfql5" }],
  ["path", { d: "M12.2 6.2 11 5", key: "i3da3b" }]
];
var Wand = createLucideIcon("wand", __iconNode1650);

// ../node_modules/lucide-react/dist/esm/icons/warehouse.js
var __iconNode1651 = [
  ["path", { d: "M18 21V10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1v11", key: "pb2vm6" }],
  [
    "path",
    {
      d: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 1.132-1.803l7.95-3.974a2 2 0 0 1 1.837 0l7.948 3.974A2 2 0 0 1 22 8z",
      key: "doq5xv"
    }
  ],
  ["path", { d: "M6 13h12", key: "yf64js" }],
  ["path", { d: "M6 17h12", key: "1jwigz" }]
];
var Warehouse = createLucideIcon("warehouse", __iconNode1651);

// ../node_modules/lucide-react/dist/esm/icons/watch.js
var __iconNode1652 = [
  ["path", { d: "M12 10v2.2l1.6 1", key: "n3r21l" }],
  [
    "path",
    { d: "m16.13 7.66-.81-4.05a2 2 0 0 0-2-1.61h-2.68a2 2 0 0 0-2 1.61l-.78 4.05", key: "18k57s" }
  ],
  ["path", { d: "m7.88 16.36.8 4a2 2 0 0 0 2 1.61h2.72a2 2 0 0 0 2-1.61l.81-4.05", key: "16ny36" }],
  ["circle", { cx: "12", cy: "12", r: "6", key: "1vlfrh" }]
];
var Watch = createLucideIcon("watch", __iconNode1652);

// ../node_modules/lucide-react/dist/esm/icons/washing-machine.js
var __iconNode1653 = [
  ["path", { d: "M3 6h3", key: "155dbl" }],
  ["path", { d: "M17 6h.01", key: "e2y6kg" }],
  ["rect", { width: "18", height: "20", x: "3", y: "2", rx: "2", key: "od3kk9" }],
  ["circle", { cx: "12", cy: "13", r: "5", key: "nlbqau" }],
  ["path", { d: "M12 18a2.5 2.5 0 0 0 0-5 2.5 2.5 0 0 1 0-5", key: "17lach" }]
];
var WashingMachine = createLucideIcon("washing-machine", __iconNode1653);

// ../node_modules/lucide-react/dist/esm/icons/waves-arrow-down.js
var __iconNode1654 = [
  ["path", { d: "M12 10L12 2", key: "jvb0aw" }],
  ["path", { d: "M16 6L12 10L8 6", key: "9j6vje" }],
  [
    "path",
    {
      d: "M2 15C2.6 15.5 3.2 16 4.5 16C7 16 7 14 9.5 14C12.1 14 11.9 16 14.5 16C17 16 17 14 19.5 14C20.8 14 21.4 14.5 22 15",
      key: "s2zepw"
    }
  ],
  [
    "path",
    {
      d: "M2 21C2.6 21.5 3.2 22 4.5 22C7 22 7 20 9.5 20C12.1 20 11.9 22 14.5 22C17 22 17 20 19.5 20C20.8 20 21.4 20.5 22 21",
      key: "u68omc"
    }
  ]
];
var WavesArrowDown = createLucideIcon("waves-arrow-down", __iconNode1654);

// ../node_modules/lucide-react/dist/esm/icons/waves-arrow-up.js
var __iconNode1655 = [
  ["path", { d: "M12 2v8", key: "1q4o3n" }],
  [
    "path",
    {
      d: "M2 15c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "1p9f19"
    }
  ],
  [
    "path",
    {
      d: "M2 21c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "vbxynw"
    }
  ],
  ["path", { d: "m8 6 4-4 4 4", key: "ybng9g" }]
];
var WavesArrowUp = createLucideIcon("waves-arrow-up", __iconNode1655);

// ../node_modules/lucide-react/dist/esm/icons/waves-ladder.js
var __iconNode1656 = [
  ["path", { d: "M19 5a2 2 0 0 0-2 2v11", key: "s41o68" }],
  [
    "path",
    {
      d: "M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "rd2r6e"
    }
  ],
  ["path", { d: "M7 13h10", key: "1rwob1" }],
  ["path", { d: "M7 9h10", key: "12czzb" }],
  ["path", { d: "M9 5a2 2 0 0 0-2 2v11", key: "x0q4gh" }]
];
var WavesLadder = createLucideIcon("waves-ladder", __iconNode1656);

// ../node_modules/lucide-react/dist/esm/icons/waves.js
var __iconNode1657 = [
  [
    "path",
    {
      d: "M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "knzxuh"
    }
  ],
  [
    "path",
    {
      d: "M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "2jd2cc"
    }
  ],
  [
    "path",
    {
      d: "M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "rd2r6e"
    }
  ]
];
var Waves = createLucideIcon("waves", __iconNode1657);

// ../node_modules/lucide-react/dist/esm/icons/waypoints.js
var __iconNode1658 = [
  ["path", { d: "m10.586 5.414-5.172 5.172", key: "4mc350" }],
  ["path", { d: "m18.586 13.414-5.172 5.172", key: "8c96vv" }],
  ["path", { d: "M6 12h12", key: "8npq4p" }],
  ["circle", { cx: "12", cy: "20", r: "2", key: "144qzu" }],
  ["circle", { cx: "12", cy: "4", r: "2", key: "muu5ef" }],
  ["circle", { cx: "20", cy: "12", r: "2", key: "1xzzfp" }],
  ["circle", { cx: "4", cy: "12", r: "2", key: "1hvhnz" }]
];
var Waypoints = createLucideIcon("waypoints", __iconNode1658);

// ../node_modules/lucide-react/dist/esm/icons/webcam.js
var __iconNode1659 = [
  ["circle", { cx: "12", cy: "10", r: "8", key: "1gshiw" }],
  ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }],
  ["path", { d: "M7 22h10", key: "10w4w3" }],
  ["path", { d: "M12 22v-4", key: "1utk9m" }]
];
var Webcam = createLucideIcon("webcam", __iconNode1659);

// ../node_modules/lucide-react/dist/esm/icons/webhook-off.js
var __iconNode1660 = [
  ["path", { d: "M17 17h-5c-1.09-.02-1.94.92-2.5 1.9A3 3 0 1 1 2.57 15", key: "1tvl6x" }],
  ["path", { d: "M9 3.4a4 4 0 0 1 6.52.66", key: "q04jfq" }],
  ["path", { d: "m6 17 3.1-5.8a2.5 2.5 0 0 0 .057-2.05", key: "azowf0" }],
  ["path", { d: "M20.3 20.3a4 4 0 0 1-2.3.7", key: "5joiws" }],
  ["path", { d: "M18.6 13a4 4 0 0 1 3.357 3.414", key: "cangb8" }],
  ["path", { d: "m12 6 .6 1", key: "tpjl1n" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var WebhookOff = createLucideIcon("webhook-off", __iconNode1660);

// ../node_modules/lucide-react/dist/esm/icons/webhook.js
var __iconNode1661 = [
  [
    "path",
    {
      d: "M18 16.98h-5.99c-1.1 0-1.95.94-2.48 1.9A4 4 0 0 1 2 17c.01-.7.2-1.4.57-2",
      key: "q3hayz"
    }
  ],
  ["path", { d: "m6 17 3.13-5.78c.53-.97.1-2.18-.5-3.1a4 4 0 1 1 6.89-4.06", key: "1go1hn" }],
  ["path", { d: "m12 6 3.13 5.73C15.66 12.7 16.9 13 18 13a4 4 0 0 1 0 8", key: "qlwsc0" }]
];
var Webhook = createLucideIcon("webhook", __iconNode1661);

// ../node_modules/lucide-react/dist/esm/icons/weight-tilde.js
var __iconNode1662 = [
  [
    "path",
    {
      d: "M6.5 8a2 2 0 0 0-1.906 1.46L2.1 18.5A2 2 0 0 0 4 21h16a2 2 0 0 0 1.925-2.54L19.4 9.5A2 2 0 0 0 17.48 8z",
      key: "1wl739"
    }
  ],
  ["path", { d: "M7.999 15a2.5 2.5 0 0 1 4 0 2.5 2.5 0 0 0 4 0", key: "1egezo" }],
  ["circle", { cx: "12", cy: "5", r: "3", key: "rqqgnr" }]
];
var WeightTilde = createLucideIcon("weight-tilde", __iconNode1662);

// ../node_modules/lucide-react/dist/esm/icons/weight.js
var __iconNode1663 = [
  ["circle", { cx: "12", cy: "5", r: "3", key: "rqqgnr" }],
  [
    "path",
    {
      d: "M6.5 8a2 2 0 0 0-1.905 1.46L2.1 18.5A2 2 0 0 0 4 21h16a2 2 0 0 0 1.925-2.54L19.4 9.5A2 2 0 0 0 17.48 8Z",
      key: "56o5sh"
    }
  ]
];
var Weight = createLucideIcon("weight", __iconNode1663);

// ../node_modules/lucide-react/dist/esm/icons/wheat-off.js
var __iconNode1664 = [
  ["path", { d: "m2 22 10-10", key: "28ilpk" }],
  ["path", { d: "m16 8-1.17 1.17", key: "1qqm82" }],
  [
    "path",
    {
      d: "M3.47 12.53 5 11l1.53 1.53a3.5 3.5 0 0 1 0 4.94L5 19l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z",
      key: "1rdhi6"
    }
  ],
  [
    "path",
    { d: "m8 8-.53.53a3.5 3.5 0 0 0 0 4.94L9 15l1.53-1.53c.55-.55.88-1.25.98-1.97", key: "4wz8re" }
  ],
  [
    "path",
    { d: "M10.91 5.26c.15-.26.34-.51.56-.73L13 3l1.53 1.53a3.5 3.5 0 0 1 .28 4.62", key: "rves66" }
  ],
  ["path", { d: "M20 2h2v2a4 4 0 0 1-4 4h-2V6a4 4 0 0 1 4-4Z", key: "19rau1" }],
  [
    "path",
    {
      d: "M11.47 17.47 13 19l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L5 19l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z",
      key: "tc8ph9"
    }
  ],
  [
    "path",
    {
      d: "m16 16-.53.53a3.5 3.5 0 0 1-4.94 0L9 15l1.53-1.53a3.49 3.49 0 0 1 1.97-.98",
      key: "ak46r"
    }
  ],
  [
    "path",
    {
      d: "M18.74 13.09c.26-.15.51-.34.73-.56L21 11l-1.53-1.53a3.5 3.5 0 0 0-4.62-.28",
      key: "1tw520"
    }
  ],
  ["line", { x1: "2", x2: "22", y1: "2", y2: "22", key: "a6p6uj" }]
];
var WheatOff = createLucideIcon("wheat-off", __iconNode1664);

// ../node_modules/lucide-react/dist/esm/icons/wheat.js
var __iconNode1665 = [
  ["path", { d: "M2 22 16 8", key: "60hf96" }],
  [
    "path",
    {
      d: "M3.47 12.53 5 11l1.53 1.53a3.5 3.5 0 0 1 0 4.94L5 19l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z",
      key: "1rdhi6"
    }
  ],
  [
    "path",
    {
      d: "M7.47 8.53 9 7l1.53 1.53a3.5 3.5 0 0 1 0 4.94L9 15l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z",
      key: "1sdzmb"
    }
  ],
  [
    "path",
    {
      d: "M11.47 4.53 13 3l1.53 1.53a3.5 3.5 0 0 1 0 4.94L13 11l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z",
      key: "eoatbi"
    }
  ],
  ["path", { d: "M20 2h2v2a4 4 0 0 1-4 4h-2V6a4 4 0 0 1 4-4Z", key: "19rau1" }],
  [
    "path",
    {
      d: "M11.47 17.47 13 19l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L5 19l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z",
      key: "tc8ph9"
    }
  ],
  [
    "path",
    {
      d: "M15.47 13.47 17 15l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L9 15l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z",
      key: "2m8kc5"
    }
  ],
  [
    "path",
    {
      d: "M19.47 9.47 21 11l-1.53 1.53a3.5 3.5 0 0 1-4.94 0L13 11l1.53-1.53a3.5 3.5 0 0 1 4.94 0Z",
      key: "vex3ng"
    }
  ]
];
var Wheat = createLucideIcon("wheat", __iconNode1665);

// ../node_modules/lucide-react/dist/esm/icons/whole-word.js
var __iconNode1666 = [
  ["circle", { cx: "7", cy: "12", r: "3", key: "12clwm" }],
  ["path", { d: "M10 9v6", key: "17i7lo" }],
  ["circle", { cx: "17", cy: "12", r: "3", key: "gl7c2s" }],
  ["path", { d: "M14 7v8", key: "dl84cr" }],
  ["path", { d: "M22 17v1c0 .5-.5 1-1 1H3c-.5 0-1-.5-1-1v-1", key: "lt2kga" }]
];
var WholeWord = createLucideIcon("whole-word", __iconNode1666);

// ../node_modules/lucide-react/dist/esm/icons/wifi-cog.js
var __iconNode1667 = [
  ["path", { d: "m14.305 19.53.923-.382", key: "3m78fa" }],
  ["path", { d: "m15.228 16.852-.923-.383", key: "npixar" }],
  ["path", { d: "m16.852 15.228-.383-.923", key: "5xggr7" }],
  ["path", { d: "m16.852 20.772-.383.924", key: "dpfhf9" }],
  ["path", { d: "m19.148 15.228.383-.923", key: "1reyyz" }],
  ["path", { d: "m19.53 21.696-.382-.924", key: "1goivc" }],
  ["path", { d: "M2 7.82a15 15 0 0 1 20 0", key: "1ovjuk" }],
  ["path", { d: "m20.772 16.852.924-.383", key: "htqkph" }],
  ["path", { d: "m20.772 19.148.924.383", key: "9w9pjp" }],
  ["path", { d: "M5 11.858a10 10 0 0 1 11.5-1.785", key: "3sn16i" }],
  ["path", { d: "M8.5 15.429a5 5 0 0 1 2.413-1.31", key: "1pxovh" }],
  ["circle", { cx: "18", cy: "18", r: "3", key: "1xkwt0" }]
];
var WifiCog = createLucideIcon("wifi-cog", __iconNode1667);

// ../node_modules/lucide-react/dist/esm/icons/wifi-high.js
var __iconNode1668 = [
  ["path", { d: "M12 20h.01", key: "zekei9" }],
  ["path", { d: "M5 12.859a10 10 0 0 1 14 0", key: "1x1e6c" }],
  ["path", { d: "M8.5 16.429a5 5 0 0 1 7 0", key: "1bycff" }]
];
var WifiHigh = createLucideIcon("wifi-high", __iconNode1668);

// ../node_modules/lucide-react/dist/esm/icons/wifi-low.js
var __iconNode1669 = [
  ["path", { d: "M12 20h.01", key: "zekei9" }],
  ["path", { d: "M8.5 16.429a5 5 0 0 1 7 0", key: "1bycff" }]
];
var WifiLow = createLucideIcon("wifi-low", __iconNode1669);

// ../node_modules/lucide-react/dist/esm/icons/wifi-off.js
var __iconNode1670 = [
  ["path", { d: "M12 20h.01", key: "zekei9" }],
  ["path", { d: "M8.5 16.429a5 5 0 0 1 7 0", key: "1bycff" }],
  ["path", { d: "M5 12.859a10 10 0 0 1 5.17-2.69", key: "1dl1wf" }],
  ["path", { d: "M19 12.859a10 10 0 0 0-2.007-1.523", key: "4k23kn" }],
  ["path", { d: "M2 8.82a15 15 0 0 1 4.177-2.643", key: "1grhjp" }],
  ["path", { d: "M22 8.82a15 15 0 0 0-11.288-3.764", key: "z3jwby" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var WifiOff = createLucideIcon("wifi-off", __iconNode1670);

// ../node_modules/lucide-react/dist/esm/icons/wifi-pen.js
var __iconNode1671 = [
  ["path", { d: "M2 8.82a15 15 0 0 1 20 0", key: "dnpr2z" }],
  [
    "path",
    {
      d: "M21.378 16.626a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z",
      key: "1817ys"
    }
  ],
  ["path", { d: "M5 12.859a10 10 0 0 1 10.5-2.222", key: "rpb7oy" }],
  ["path", { d: "M8.5 16.429a5 5 0 0 1 3-1.406", key: "r8bmzl" }]
];
var WifiPen = createLucideIcon("wifi-pen", __iconNode1671);

// ../node_modules/lucide-react/dist/esm/icons/wifi-sync.js
var __iconNode1672 = [
  ["path", { d: "M11.965 10.105v4L13.5 12.5a5 5 0 0 1 8 1.5", key: "1immaq" }],
  ["path", { d: "M11.965 14.105h4", key: "uejny8" }],
  ["path", { d: "M17.965 18.105h4L20.43 19.71a5 5 0 0 1-8-1.5", key: "1i3a7e" }],
  ["path", { d: "M2 8.82a15 15 0 0 1 20 0", key: "dnpr2z" }],
  ["path", { d: "M21.965 22.105v-4", key: "1ku6vx" }],
  ["path", { d: "M5 12.86a10 10 0 0 1 3-2.032", key: "pemdtu" }],
  ["path", { d: "M8.5 16.429h.01", key: "2bm739" }]
];
var WifiSync = createLucideIcon("wifi-sync", __iconNode1672);

// ../node_modules/lucide-react/dist/esm/icons/wifi-zero.js
var __iconNode1673 = [["path", { d: "M12 20h.01", key: "zekei9" }]];
var WifiZero = createLucideIcon("wifi-zero", __iconNode1673);

// ../node_modules/lucide-react/dist/esm/icons/wifi.js
var __iconNode1674 = [
  ["path", { d: "M12 20h.01", key: "zekei9" }],
  ["path", { d: "M2 8.82a15 15 0 0 1 20 0", key: "dnpr2z" }],
  ["path", { d: "M5 12.859a10 10 0 0 1 14 0", key: "1x1e6c" }],
  ["path", { d: "M8.5 16.429a5 5 0 0 1 7 0", key: "1bycff" }]
];
var Wifi = createLucideIcon("wifi", __iconNode1674);

// ../node_modules/lucide-react/dist/esm/icons/wind-arrow-down.js
var __iconNode1675 = [
  ["path", { d: "M10 2v8", key: "d4bbey" }],
  ["path", { d: "M12.8 21.6A2 2 0 1 0 14 18H2", key: "19kp1d" }],
  ["path", { d: "M17.5 10a2.5 2.5 0 1 1 2 4H2", key: "19kpjc" }],
  ["path", { d: "m6 6 4 4 4-4", key: "k13n16" }]
];
var WindArrowDown = createLucideIcon("wind-arrow-down", __iconNode1675);

// ../node_modules/lucide-react/dist/esm/icons/wind.js
var __iconNode1676 = [
  ["path", { d: "M12.8 19.6A2 2 0 1 0 14 16H2", key: "148xed" }],
  ["path", { d: "M17.5 8a2.5 2.5 0 1 1 2 4H2", key: "1u4tom" }],
  ["path", { d: "M9.8 4.4A2 2 0 1 1 11 8H2", key: "75valh" }]
];
var Wind = createLucideIcon("wind", __iconNode1676);

// ../node_modules/lucide-react/dist/esm/icons/wine-off.js
var __iconNode1677 = [
  ["path", { d: "M8 22h8", key: "rmew8v" }],
  ["path", { d: "M7 10h3m7 0h-1.343", key: "v48bem" }],
  ["path", { d: "M12 15v7", key: "t2xh3l" }],
  [
    "path",
    {
      d: "M7.307 7.307A12.33 12.33 0 0 0 7 10a5 5 0 0 0 7.391 4.391M8.638 2.981C8.75 2.668 8.872 2.34 9 2h6c1.5 4 2 6 2 8 0 .407-.05.809-.145 1.198",
      key: "1ymjlu"
    }
  ],
  ["line", { x1: "2", x2: "22", y1: "2", y2: "22", key: "a6p6uj" }]
];
var WineOff = createLucideIcon("wine-off", __iconNode1677);

// ../node_modules/lucide-react/dist/esm/icons/wine.js
var __iconNode1678 = [
  ["path", { d: "M8 22h8", key: "rmew8v" }],
  ["path", { d: "M7 10h10", key: "1101jm" }],
  ["path", { d: "M12 15v7", key: "t2xh3l" }],
  [
    "path",
    { d: "M12 15a5 5 0 0 0 5-5c0-2-.5-4-2-8H9c-1.5 4-2 6-2 8a5 5 0 0 0 5 5Z", key: "10ffi3" }
  ]
];
var Wine = createLucideIcon("wine", __iconNode1678);

// ../node_modules/lucide-react/dist/esm/icons/workflow.js
var __iconNode1679 = [
  ["rect", { width: "8", height: "8", x: "3", y: "3", rx: "2", key: "by2w9f" }],
  ["path", { d: "M7 11v4a2 2 0 0 0 2 2h4", key: "xkn7yn" }],
  ["rect", { width: "8", height: "8", x: "13", y: "13", rx: "2", key: "1cgmvn" }]
];
var Workflow = createLucideIcon("workflow", __iconNode1679);

// ../node_modules/lucide-react/dist/esm/icons/worm.js
var __iconNode1680 = [
  ["path", { d: "m19 12-1.5 3", key: "9bcu4o" }],
  ["path", { d: "M19.63 18.81 22 20", key: "121v98" }],
  [
    "path",
    {
      d: "M6.47 8.23a1.68 1.68 0 0 1 2.44 1.93l-.64 2.08a6.76 6.76 0 0 0 10.16 7.67l.42-.27a1 1 0 1 0-2.73-4.21l-.42.27a1.76 1.76 0 0 1-2.63-1.99l.64-2.08A6.66 6.66 0 0 0 3.94 3.9l-.7.4a1 1 0 1 0 2.55 4.34z",
      key: "1tij6q"
    }
  ]
];
var Worm = createLucideIcon("worm", __iconNode1680);

// ../node_modules/lucide-react/dist/esm/icons/wrench.js
var __iconNode1681 = [
  [
    "path",
    {
      d: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z",
      key: "1ngwbx"
    }
  ]
];
var Wrench = createLucideIcon("wrench", __iconNode1681);

// ../node_modules/lucide-react/dist/esm/icons/x-line-top.js
var __iconNode1682 = [
  ["path", { d: "M18 4H6", key: "1hsngl" }],
  ["path", { d: "M18 8 6 20", key: "xspwia" }],
  ["path", { d: "m6 8 12 12", key: "qb1veh" }]
];
var XLineTop = createLucideIcon("x-line-top", __iconNode1682);

// ../node_modules/lucide-react/dist/esm/icons/x.js
var __iconNode1683 = [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
];
var X = createLucideIcon("x", __iconNode1683);

// ../node_modules/lucide-react/dist/esm/icons/youtube.js
var __iconNode1684 = [
  [
    "path",
    {
      d: "M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17",
      key: "1q2vi4"
    }
  ],
  ["path", { d: "m10 15 5-3-5-3z", key: "1jp15x" }]
];
var Youtube = createLucideIcon("youtube", __iconNode1684);

// ../node_modules/lucide-react/dist/esm/icons/zap-off.js
var __iconNode1685 = [
  ["path", { d: "M10.513 4.856 13.12 2.17a.5.5 0 0 1 .86.46l-1.377 4.317", key: "193nxd" }],
  ["path", { d: "M15.656 10H20a1 1 0 0 1 .78 1.63l-1.72 1.773", key: "27a7lr" }],
  [
    "path",
    {
      d: "M16.273 16.273 10.88 21.83a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14H4a1 1 0 0 1-.78-1.63l4.507-4.643",
      key: "1e0qe9"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
];
var ZapOff = createLucideIcon("zap-off", __iconNode1685);

// ../node_modules/lucide-react/dist/esm/icons/zap.js
var __iconNode1686 = [
  [
    "path",
    {
      d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
      key: "1xq2db"
    }
  ]
];
var Zap = createLucideIcon("zap", __iconNode1686);

// ../node_modules/lucide-react/dist/esm/icons/zoom-in.js
var __iconNode1687 = [
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["line", { x1: "21", x2: "16.65", y1: "21", y2: "16.65", key: "13gj7c" }],
  ["line", { x1: "11", x2: "11", y1: "8", y2: "14", key: "1vmskp" }],
  ["line", { x1: "8", x2: "14", y1: "11", y2: "11", key: "durymu" }]
];
var ZoomIn = createLucideIcon("zoom-in", __iconNode1687);

// ../node_modules/lucide-react/dist/esm/icons/zoom-out.js
var __iconNode1688 = [
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["line", { x1: "21", x2: "16.65", y1: "21", y2: "16.65", key: "13gj7c" }],
  ["line", { x1: "8", x2: "14", y1: "11", y2: "11", key: "durymu" }]
];
var ZoomOut = createLucideIcon("zoom-out", __iconNode1688);
export {
  AArrowDown,
  AArrowDown as AArrowDownIcon,
  AArrowUp,
  AArrowUp as AArrowUpIcon,
  ALargeSmall,
  ALargeSmall as ALargeSmallIcon,
  Accessibility,
  Accessibility as AccessibilityIcon,
  Activity,
  Activity as ActivityIcon,
  SquareActivity as ActivitySquare,
  SquareActivity as ActivitySquareIcon,
  AirVent,
  AirVent as AirVentIcon,
  Airplay,
  Airplay as AirplayIcon,
  AlarmClockCheck as AlarmCheck,
  AlarmClockCheck as AlarmCheckIcon,
  AlarmClock,
  AlarmClockCheck,
  AlarmClockCheck as AlarmClockCheckIcon,
  AlarmClock as AlarmClockIcon,
  AlarmClockMinus,
  AlarmClockMinus as AlarmClockMinusIcon,
  AlarmClockOff,
  AlarmClockOff as AlarmClockOffIcon,
  AlarmClockPlus,
  AlarmClockPlus as AlarmClockPlusIcon,
  AlarmClockMinus as AlarmMinus,
  AlarmClockMinus as AlarmMinusIcon,
  AlarmClockPlus as AlarmPlus,
  AlarmClockPlus as AlarmPlusIcon,
  AlarmSmoke,
  AlarmSmoke as AlarmSmokeIcon,
  Album,
  Album as AlbumIcon,
  CircleAlert as AlertCircle,
  CircleAlert as AlertCircleIcon,
  OctagonAlert as AlertOctagon,
  OctagonAlert as AlertOctagonIcon,
  TriangleAlert as AlertTriangle,
  TriangleAlert as AlertTriangleIcon,
  TextAlignCenter as AlignCenter,
  AlignCenterHorizontal,
  AlignCenterHorizontal as AlignCenterHorizontalIcon,
  TextAlignCenter as AlignCenterIcon,
  AlignCenterVertical,
  AlignCenterVertical as AlignCenterVerticalIcon,
  AlignEndHorizontal,
  AlignEndHorizontal as AlignEndHorizontalIcon,
  AlignEndVertical,
  AlignEndVertical as AlignEndVerticalIcon,
  AlignHorizontalDistributeCenter,
  AlignHorizontalDistributeCenter as AlignHorizontalDistributeCenterIcon,
  AlignHorizontalDistributeEnd,
  AlignHorizontalDistributeEnd as AlignHorizontalDistributeEndIcon,
  AlignHorizontalDistributeStart,
  AlignHorizontalDistributeStart as AlignHorizontalDistributeStartIcon,
  AlignHorizontalJustifyCenter,
  AlignHorizontalJustifyCenter as AlignHorizontalJustifyCenterIcon,
  AlignHorizontalJustifyEnd,
  AlignHorizontalJustifyEnd as AlignHorizontalJustifyEndIcon,
  AlignHorizontalJustifyStart,
  AlignHorizontalJustifyStart as AlignHorizontalJustifyStartIcon,
  AlignHorizontalSpaceAround,
  AlignHorizontalSpaceAround as AlignHorizontalSpaceAroundIcon,
  AlignHorizontalSpaceBetween,
  AlignHorizontalSpaceBetween as AlignHorizontalSpaceBetweenIcon,
  TextAlignJustify as AlignJustify,
  TextAlignJustify as AlignJustifyIcon,
  TextAlignStart as AlignLeft,
  TextAlignStart as AlignLeftIcon,
  TextAlignEnd as AlignRight,
  TextAlignEnd as AlignRightIcon,
  AlignStartHorizontal,
  AlignStartHorizontal as AlignStartHorizontalIcon,
  AlignStartVertical,
  AlignStartVertical as AlignStartVerticalIcon,
  AlignVerticalDistributeCenter,
  AlignVerticalDistributeCenter as AlignVerticalDistributeCenterIcon,
  AlignVerticalDistributeEnd,
  AlignVerticalDistributeEnd as AlignVerticalDistributeEndIcon,
  AlignVerticalDistributeStart,
  AlignVerticalDistributeStart as AlignVerticalDistributeStartIcon,
  AlignVerticalJustifyCenter,
  AlignVerticalJustifyCenter as AlignVerticalJustifyCenterIcon,
  AlignVerticalJustifyEnd,
  AlignVerticalJustifyEnd as AlignVerticalJustifyEndIcon,
  AlignVerticalJustifyStart,
  AlignVerticalJustifyStart as AlignVerticalJustifyStartIcon,
  AlignVerticalSpaceAround,
  AlignVerticalSpaceAround as AlignVerticalSpaceAroundIcon,
  AlignVerticalSpaceBetween,
  AlignVerticalSpaceBetween as AlignVerticalSpaceBetweenIcon,
  Ambulance,
  Ambulance as AmbulanceIcon,
  Ampersand,
  Ampersand as AmpersandIcon,
  Ampersands,
  Ampersands as AmpersandsIcon,
  Amphora,
  Amphora as AmphoraIcon,
  Anchor,
  Anchor as AnchorIcon,
  Angry,
  Angry as AngryIcon,
  Annoyed,
  Annoyed as AnnoyedIcon,
  Antenna,
  Antenna as AntennaIcon,
  Anvil,
  Anvil as AnvilIcon,
  Aperture,
  Aperture as ApertureIcon,
  AppWindow,
  AppWindow as AppWindowIcon,
  AppWindowMac,
  AppWindowMac as AppWindowMacIcon,
  Apple,
  Apple as AppleIcon,
  Archive,
  Archive as ArchiveIcon,
  ArchiveRestore,
  ArchiveRestore as ArchiveRestoreIcon,
  ArchiveX,
  ArchiveX as ArchiveXIcon,
  ChartArea as AreaChart,
  ChartArea as AreaChartIcon,
  Armchair,
  Armchair as ArmchairIcon,
  ArrowBigDown,
  ArrowBigDownDash,
  ArrowBigDownDash as ArrowBigDownDashIcon,
  ArrowBigDown as ArrowBigDownIcon,
  ArrowBigLeft,
  ArrowBigLeftDash,
  ArrowBigLeftDash as ArrowBigLeftDashIcon,
  ArrowBigLeft as ArrowBigLeftIcon,
  ArrowBigRight,
  ArrowBigRightDash,
  ArrowBigRightDash as ArrowBigRightDashIcon,
  ArrowBigRight as ArrowBigRightIcon,
  ArrowBigUp,
  ArrowBigUpDash,
  ArrowBigUpDash as ArrowBigUpDashIcon,
  ArrowBigUp as ArrowBigUpIcon,
  ArrowDown,
  ArrowDown01,
  ArrowDown01 as ArrowDown01Icon,
  ArrowDown10,
  ArrowDown10 as ArrowDown10Icon,
  ArrowDownAZ,
  ArrowDownAZ as ArrowDownAZIcon,
  ArrowDownAZ as ArrowDownAz,
  ArrowDownAZ as ArrowDownAzIcon,
  CircleArrowDown as ArrowDownCircle,
  CircleArrowDown as ArrowDownCircleIcon,
  ArrowDownFromLine,
  ArrowDownFromLine as ArrowDownFromLineIcon,
  ArrowDown as ArrowDownIcon,
  ArrowDownLeft,
  CircleArrowOutDownLeft as ArrowDownLeftFromCircle,
  CircleArrowOutDownLeft as ArrowDownLeftFromCircleIcon,
  SquareArrowOutDownLeft as ArrowDownLeftFromSquare,
  SquareArrowOutDownLeft as ArrowDownLeftFromSquareIcon,
  ArrowDownLeft as ArrowDownLeftIcon,
  SquareArrowDownLeft as ArrowDownLeftSquare,
  SquareArrowDownLeft as ArrowDownLeftSquareIcon,
  ArrowDownNarrowWide,
  ArrowDownNarrowWide as ArrowDownNarrowWideIcon,
  ArrowDownRight,
  CircleArrowOutDownRight as ArrowDownRightFromCircle,
  CircleArrowOutDownRight as ArrowDownRightFromCircleIcon,
  SquareArrowOutDownRight as ArrowDownRightFromSquare,
  SquareArrowOutDownRight as ArrowDownRightFromSquareIcon,
  ArrowDownRight as ArrowDownRightIcon,
  SquareArrowDownRight as ArrowDownRightSquare,
  SquareArrowDownRight as ArrowDownRightSquareIcon,
  SquareArrowDown as ArrowDownSquare,
  SquareArrowDown as ArrowDownSquareIcon,
  ArrowDownToDot,
  ArrowDownToDot as ArrowDownToDotIcon,
  ArrowDownToLine,
  ArrowDownToLine as ArrowDownToLineIcon,
  ArrowDownUp,
  ArrowDownUp as ArrowDownUpIcon,
  ArrowDownWideNarrow,
  ArrowDownWideNarrow as ArrowDownWideNarrowIcon,
  ArrowDownZA,
  ArrowDownZA as ArrowDownZAIcon,
  ArrowDownZA as ArrowDownZa,
  ArrowDownZA as ArrowDownZaIcon,
  ArrowLeft,
  CircleArrowLeft as ArrowLeftCircle,
  CircleArrowLeft as ArrowLeftCircleIcon,
  ArrowLeftFromLine,
  ArrowLeftFromLine as ArrowLeftFromLineIcon,
  ArrowLeft as ArrowLeftIcon,
  ArrowLeftRight,
  ArrowLeftRight as ArrowLeftRightIcon,
  SquareArrowLeft as ArrowLeftSquare,
  SquareArrowLeft as ArrowLeftSquareIcon,
  ArrowLeftToLine,
  ArrowLeftToLine as ArrowLeftToLineIcon,
  ArrowRight,
  CircleArrowRight as ArrowRightCircle,
  CircleArrowRight as ArrowRightCircleIcon,
  ArrowRightFromLine,
  ArrowRightFromLine as ArrowRightFromLineIcon,
  ArrowRight as ArrowRightIcon,
  ArrowRightLeft,
  ArrowRightLeft as ArrowRightLeftIcon,
  SquareArrowRight as ArrowRightSquare,
  SquareArrowRight as ArrowRightSquareIcon,
  ArrowRightToLine,
  ArrowRightToLine as ArrowRightToLineIcon,
  ArrowUp,
  ArrowUp01,
  ArrowUp01 as ArrowUp01Icon,
  ArrowUp10,
  ArrowUp10 as ArrowUp10Icon,
  ArrowUpAZ,
  ArrowUpAZ as ArrowUpAZIcon,
  ArrowUpAZ as ArrowUpAz,
  ArrowUpAZ as ArrowUpAzIcon,
  CircleArrowUp as ArrowUpCircle,
  CircleArrowUp as ArrowUpCircleIcon,
  ArrowUpDown,
  ArrowUpDown as ArrowUpDownIcon,
  ArrowUpFromDot,
  ArrowUpFromDot as ArrowUpFromDotIcon,
  ArrowUpFromLine,
  ArrowUpFromLine as ArrowUpFromLineIcon,
  ArrowUp as ArrowUpIcon,
  ArrowUpLeft,
  CircleArrowOutUpLeft as ArrowUpLeftFromCircle,
  CircleArrowOutUpLeft as ArrowUpLeftFromCircleIcon,
  SquareArrowOutUpLeft as ArrowUpLeftFromSquare,
  SquareArrowOutUpLeft as ArrowUpLeftFromSquareIcon,
  ArrowUpLeft as ArrowUpLeftIcon,
  SquareArrowUpLeft as ArrowUpLeftSquare,
  SquareArrowUpLeft as ArrowUpLeftSquareIcon,
  ArrowUpNarrowWide,
  ArrowUpNarrowWide as ArrowUpNarrowWideIcon,
  ArrowUpRight,
  CircleArrowOutUpRight as ArrowUpRightFromCircle,
  CircleArrowOutUpRight as ArrowUpRightFromCircleIcon,
  SquareArrowOutUpRight as ArrowUpRightFromSquare,
  SquareArrowOutUpRight as ArrowUpRightFromSquareIcon,
  ArrowUpRight as ArrowUpRightIcon,
  SquareArrowUpRight as ArrowUpRightSquare,
  SquareArrowUpRight as ArrowUpRightSquareIcon,
  SquareArrowUp as ArrowUpSquare,
  SquareArrowUp as ArrowUpSquareIcon,
  ArrowUpToLine,
  ArrowUpToLine as ArrowUpToLineIcon,
  ArrowUpWideNarrow,
  ArrowUpWideNarrow as ArrowUpWideNarrowIcon,
  ArrowUpZA,
  ArrowUpZA as ArrowUpZAIcon,
  ArrowUpZA as ArrowUpZa,
  ArrowUpZA as ArrowUpZaIcon,
  ArrowsUpFromLine,
  ArrowsUpFromLine as ArrowsUpFromLineIcon,
  Asterisk,
  Asterisk as AsteriskIcon,
  SquareAsterisk as AsteriskSquare,
  SquareAsterisk as AsteriskSquareIcon,
  AtSign,
  AtSign as AtSignIcon,
  Atom,
  Atom as AtomIcon,
  AudioLines,
  AudioLines as AudioLinesIcon,
  AudioWaveform,
  AudioWaveform as AudioWaveformIcon,
  Award,
  Award as AwardIcon,
  Axe,
  Axe as AxeIcon,
  Axis3d as Axis3D,
  Axis3d as Axis3DIcon,
  Axis3d,
  Axis3d as Axis3dIcon,
  Baby,
  Baby as BabyIcon,
  Backpack,
  Backpack as BackpackIcon,
  Badge,
  BadgeAlert,
  BadgeAlert as BadgeAlertIcon,
  BadgeCent,
  BadgeCent as BadgeCentIcon,
  BadgeCheck,
  BadgeCheck as BadgeCheckIcon,
  BadgeDollarSign,
  BadgeDollarSign as BadgeDollarSignIcon,
  BadgeEuro,
  BadgeEuro as BadgeEuroIcon,
  BadgeQuestionMark as BadgeHelp,
  BadgeQuestionMark as BadgeHelpIcon,
  Badge as BadgeIcon,
  BadgeIndianRupee,
  BadgeIndianRupee as BadgeIndianRupeeIcon,
  BadgeInfo,
  BadgeInfo as BadgeInfoIcon,
  BadgeJapaneseYen,
  BadgeJapaneseYen as BadgeJapaneseYenIcon,
  BadgeMinus,
  BadgeMinus as BadgeMinusIcon,
  BadgePercent,
  BadgePercent as BadgePercentIcon,
  BadgePlus,
  BadgePlus as BadgePlusIcon,
  BadgePoundSterling,
  BadgePoundSterling as BadgePoundSterlingIcon,
  BadgeQuestionMark,
  BadgeQuestionMark as BadgeQuestionMarkIcon,
  BadgeRussianRuble,
  BadgeRussianRuble as BadgeRussianRubleIcon,
  BadgeSwissFranc,
  BadgeSwissFranc as BadgeSwissFrancIcon,
  BadgeTurkishLira,
  BadgeTurkishLira as BadgeTurkishLiraIcon,
  BadgeX,
  BadgeX as BadgeXIcon,
  BaggageClaim,
  BaggageClaim as BaggageClaimIcon,
  Balloon,
  Balloon as BalloonIcon,
  Ban,
  Ban as BanIcon,
  Banana,
  Banana as BananaIcon,
  Bandage,
  Bandage as BandageIcon,
  Banknote,
  BanknoteArrowDown,
  BanknoteArrowDown as BanknoteArrowDownIcon,
  BanknoteArrowUp,
  BanknoteArrowUp as BanknoteArrowUpIcon,
  Banknote as BanknoteIcon,
  BanknoteX,
  BanknoteX as BanknoteXIcon,
  ChartNoAxesColumnIncreasing as BarChart,
  ChartNoAxesColumn as BarChart2,
  ChartNoAxesColumn as BarChart2Icon,
  ChartColumn as BarChart3,
  ChartColumn as BarChart3Icon,
  ChartColumnIncreasing as BarChart4,
  ChartColumnIncreasing as BarChart4Icon,
  ChartColumnBig as BarChartBig,
  ChartColumnBig as BarChartBigIcon,
  ChartBar as BarChartHorizontal,
  ChartBarBig as BarChartHorizontalBig,
  ChartBarBig as BarChartHorizontalBigIcon,
  ChartBar as BarChartHorizontalIcon,
  ChartNoAxesColumnIncreasing as BarChartIcon,
  Barcode,
  Barcode as BarcodeIcon,
  Barrel,
  Barrel as BarrelIcon,
  Baseline,
  Baseline as BaselineIcon,
  Bath,
  Bath as BathIcon,
  Battery,
  BatteryCharging,
  BatteryCharging as BatteryChargingIcon,
  BatteryFull,
  BatteryFull as BatteryFullIcon,
  Battery as BatteryIcon,
  BatteryLow,
  BatteryLow as BatteryLowIcon,
  BatteryMedium,
  BatteryMedium as BatteryMediumIcon,
  BatteryPlus,
  BatteryPlus as BatteryPlusIcon,
  BatteryWarning,
  BatteryWarning as BatteryWarningIcon,
  Beaker,
  Beaker as BeakerIcon,
  Bean,
  Bean as BeanIcon,
  BeanOff,
  BeanOff as BeanOffIcon,
  Bed,
  BedDouble,
  BedDouble as BedDoubleIcon,
  Bed as BedIcon,
  BedSingle,
  BedSingle as BedSingleIcon,
  Beef,
  Beef as BeefIcon,
  Beer,
  Beer as BeerIcon,
  BeerOff,
  BeerOff as BeerOffIcon,
  Bell,
  BellDot,
  BellDot as BellDotIcon,
  BellElectric,
  BellElectric as BellElectricIcon,
  Bell as BellIcon,
  BellMinus,
  BellMinus as BellMinusIcon,
  BellOff,
  BellOff as BellOffIcon,
  BellPlus,
  BellPlus as BellPlusIcon,
  BellRing,
  BellRing as BellRingIcon,
  BetweenHorizontalEnd as BetweenHorizonalEnd,
  BetweenHorizontalEnd as BetweenHorizonalEndIcon,
  BetweenHorizontalStart as BetweenHorizonalStart,
  BetweenHorizontalStart as BetweenHorizonalStartIcon,
  BetweenHorizontalEnd,
  BetweenHorizontalEnd as BetweenHorizontalEndIcon,
  BetweenHorizontalStart,
  BetweenHorizontalStart as BetweenHorizontalStartIcon,
  BetweenVerticalEnd,
  BetweenVerticalEnd as BetweenVerticalEndIcon,
  BetweenVerticalStart,
  BetweenVerticalStart as BetweenVerticalStartIcon,
  BicepsFlexed,
  BicepsFlexed as BicepsFlexedIcon,
  Bike,
  Bike as BikeIcon,
  Binary,
  Binary as BinaryIcon,
  Binoculars,
  Binoculars as BinocularsIcon,
  Biohazard,
  Biohazard as BiohazardIcon,
  Bird,
  Bird as BirdIcon,
  Birdhouse,
  Birdhouse as BirdhouseIcon,
  Bitcoin,
  Bitcoin as BitcoinIcon,
  Blend,
  Blend as BlendIcon,
  Blinds,
  Blinds as BlindsIcon,
  Blocks,
  Blocks as BlocksIcon,
  Bluetooth,
  BluetoothConnected,
  BluetoothConnected as BluetoothConnectedIcon,
  Bluetooth as BluetoothIcon,
  BluetoothOff,
  BluetoothOff as BluetoothOffIcon,
  BluetoothSearching,
  BluetoothSearching as BluetoothSearchingIcon,
  Bold,
  Bold as BoldIcon,
  Bolt,
  Bolt as BoltIcon,
  Bomb,
  Bomb as BombIcon,
  Bone,
  Bone as BoneIcon,
  Book,
  BookA,
  BookA as BookAIcon,
  BookAlert,
  BookAlert as BookAlertIcon,
  BookAudio,
  BookAudio as BookAudioIcon,
  BookCheck,
  BookCheck as BookCheckIcon,
  BookCopy,
  BookCopy as BookCopyIcon,
  BookDashed,
  BookDashed as BookDashedIcon,
  BookDown,
  BookDown as BookDownIcon,
  BookHeadphones,
  BookHeadphones as BookHeadphonesIcon,
  BookHeart,
  BookHeart as BookHeartIcon,
  Book as BookIcon,
  BookImage,
  BookImage as BookImageIcon,
  BookKey,
  BookKey as BookKeyIcon,
  BookLock,
  BookLock as BookLockIcon,
  BookMarked,
  BookMarked as BookMarkedIcon,
  BookMinus,
  BookMinus as BookMinusIcon,
  BookOpen,
  BookOpenCheck,
  BookOpenCheck as BookOpenCheckIcon,
  BookOpen as BookOpenIcon,
  BookOpenText,
  BookOpenText as BookOpenTextIcon,
  BookPlus,
  BookPlus as BookPlusIcon,
  BookSearch,
  BookSearch as BookSearchIcon,
  BookDashed as BookTemplate,
  BookDashed as BookTemplateIcon,
  BookText,
  BookText as BookTextIcon,
  BookType,
  BookType as BookTypeIcon,
  BookUp,
  BookUp2,
  BookUp2 as BookUp2Icon,
  BookUp as BookUpIcon,
  BookUser,
  BookUser as BookUserIcon,
  BookX,
  BookX as BookXIcon,
  Bookmark,
  BookmarkCheck,
  BookmarkCheck as BookmarkCheckIcon,
  Bookmark as BookmarkIcon,
  BookmarkMinus,
  BookmarkMinus as BookmarkMinusIcon,
  BookmarkPlus,
  BookmarkPlus as BookmarkPlusIcon,
  BookmarkX,
  BookmarkX as BookmarkXIcon,
  BoomBox,
  BoomBox as BoomBoxIcon,
  Bot,
  Bot as BotIcon,
  BotMessageSquare,
  BotMessageSquare as BotMessageSquareIcon,
  BotOff,
  BotOff as BotOffIcon,
  BottleWine,
  BottleWine as BottleWineIcon,
  BowArrow,
  BowArrow as BowArrowIcon,
  Box,
  Box as BoxIcon,
  SquareDashed as BoxSelect,
  SquareDashed as BoxSelectIcon,
  Boxes,
  Boxes as BoxesIcon,
  Braces,
  Braces as BracesIcon,
  Brackets,
  Brackets as BracketsIcon,
  Brain,
  BrainCircuit,
  BrainCircuit as BrainCircuitIcon,
  BrainCog,
  BrainCog as BrainCogIcon,
  Brain as BrainIcon,
  BrickWall,
  BrickWallFire,
  BrickWallFire as BrickWallFireIcon,
  BrickWall as BrickWallIcon,
  BrickWallShield,
  BrickWallShield as BrickWallShieldIcon,
  Briefcase,
  BriefcaseBusiness,
  BriefcaseBusiness as BriefcaseBusinessIcon,
  BriefcaseConveyorBelt,
  BriefcaseConveyorBelt as BriefcaseConveyorBeltIcon,
  Briefcase as BriefcaseIcon,
  BriefcaseMedical,
  BriefcaseMedical as BriefcaseMedicalIcon,
  BringToFront,
  BringToFront as BringToFrontIcon,
  Brush,
  BrushCleaning,
  BrushCleaning as BrushCleaningIcon,
  Brush as BrushIcon,
  Bubbles,
  Bubbles as BubblesIcon,
  Bug,
  Bug as BugIcon,
  BugOff,
  BugOff as BugOffIcon,
  BugPlay,
  BugPlay as BugPlayIcon,
  Building,
  Building2,
  Building2 as Building2Icon,
  Building as BuildingIcon,
  Bus,
  BusFront,
  BusFront as BusFrontIcon,
  Bus as BusIcon,
  Cable,
  CableCar,
  CableCar as CableCarIcon,
  Cable as CableIcon,
  Cake,
  Cake as CakeIcon,
  CakeSlice,
  CakeSlice as CakeSliceIcon,
  Calculator,
  Calculator as CalculatorIcon,
  Calendar,
  Calendar1,
  Calendar1 as Calendar1Icon,
  CalendarArrowDown,
  CalendarArrowDown as CalendarArrowDownIcon,
  CalendarArrowUp,
  CalendarArrowUp as CalendarArrowUpIcon,
  CalendarCheck,
  CalendarCheck2,
  CalendarCheck2 as CalendarCheck2Icon,
  CalendarCheck as CalendarCheckIcon,
  CalendarClock,
  CalendarClock as CalendarClockIcon,
  CalendarCog,
  CalendarCog as CalendarCogIcon,
  CalendarDays,
  CalendarDays as CalendarDaysIcon,
  CalendarFold,
  CalendarFold as CalendarFoldIcon,
  CalendarHeart,
  CalendarHeart as CalendarHeartIcon,
  Calendar as CalendarIcon,
  CalendarMinus,
  CalendarMinus2,
  CalendarMinus2 as CalendarMinus2Icon,
  CalendarMinus as CalendarMinusIcon,
  CalendarOff,
  CalendarOff as CalendarOffIcon,
  CalendarPlus,
  CalendarPlus2,
  CalendarPlus2 as CalendarPlus2Icon,
  CalendarPlus as CalendarPlusIcon,
  CalendarRange,
  CalendarRange as CalendarRangeIcon,
  CalendarSearch,
  CalendarSearch as CalendarSearchIcon,
  CalendarSync,
  CalendarSync as CalendarSyncIcon,
  CalendarX,
  CalendarX2,
  CalendarX2 as CalendarX2Icon,
  CalendarX as CalendarXIcon,
  Calendars,
  Calendars as CalendarsIcon,
  Camera,
  Camera as CameraIcon,
  CameraOff,
  CameraOff as CameraOffIcon,
  ChartCandlestick as CandlestickChart,
  ChartCandlestick as CandlestickChartIcon,
  Candy,
  CandyCane,
  CandyCane as CandyCaneIcon,
  Candy as CandyIcon,
  CandyOff,
  CandyOff as CandyOffIcon,
  Cannabis,
  Cannabis as CannabisIcon,
  CannabisOff,
  CannabisOff as CannabisOffIcon,
  Captions,
  Captions as CaptionsIcon,
  CaptionsOff,
  CaptionsOff as CaptionsOffIcon,
  Car,
  CarFront,
  CarFront as CarFrontIcon,
  Car as CarIcon,
  CarTaxiFront,
  CarTaxiFront as CarTaxiFrontIcon,
  Caravan,
  Caravan as CaravanIcon,
  CardSim,
  CardSim as CardSimIcon,
  Carrot,
  Carrot as CarrotIcon,
  CaseLower,
  CaseLower as CaseLowerIcon,
  CaseSensitive,
  CaseSensitive as CaseSensitiveIcon,
  CaseUpper,
  CaseUpper as CaseUpperIcon,
  CassetteTape,
  CassetteTape as CassetteTapeIcon,
  Cast,
  Cast as CastIcon,
  Castle,
  Castle as CastleIcon,
  Cat,
  Cat as CatIcon,
  Cctv,
  Cctv as CctvIcon,
  ChartArea,
  ChartArea as ChartAreaIcon,
  ChartBar,
  ChartBarBig,
  ChartBarBig as ChartBarBigIcon,
  ChartBarDecreasing,
  ChartBarDecreasing as ChartBarDecreasingIcon,
  ChartBar as ChartBarIcon,
  ChartBarIncreasing,
  ChartBarIncreasing as ChartBarIncreasingIcon,
  ChartBarStacked,
  ChartBarStacked as ChartBarStackedIcon,
  ChartCandlestick,
  ChartCandlestick as ChartCandlestickIcon,
  ChartColumn,
  ChartColumnBig,
  ChartColumnBig as ChartColumnBigIcon,
  ChartColumnDecreasing,
  ChartColumnDecreasing as ChartColumnDecreasingIcon,
  ChartColumn as ChartColumnIcon,
  ChartColumnIncreasing,
  ChartColumnIncreasing as ChartColumnIncreasingIcon,
  ChartColumnStacked,
  ChartColumnStacked as ChartColumnStackedIcon,
  ChartGantt,
  ChartGantt as ChartGanttIcon,
  ChartLine,
  ChartLine as ChartLineIcon,
  ChartNetwork,
  ChartNetwork as ChartNetworkIcon,
  ChartNoAxesColumn,
  ChartNoAxesColumnDecreasing,
  ChartNoAxesColumnDecreasing as ChartNoAxesColumnDecreasingIcon,
  ChartNoAxesColumn as ChartNoAxesColumnIcon,
  ChartNoAxesColumnIncreasing,
  ChartNoAxesColumnIncreasing as ChartNoAxesColumnIncreasingIcon,
  ChartNoAxesCombined,
  ChartNoAxesCombined as ChartNoAxesCombinedIcon,
  ChartNoAxesGantt,
  ChartNoAxesGantt as ChartNoAxesGanttIcon,
  ChartPie,
  ChartPie as ChartPieIcon,
  ChartScatter,
  ChartScatter as ChartScatterIcon,
  ChartSpline,
  ChartSpline as ChartSplineIcon,
  Check,
  CheckCheck,
  CheckCheck as CheckCheckIcon,
  CircleCheckBig as CheckCircle,
  CircleCheck as CheckCircle2,
  CircleCheck as CheckCircle2Icon,
  CircleCheckBig as CheckCircleIcon,
  Check as CheckIcon,
  CheckLine,
  CheckLine as CheckLineIcon,
  SquareCheckBig as CheckSquare,
  SquareCheck as CheckSquare2,
  SquareCheck as CheckSquare2Icon,
  SquareCheckBig as CheckSquareIcon,
  ChefHat,
  ChefHat as ChefHatIcon,
  Cherry,
  Cherry as CherryIcon,
  ChessBishop,
  ChessBishop as ChessBishopIcon,
  ChessKing,
  ChessKing as ChessKingIcon,
  ChessKnight,
  ChessKnight as ChessKnightIcon,
  ChessPawn,
  ChessPawn as ChessPawnIcon,
  ChessQueen,
  ChessQueen as ChessQueenIcon,
  ChessRook,
  ChessRook as ChessRookIcon,
  ChevronDown,
  CircleChevronDown as ChevronDownCircle,
  CircleChevronDown as ChevronDownCircleIcon,
  ChevronDown as ChevronDownIcon,
  SquareChevronDown as ChevronDownSquare,
  SquareChevronDown as ChevronDownSquareIcon,
  ChevronFirst,
  ChevronFirst as ChevronFirstIcon,
  ChevronLast,
  ChevronLast as ChevronLastIcon,
  ChevronLeft,
  CircleChevronLeft as ChevronLeftCircle,
  CircleChevronLeft as ChevronLeftCircleIcon,
  ChevronLeft as ChevronLeftIcon,
  SquareChevronLeft as ChevronLeftSquare,
  SquareChevronLeft as ChevronLeftSquareIcon,
  ChevronRight,
  CircleChevronRight as ChevronRightCircle,
  CircleChevronRight as ChevronRightCircleIcon,
  ChevronRight as ChevronRightIcon,
  SquareChevronRight as ChevronRightSquare,
  SquareChevronRight as ChevronRightSquareIcon,
  ChevronUp,
  CircleChevronUp as ChevronUpCircle,
  CircleChevronUp as ChevronUpCircleIcon,
  ChevronUp as ChevronUpIcon,
  SquareChevronUp as ChevronUpSquare,
  SquareChevronUp as ChevronUpSquareIcon,
  ChevronsDown,
  ChevronsDown as ChevronsDownIcon,
  ChevronsDownUp,
  ChevronsDownUp as ChevronsDownUpIcon,
  ChevronsLeft,
  ChevronsLeft as ChevronsLeftIcon,
  ChevronsLeftRight,
  ChevronsLeftRightEllipsis,
  ChevronsLeftRightEllipsis as ChevronsLeftRightEllipsisIcon,
  ChevronsLeftRight as ChevronsLeftRightIcon,
  ChevronsRight,
  ChevronsRight as ChevronsRightIcon,
  ChevronsRightLeft,
  ChevronsRightLeft as ChevronsRightLeftIcon,
  ChevronsUp,
  ChevronsUpDown,
  ChevronsUpDown as ChevronsUpDownIcon,
  ChevronsUp as ChevronsUpIcon,
  Chromium as Chrome,
  Chromium as ChromeIcon,
  Chromium,
  Chromium as ChromiumIcon,
  Church,
  Church as ChurchIcon,
  Cigarette,
  Cigarette as CigaretteIcon,
  CigaretteOff,
  CigaretteOff as CigaretteOffIcon,
  Circle,
  CircleAlert,
  CircleAlert as CircleAlertIcon,
  CircleArrowDown,
  CircleArrowDown as CircleArrowDownIcon,
  CircleArrowLeft,
  CircleArrowLeft as CircleArrowLeftIcon,
  CircleArrowOutDownLeft,
  CircleArrowOutDownLeft as CircleArrowOutDownLeftIcon,
  CircleArrowOutDownRight,
  CircleArrowOutDownRight as CircleArrowOutDownRightIcon,
  CircleArrowOutUpLeft,
  CircleArrowOutUpLeft as CircleArrowOutUpLeftIcon,
  CircleArrowOutUpRight,
  CircleArrowOutUpRight as CircleArrowOutUpRightIcon,
  CircleArrowRight,
  CircleArrowRight as CircleArrowRightIcon,
  CircleArrowUp,
  CircleArrowUp as CircleArrowUpIcon,
  CircleCheck,
  CircleCheckBig,
  CircleCheckBig as CircleCheckBigIcon,
  CircleCheck as CircleCheckIcon,
  CircleChevronDown,
  CircleChevronDown as CircleChevronDownIcon,
  CircleChevronLeft,
  CircleChevronLeft as CircleChevronLeftIcon,
  CircleChevronRight,
  CircleChevronRight as CircleChevronRightIcon,
  CircleChevronUp,
  CircleChevronUp as CircleChevronUpIcon,
  CircleDashed,
  CircleDashed as CircleDashedIcon,
  CircleDivide,
  CircleDivide as CircleDivideIcon,
  CircleDollarSign,
  CircleDollarSign as CircleDollarSignIcon,
  CircleDot,
  CircleDotDashed,
  CircleDotDashed as CircleDotDashedIcon,
  CircleDot as CircleDotIcon,
  CircleEllipsis,
  CircleEllipsis as CircleEllipsisIcon,
  CircleEqual,
  CircleEqual as CircleEqualIcon,
  CircleFadingArrowUp,
  CircleFadingArrowUp as CircleFadingArrowUpIcon,
  CircleFadingPlus,
  CircleFadingPlus as CircleFadingPlusIcon,
  CircleGauge,
  CircleGauge as CircleGaugeIcon,
  CircleQuestionMark as CircleHelp,
  CircleQuestionMark as CircleHelpIcon,
  Circle as CircleIcon,
  CircleMinus,
  CircleMinus as CircleMinusIcon,
  CircleOff,
  CircleOff as CircleOffIcon,
  CircleParking,
  CircleParking as CircleParkingIcon,
  CircleParkingOff,
  CircleParkingOff as CircleParkingOffIcon,
  CirclePause,
  CirclePause as CirclePauseIcon,
  CirclePercent,
  CirclePercent as CirclePercentIcon,
  CirclePile,
  CirclePile as CirclePileIcon,
  CirclePlay,
  CirclePlay as CirclePlayIcon,
  CirclePlus,
  CirclePlus as CirclePlusIcon,
  CirclePoundSterling,
  CirclePoundSterling as CirclePoundSterlingIcon,
  CirclePower,
  CirclePower as CirclePowerIcon,
  CircleQuestionMark,
  CircleQuestionMark as CircleQuestionMarkIcon,
  CircleSlash,
  CircleSlash2,
  CircleSlash2 as CircleSlash2Icon,
  CircleSlash as CircleSlashIcon,
  CircleSlash2 as CircleSlashed,
  CircleSlash2 as CircleSlashedIcon,
  CircleSmall,
  CircleSmall as CircleSmallIcon,
  CircleStar,
  CircleStar as CircleStarIcon,
  CircleStop,
  CircleStop as CircleStopIcon,
  CircleUser,
  CircleUser as CircleUserIcon,
  CircleUserRound,
  CircleUserRound as CircleUserRoundIcon,
  CircleX,
  CircleX as CircleXIcon,
  CircuitBoard,
  CircuitBoard as CircuitBoardIcon,
  Citrus,
  Citrus as CitrusIcon,
  Clapperboard,
  Clapperboard as ClapperboardIcon,
  Clipboard,
  ClipboardCheck,
  ClipboardCheck as ClipboardCheckIcon,
  ClipboardClock,
  ClipboardClock as ClipboardClockIcon,
  ClipboardCopy,
  ClipboardCopy as ClipboardCopyIcon,
  ClipboardPen as ClipboardEdit,
  ClipboardPen as ClipboardEditIcon,
  Clipboard as ClipboardIcon,
  ClipboardList,
  ClipboardList as ClipboardListIcon,
  ClipboardMinus,
  ClipboardMinus as ClipboardMinusIcon,
  ClipboardPaste,
  ClipboardPaste as ClipboardPasteIcon,
  ClipboardPen,
  ClipboardPen as ClipboardPenIcon,
  ClipboardPenLine,
  ClipboardPenLine as ClipboardPenLineIcon,
  ClipboardPlus,
  ClipboardPlus as ClipboardPlusIcon,
  ClipboardPenLine as ClipboardSignature,
  ClipboardPenLine as ClipboardSignatureIcon,
  ClipboardType,
  ClipboardType as ClipboardTypeIcon,
  ClipboardX,
  ClipboardX as ClipboardXIcon,
  Clock,
  Clock1,
  Clock10,
  Clock10 as Clock10Icon,
  Clock11,
  Clock11 as Clock11Icon,
  Clock12,
  Clock12 as Clock12Icon,
  Clock1 as Clock1Icon,
  Clock2,
  Clock2 as Clock2Icon,
  Clock3,
  Clock3 as Clock3Icon,
  Clock4,
  Clock4 as Clock4Icon,
  Clock5,
  Clock5 as Clock5Icon,
  Clock6,
  Clock6 as Clock6Icon,
  Clock7,
  Clock7 as Clock7Icon,
  Clock8,
  Clock8 as Clock8Icon,
  Clock9,
  Clock9 as Clock9Icon,
  ClockAlert,
  ClockAlert as ClockAlertIcon,
  ClockArrowDown,
  ClockArrowDown as ClockArrowDownIcon,
  ClockArrowUp,
  ClockArrowUp as ClockArrowUpIcon,
  ClockCheck,
  ClockCheck as ClockCheckIcon,
  ClockFading,
  ClockFading as ClockFadingIcon,
  Clock as ClockIcon,
  ClockPlus,
  ClockPlus as ClockPlusIcon,
  ClosedCaption,
  ClosedCaption as ClosedCaptionIcon,
  Cloud,
  CloudAlert,
  CloudAlert as CloudAlertIcon,
  CloudBackup,
  CloudBackup as CloudBackupIcon,
  CloudCheck,
  CloudCheck as CloudCheckIcon,
  CloudCog,
  CloudCog as CloudCogIcon,
  CloudDownload,
  CloudDownload as CloudDownloadIcon,
  CloudDrizzle,
  CloudDrizzle as CloudDrizzleIcon,
  CloudFog,
  CloudFog as CloudFogIcon,
  CloudHail,
  CloudHail as CloudHailIcon,
  Cloud as CloudIcon,
  CloudLightning,
  CloudLightning as CloudLightningIcon,
  CloudMoon,
  CloudMoon as CloudMoonIcon,
  CloudMoonRain,
  CloudMoonRain as CloudMoonRainIcon,
  CloudOff,
  CloudOff as CloudOffIcon,
  CloudRain,
  CloudRain as CloudRainIcon,
  CloudRainWind,
  CloudRainWind as CloudRainWindIcon,
  CloudSnow,
  CloudSnow as CloudSnowIcon,
  CloudSun,
  CloudSun as CloudSunIcon,
  CloudSunRain,
  CloudSunRain as CloudSunRainIcon,
  CloudSync,
  CloudSync as CloudSyncIcon,
  CloudUpload,
  CloudUpload as CloudUploadIcon,
  Cloudy,
  Cloudy as CloudyIcon,
  Clover,
  Clover as CloverIcon,
  Club,
  Club as ClubIcon,
  Code,
  CodeXml as Code2,
  CodeXml as Code2Icon,
  Code as CodeIcon,
  SquareCode as CodeSquare,
  SquareCode as CodeSquareIcon,
  CodeXml,
  CodeXml as CodeXmlIcon,
  Codepen,
  Codepen as CodepenIcon,
  Codesandbox,
  Codesandbox as CodesandboxIcon,
  Coffee,
  Coffee as CoffeeIcon,
  Cog,
  Cog as CogIcon,
  Coins,
  Coins as CoinsIcon,
  Columns2 as Columns,
  Columns2,
  Columns2 as Columns2Icon,
  Columns3,
  Columns3Cog,
  Columns3Cog as Columns3CogIcon,
  Columns3 as Columns3Icon,
  Columns4,
  Columns4 as Columns4Icon,
  Columns2 as ColumnsIcon,
  Columns3Cog as ColumnsSettings,
  Columns3Cog as ColumnsSettingsIcon,
  Combine,
  Combine as CombineIcon,
  Command,
  Command as CommandIcon,
  Compass,
  Compass as CompassIcon,
  Component,
  Component as ComponentIcon,
  Computer,
  Computer as ComputerIcon,
  ConciergeBell,
  ConciergeBell as ConciergeBellIcon,
  Cone,
  Cone as ConeIcon,
  Construction,
  Construction as ConstructionIcon,
  Contact,
  ContactRound as Contact2,
  ContactRound as Contact2Icon,
  Contact as ContactIcon,
  ContactRound,
  ContactRound as ContactRoundIcon,
  Container,
  Container as ContainerIcon,
  Contrast,
  Contrast as ContrastIcon,
  Cookie,
  Cookie as CookieIcon,
  CookingPot,
  CookingPot as CookingPotIcon,
  Copy,
  CopyCheck,
  CopyCheck as CopyCheckIcon,
  Copy as CopyIcon,
  CopyMinus,
  CopyMinus as CopyMinusIcon,
  CopyPlus,
  CopyPlus as CopyPlusIcon,
  CopySlash,
  CopySlash as CopySlashIcon,
  CopyX,
  CopyX as CopyXIcon,
  Copyleft,
  Copyleft as CopyleftIcon,
  Copyright,
  Copyright as CopyrightIcon,
  CornerDownLeft,
  CornerDownLeft as CornerDownLeftIcon,
  CornerDownRight,
  CornerDownRight as CornerDownRightIcon,
  CornerLeftDown,
  CornerLeftDown as CornerLeftDownIcon,
  CornerLeftUp,
  CornerLeftUp as CornerLeftUpIcon,
  CornerRightDown,
  CornerRightDown as CornerRightDownIcon,
  CornerRightUp,
  CornerRightUp as CornerRightUpIcon,
  CornerUpLeft,
  CornerUpLeft as CornerUpLeftIcon,
  CornerUpRight,
  CornerUpRight as CornerUpRightIcon,
  Cpu,
  Cpu as CpuIcon,
  CreativeCommons,
  CreativeCommons as CreativeCommonsIcon,
  CreditCard,
  CreditCard as CreditCardIcon,
  Croissant,
  Croissant as CroissantIcon,
  Crop,
  Crop as CropIcon,
  Cross,
  Cross as CrossIcon,
  Crosshair,
  Crosshair as CrosshairIcon,
  Crown,
  Crown as CrownIcon,
  Cuboid,
  Cuboid as CuboidIcon,
  CupSoda,
  CupSoda as CupSodaIcon,
  Braces as CurlyBraces,
  Braces as CurlyBracesIcon,
  Currency,
  Currency as CurrencyIcon,
  Cylinder,
  Cylinder as CylinderIcon,
  Dam,
  Dam as DamIcon,
  Database,
  DatabaseBackup,
  DatabaseBackup as DatabaseBackupIcon,
  Database as DatabaseIcon,
  DatabaseSearch,
  DatabaseSearch as DatabaseSearchIcon,
  DatabaseZap,
  DatabaseZap as DatabaseZapIcon,
  DecimalsArrowLeft,
  DecimalsArrowLeft as DecimalsArrowLeftIcon,
  DecimalsArrowRight,
  DecimalsArrowRight as DecimalsArrowRightIcon,
  Delete,
  Delete as DeleteIcon,
  Dessert,
  Dessert as DessertIcon,
  Diameter,
  Diameter as DiameterIcon,
  Diamond,
  Diamond as DiamondIcon,
  DiamondMinus,
  DiamondMinus as DiamondMinusIcon,
  DiamondPercent,
  DiamondPercent as DiamondPercentIcon,
  DiamondPlus,
  DiamondPlus as DiamondPlusIcon,
  Dice1,
  Dice1 as Dice1Icon,
  Dice2,
  Dice2 as Dice2Icon,
  Dice3,
  Dice3 as Dice3Icon,
  Dice4,
  Dice4 as Dice4Icon,
  Dice5,
  Dice5 as Dice5Icon,
  Dice6,
  Dice6 as Dice6Icon,
  Dices,
  Dices as DicesIcon,
  Diff,
  Diff as DiffIcon,
  Disc,
  Disc2,
  Disc2 as Disc2Icon,
  Disc3,
  Disc3 as Disc3Icon,
  DiscAlbum,
  DiscAlbum as DiscAlbumIcon,
  Disc as DiscIcon,
  Divide,
  CircleDivide as DivideCircle,
  CircleDivide as DivideCircleIcon,
  Divide as DivideIcon,
  SquareDivide as DivideSquare,
  SquareDivide as DivideSquareIcon,
  Dna,
  Dna as DnaIcon,
  DnaOff,
  DnaOff as DnaOffIcon,
  Dock,
  Dock as DockIcon,
  Dog,
  Dog as DogIcon,
  DollarSign,
  DollarSign as DollarSignIcon,
  Donut,
  Donut as DonutIcon,
  DoorClosed,
  DoorClosed as DoorClosedIcon,
  DoorClosedLocked,
  DoorClosedLocked as DoorClosedLockedIcon,
  DoorOpen,
  DoorOpen as DoorOpenIcon,
  Dot,
  Dot as DotIcon,
  SquareDot as DotSquare,
  SquareDot as DotSquareIcon,
  Download,
  CloudDownload as DownloadCloud,
  CloudDownload as DownloadCloudIcon,
  Download as DownloadIcon,
  DraftingCompass,
  DraftingCompass as DraftingCompassIcon,
  Drama,
  Drama as DramaIcon,
  Dribbble,
  Dribbble as DribbbleIcon,
  Drill,
  Drill as DrillIcon,
  Drone,
  Drone as DroneIcon,
  Droplet,
  Droplet as DropletIcon,
  DropletOff,
  DropletOff as DropletOffIcon,
  Droplets,
  Droplets as DropletsIcon,
  Drum,
  Drum as DrumIcon,
  Drumstick,
  Drumstick as DrumstickIcon,
  Dumbbell,
  Dumbbell as DumbbellIcon,
  Ear,
  Ear as EarIcon,
  EarOff,
  EarOff as EarOffIcon,
  Earth,
  Earth as EarthIcon,
  EarthLock,
  EarthLock as EarthLockIcon,
  Eclipse,
  Eclipse as EclipseIcon,
  SquarePen as Edit,
  Pen as Edit2,
  Pen as Edit2Icon,
  PenLine as Edit3,
  PenLine as Edit3Icon,
  SquarePen as EditIcon,
  Egg,
  EggFried,
  EggFried as EggFriedIcon,
  Egg as EggIcon,
  EggOff,
  EggOff as EggOffIcon,
  Ellipsis,
  Ellipsis as EllipsisIcon,
  EllipsisVertical,
  EllipsisVertical as EllipsisVerticalIcon,
  Equal,
  EqualApproximately,
  EqualApproximately as EqualApproximatelyIcon,
  Equal as EqualIcon,
  EqualNot,
  EqualNot as EqualNotIcon,
  SquareEqual as EqualSquare,
  SquareEqual as EqualSquareIcon,
  Eraser,
  Eraser as EraserIcon,
  EthernetPort,
  EthernetPort as EthernetPortIcon,
  Euro,
  Euro as EuroIcon,
  EvCharger,
  EvCharger as EvChargerIcon,
  Expand,
  Expand as ExpandIcon,
  ExternalLink,
  ExternalLink as ExternalLinkIcon,
  Eye,
  EyeClosed,
  EyeClosed as EyeClosedIcon,
  Eye as EyeIcon,
  EyeOff,
  EyeOff as EyeOffIcon,
  Facebook,
  Facebook as FacebookIcon,
  Factory,
  Factory as FactoryIcon,
  Fan,
  Fan as FanIcon,
  FastForward,
  FastForward as FastForwardIcon,
  Feather,
  Feather as FeatherIcon,
  Fence,
  Fence as FenceIcon,
  FerrisWheel,
  FerrisWheel as FerrisWheelIcon,
  Figma,
  Figma as FigmaIcon,
  File,
  FileArchive,
  FileArchive as FileArchiveIcon,
  FileHeadphone as FileAudio,
  FileHeadphone as FileAudio2,
  FileHeadphone as FileAudio2Icon,
  FileHeadphone as FileAudioIcon,
  FileAxis3d as FileAxis3D,
  FileAxis3d as FileAxis3DIcon,
  FileAxis3d,
  FileAxis3d as FileAxis3dIcon,
  FileBadge,
  FileBadge as FileBadge2,
  FileBadge as FileBadge2Icon,
  FileBadge as FileBadgeIcon,
  FileChartColumnIncreasing as FileBarChart,
  FileChartColumn as FileBarChart2,
  FileChartColumn as FileBarChart2Icon,
  FileChartColumnIncreasing as FileBarChartIcon,
  FileBox,
  FileBox as FileBoxIcon,
  FileBraces,
  FileBracesCorner,
  FileBracesCorner as FileBracesCornerIcon,
  FileBraces as FileBracesIcon,
  FileChartColumn,
  FileChartColumn as FileChartColumnIcon,
  FileChartColumnIncreasing,
  FileChartColumnIncreasing as FileChartColumnIncreasingIcon,
  FileChartLine,
  FileChartLine as FileChartLineIcon,
  FileChartPie,
  FileChartPie as FileChartPieIcon,
  FileCheck,
  FileCheckCorner as FileCheck2,
  FileCheckCorner as FileCheck2Icon,
  FileCheckCorner,
  FileCheckCorner as FileCheckCornerIcon,
  FileCheck as FileCheckIcon,
  FileClock,
  FileClock as FileClockIcon,
  FileCode,
  FileCodeCorner as FileCode2,
  FileCodeCorner as FileCode2Icon,
  FileCodeCorner,
  FileCodeCorner as FileCodeCornerIcon,
  FileCode as FileCodeIcon,
  FileCog,
  FileCog as FileCog2,
  FileCog as FileCog2Icon,
  FileCog as FileCogIcon,
  FileDiff,
  FileDiff as FileDiffIcon,
  FileDigit,
  FileDigit as FileDigitIcon,
  FileDown,
  FileDown as FileDownIcon,
  FilePen as FileEdit,
  FilePen as FileEditIcon,
  FileExclamationPoint,
  FileExclamationPoint as FileExclamationPointIcon,
  FileHeadphone,
  FileHeadphone as FileHeadphoneIcon,
  FileHeart,
  FileHeart as FileHeartIcon,
  File as FileIcon,
  FileImage,
  FileImage as FileImageIcon,
  FileInput,
  FileInput as FileInputIcon,
  FileBraces as FileJson,
  FileBracesCorner as FileJson2,
  FileBracesCorner as FileJson2Icon,
  FileBraces as FileJsonIcon,
  FileKey,
  FileKey as FileKey2,
  FileKey as FileKey2Icon,
  FileKey as FileKeyIcon,
  FileChartLine as FileLineChart,
  FileChartLine as FileLineChartIcon,
  FileLock,
  FileLock as FileLock2,
  FileLock as FileLock2Icon,
  FileLock as FileLockIcon,
  FileMinus,
  FileMinusCorner as FileMinus2,
  FileMinusCorner as FileMinus2Icon,
  FileMinusCorner,
  FileMinusCorner as FileMinusCornerIcon,
  FileMinus as FileMinusIcon,
  FileMusic,
  FileMusic as FileMusicIcon,
  FileOutput,
  FileOutput as FileOutputIcon,
  FilePen,
  FilePen as FilePenIcon,
  FilePenLine,
  FilePenLine as FilePenLineIcon,
  FileChartPie as FilePieChart,
  FileChartPie as FilePieChartIcon,
  FilePlay,
  FilePlay as FilePlayIcon,
  FilePlus,
  FilePlusCorner as FilePlus2,
  FilePlusCorner as FilePlus2Icon,
  FilePlusCorner,
  FilePlusCorner as FilePlusCornerIcon,
  FilePlus as FilePlusIcon,
  FileQuestionMark as FileQuestion,
  FileQuestionMark as FileQuestionIcon,
  FileQuestionMark,
  FileQuestionMark as FileQuestionMarkIcon,
  FileScan,
  FileScan as FileScanIcon,
  FileSearch,
  FileSearchCorner as FileSearch2,
  FileSearchCorner as FileSearch2Icon,
  FileSearchCorner,
  FileSearchCorner as FileSearchCornerIcon,
  FileSearch as FileSearchIcon,
  FileSignal,
  FileSignal as FileSignalIcon,
  FilePenLine as FileSignature,
  FilePenLine as FileSignatureIcon,
  FileSliders,
  FileSliders as FileSlidersIcon,
  FileSpreadsheet,
  FileSpreadsheet as FileSpreadsheetIcon,
  FileStack,
  FileStack as FileStackIcon,
  FileSymlink,
  FileSymlink as FileSymlinkIcon,
  FileTerminal,
  FileTerminal as FileTerminalIcon,
  FileText,
  FileText as FileTextIcon,
  FileType,
  FileTypeCorner as FileType2,
  FileTypeCorner as FileType2Icon,
  FileTypeCorner,
  FileTypeCorner as FileTypeCornerIcon,
  FileType as FileTypeIcon,
  FileUp,
  FileUp as FileUpIcon,
  FileUser,
  FileUser as FileUserIcon,
  FilePlay as FileVideo,
  FileVideoCamera as FileVideo2,
  FileVideoCamera as FileVideo2Icon,
  FileVideoCamera,
  FileVideoCamera as FileVideoCameraIcon,
  FilePlay as FileVideoIcon,
  FileVolume,
  FileSignal as FileVolume2,
  FileSignal as FileVolume2Icon,
  FileVolume as FileVolumeIcon,
  FileExclamationPoint as FileWarning,
  FileExclamationPoint as FileWarningIcon,
  FileX,
  FileXCorner as FileX2,
  FileXCorner as FileX2Icon,
  FileXCorner,
  FileXCorner as FileXCornerIcon,
  FileX as FileXIcon,
  Files,
  Files as FilesIcon,
  Film,
  Film as FilmIcon,
  Funnel as Filter,
  Funnel as FilterIcon,
  FunnelX as FilterX,
  FunnelX as FilterXIcon,
  FingerprintPattern as Fingerprint,
  FingerprintPattern as FingerprintIcon,
  FingerprintPattern,
  FingerprintPattern as FingerprintPatternIcon,
  FireExtinguisher,
  FireExtinguisher as FireExtinguisherIcon,
  Fish,
  Fish as FishIcon,
  FishOff,
  FishOff as FishOffIcon,
  FishSymbol,
  FishSymbol as FishSymbolIcon,
  FishingHook,
  FishingHook as FishingHookIcon,
  Flag,
  Flag as FlagIcon,
  FlagOff,
  FlagOff as FlagOffIcon,
  FlagTriangleLeft,
  FlagTriangleLeft as FlagTriangleLeftIcon,
  FlagTriangleRight,
  FlagTriangleRight as FlagTriangleRightIcon,
  Flame,
  Flame as FlameIcon,
  FlameKindling,
  FlameKindling as FlameKindlingIcon,
  Flashlight,
  Flashlight as FlashlightIcon,
  FlashlightOff,
  FlashlightOff as FlashlightOffIcon,
  FlaskConical,
  FlaskConical as FlaskConicalIcon,
  FlaskConicalOff,
  FlaskConicalOff as FlaskConicalOffIcon,
  FlaskRound,
  FlaskRound as FlaskRoundIcon,
  SquareCenterlineDashedHorizontal as FlipHorizontal,
  FlipHorizontal2,
  FlipHorizontal2 as FlipHorizontal2Icon,
  SquareCenterlineDashedHorizontal as FlipHorizontalIcon,
  SquareCenterlineDashedVertical as FlipVertical,
  FlipVertical2,
  FlipVertical2 as FlipVertical2Icon,
  SquareCenterlineDashedVertical as FlipVerticalIcon,
  Flower,
  Flower2,
  Flower2 as Flower2Icon,
  Flower as FlowerIcon,
  Focus,
  Focus as FocusIcon,
  FoldHorizontal,
  FoldHorizontal as FoldHorizontalIcon,
  FoldVertical,
  FoldVertical as FoldVerticalIcon,
  Folder,
  FolderArchive,
  FolderArchive as FolderArchiveIcon,
  FolderCheck,
  FolderCheck as FolderCheckIcon,
  FolderClock,
  FolderClock as FolderClockIcon,
  FolderClosed,
  FolderClosed as FolderClosedIcon,
  FolderCode,
  FolderCode as FolderCodeIcon,
  FolderCog,
  FolderCog as FolderCog2,
  FolderCog as FolderCog2Icon,
  FolderCog as FolderCogIcon,
  FolderDot,
  FolderDot as FolderDotIcon,
  FolderDown,
  FolderDown as FolderDownIcon,
  FolderPen as FolderEdit,
  FolderPen as FolderEditIcon,
  FolderGit,
  FolderGit2,
  FolderGit2 as FolderGit2Icon,
  FolderGit as FolderGitIcon,
  FolderHeart,
  FolderHeart as FolderHeartIcon,
  Folder as FolderIcon,
  FolderInput,
  FolderInput as FolderInputIcon,
  FolderKanban,
  FolderKanban as FolderKanbanIcon,
  FolderKey,
  FolderKey as FolderKeyIcon,
  FolderLock,
  FolderLock as FolderLockIcon,
  FolderMinus,
  FolderMinus as FolderMinusIcon,
  FolderOpen,
  FolderOpenDot,
  FolderOpenDot as FolderOpenDotIcon,
  FolderOpen as FolderOpenIcon,
  FolderOutput,
  FolderOutput as FolderOutputIcon,
  FolderPen,
  FolderPen as FolderPenIcon,
  FolderPlus,
  FolderPlus as FolderPlusIcon,
  FolderRoot,
  FolderRoot as FolderRootIcon,
  FolderSearch,
  FolderSearch2,
  FolderSearch2 as FolderSearch2Icon,
  FolderSearch as FolderSearchIcon,
  FolderSymlink,
  FolderSymlink as FolderSymlinkIcon,
  FolderSync,
  FolderSync as FolderSyncIcon,
  FolderTree,
  FolderTree as FolderTreeIcon,
  FolderUp,
  FolderUp as FolderUpIcon,
  FolderX,
  FolderX as FolderXIcon,
  Folders,
  Folders as FoldersIcon,
  Footprints,
  Footprints as FootprintsIcon,
  Utensils as ForkKnife,
  UtensilsCrossed as ForkKnifeCrossed,
  UtensilsCrossed as ForkKnifeCrossedIcon,
  Utensils as ForkKnifeIcon,
  Forklift,
  Forklift as ForkliftIcon,
  Form,
  Form as FormIcon,
  RectangleEllipsis as FormInput,
  RectangleEllipsis as FormInputIcon,
  Forward,
  Forward as ForwardIcon,
  Frame,
  Frame as FrameIcon,
  Framer,
  Framer as FramerIcon,
  Frown,
  Frown as FrownIcon,
  Fuel,
  Fuel as FuelIcon,
  Fullscreen,
  Fullscreen as FullscreenIcon,
  SquareFunction as FunctionSquare,
  SquareFunction as FunctionSquareIcon,
  Funnel,
  Funnel as FunnelIcon,
  FunnelPlus,
  FunnelPlus as FunnelPlusIcon,
  FunnelX,
  FunnelX as FunnelXIcon,
  GalleryHorizontal,
  GalleryHorizontalEnd,
  GalleryHorizontalEnd as GalleryHorizontalEndIcon,
  GalleryHorizontal as GalleryHorizontalIcon,
  GalleryThumbnails,
  GalleryThumbnails as GalleryThumbnailsIcon,
  GalleryVertical,
  GalleryVerticalEnd,
  GalleryVerticalEnd as GalleryVerticalEndIcon,
  GalleryVertical as GalleryVerticalIcon,
  Gamepad,
  Gamepad2,
  Gamepad2 as Gamepad2Icon,
  GamepadDirectional,
  GamepadDirectional as GamepadDirectionalIcon,
  Gamepad as GamepadIcon,
  ChartNoAxesGantt as GanttChart,
  ChartNoAxesGantt as GanttChartIcon,
  SquareChartGantt as GanttChartSquare,
  SquareChartGantt as GanttChartSquareIcon,
  Gauge,
  CircleGauge as GaugeCircle,
  CircleGauge as GaugeCircleIcon,
  Gauge as GaugeIcon,
  Gavel,
  Gavel as GavelIcon,
  Gem,
  Gem as GemIcon,
  GeorgianLari,
  GeorgianLari as GeorgianLariIcon,
  Ghost,
  Ghost as GhostIcon,
  Gift,
  Gift as GiftIcon,
  GitBranch,
  GitBranch as GitBranchIcon,
  GitBranchMinus,
  GitBranchMinus as GitBranchMinusIcon,
  GitBranchPlus,
  GitBranchPlus as GitBranchPlusIcon,
  GitCommitHorizontal as GitCommit,
  GitCommitHorizontal,
  GitCommitHorizontal as GitCommitHorizontalIcon,
  GitCommitHorizontal as GitCommitIcon,
  GitCommitVertical,
  GitCommitVertical as GitCommitVerticalIcon,
  GitCompare,
  GitCompareArrows,
  GitCompareArrows as GitCompareArrowsIcon,
  GitCompare as GitCompareIcon,
  GitFork,
  GitFork as GitForkIcon,
  GitGraph,
  GitGraph as GitGraphIcon,
  GitMerge,
  GitMergeConflict,
  GitMergeConflict as GitMergeConflictIcon,
  GitMerge as GitMergeIcon,
  GitPullRequest,
  GitPullRequestArrow,
  GitPullRequestArrow as GitPullRequestArrowIcon,
  GitPullRequestClosed,
  GitPullRequestClosed as GitPullRequestClosedIcon,
  GitPullRequestCreate,
  GitPullRequestCreateArrow,
  GitPullRequestCreateArrow as GitPullRequestCreateArrowIcon,
  GitPullRequestCreate as GitPullRequestCreateIcon,
  GitPullRequestDraft,
  GitPullRequestDraft as GitPullRequestDraftIcon,
  GitPullRequest as GitPullRequestIcon,
  Github,
  Github as GithubIcon,
  Gitlab,
  Gitlab as GitlabIcon,
  GlassWater,
  GlassWater as GlassWaterIcon,
  Glasses,
  Glasses as GlassesIcon,
  Globe,
  Earth as Globe2,
  Earth as Globe2Icon,
  Globe as GlobeIcon,
  GlobeLock,
  GlobeLock as GlobeLockIcon,
  GlobeOff,
  GlobeOff as GlobeOffIcon,
  GlobeX,
  GlobeX as GlobeXIcon,
  Goal,
  Goal as GoalIcon,
  Gpu,
  Gpu as GpuIcon,
  HandGrab as Grab,
  HandGrab as GrabIcon,
  GraduationCap,
  GraduationCap as GraduationCapIcon,
  Grape,
  Grape as GrapeIcon,
  Grid3x3 as Grid,
  Grid2x2 as Grid2X2,
  Grid2x2Check as Grid2X2Check,
  Grid2x2Check as Grid2X2CheckIcon,
  Grid2x2 as Grid2X2Icon,
  Grid2x2Plus as Grid2X2Plus,
  Grid2x2Plus as Grid2X2PlusIcon,
  Grid2x2X as Grid2X2X,
  Grid2x2X as Grid2X2XIcon,
  Grid2x2,
  Grid2x2Check,
  Grid2x2Check as Grid2x2CheckIcon,
  Grid2x2 as Grid2x2Icon,
  Grid2x2Plus,
  Grid2x2Plus as Grid2x2PlusIcon,
  Grid2x2X,
  Grid2x2X as Grid2x2XIcon,
  Grid3x3 as Grid3X3,
  Grid3x3 as Grid3X3Icon,
  Grid3x2,
  Grid3x2 as Grid3x2Icon,
  Grid3x3,
  Grid3x3 as Grid3x3Icon,
  Grid3x3 as GridIcon,
  Grip,
  GripHorizontal,
  GripHorizontal as GripHorizontalIcon,
  Grip as GripIcon,
  GripVertical,
  GripVertical as GripVerticalIcon,
  Group,
  Group as GroupIcon,
  Guitar,
  Guitar as GuitarIcon,
  Ham,
  Ham as HamIcon,
  Hamburger,
  Hamburger as HamburgerIcon,
  Hammer,
  Hammer as HammerIcon,
  Hand,
  HandCoins,
  HandCoins as HandCoinsIcon,
  HandFist,
  HandFist as HandFistIcon,
  HandGrab,
  HandGrab as HandGrabIcon,
  HandHeart,
  HandHeart as HandHeartIcon,
  HandHelping,
  HandHelping as HandHelpingIcon,
  Hand as HandIcon,
  HandMetal,
  HandMetal as HandMetalIcon,
  HandPlatter,
  HandPlatter as HandPlatterIcon,
  Handbag,
  Handbag as HandbagIcon,
  Handshake,
  Handshake as HandshakeIcon,
  HardDrive,
  HardDriveDownload,
  HardDriveDownload as HardDriveDownloadIcon,
  HardDrive as HardDriveIcon,
  HardDriveUpload,
  HardDriveUpload as HardDriveUploadIcon,
  HardHat,
  HardHat as HardHatIcon,
  Hash,
  Hash as HashIcon,
  HatGlasses,
  HatGlasses as HatGlassesIcon,
  Haze,
  Haze as HazeIcon,
  Hd,
  Hd as HdIcon,
  HdmiPort,
  HdmiPort as HdmiPortIcon,
  Heading,
  Heading1,
  Heading1 as Heading1Icon,
  Heading2,
  Heading2 as Heading2Icon,
  Heading3,
  Heading3 as Heading3Icon,
  Heading4,
  Heading4 as Heading4Icon,
  Heading5,
  Heading5 as Heading5Icon,
  Heading6,
  Heading6 as Heading6Icon,
  Heading as HeadingIcon,
  HeadphoneOff,
  HeadphoneOff as HeadphoneOffIcon,
  Headphones,
  Headphones as HeadphonesIcon,
  Headset,
  Headset as HeadsetIcon,
  Heart,
  HeartCrack,
  HeartCrack as HeartCrackIcon,
  HeartHandshake,
  HeartHandshake as HeartHandshakeIcon,
  Heart as HeartIcon,
  HeartMinus,
  HeartMinus as HeartMinusIcon,
  HeartOff,
  HeartOff as HeartOffIcon,
  HeartPlus,
  HeartPlus as HeartPlusIcon,
  HeartPulse,
  HeartPulse as HeartPulseIcon,
  Heater,
  Heater as HeaterIcon,
  Helicopter,
  Helicopter as HelicopterIcon,
  CircleQuestionMark as HelpCircle,
  CircleQuestionMark as HelpCircleIcon,
  HandHelping as HelpingHand,
  HandHelping as HelpingHandIcon,
  Hexagon,
  Hexagon as HexagonIcon,
  Highlighter,
  Highlighter as HighlighterIcon,
  History,
  History as HistoryIcon,
  House as Home,
  House as HomeIcon,
  Hop,
  Hop as HopIcon,
  HopOff,
  HopOff as HopOffIcon,
  Hospital,
  Hospital as HospitalIcon,
  Hotel,
  Hotel as HotelIcon,
  Hourglass,
  Hourglass as HourglassIcon,
  House,
  HouseHeart,
  HouseHeart as HouseHeartIcon,
  House as HouseIcon,
  HousePlug,
  HousePlug as HousePlugIcon,
  HousePlus,
  HousePlus as HousePlusIcon,
  HouseWifi,
  HouseWifi as HouseWifiIcon,
  IceCreamCone as IceCream,
  IceCreamBowl as IceCream2,
  IceCreamBowl as IceCream2Icon,
  IceCreamBowl,
  IceCreamBowl as IceCreamBowlIcon,
  IceCreamCone,
  IceCreamCone as IceCreamConeIcon,
  IceCreamCone as IceCreamIcon,
  Icon,
  IdCard,
  IdCard as IdCardIcon,
  IdCardLanyard,
  IdCardLanyard as IdCardLanyardIcon,
  Image,
  ImageDown,
  ImageDown as ImageDownIcon,
  Image as ImageIcon,
  ImageMinus,
  ImageMinus as ImageMinusIcon,
  ImageOff,
  ImageOff as ImageOffIcon,
  ImagePlay,
  ImagePlay as ImagePlayIcon,
  ImagePlus,
  ImagePlus as ImagePlusIcon,
  ImageUp,
  ImageUp as ImageUpIcon,
  ImageUpscale,
  ImageUpscale as ImageUpscaleIcon,
  Images,
  Images as ImagesIcon,
  Import,
  Import as ImportIcon,
  Inbox,
  Inbox as InboxIcon,
  ListIndentIncrease as Indent,
  ListIndentDecrease as IndentDecrease,
  ListIndentDecrease as IndentDecreaseIcon,
  ListIndentIncrease as IndentIcon,
  ListIndentIncrease as IndentIncrease,
  ListIndentIncrease as IndentIncreaseIcon,
  IndianRupee,
  IndianRupee as IndianRupeeIcon,
  Infinity,
  Infinity as InfinityIcon,
  Info,
  Info as InfoIcon,
  SquareMousePointer as Inspect,
  SquareMousePointer as InspectIcon,
  InspectionPanel,
  InspectionPanel as InspectionPanelIcon,
  Instagram,
  Instagram as InstagramIcon,
  Italic,
  Italic as ItalicIcon,
  IterationCcw,
  IterationCcw as IterationCcwIcon,
  IterationCw,
  IterationCw as IterationCwIcon,
  JapaneseYen,
  JapaneseYen as JapaneseYenIcon,
  Joystick,
  Joystick as JoystickIcon,
  Kanban,
  Kanban as KanbanIcon,
  SquareKanban as KanbanSquare,
  SquareDashedKanban as KanbanSquareDashed,
  SquareDashedKanban as KanbanSquareDashedIcon,
  SquareKanban as KanbanSquareIcon,
  Kayak,
  Kayak as KayakIcon,
  Key,
  Key as KeyIcon,
  KeyRound,
  KeyRound as KeyRoundIcon,
  KeySquare,
  KeySquare as KeySquareIcon,
  Keyboard,
  Keyboard as KeyboardIcon,
  KeyboardMusic,
  KeyboardMusic as KeyboardMusicIcon,
  KeyboardOff,
  KeyboardOff as KeyboardOffIcon,
  Lamp,
  LampCeiling,
  LampCeiling as LampCeilingIcon,
  LampDesk,
  LampDesk as LampDeskIcon,
  LampFloor,
  LampFloor as LampFloorIcon,
  Lamp as LampIcon,
  LampWallDown,
  LampWallDown as LampWallDownIcon,
  LampWallUp,
  LampWallUp as LampWallUpIcon,
  LandPlot,
  LandPlot as LandPlotIcon,
  Landmark,
  Landmark as LandmarkIcon,
  Languages,
  Languages as LanguagesIcon,
  Laptop,
  LaptopMinimal as Laptop2,
  LaptopMinimal as Laptop2Icon,
  Laptop as LaptopIcon,
  LaptopMinimal,
  LaptopMinimalCheck,
  LaptopMinimalCheck as LaptopMinimalCheckIcon,
  LaptopMinimal as LaptopMinimalIcon,
  Lasso,
  Lasso as LassoIcon,
  LassoSelect,
  LassoSelect as LassoSelectIcon,
  Laugh,
  Laugh as LaughIcon,
  Layers,
  Layers2,
  Layers2 as Layers2Icon,
  Layers as Layers3,
  Layers as Layers3Icon,
  Layers as LayersIcon,
  LayersPlus,
  LayersPlus as LayersPlusIcon,
  PanelsTopLeft as Layout,
  LayoutDashboard,
  LayoutDashboard as LayoutDashboardIcon,
  LayoutGrid,
  LayoutGrid as LayoutGridIcon,
  PanelsTopLeft as LayoutIcon,
  LayoutList,
  LayoutList as LayoutListIcon,
  LayoutPanelLeft,
  LayoutPanelLeft as LayoutPanelLeftIcon,
  LayoutPanelTop,
  LayoutPanelTop as LayoutPanelTopIcon,
  LayoutTemplate,
  LayoutTemplate as LayoutTemplateIcon,
  Leaf,
  Leaf as LeafIcon,
  LeafyGreen,
  LeafyGreen as LeafyGreenIcon,
  Lectern,
  Lectern as LecternIcon,
  LensConcave,
  LensConcave as LensConcaveIcon,
  LensConvex,
  LensConvex as LensConvexIcon,
  TextInitial as LetterText,
  TextInitial as LetterTextIcon,
  Library,
  LibraryBig,
  LibraryBig as LibraryBigIcon,
  Library as LibraryIcon,
  SquareLibrary as LibrarySquare,
  SquareLibrary as LibrarySquareIcon,
  LifeBuoy,
  LifeBuoy as LifeBuoyIcon,
  Ligature,
  Ligature as LigatureIcon,
  Lightbulb,
  Lightbulb as LightbulbIcon,
  LightbulbOff,
  LightbulbOff as LightbulbOffIcon,
  ChartLine as LineChart,
  ChartLine as LineChartIcon,
  LineDotRightHorizontal,
  LineDotRightHorizontal as LineDotRightHorizontalIcon,
  LineSquiggle,
  LineSquiggle as LineSquiggleIcon,
  Link,
  Link2,
  Link2 as Link2Icon,
  Link2Off,
  Link2Off as Link2OffIcon,
  Link as LinkIcon,
  Linkedin,
  Linkedin as LinkedinIcon,
  List,
  ListCheck,
  ListCheck as ListCheckIcon,
  ListChecks,
  ListChecks as ListChecksIcon,
  ListChevronsDownUp,
  ListChevronsDownUp as ListChevronsDownUpIcon,
  ListChevronsUpDown,
  ListChevronsUpDown as ListChevronsUpDownIcon,
  ListCollapse,
  ListCollapse as ListCollapseIcon,
  ListEnd,
  ListEnd as ListEndIcon,
  ListFilter,
  ListFilter as ListFilterIcon,
  ListFilterPlus,
  ListFilterPlus as ListFilterPlusIcon,
  List as ListIcon,
  ListIndentDecrease,
  ListIndentDecrease as ListIndentDecreaseIcon,
  ListIndentIncrease,
  ListIndentIncrease as ListIndentIncreaseIcon,
  ListMinus,
  ListMinus as ListMinusIcon,
  ListMusic,
  ListMusic as ListMusicIcon,
  ListOrdered,
  ListOrdered as ListOrderedIcon,
  ListPlus,
  ListPlus as ListPlusIcon,
  ListRestart,
  ListRestart as ListRestartIcon,
  ListStart,
  ListStart as ListStartIcon,
  ListTodo,
  ListTodo as ListTodoIcon,
  ListTree,
  ListTree as ListTreeIcon,
  ListVideo,
  ListVideo as ListVideoIcon,
  ListX,
  ListX as ListXIcon,
  Loader,
  LoaderCircle as Loader2,
  LoaderCircle as Loader2Icon,
  LoaderCircle,
  LoaderCircle as LoaderCircleIcon,
  Loader as LoaderIcon,
  LoaderPinwheel,
  LoaderPinwheel as LoaderPinwheelIcon,
  Locate,
  LocateFixed,
  LocateFixed as LocateFixedIcon,
  Locate as LocateIcon,
  LocateOff,
  LocateOff as LocateOffIcon,
  MapPinPen as LocationEdit,
  MapPinPen as LocationEditIcon,
  Lock,
  Lock as LockIcon,
  LockKeyhole,
  LockKeyhole as LockKeyholeIcon,
  LockKeyholeOpen,
  LockKeyholeOpen as LockKeyholeOpenIcon,
  LockOpen,
  LockOpen as LockOpenIcon,
  LogIn,
  LogIn as LogInIcon,
  LogOut,
  LogOut as LogOutIcon,
  Logs,
  Logs as LogsIcon,
  Lollipop,
  Lollipop as LollipopIcon,
  AArrowDown as LucideAArrowDown,
  AArrowUp as LucideAArrowUp,
  ALargeSmall as LucideALargeSmall,
  Accessibility as LucideAccessibility,
  Activity as LucideActivity,
  SquareActivity as LucideActivitySquare,
  AirVent as LucideAirVent,
  Airplay as LucideAirplay,
  AlarmClockCheck as LucideAlarmCheck,
  AlarmClock as LucideAlarmClock,
  AlarmClockCheck as LucideAlarmClockCheck,
  AlarmClockMinus as LucideAlarmClockMinus,
  AlarmClockOff as LucideAlarmClockOff,
  AlarmClockPlus as LucideAlarmClockPlus,
  AlarmClockMinus as LucideAlarmMinus,
  AlarmClockPlus as LucideAlarmPlus,
  AlarmSmoke as LucideAlarmSmoke,
  Album as LucideAlbum,
  CircleAlert as LucideAlertCircle,
  OctagonAlert as LucideAlertOctagon,
  TriangleAlert as LucideAlertTriangle,
  TextAlignCenter as LucideAlignCenter,
  AlignCenterHorizontal as LucideAlignCenterHorizontal,
  AlignCenterVertical as LucideAlignCenterVertical,
  AlignEndHorizontal as LucideAlignEndHorizontal,
  AlignEndVertical as LucideAlignEndVertical,
  AlignHorizontalDistributeCenter as LucideAlignHorizontalDistributeCenter,
  AlignHorizontalDistributeEnd as LucideAlignHorizontalDistributeEnd,
  AlignHorizontalDistributeStart as LucideAlignHorizontalDistributeStart,
  AlignHorizontalJustifyCenter as LucideAlignHorizontalJustifyCenter,
  AlignHorizontalJustifyEnd as LucideAlignHorizontalJustifyEnd,
  AlignHorizontalJustifyStart as LucideAlignHorizontalJustifyStart,
  AlignHorizontalSpaceAround as LucideAlignHorizontalSpaceAround,
  AlignHorizontalSpaceBetween as LucideAlignHorizontalSpaceBetween,
  TextAlignJustify as LucideAlignJustify,
  TextAlignStart as LucideAlignLeft,
  TextAlignEnd as LucideAlignRight,
  AlignStartHorizontal as LucideAlignStartHorizontal,
  AlignStartVertical as LucideAlignStartVertical,
  AlignVerticalDistributeCenter as LucideAlignVerticalDistributeCenter,
  AlignVerticalDistributeEnd as LucideAlignVerticalDistributeEnd,
  AlignVerticalDistributeStart as LucideAlignVerticalDistributeStart,
  AlignVerticalJustifyCenter as LucideAlignVerticalJustifyCenter,
  AlignVerticalJustifyEnd as LucideAlignVerticalJustifyEnd,
  AlignVerticalJustifyStart as LucideAlignVerticalJustifyStart,
  AlignVerticalSpaceAround as LucideAlignVerticalSpaceAround,
  AlignVerticalSpaceBetween as LucideAlignVerticalSpaceBetween,
  Ambulance as LucideAmbulance,
  Ampersand as LucideAmpersand,
  Ampersands as LucideAmpersands,
  Amphora as LucideAmphora,
  Anchor as LucideAnchor,
  Angry as LucideAngry,
  Annoyed as LucideAnnoyed,
  Antenna as LucideAntenna,
  Anvil as LucideAnvil,
  Aperture as LucideAperture,
  AppWindow as LucideAppWindow,
  AppWindowMac as LucideAppWindowMac,
  Apple as LucideApple,
  Archive as LucideArchive,
  ArchiveRestore as LucideArchiveRestore,
  ArchiveX as LucideArchiveX,
  ChartArea as LucideAreaChart,
  Armchair as LucideArmchair,
  ArrowBigDown as LucideArrowBigDown,
  ArrowBigDownDash as LucideArrowBigDownDash,
  ArrowBigLeft as LucideArrowBigLeft,
  ArrowBigLeftDash as LucideArrowBigLeftDash,
  ArrowBigRight as LucideArrowBigRight,
  ArrowBigRightDash as LucideArrowBigRightDash,
  ArrowBigUp as LucideArrowBigUp,
  ArrowBigUpDash as LucideArrowBigUpDash,
  ArrowDown as LucideArrowDown,
  ArrowDown01 as LucideArrowDown01,
  ArrowDown10 as LucideArrowDown10,
  ArrowDownAZ as LucideArrowDownAZ,
  ArrowDownAZ as LucideArrowDownAz,
  CircleArrowDown as LucideArrowDownCircle,
  ArrowDownFromLine as LucideArrowDownFromLine,
  ArrowDownLeft as LucideArrowDownLeft,
  CircleArrowOutDownLeft as LucideArrowDownLeftFromCircle,
  SquareArrowOutDownLeft as LucideArrowDownLeftFromSquare,
  SquareArrowDownLeft as LucideArrowDownLeftSquare,
  ArrowDownNarrowWide as LucideArrowDownNarrowWide,
  ArrowDownRight as LucideArrowDownRight,
  CircleArrowOutDownRight as LucideArrowDownRightFromCircle,
  SquareArrowOutDownRight as LucideArrowDownRightFromSquare,
  SquareArrowDownRight as LucideArrowDownRightSquare,
  SquareArrowDown as LucideArrowDownSquare,
  ArrowDownToDot as LucideArrowDownToDot,
  ArrowDownToLine as LucideArrowDownToLine,
  ArrowDownUp as LucideArrowDownUp,
  ArrowDownWideNarrow as LucideArrowDownWideNarrow,
  ArrowDownZA as LucideArrowDownZA,
  ArrowDownZA as LucideArrowDownZa,
  ArrowLeft as LucideArrowLeft,
  CircleArrowLeft as LucideArrowLeftCircle,
  ArrowLeftFromLine as LucideArrowLeftFromLine,
  ArrowLeftRight as LucideArrowLeftRight,
  SquareArrowLeft as LucideArrowLeftSquare,
  ArrowLeftToLine as LucideArrowLeftToLine,
  ArrowRight as LucideArrowRight,
  CircleArrowRight as LucideArrowRightCircle,
  ArrowRightFromLine as LucideArrowRightFromLine,
  ArrowRightLeft as LucideArrowRightLeft,
  SquareArrowRight as LucideArrowRightSquare,
  ArrowRightToLine as LucideArrowRightToLine,
  ArrowUp as LucideArrowUp,
  ArrowUp01 as LucideArrowUp01,
  ArrowUp10 as LucideArrowUp10,
  ArrowUpAZ as LucideArrowUpAZ,
  ArrowUpAZ as LucideArrowUpAz,
  CircleArrowUp as LucideArrowUpCircle,
  ArrowUpDown as LucideArrowUpDown,
  ArrowUpFromDot as LucideArrowUpFromDot,
  ArrowUpFromLine as LucideArrowUpFromLine,
  ArrowUpLeft as LucideArrowUpLeft,
  CircleArrowOutUpLeft as LucideArrowUpLeftFromCircle,
  SquareArrowOutUpLeft as LucideArrowUpLeftFromSquare,
  SquareArrowUpLeft as LucideArrowUpLeftSquare,
  ArrowUpNarrowWide as LucideArrowUpNarrowWide,
  ArrowUpRight as LucideArrowUpRight,
  CircleArrowOutUpRight as LucideArrowUpRightFromCircle,
  SquareArrowOutUpRight as LucideArrowUpRightFromSquare,
  SquareArrowUpRight as LucideArrowUpRightSquare,
  SquareArrowUp as LucideArrowUpSquare,
  ArrowUpToLine as LucideArrowUpToLine,
  ArrowUpWideNarrow as LucideArrowUpWideNarrow,
  ArrowUpZA as LucideArrowUpZA,
  ArrowUpZA as LucideArrowUpZa,
  ArrowsUpFromLine as LucideArrowsUpFromLine,
  Asterisk as LucideAsterisk,
  SquareAsterisk as LucideAsteriskSquare,
  AtSign as LucideAtSign,
  Atom as LucideAtom,
  AudioLines as LucideAudioLines,
  AudioWaveform as LucideAudioWaveform,
  Award as LucideAward,
  Axe as LucideAxe,
  Axis3d as LucideAxis3D,
  Axis3d as LucideAxis3d,
  Baby as LucideBaby,
  Backpack as LucideBackpack,
  Badge as LucideBadge,
  BadgeAlert as LucideBadgeAlert,
  BadgeCent as LucideBadgeCent,
  BadgeCheck as LucideBadgeCheck,
  BadgeDollarSign as LucideBadgeDollarSign,
  BadgeEuro as LucideBadgeEuro,
  BadgeQuestionMark as LucideBadgeHelp,
  BadgeIndianRupee as LucideBadgeIndianRupee,
  BadgeInfo as LucideBadgeInfo,
  BadgeJapaneseYen as LucideBadgeJapaneseYen,
  BadgeMinus as LucideBadgeMinus,
  BadgePercent as LucideBadgePercent,
  BadgePlus as LucideBadgePlus,
  BadgePoundSterling as LucideBadgePoundSterling,
  BadgeQuestionMark as LucideBadgeQuestionMark,
  BadgeRussianRuble as LucideBadgeRussianRuble,
  BadgeSwissFranc as LucideBadgeSwissFranc,
  BadgeTurkishLira as LucideBadgeTurkishLira,
  BadgeX as LucideBadgeX,
  BaggageClaim as LucideBaggageClaim,
  Balloon as LucideBalloon,
  Ban as LucideBan,
  Banana as LucideBanana,
  Bandage as LucideBandage,
  Banknote as LucideBanknote,
  BanknoteArrowDown as LucideBanknoteArrowDown,
  BanknoteArrowUp as LucideBanknoteArrowUp,
  BanknoteX as LucideBanknoteX,
  ChartNoAxesColumnIncreasing as LucideBarChart,
  ChartNoAxesColumn as LucideBarChart2,
  ChartColumn as LucideBarChart3,
  ChartColumnIncreasing as LucideBarChart4,
  ChartColumnBig as LucideBarChartBig,
  ChartBar as LucideBarChartHorizontal,
  ChartBarBig as LucideBarChartHorizontalBig,
  Barcode as LucideBarcode,
  Barrel as LucideBarrel,
  Baseline as LucideBaseline,
  Bath as LucideBath,
  Battery as LucideBattery,
  BatteryCharging as LucideBatteryCharging,
  BatteryFull as LucideBatteryFull,
  BatteryLow as LucideBatteryLow,
  BatteryMedium as LucideBatteryMedium,
  BatteryPlus as LucideBatteryPlus,
  BatteryWarning as LucideBatteryWarning,
  Beaker as LucideBeaker,
  Bean as LucideBean,
  BeanOff as LucideBeanOff,
  Bed as LucideBed,
  BedDouble as LucideBedDouble,
  BedSingle as LucideBedSingle,
  Beef as LucideBeef,
  Beer as LucideBeer,
  BeerOff as LucideBeerOff,
  Bell as LucideBell,
  BellDot as LucideBellDot,
  BellElectric as LucideBellElectric,
  BellMinus as LucideBellMinus,
  BellOff as LucideBellOff,
  BellPlus as LucideBellPlus,
  BellRing as LucideBellRing,
  BetweenHorizontalEnd as LucideBetweenHorizonalEnd,
  BetweenHorizontalStart as LucideBetweenHorizonalStart,
  BetweenHorizontalEnd as LucideBetweenHorizontalEnd,
  BetweenHorizontalStart as LucideBetweenHorizontalStart,
  BetweenVerticalEnd as LucideBetweenVerticalEnd,
  BetweenVerticalStart as LucideBetweenVerticalStart,
  BicepsFlexed as LucideBicepsFlexed,
  Bike as LucideBike,
  Binary as LucideBinary,
  Binoculars as LucideBinoculars,
  Biohazard as LucideBiohazard,
  Bird as LucideBird,
  Birdhouse as LucideBirdhouse,
  Bitcoin as LucideBitcoin,
  Blend as LucideBlend,
  Blinds as LucideBlinds,
  Blocks as LucideBlocks,
  Bluetooth as LucideBluetooth,
  BluetoothConnected as LucideBluetoothConnected,
  BluetoothOff as LucideBluetoothOff,
  BluetoothSearching as LucideBluetoothSearching,
  Bold as LucideBold,
  Bolt as LucideBolt,
  Bomb as LucideBomb,
  Bone as LucideBone,
  Book as LucideBook,
  BookA as LucideBookA,
  BookAlert as LucideBookAlert,
  BookAudio as LucideBookAudio,
  BookCheck as LucideBookCheck,
  BookCopy as LucideBookCopy,
  BookDashed as LucideBookDashed,
  BookDown as LucideBookDown,
  BookHeadphones as LucideBookHeadphones,
  BookHeart as LucideBookHeart,
  BookImage as LucideBookImage,
  BookKey as LucideBookKey,
  BookLock as LucideBookLock,
  BookMarked as LucideBookMarked,
  BookMinus as LucideBookMinus,
  BookOpen as LucideBookOpen,
  BookOpenCheck as LucideBookOpenCheck,
  BookOpenText as LucideBookOpenText,
  BookPlus as LucideBookPlus,
  BookSearch as LucideBookSearch,
  BookDashed as LucideBookTemplate,
  BookText as LucideBookText,
  BookType as LucideBookType,
  BookUp as LucideBookUp,
  BookUp2 as LucideBookUp2,
  BookUser as LucideBookUser,
  BookX as LucideBookX,
  Bookmark as LucideBookmark,
  BookmarkCheck as LucideBookmarkCheck,
  BookmarkMinus as LucideBookmarkMinus,
  BookmarkPlus as LucideBookmarkPlus,
  BookmarkX as LucideBookmarkX,
  BoomBox as LucideBoomBox,
  Bot as LucideBot,
  BotMessageSquare as LucideBotMessageSquare,
  BotOff as LucideBotOff,
  BottleWine as LucideBottleWine,
  BowArrow as LucideBowArrow,
  Box as LucideBox,
  SquareDashed as LucideBoxSelect,
  Boxes as LucideBoxes,
  Braces as LucideBraces,
  Brackets as LucideBrackets,
  Brain as LucideBrain,
  BrainCircuit as LucideBrainCircuit,
  BrainCog as LucideBrainCog,
  BrickWall as LucideBrickWall,
  BrickWallFire as LucideBrickWallFire,
  BrickWallShield as LucideBrickWallShield,
  Briefcase as LucideBriefcase,
  BriefcaseBusiness as LucideBriefcaseBusiness,
  BriefcaseConveyorBelt as LucideBriefcaseConveyorBelt,
  BriefcaseMedical as LucideBriefcaseMedical,
  BringToFront as LucideBringToFront,
  Brush as LucideBrush,
  BrushCleaning as LucideBrushCleaning,
  Bubbles as LucideBubbles,
  Bug as LucideBug,
  BugOff as LucideBugOff,
  BugPlay as LucideBugPlay,
  Building as LucideBuilding,
  Building2 as LucideBuilding2,
  Bus as LucideBus,
  BusFront as LucideBusFront,
  Cable as LucideCable,
  CableCar as LucideCableCar,
  Cake as LucideCake,
  CakeSlice as LucideCakeSlice,
  Calculator as LucideCalculator,
  Calendar as LucideCalendar,
  Calendar1 as LucideCalendar1,
  CalendarArrowDown as LucideCalendarArrowDown,
  CalendarArrowUp as LucideCalendarArrowUp,
  CalendarCheck as LucideCalendarCheck,
  CalendarCheck2 as LucideCalendarCheck2,
  CalendarClock as LucideCalendarClock,
  CalendarCog as LucideCalendarCog,
  CalendarDays as LucideCalendarDays,
  CalendarFold as LucideCalendarFold,
  CalendarHeart as LucideCalendarHeart,
  CalendarMinus as LucideCalendarMinus,
  CalendarMinus2 as LucideCalendarMinus2,
  CalendarOff as LucideCalendarOff,
  CalendarPlus as LucideCalendarPlus,
  CalendarPlus2 as LucideCalendarPlus2,
  CalendarRange as LucideCalendarRange,
  CalendarSearch as LucideCalendarSearch,
  CalendarSync as LucideCalendarSync,
  CalendarX as LucideCalendarX,
  CalendarX2 as LucideCalendarX2,
  Calendars as LucideCalendars,
  Camera as LucideCamera,
  CameraOff as LucideCameraOff,
  ChartCandlestick as LucideCandlestickChart,
  Candy as LucideCandy,
  CandyCane as LucideCandyCane,
  CandyOff as LucideCandyOff,
  Cannabis as LucideCannabis,
  CannabisOff as LucideCannabisOff,
  Captions as LucideCaptions,
  CaptionsOff as LucideCaptionsOff,
  Car as LucideCar,
  CarFront as LucideCarFront,
  CarTaxiFront as LucideCarTaxiFront,
  Caravan as LucideCaravan,
  CardSim as LucideCardSim,
  Carrot as LucideCarrot,
  CaseLower as LucideCaseLower,
  CaseSensitive as LucideCaseSensitive,
  CaseUpper as LucideCaseUpper,
  CassetteTape as LucideCassetteTape,
  Cast as LucideCast,
  Castle as LucideCastle,
  Cat as LucideCat,
  Cctv as LucideCctv,
  ChartArea as LucideChartArea,
  ChartBar as LucideChartBar,
  ChartBarBig as LucideChartBarBig,
  ChartBarDecreasing as LucideChartBarDecreasing,
  ChartBarIncreasing as LucideChartBarIncreasing,
  ChartBarStacked as LucideChartBarStacked,
  ChartCandlestick as LucideChartCandlestick,
  ChartColumn as LucideChartColumn,
  ChartColumnBig as LucideChartColumnBig,
  ChartColumnDecreasing as LucideChartColumnDecreasing,
  ChartColumnIncreasing as LucideChartColumnIncreasing,
  ChartColumnStacked as LucideChartColumnStacked,
  ChartGantt as LucideChartGantt,
  ChartLine as LucideChartLine,
  ChartNetwork as LucideChartNetwork,
  ChartNoAxesColumn as LucideChartNoAxesColumn,
  ChartNoAxesColumnDecreasing as LucideChartNoAxesColumnDecreasing,
  ChartNoAxesColumnIncreasing as LucideChartNoAxesColumnIncreasing,
  ChartNoAxesCombined as LucideChartNoAxesCombined,
  ChartNoAxesGantt as LucideChartNoAxesGantt,
  ChartPie as LucideChartPie,
  ChartScatter as LucideChartScatter,
  ChartSpline as LucideChartSpline,
  Check as LucideCheck,
  CheckCheck as LucideCheckCheck,
  CircleCheckBig as LucideCheckCircle,
  CircleCheck as LucideCheckCircle2,
  CheckLine as LucideCheckLine,
  SquareCheckBig as LucideCheckSquare,
  SquareCheck as LucideCheckSquare2,
  ChefHat as LucideChefHat,
  Cherry as LucideCherry,
  ChessBishop as LucideChessBishop,
  ChessKing as LucideChessKing,
  ChessKnight as LucideChessKnight,
  ChessPawn as LucideChessPawn,
  ChessQueen as LucideChessQueen,
  ChessRook as LucideChessRook,
  ChevronDown as LucideChevronDown,
  CircleChevronDown as LucideChevronDownCircle,
  SquareChevronDown as LucideChevronDownSquare,
  ChevronFirst as LucideChevronFirst,
  ChevronLast as LucideChevronLast,
  ChevronLeft as LucideChevronLeft,
  CircleChevronLeft as LucideChevronLeftCircle,
  SquareChevronLeft as LucideChevronLeftSquare,
  ChevronRight as LucideChevronRight,
  CircleChevronRight as LucideChevronRightCircle,
  SquareChevronRight as LucideChevronRightSquare,
  ChevronUp as LucideChevronUp,
  CircleChevronUp as LucideChevronUpCircle,
  SquareChevronUp as LucideChevronUpSquare,
  ChevronsDown as LucideChevronsDown,
  ChevronsDownUp as LucideChevronsDownUp,
  ChevronsLeft as LucideChevronsLeft,
  ChevronsLeftRight as LucideChevronsLeftRight,
  ChevronsLeftRightEllipsis as LucideChevronsLeftRightEllipsis,
  ChevronsRight as LucideChevronsRight,
  ChevronsRightLeft as LucideChevronsRightLeft,
  ChevronsUp as LucideChevronsUp,
  ChevronsUpDown as LucideChevronsUpDown,
  Chromium as LucideChrome,
  Chromium as LucideChromium,
  Church as LucideChurch,
  Cigarette as LucideCigarette,
  CigaretteOff as LucideCigaretteOff,
  Circle as LucideCircle,
  CircleAlert as LucideCircleAlert,
  CircleArrowDown as LucideCircleArrowDown,
  CircleArrowLeft as LucideCircleArrowLeft,
  CircleArrowOutDownLeft as LucideCircleArrowOutDownLeft,
  CircleArrowOutDownRight as LucideCircleArrowOutDownRight,
  CircleArrowOutUpLeft as LucideCircleArrowOutUpLeft,
  CircleArrowOutUpRight as LucideCircleArrowOutUpRight,
  CircleArrowRight as LucideCircleArrowRight,
  CircleArrowUp as LucideCircleArrowUp,
  CircleCheck as LucideCircleCheck,
  CircleCheckBig as LucideCircleCheckBig,
  CircleChevronDown as LucideCircleChevronDown,
  CircleChevronLeft as LucideCircleChevronLeft,
  CircleChevronRight as LucideCircleChevronRight,
  CircleChevronUp as LucideCircleChevronUp,
  CircleDashed as LucideCircleDashed,
  CircleDivide as LucideCircleDivide,
  CircleDollarSign as LucideCircleDollarSign,
  CircleDot as LucideCircleDot,
  CircleDotDashed as LucideCircleDotDashed,
  CircleEllipsis as LucideCircleEllipsis,
  CircleEqual as LucideCircleEqual,
  CircleFadingArrowUp as LucideCircleFadingArrowUp,
  CircleFadingPlus as LucideCircleFadingPlus,
  CircleGauge as LucideCircleGauge,
  CircleQuestionMark as LucideCircleHelp,
  CircleMinus as LucideCircleMinus,
  CircleOff as LucideCircleOff,
  CircleParking as LucideCircleParking,
  CircleParkingOff as LucideCircleParkingOff,
  CirclePause as LucideCirclePause,
  CirclePercent as LucideCirclePercent,
  CirclePile as LucideCirclePile,
  CirclePlay as LucideCirclePlay,
  CirclePlus as LucideCirclePlus,
  CirclePoundSterling as LucideCirclePoundSterling,
  CirclePower as LucideCirclePower,
  CircleQuestionMark as LucideCircleQuestionMark,
  CircleSlash as LucideCircleSlash,
  CircleSlash2 as LucideCircleSlash2,
  CircleSlash2 as LucideCircleSlashed,
  CircleSmall as LucideCircleSmall,
  CircleStar as LucideCircleStar,
  CircleStop as LucideCircleStop,
  CircleUser as LucideCircleUser,
  CircleUserRound as LucideCircleUserRound,
  CircleX as LucideCircleX,
  CircuitBoard as LucideCircuitBoard,
  Citrus as LucideCitrus,
  Clapperboard as LucideClapperboard,
  Clipboard as LucideClipboard,
  ClipboardCheck as LucideClipboardCheck,
  ClipboardClock as LucideClipboardClock,
  ClipboardCopy as LucideClipboardCopy,
  ClipboardPen as LucideClipboardEdit,
  ClipboardList as LucideClipboardList,
  ClipboardMinus as LucideClipboardMinus,
  ClipboardPaste as LucideClipboardPaste,
  ClipboardPen as LucideClipboardPen,
  ClipboardPenLine as LucideClipboardPenLine,
  ClipboardPlus as LucideClipboardPlus,
  ClipboardPenLine as LucideClipboardSignature,
  ClipboardType as LucideClipboardType,
  ClipboardX as LucideClipboardX,
  Clock as LucideClock,
  Clock1 as LucideClock1,
  Clock10 as LucideClock10,
  Clock11 as LucideClock11,
  Clock12 as LucideClock12,
  Clock2 as LucideClock2,
  Clock3 as LucideClock3,
  Clock4 as LucideClock4,
  Clock5 as LucideClock5,
  Clock6 as LucideClock6,
  Clock7 as LucideClock7,
  Clock8 as LucideClock8,
  Clock9 as LucideClock9,
  ClockAlert as LucideClockAlert,
  ClockArrowDown as LucideClockArrowDown,
  ClockArrowUp as LucideClockArrowUp,
  ClockCheck as LucideClockCheck,
  ClockFading as LucideClockFading,
  ClockPlus as LucideClockPlus,
  ClosedCaption as LucideClosedCaption,
  Cloud as LucideCloud,
  CloudAlert as LucideCloudAlert,
  CloudBackup as LucideCloudBackup,
  CloudCheck as LucideCloudCheck,
  CloudCog as LucideCloudCog,
  CloudDownload as LucideCloudDownload,
  CloudDrizzle as LucideCloudDrizzle,
  CloudFog as LucideCloudFog,
  CloudHail as LucideCloudHail,
  CloudLightning as LucideCloudLightning,
  CloudMoon as LucideCloudMoon,
  CloudMoonRain as LucideCloudMoonRain,
  CloudOff as LucideCloudOff,
  CloudRain as LucideCloudRain,
  CloudRainWind as LucideCloudRainWind,
  CloudSnow as LucideCloudSnow,
  CloudSun as LucideCloudSun,
  CloudSunRain as LucideCloudSunRain,
  CloudSync as LucideCloudSync,
  CloudUpload as LucideCloudUpload,
  Cloudy as LucideCloudy,
  Clover as LucideClover,
  Club as LucideClub,
  Code as LucideCode,
  CodeXml as LucideCode2,
  SquareCode as LucideCodeSquare,
  CodeXml as LucideCodeXml,
  Codepen as LucideCodepen,
  Codesandbox as LucideCodesandbox,
  Coffee as LucideCoffee,
  Cog as LucideCog,
  Coins as LucideCoins,
  Columns2 as LucideColumns,
  Columns2 as LucideColumns2,
  Columns3 as LucideColumns3,
  Columns3Cog as LucideColumns3Cog,
  Columns4 as LucideColumns4,
  Columns3Cog as LucideColumnsSettings,
  Combine as LucideCombine,
  Command as LucideCommand,
  Compass as LucideCompass,
  Component as LucideComponent,
  Computer as LucideComputer,
  ConciergeBell as LucideConciergeBell,
  Cone as LucideCone,
  Construction as LucideConstruction,
  Contact as LucideContact,
  ContactRound as LucideContact2,
  ContactRound as LucideContactRound,
  Container as LucideContainer,
  Contrast as LucideContrast,
  Cookie as LucideCookie,
  CookingPot as LucideCookingPot,
  Copy as LucideCopy,
  CopyCheck as LucideCopyCheck,
  CopyMinus as LucideCopyMinus,
  CopyPlus as LucideCopyPlus,
  CopySlash as LucideCopySlash,
  CopyX as LucideCopyX,
  Copyleft as LucideCopyleft,
  Copyright as LucideCopyright,
  CornerDownLeft as LucideCornerDownLeft,
  CornerDownRight as LucideCornerDownRight,
  CornerLeftDown as LucideCornerLeftDown,
  CornerLeftUp as LucideCornerLeftUp,
  CornerRightDown as LucideCornerRightDown,
  CornerRightUp as LucideCornerRightUp,
  CornerUpLeft as LucideCornerUpLeft,
  CornerUpRight as LucideCornerUpRight,
  Cpu as LucideCpu,
  CreativeCommons as LucideCreativeCommons,
  CreditCard as LucideCreditCard,
  Croissant as LucideCroissant,
  Crop as LucideCrop,
  Cross as LucideCross,
  Crosshair as LucideCrosshair,
  Crown as LucideCrown,
  Cuboid as LucideCuboid,
  CupSoda as LucideCupSoda,
  Braces as LucideCurlyBraces,
  Currency as LucideCurrency,
  Cylinder as LucideCylinder,
  Dam as LucideDam,
  Database as LucideDatabase,
  DatabaseBackup as LucideDatabaseBackup,
  DatabaseSearch as LucideDatabaseSearch,
  DatabaseZap as LucideDatabaseZap,
  DecimalsArrowLeft as LucideDecimalsArrowLeft,
  DecimalsArrowRight as LucideDecimalsArrowRight,
  Delete as LucideDelete,
  Dessert as LucideDessert,
  Diameter as LucideDiameter,
  Diamond as LucideDiamond,
  DiamondMinus as LucideDiamondMinus,
  DiamondPercent as LucideDiamondPercent,
  DiamondPlus as LucideDiamondPlus,
  Dice1 as LucideDice1,
  Dice2 as LucideDice2,
  Dice3 as LucideDice3,
  Dice4 as LucideDice4,
  Dice5 as LucideDice5,
  Dice6 as LucideDice6,
  Dices as LucideDices,
  Diff as LucideDiff,
  Disc as LucideDisc,
  Disc2 as LucideDisc2,
  Disc3 as LucideDisc3,
  DiscAlbum as LucideDiscAlbum,
  Divide as LucideDivide,
  CircleDivide as LucideDivideCircle,
  SquareDivide as LucideDivideSquare,
  Dna as LucideDna,
  DnaOff as LucideDnaOff,
  Dock as LucideDock,
  Dog as LucideDog,
  DollarSign as LucideDollarSign,
  Donut as LucideDonut,
  DoorClosed as LucideDoorClosed,
  DoorClosedLocked as LucideDoorClosedLocked,
  DoorOpen as LucideDoorOpen,
  Dot as LucideDot,
  SquareDot as LucideDotSquare,
  Download as LucideDownload,
  CloudDownload as LucideDownloadCloud,
  DraftingCompass as LucideDraftingCompass,
  Drama as LucideDrama,
  Dribbble as LucideDribbble,
  Drill as LucideDrill,
  Drone as LucideDrone,
  Droplet as LucideDroplet,
  DropletOff as LucideDropletOff,
  Droplets as LucideDroplets,
  Drum as LucideDrum,
  Drumstick as LucideDrumstick,
  Dumbbell as LucideDumbbell,
  Ear as LucideEar,
  EarOff as LucideEarOff,
  Earth as LucideEarth,
  EarthLock as LucideEarthLock,
  Eclipse as LucideEclipse,
  SquarePen as LucideEdit,
  Pen as LucideEdit2,
  PenLine as LucideEdit3,
  Egg as LucideEgg,
  EggFried as LucideEggFried,
  EggOff as LucideEggOff,
  Ellipsis as LucideEllipsis,
  EllipsisVertical as LucideEllipsisVertical,
  Equal as LucideEqual,
  EqualApproximately as LucideEqualApproximately,
  EqualNot as LucideEqualNot,
  SquareEqual as LucideEqualSquare,
  Eraser as LucideEraser,
  EthernetPort as LucideEthernetPort,
  Euro as LucideEuro,
  EvCharger as LucideEvCharger,
  Expand as LucideExpand,
  ExternalLink as LucideExternalLink,
  Eye as LucideEye,
  EyeClosed as LucideEyeClosed,
  EyeOff as LucideEyeOff,
  Facebook as LucideFacebook,
  Factory as LucideFactory,
  Fan as LucideFan,
  FastForward as LucideFastForward,
  Feather as LucideFeather,
  Fence as LucideFence,
  FerrisWheel as LucideFerrisWheel,
  Figma as LucideFigma,
  File as LucideFile,
  FileArchive as LucideFileArchive,
  FileHeadphone as LucideFileAudio,
  FileHeadphone as LucideFileAudio2,
  FileAxis3d as LucideFileAxis3D,
  FileAxis3d as LucideFileAxis3d,
  FileBadge as LucideFileBadge,
  FileBadge as LucideFileBadge2,
  FileChartColumnIncreasing as LucideFileBarChart,
  FileChartColumn as LucideFileBarChart2,
  FileBox as LucideFileBox,
  FileBraces as LucideFileBraces,
  FileBracesCorner as LucideFileBracesCorner,
  FileChartColumn as LucideFileChartColumn,
  FileChartColumnIncreasing as LucideFileChartColumnIncreasing,
  FileChartLine as LucideFileChartLine,
  FileChartPie as LucideFileChartPie,
  FileCheck as LucideFileCheck,
  FileCheckCorner as LucideFileCheck2,
  FileCheckCorner as LucideFileCheckCorner,
  FileClock as LucideFileClock,
  FileCode as LucideFileCode,
  FileCodeCorner as LucideFileCode2,
  FileCodeCorner as LucideFileCodeCorner,
  FileCog as LucideFileCog,
  FileCog as LucideFileCog2,
  FileDiff as LucideFileDiff,
  FileDigit as LucideFileDigit,
  FileDown as LucideFileDown,
  FilePen as LucideFileEdit,
  FileExclamationPoint as LucideFileExclamationPoint,
  FileHeadphone as LucideFileHeadphone,
  FileHeart as LucideFileHeart,
  FileImage as LucideFileImage,
  FileInput as LucideFileInput,
  FileBraces as LucideFileJson,
  FileBracesCorner as LucideFileJson2,
  FileKey as LucideFileKey,
  FileKey as LucideFileKey2,
  FileChartLine as LucideFileLineChart,
  FileLock as LucideFileLock,
  FileLock as LucideFileLock2,
  FileMinus as LucideFileMinus,
  FileMinusCorner as LucideFileMinus2,
  FileMinusCorner as LucideFileMinusCorner,
  FileMusic as LucideFileMusic,
  FileOutput as LucideFileOutput,
  FilePen as LucideFilePen,
  FilePenLine as LucideFilePenLine,
  FileChartPie as LucideFilePieChart,
  FilePlay as LucideFilePlay,
  FilePlus as LucideFilePlus,
  FilePlusCorner as LucideFilePlus2,
  FilePlusCorner as LucideFilePlusCorner,
  FileQuestionMark as LucideFileQuestion,
  FileQuestionMark as LucideFileQuestionMark,
  FileScan as LucideFileScan,
  FileSearch as LucideFileSearch,
  FileSearchCorner as LucideFileSearch2,
  FileSearchCorner as LucideFileSearchCorner,
  FileSignal as LucideFileSignal,
  FilePenLine as LucideFileSignature,
  FileSliders as LucideFileSliders,
  FileSpreadsheet as LucideFileSpreadsheet,
  FileStack as LucideFileStack,
  FileSymlink as LucideFileSymlink,
  FileTerminal as LucideFileTerminal,
  FileText as LucideFileText,
  FileType as LucideFileType,
  FileTypeCorner as LucideFileType2,
  FileTypeCorner as LucideFileTypeCorner,
  FileUp as LucideFileUp,
  FileUser as LucideFileUser,
  FilePlay as LucideFileVideo,
  FileVideoCamera as LucideFileVideo2,
  FileVideoCamera as LucideFileVideoCamera,
  FileVolume as LucideFileVolume,
  FileSignal as LucideFileVolume2,
  FileExclamationPoint as LucideFileWarning,
  FileX as LucideFileX,
  FileXCorner as LucideFileX2,
  FileXCorner as LucideFileXCorner,
  Files as LucideFiles,
  Film as LucideFilm,
  Funnel as LucideFilter,
  FunnelX as LucideFilterX,
  FingerprintPattern as LucideFingerprint,
  FingerprintPattern as LucideFingerprintPattern,
  FireExtinguisher as LucideFireExtinguisher,
  Fish as LucideFish,
  FishOff as LucideFishOff,
  FishSymbol as LucideFishSymbol,
  FishingHook as LucideFishingHook,
  Flag as LucideFlag,
  FlagOff as LucideFlagOff,
  FlagTriangleLeft as LucideFlagTriangleLeft,
  FlagTriangleRight as LucideFlagTriangleRight,
  Flame as LucideFlame,
  FlameKindling as LucideFlameKindling,
  Flashlight as LucideFlashlight,
  FlashlightOff as LucideFlashlightOff,
  FlaskConical as LucideFlaskConical,
  FlaskConicalOff as LucideFlaskConicalOff,
  FlaskRound as LucideFlaskRound,
  SquareCenterlineDashedHorizontal as LucideFlipHorizontal,
  FlipHorizontal2 as LucideFlipHorizontal2,
  SquareCenterlineDashedVertical as LucideFlipVertical,
  FlipVertical2 as LucideFlipVertical2,
  Flower as LucideFlower,
  Flower2 as LucideFlower2,
  Focus as LucideFocus,
  FoldHorizontal as LucideFoldHorizontal,
  FoldVertical as LucideFoldVertical,
  Folder as LucideFolder,
  FolderArchive as LucideFolderArchive,
  FolderCheck as LucideFolderCheck,
  FolderClock as LucideFolderClock,
  FolderClosed as LucideFolderClosed,
  FolderCode as LucideFolderCode,
  FolderCog as LucideFolderCog,
  FolderCog as LucideFolderCog2,
  FolderDot as LucideFolderDot,
  FolderDown as LucideFolderDown,
  FolderPen as LucideFolderEdit,
  FolderGit as LucideFolderGit,
  FolderGit2 as LucideFolderGit2,
  FolderHeart as LucideFolderHeart,
  FolderInput as LucideFolderInput,
  FolderKanban as LucideFolderKanban,
  FolderKey as LucideFolderKey,
  FolderLock as LucideFolderLock,
  FolderMinus as LucideFolderMinus,
  FolderOpen as LucideFolderOpen,
  FolderOpenDot as LucideFolderOpenDot,
  FolderOutput as LucideFolderOutput,
  FolderPen as LucideFolderPen,
  FolderPlus as LucideFolderPlus,
  FolderRoot as LucideFolderRoot,
  FolderSearch as LucideFolderSearch,
  FolderSearch2 as LucideFolderSearch2,
  FolderSymlink as LucideFolderSymlink,
  FolderSync as LucideFolderSync,
  FolderTree as LucideFolderTree,
  FolderUp as LucideFolderUp,
  FolderX as LucideFolderX,
  Folders as LucideFolders,
  Footprints as LucideFootprints,
  Utensils as LucideForkKnife,
  UtensilsCrossed as LucideForkKnifeCrossed,
  Forklift as LucideForklift,
  Form as LucideForm,
  RectangleEllipsis as LucideFormInput,
  Forward as LucideForward,
  Frame as LucideFrame,
  Framer as LucideFramer,
  Frown as LucideFrown,
  Fuel as LucideFuel,
  Fullscreen as LucideFullscreen,
  SquareFunction as LucideFunctionSquare,
  Funnel as LucideFunnel,
  FunnelPlus as LucideFunnelPlus,
  FunnelX as LucideFunnelX,
  GalleryHorizontal as LucideGalleryHorizontal,
  GalleryHorizontalEnd as LucideGalleryHorizontalEnd,
  GalleryThumbnails as LucideGalleryThumbnails,
  GalleryVertical as LucideGalleryVertical,
  GalleryVerticalEnd as LucideGalleryVerticalEnd,
  Gamepad as LucideGamepad,
  Gamepad2 as LucideGamepad2,
  GamepadDirectional as LucideGamepadDirectional,
  ChartNoAxesGantt as LucideGanttChart,
  SquareChartGantt as LucideGanttChartSquare,
  Gauge as LucideGauge,
  CircleGauge as LucideGaugeCircle,
  Gavel as LucideGavel,
  Gem as LucideGem,
  GeorgianLari as LucideGeorgianLari,
  Ghost as LucideGhost,
  Gift as LucideGift,
  GitBranch as LucideGitBranch,
  GitBranchMinus as LucideGitBranchMinus,
  GitBranchPlus as LucideGitBranchPlus,
  GitCommitHorizontal as LucideGitCommit,
  GitCommitHorizontal as LucideGitCommitHorizontal,
  GitCommitVertical as LucideGitCommitVertical,
  GitCompare as LucideGitCompare,
  GitCompareArrows as LucideGitCompareArrows,
  GitFork as LucideGitFork,
  GitGraph as LucideGitGraph,
  GitMerge as LucideGitMerge,
  GitMergeConflict as LucideGitMergeConflict,
  GitPullRequest as LucideGitPullRequest,
  GitPullRequestArrow as LucideGitPullRequestArrow,
  GitPullRequestClosed as LucideGitPullRequestClosed,
  GitPullRequestCreate as LucideGitPullRequestCreate,
  GitPullRequestCreateArrow as LucideGitPullRequestCreateArrow,
  GitPullRequestDraft as LucideGitPullRequestDraft,
  Github as LucideGithub,
  Gitlab as LucideGitlab,
  GlassWater as LucideGlassWater,
  Glasses as LucideGlasses,
  Globe as LucideGlobe,
  Earth as LucideGlobe2,
  GlobeLock as LucideGlobeLock,
  GlobeOff as LucideGlobeOff,
  GlobeX as LucideGlobeX,
  Goal as LucideGoal,
  Gpu as LucideGpu,
  HandGrab as LucideGrab,
  GraduationCap as LucideGraduationCap,
  Grape as LucideGrape,
  Grid3x3 as LucideGrid,
  Grid2x2 as LucideGrid2X2,
  Grid2x2Check as LucideGrid2X2Check,
  Grid2x2Plus as LucideGrid2X2Plus,
  Grid2x2X as LucideGrid2X2X,
  Grid2x2 as LucideGrid2x2,
  Grid2x2Check as LucideGrid2x2Check,
  Grid2x2Plus as LucideGrid2x2Plus,
  Grid2x2X as LucideGrid2x2X,
  Grid3x3 as LucideGrid3X3,
  Grid3x2 as LucideGrid3x2,
  Grid3x3 as LucideGrid3x3,
  Grip as LucideGrip,
  GripHorizontal as LucideGripHorizontal,
  GripVertical as LucideGripVertical,
  Group as LucideGroup,
  Guitar as LucideGuitar,
  Ham as LucideHam,
  Hamburger as LucideHamburger,
  Hammer as LucideHammer,
  Hand as LucideHand,
  HandCoins as LucideHandCoins,
  HandFist as LucideHandFist,
  HandGrab as LucideHandGrab,
  HandHeart as LucideHandHeart,
  HandHelping as LucideHandHelping,
  HandMetal as LucideHandMetal,
  HandPlatter as LucideHandPlatter,
  Handbag as LucideHandbag,
  Handshake as LucideHandshake,
  HardDrive as LucideHardDrive,
  HardDriveDownload as LucideHardDriveDownload,
  HardDriveUpload as LucideHardDriveUpload,
  HardHat as LucideHardHat,
  Hash as LucideHash,
  HatGlasses as LucideHatGlasses,
  Haze as LucideHaze,
  Hd as LucideHd,
  HdmiPort as LucideHdmiPort,
  Heading as LucideHeading,
  Heading1 as LucideHeading1,
  Heading2 as LucideHeading2,
  Heading3 as LucideHeading3,
  Heading4 as LucideHeading4,
  Heading5 as LucideHeading5,
  Heading6 as LucideHeading6,
  HeadphoneOff as LucideHeadphoneOff,
  Headphones as LucideHeadphones,
  Headset as LucideHeadset,
  Heart as LucideHeart,
  HeartCrack as LucideHeartCrack,
  HeartHandshake as LucideHeartHandshake,
  HeartMinus as LucideHeartMinus,
  HeartOff as LucideHeartOff,
  HeartPlus as LucideHeartPlus,
  HeartPulse as LucideHeartPulse,
  Heater as LucideHeater,
  Helicopter as LucideHelicopter,
  CircleQuestionMark as LucideHelpCircle,
  HandHelping as LucideHelpingHand,
  Hexagon as LucideHexagon,
  Highlighter as LucideHighlighter,
  History as LucideHistory,
  House as LucideHome,
  Hop as LucideHop,
  HopOff as LucideHopOff,
  Hospital as LucideHospital,
  Hotel as LucideHotel,
  Hourglass as LucideHourglass,
  House as LucideHouse,
  HouseHeart as LucideHouseHeart,
  HousePlug as LucideHousePlug,
  HousePlus as LucideHousePlus,
  HouseWifi as LucideHouseWifi,
  IceCreamCone as LucideIceCream,
  IceCreamBowl as LucideIceCream2,
  IceCreamBowl as LucideIceCreamBowl,
  IceCreamCone as LucideIceCreamCone,
  IdCard as LucideIdCard,
  IdCardLanyard as LucideIdCardLanyard,
  Image as LucideImage,
  ImageDown as LucideImageDown,
  ImageMinus as LucideImageMinus,
  ImageOff as LucideImageOff,
  ImagePlay as LucideImagePlay,
  ImagePlus as LucideImagePlus,
  ImageUp as LucideImageUp,
  ImageUpscale as LucideImageUpscale,
  Images as LucideImages,
  Import as LucideImport,
  Inbox as LucideInbox,
  ListIndentIncrease as LucideIndent,
  ListIndentDecrease as LucideIndentDecrease,
  ListIndentIncrease as LucideIndentIncrease,
  IndianRupee as LucideIndianRupee,
  Infinity as LucideInfinity,
  Info as LucideInfo,
  SquareMousePointer as LucideInspect,
  InspectionPanel as LucideInspectionPanel,
  Instagram as LucideInstagram,
  Italic as LucideItalic,
  IterationCcw as LucideIterationCcw,
  IterationCw as LucideIterationCw,
  JapaneseYen as LucideJapaneseYen,
  Joystick as LucideJoystick,
  Kanban as LucideKanban,
  SquareKanban as LucideKanbanSquare,
  SquareDashedKanban as LucideKanbanSquareDashed,
  Kayak as LucideKayak,
  Key as LucideKey,
  KeyRound as LucideKeyRound,
  KeySquare as LucideKeySquare,
  Keyboard as LucideKeyboard,
  KeyboardMusic as LucideKeyboardMusic,
  KeyboardOff as LucideKeyboardOff,
  Lamp as LucideLamp,
  LampCeiling as LucideLampCeiling,
  LampDesk as LucideLampDesk,
  LampFloor as LucideLampFloor,
  LampWallDown as LucideLampWallDown,
  LampWallUp as LucideLampWallUp,
  LandPlot as LucideLandPlot,
  Landmark as LucideLandmark,
  Languages as LucideLanguages,
  Laptop as LucideLaptop,
  LaptopMinimal as LucideLaptop2,
  LaptopMinimal as LucideLaptopMinimal,
  LaptopMinimalCheck as LucideLaptopMinimalCheck,
  Lasso as LucideLasso,
  LassoSelect as LucideLassoSelect,
  Laugh as LucideLaugh,
  Layers as LucideLayers,
  Layers2 as LucideLayers2,
  Layers as LucideLayers3,
  LayersPlus as LucideLayersPlus,
  PanelsTopLeft as LucideLayout,
  LayoutDashboard as LucideLayoutDashboard,
  LayoutGrid as LucideLayoutGrid,
  LayoutList as LucideLayoutList,
  LayoutPanelLeft as LucideLayoutPanelLeft,
  LayoutPanelTop as LucideLayoutPanelTop,
  LayoutTemplate as LucideLayoutTemplate,
  Leaf as LucideLeaf,
  LeafyGreen as LucideLeafyGreen,
  Lectern as LucideLectern,
  LensConcave as LucideLensConcave,
  LensConvex as LucideLensConvex,
  TextInitial as LucideLetterText,
  Library as LucideLibrary,
  LibraryBig as LucideLibraryBig,
  SquareLibrary as LucideLibrarySquare,
  LifeBuoy as LucideLifeBuoy,
  Ligature as LucideLigature,
  Lightbulb as LucideLightbulb,
  LightbulbOff as LucideLightbulbOff,
  ChartLine as LucideLineChart,
  LineDotRightHorizontal as LucideLineDotRightHorizontal,
  LineSquiggle as LucideLineSquiggle,
  Link as LucideLink,
  Link2 as LucideLink2,
  Link2Off as LucideLink2Off,
  Linkedin as LucideLinkedin,
  List as LucideList,
  ListCheck as LucideListCheck,
  ListChecks as LucideListChecks,
  ListChevronsDownUp as LucideListChevronsDownUp,
  ListChevronsUpDown as LucideListChevronsUpDown,
  ListCollapse as LucideListCollapse,
  ListEnd as LucideListEnd,
  ListFilter as LucideListFilter,
  ListFilterPlus as LucideListFilterPlus,
  ListIndentDecrease as LucideListIndentDecrease,
  ListIndentIncrease as LucideListIndentIncrease,
  ListMinus as LucideListMinus,
  ListMusic as LucideListMusic,
  ListOrdered as LucideListOrdered,
  ListPlus as LucideListPlus,
  ListRestart as LucideListRestart,
  ListStart as LucideListStart,
  ListTodo as LucideListTodo,
  ListTree as LucideListTree,
  ListVideo as LucideListVideo,
  ListX as LucideListX,
  Loader as LucideLoader,
  LoaderCircle as LucideLoader2,
  LoaderCircle as LucideLoaderCircle,
  LoaderPinwheel as LucideLoaderPinwheel,
  Locate as LucideLocate,
  LocateFixed as LucideLocateFixed,
  LocateOff as LucideLocateOff,
  MapPinPen as LucideLocationEdit,
  Lock as LucideLock,
  LockKeyhole as LucideLockKeyhole,
  LockKeyholeOpen as LucideLockKeyholeOpen,
  LockOpen as LucideLockOpen,
  LogIn as LucideLogIn,
  LogOut as LucideLogOut,
  Logs as LucideLogs,
  Lollipop as LucideLollipop,
  Luggage as LucideLuggage,
  SquareM as LucideMSquare,
  Magnet as LucideMagnet,
  Mail as LucideMail,
  MailCheck as LucideMailCheck,
  MailMinus as LucideMailMinus,
  MailOpen as LucideMailOpen,
  MailPlus as LucideMailPlus,
  MailQuestionMark as LucideMailQuestion,
  MailQuestionMark as LucideMailQuestionMark,
  MailSearch as LucideMailSearch,
  MailWarning as LucideMailWarning,
  MailX as LucideMailX,
  Mailbox as LucideMailbox,
  Mails as LucideMails,
  Map as LucideMap,
  MapMinus as LucideMapMinus,
  MapPin as LucideMapPin,
  MapPinCheck as LucideMapPinCheck,
  MapPinCheckInside as LucideMapPinCheckInside,
  MapPinHouse as LucideMapPinHouse,
  MapPinMinus as LucideMapPinMinus,
  MapPinMinusInside as LucideMapPinMinusInside,
  MapPinOff as LucideMapPinOff,
  MapPinPen as LucideMapPinPen,
  MapPinPlus as LucideMapPinPlus,
  MapPinPlusInside as LucideMapPinPlusInside,
  MapPinX as LucideMapPinX,
  MapPinXInside as LucideMapPinXInside,
  MapPinned as LucideMapPinned,
  MapPlus as LucideMapPlus,
  Mars as LucideMars,
  MarsStroke as LucideMarsStroke,
  Martini as LucideMartini,
  Maximize as LucideMaximize,
  Maximize2 as LucideMaximize2,
  Medal as LucideMedal,
  Megaphone as LucideMegaphone,
  MegaphoneOff as LucideMegaphoneOff,
  Meh as LucideMeh,
  MemoryStick as LucideMemoryStick,
  Menu as LucideMenu,
  SquareMenu as LucideMenuSquare,
  Merge as LucideMerge,
  MessageCircle as LucideMessageCircle,
  MessageCircleCheck as LucideMessageCircleCheck,
  MessageCircleCode as LucideMessageCircleCode,
  MessageCircleDashed as LucideMessageCircleDashed,
  MessageCircleHeart as LucideMessageCircleHeart,
  MessageCircleMore as LucideMessageCircleMore,
  MessageCircleOff as LucideMessageCircleOff,
  MessageCirclePlus as LucideMessageCirclePlus,
  MessageCircleQuestionMark as LucideMessageCircleQuestion,
  MessageCircleQuestionMark as LucideMessageCircleQuestionMark,
  MessageCircleReply as LucideMessageCircleReply,
  MessageCircleWarning as LucideMessageCircleWarning,
  MessageCircleX as LucideMessageCircleX,
  MessageSquare as LucideMessageSquare,
  MessageSquareCheck as LucideMessageSquareCheck,
  MessageSquareCode as LucideMessageSquareCode,
  MessageSquareDashed as LucideMessageSquareDashed,
  MessageSquareDiff as LucideMessageSquareDiff,
  MessageSquareDot as LucideMessageSquareDot,
  MessageSquareHeart as LucideMessageSquareHeart,
  MessageSquareLock as LucideMessageSquareLock,
  MessageSquareMore as LucideMessageSquareMore,
  MessageSquareOff as LucideMessageSquareOff,
  MessageSquarePlus as LucideMessageSquarePlus,
  MessageSquareQuote as LucideMessageSquareQuote,
  MessageSquareReply as LucideMessageSquareReply,
  MessageSquareShare as LucideMessageSquareShare,
  MessageSquareText as LucideMessageSquareText,
  MessageSquareWarning as LucideMessageSquareWarning,
  MessageSquareX as LucideMessageSquareX,
  MessagesSquare as LucideMessagesSquare,
  Metronome as LucideMetronome,
  Mic as LucideMic,
  MicVocal as LucideMic2,
  MicOff as LucideMicOff,
  MicVocal as LucideMicVocal,
  Microchip as LucideMicrochip,
  Microscope as LucideMicroscope,
  Microwave as LucideMicrowave,
  Milestone as LucideMilestone,
  Milk as LucideMilk,
  MilkOff as LucideMilkOff,
  Minimize as LucideMinimize,
  Minimize2 as LucideMinimize2,
  Minus as LucideMinus,
  CircleMinus as LucideMinusCircle,
  SquareMinus as LucideMinusSquare,
  MirrorRectangular as LucideMirrorRectangular,
  MirrorRound as LucideMirrorRound,
  Monitor as LucideMonitor,
  MonitorCheck as LucideMonitorCheck,
  MonitorCloud as LucideMonitorCloud,
  MonitorCog as LucideMonitorCog,
  MonitorDot as LucideMonitorDot,
  MonitorDown as LucideMonitorDown,
  MonitorOff as LucideMonitorOff,
  MonitorPause as LucideMonitorPause,
  MonitorPlay as LucideMonitorPlay,
  MonitorSmartphone as LucideMonitorSmartphone,
  MonitorSpeaker as LucideMonitorSpeaker,
  MonitorStop as LucideMonitorStop,
  MonitorUp as LucideMonitorUp,
  MonitorX as LucideMonitorX,
  Moon as LucideMoon,
  MoonStar as LucideMoonStar,
  Ellipsis as LucideMoreHorizontal,
  EllipsisVertical as LucideMoreVertical,
  Motorbike as LucideMotorbike,
  Mountain as LucideMountain,
  MountainSnow as LucideMountainSnow,
  Mouse as LucideMouse,
  MouseLeft as LucideMouseLeft,
  MouseOff as LucideMouseOff,
  MousePointer as LucideMousePointer,
  MousePointer2 as LucideMousePointer2,
  MousePointer2Off as LucideMousePointer2Off,
  MousePointerBan as LucideMousePointerBan,
  MousePointerClick as LucideMousePointerClick,
  SquareDashedMousePointer as LucideMousePointerSquareDashed,
  MouseRight as LucideMouseRight,
  Move as LucideMove,
  Move3d as LucideMove3D,
  Move3d as LucideMove3d,
  MoveDiagonal as LucideMoveDiagonal,
  MoveDiagonal2 as LucideMoveDiagonal2,
  MoveDown as LucideMoveDown,
  MoveDownLeft as LucideMoveDownLeft,
  MoveDownRight as LucideMoveDownRight,
  MoveHorizontal as LucideMoveHorizontal,
  MoveLeft as LucideMoveLeft,
  MoveRight as LucideMoveRight,
  MoveUp as LucideMoveUp,
  MoveUpLeft as LucideMoveUpLeft,
  MoveUpRight as LucideMoveUpRight,
  MoveVertical as LucideMoveVertical,
  Music as LucideMusic,
  Music2 as LucideMusic2,
  Music3 as LucideMusic3,
  Music4 as LucideMusic4,
  Navigation as LucideNavigation,
  Navigation2 as LucideNavigation2,
  Navigation2Off as LucideNavigation2Off,
  NavigationOff as LucideNavigationOff,
  Network as LucideNetwork,
  Newspaper as LucideNewspaper,
  Nfc as LucideNfc,
  NonBinary as LucideNonBinary,
  Notebook as LucideNotebook,
  NotebookPen as LucideNotebookPen,
  NotebookTabs as LucideNotebookTabs,
  NotebookText as LucideNotebookText,
  NotepadText as LucideNotepadText,
  NotepadTextDashed as LucideNotepadTextDashed,
  Nut as LucideNut,
  NutOff as LucideNutOff,
  Octagon as LucideOctagon,
  OctagonAlert as LucideOctagonAlert,
  OctagonMinus as LucideOctagonMinus,
  OctagonPause as LucideOctagonPause,
  OctagonX as LucideOctagonX,
  Omega as LucideOmega,
  Option as LucideOption,
  Orbit as LucideOrbit,
  Origami as LucideOrigami,
  ListIndentDecrease as LucideOutdent,
  Package as LucidePackage,
  Package2 as LucidePackage2,
  PackageCheck as LucidePackageCheck,
  PackageMinus as LucidePackageMinus,
  PackageOpen as LucidePackageOpen,
  PackagePlus as LucidePackagePlus,
  PackageSearch as LucidePackageSearch,
  PackageX as LucidePackageX,
  PaintBucket as LucidePaintBucket,
  PaintRoller as LucidePaintRoller,
  Paintbrush as LucidePaintbrush,
  PaintbrushVertical as LucidePaintbrush2,
  PaintbrushVertical as LucidePaintbrushVertical,
  Palette as LucidePalette,
  TreePalm as LucidePalmtree,
  Panda as LucidePanda,
  PanelBottom as LucidePanelBottom,
  PanelBottomClose as LucidePanelBottomClose,
  PanelBottomDashed as LucidePanelBottomDashed,
  PanelBottomDashed as LucidePanelBottomInactive,
  PanelBottomOpen as LucidePanelBottomOpen,
  PanelLeft as LucidePanelLeft,
  PanelLeftClose as LucidePanelLeftClose,
  PanelLeftDashed as LucidePanelLeftDashed,
  PanelLeftDashed as LucidePanelLeftInactive,
  PanelLeftOpen as LucidePanelLeftOpen,
  PanelLeftRightDashed as LucidePanelLeftRightDashed,
  PanelRight as LucidePanelRight,
  PanelRightClose as LucidePanelRightClose,
  PanelRightDashed as LucidePanelRightDashed,
  PanelRightDashed as LucidePanelRightInactive,
  PanelRightOpen as LucidePanelRightOpen,
  PanelTop as LucidePanelTop,
  PanelTopBottomDashed as LucidePanelTopBottomDashed,
  PanelTopClose as LucidePanelTopClose,
  PanelTopDashed as LucidePanelTopDashed,
  PanelTopDashed as LucidePanelTopInactive,
  PanelTopOpen as LucidePanelTopOpen,
  PanelsLeftBottom as LucidePanelsLeftBottom,
  Columns3 as LucidePanelsLeftRight,
  PanelsRightBottom as LucidePanelsRightBottom,
  Rows3 as LucidePanelsTopBottom,
  PanelsTopLeft as LucidePanelsTopLeft,
  Paperclip as LucidePaperclip,
  Parentheses as LucideParentheses,
  CircleParking as LucideParkingCircle,
  CircleParkingOff as LucideParkingCircleOff,
  ParkingMeter as LucideParkingMeter,
  SquareParking as LucideParkingSquare,
  SquareParkingOff as LucideParkingSquareOff,
  PartyPopper as LucidePartyPopper,
  Pause as LucidePause,
  CirclePause as LucidePauseCircle,
  OctagonPause as LucidePauseOctagon,
  PawPrint as LucidePawPrint,
  PcCase as LucidePcCase,
  Pen as LucidePen,
  SquarePen as LucidePenBox,
  PenLine as LucidePenLine,
  PenOff as LucidePenOff,
  SquarePen as LucidePenSquare,
  PenTool as LucidePenTool,
  Pencil as LucidePencil,
  PencilLine as LucidePencilLine,
  PencilOff as LucidePencilOff,
  PencilRuler as LucidePencilRuler,
  Pentagon as LucidePentagon,
  Percent as LucidePercent,
  CirclePercent as LucidePercentCircle,
  DiamondPercent as LucidePercentDiamond,
  SquarePercent as LucidePercentSquare,
  PersonStanding as LucidePersonStanding,
  PhilippinePeso as LucidePhilippinePeso,
  Phone as LucidePhone,
  PhoneCall as LucidePhoneCall,
  PhoneForwarded as LucidePhoneForwarded,
  PhoneIncoming as LucidePhoneIncoming,
  PhoneMissed as LucidePhoneMissed,
  PhoneOff as LucidePhoneOff,
  PhoneOutgoing as LucidePhoneOutgoing,
  Pi as LucidePi,
  SquarePi as LucidePiSquare,
  Piano as LucidePiano,
  Pickaxe as LucidePickaxe,
  PictureInPicture as LucidePictureInPicture,
  PictureInPicture2 as LucidePictureInPicture2,
  ChartPie as LucidePieChart,
  PiggyBank as LucidePiggyBank,
  Pilcrow as LucidePilcrow,
  PilcrowLeft as LucidePilcrowLeft,
  PilcrowRight as LucidePilcrowRight,
  SquarePilcrow as LucidePilcrowSquare,
  Pill as LucidePill,
  PillBottle as LucidePillBottle,
  Pin as LucidePin,
  PinOff as LucidePinOff,
  Pipette as LucidePipette,
  Pizza as LucidePizza,
  Plane as LucidePlane,
  PlaneLanding as LucidePlaneLanding,
  PlaneTakeoff as LucidePlaneTakeoff,
  Play as LucidePlay,
  CirclePlay as LucidePlayCircle,
  SquarePlay as LucidePlaySquare,
  Plug as LucidePlug,
  Plug2 as LucidePlug2,
  PlugZap as LucidePlugZap,
  PlugZap as LucidePlugZap2,
  Plus as LucidePlus,
  CirclePlus as LucidePlusCircle,
  SquarePlus as LucidePlusSquare,
  Pocket as LucidePocket,
  PocketKnife as LucidePocketKnife,
  Podcast as LucidePodcast,
  Pointer as LucidePointer,
  PointerOff as LucidePointerOff,
  Popcorn as LucidePopcorn,
  Popsicle as LucidePopsicle,
  PoundSterling as LucidePoundSterling,
  Power as LucidePower,
  CirclePower as LucidePowerCircle,
  PowerOff as LucidePowerOff,
  SquarePower as LucidePowerSquare,
  Presentation as LucidePresentation,
  Printer as LucidePrinter,
  PrinterCheck as LucidePrinterCheck,
  PrinterX as LucidePrinterX,
  Projector as LucideProjector,
  Proportions as LucideProportions,
  Puzzle as LucidePuzzle,
  Pyramid as LucidePyramid,
  QrCode as LucideQrCode,
  Quote as LucideQuote,
  Rabbit as LucideRabbit,
  Radar as LucideRadar,
  Radiation as LucideRadiation,
  Radical as LucideRadical,
  Radio as LucideRadio,
  RadioReceiver as LucideRadioReceiver,
  RadioTower as LucideRadioTower,
  Radius as LucideRadius,
  RailSymbol as LucideRailSymbol,
  Rainbow as LucideRainbow,
  Rat as LucideRat,
  Ratio as LucideRatio,
  Receipt as LucideReceipt,
  ReceiptCent as LucideReceiptCent,
  ReceiptEuro as LucideReceiptEuro,
  ReceiptIndianRupee as LucideReceiptIndianRupee,
  ReceiptJapaneseYen as LucideReceiptJapaneseYen,
  ReceiptPoundSterling as LucideReceiptPoundSterling,
  ReceiptRussianRuble as LucideReceiptRussianRuble,
  ReceiptSwissFranc as LucideReceiptSwissFranc,
  ReceiptText as LucideReceiptText,
  ReceiptTurkishLira as LucideReceiptTurkishLira,
  RectangleCircle as LucideRectangleCircle,
  RectangleEllipsis as LucideRectangleEllipsis,
  RectangleGoggles as LucideRectangleGoggles,
  RectangleHorizontal as LucideRectangleHorizontal,
  RectangleVertical as LucideRectangleVertical,
  Recycle as LucideRecycle,
  Redo as LucideRedo,
  Redo2 as LucideRedo2,
  RedoDot as LucideRedoDot,
  RefreshCcw as LucideRefreshCcw,
  RefreshCcwDot as LucideRefreshCcwDot,
  RefreshCw as LucideRefreshCw,
  RefreshCwOff as LucideRefreshCwOff,
  Refrigerator as LucideRefrigerator,
  Regex as LucideRegex,
  RemoveFormatting as LucideRemoveFormatting,
  Repeat as LucideRepeat,
  Repeat1 as LucideRepeat1,
  Repeat2 as LucideRepeat2,
  Replace as LucideReplace,
  ReplaceAll as LucideReplaceAll,
  Reply as LucideReply,
  ReplyAll as LucideReplyAll,
  Rewind as LucideRewind,
  Ribbon as LucideRibbon,
  Rocket as LucideRocket,
  RockingChair as LucideRockingChair,
  RollerCoaster as LucideRollerCoaster,
  Rose as LucideRose,
  Rotate3d as LucideRotate3D,
  Rotate3d as LucideRotate3d,
  RotateCcw as LucideRotateCcw,
  RotateCcwKey as LucideRotateCcwKey,
  RotateCcwSquare as LucideRotateCcwSquare,
  RotateCw as LucideRotateCw,
  RotateCwSquare as LucideRotateCwSquare,
  Route as LucideRoute,
  RouteOff as LucideRouteOff,
  Router as LucideRouter,
  Rows2 as LucideRows,
  Rows2 as LucideRows2,
  Rows3 as LucideRows3,
  Rows4 as LucideRows4,
  Rss as LucideRss,
  Ruler as LucideRuler,
  RulerDimensionLine as LucideRulerDimensionLine,
  RussianRuble as LucideRussianRuble,
  Sailboat as LucideSailboat,
  Salad as LucideSalad,
  Sandwich as LucideSandwich,
  Satellite as LucideSatellite,
  SatelliteDish as LucideSatelliteDish,
  SaudiRiyal as LucideSaudiRiyal,
  Save as LucideSave,
  SaveAll as LucideSaveAll,
  SaveOff as LucideSaveOff,
  Scale as LucideScale,
  Scale3d as LucideScale3D,
  Scale3d as LucideScale3d,
  Scaling as LucideScaling,
  Scan as LucideScan,
  ScanBarcode as LucideScanBarcode,
  ScanEye as LucideScanEye,
  ScanFace as LucideScanFace,
  ScanHeart as LucideScanHeart,
  ScanLine as LucideScanLine,
  ScanQrCode as LucideScanQrCode,
  ScanSearch as LucideScanSearch,
  ScanText as LucideScanText,
  ChartScatter as LucideScatterChart,
  School as LucideSchool,
  University as LucideSchool2,
  Scissors as LucideScissors,
  ScissorsLineDashed as LucideScissorsLineDashed,
  SquareScissors as LucideScissorsSquare,
  SquareBottomDashedScissors as LucideScissorsSquareDashedBottom,
  Scooter as LucideScooter,
  ScreenShare as LucideScreenShare,
  ScreenShareOff as LucideScreenShareOff,
  Scroll as LucideScroll,
  ScrollText as LucideScrollText,
  Search as LucideSearch,
  SearchAlert as LucideSearchAlert,
  SearchCheck as LucideSearchCheck,
  SearchCode as LucideSearchCode,
  SearchSlash as LucideSearchSlash,
  SearchX as LucideSearchX,
  Section as LucideSection,
  Send as LucideSend,
  SendHorizontal as LucideSendHorizonal,
  SendHorizontal as LucideSendHorizontal,
  SendToBack as LucideSendToBack,
  SeparatorHorizontal as LucideSeparatorHorizontal,
  SeparatorVertical as LucideSeparatorVertical,
  Server as LucideServer,
  ServerCog as LucideServerCog,
  ServerCrash as LucideServerCrash,
  ServerOff as LucideServerOff,
  Settings as LucideSettings,
  Settings2 as LucideSettings2,
  Shapes as LucideShapes,
  Share as LucideShare,
  Share2 as LucideShare2,
  Sheet as LucideSheet,
  Shell as LucideShell,
  ShelvingUnit as LucideShelvingUnit,
  Shield as LucideShield,
  ShieldAlert as LucideShieldAlert,
  ShieldBan as LucideShieldBan,
  ShieldCheck as LucideShieldCheck,
  ShieldX as LucideShieldClose,
  ShieldEllipsis as LucideShieldEllipsis,
  ShieldHalf as LucideShieldHalf,
  ShieldMinus as LucideShieldMinus,
  ShieldOff as LucideShieldOff,
  ShieldPlus as LucideShieldPlus,
  ShieldQuestionMark as LucideShieldQuestion,
  ShieldQuestionMark as LucideShieldQuestionMark,
  ShieldUser as LucideShieldUser,
  ShieldX as LucideShieldX,
  Ship as LucideShip,
  ShipWheel as LucideShipWheel,
  Shirt as LucideShirt,
  ShoppingBag as LucideShoppingBag,
  ShoppingBasket as LucideShoppingBasket,
  ShoppingCart as LucideShoppingCart,
  Shovel as LucideShovel,
  ShowerHead as LucideShowerHead,
  Shredder as LucideShredder,
  Shrimp as LucideShrimp,
  Shrink as LucideShrink,
  Shrub as LucideShrub,
  Shuffle as LucideShuffle,
  PanelLeft as LucideSidebar,
  PanelLeftClose as LucideSidebarClose,
  PanelLeftOpen as LucideSidebarOpen,
  Sigma as LucideSigma,
  SquareSigma as LucideSigmaSquare,
  Signal as LucideSignal,
  SignalHigh as LucideSignalHigh,
  SignalLow as LucideSignalLow,
  SignalMedium as LucideSignalMedium,
  SignalZero as LucideSignalZero,
  Signature as LucideSignature,
  Signpost as LucideSignpost,
  SignpostBig as LucideSignpostBig,
  Siren as LucideSiren,
  SkipBack as LucideSkipBack,
  SkipForward as LucideSkipForward,
  Skull as LucideSkull,
  Slack as LucideSlack,
  Slash as LucideSlash,
  SquareSlash as LucideSlashSquare,
  Slice as LucideSlice,
  SlidersVertical as LucideSliders,
  SlidersHorizontal as LucideSlidersHorizontal,
  SlidersVertical as LucideSlidersVertical,
  Smartphone as LucideSmartphone,
  SmartphoneCharging as LucideSmartphoneCharging,
  SmartphoneNfc as LucideSmartphoneNfc,
  Smile as LucideSmile,
  SmilePlus as LucideSmilePlus,
  Snail as LucideSnail,
  Snowflake as LucideSnowflake,
  SoapDispenserDroplet as LucideSoapDispenserDroplet,
  Sofa as LucideSofa,
  SolarPanel as LucideSolarPanel,
  ArrowUpNarrowWide as LucideSortAsc,
  ArrowDownWideNarrow as LucideSortDesc,
  Soup as LucideSoup,
  Space as LucideSpace,
  Spade as LucideSpade,
  Sparkle as LucideSparkle,
  Sparkles as LucideSparkles,
  Speaker as LucideSpeaker,
  Speech as LucideSpeech,
  SpellCheck as LucideSpellCheck,
  SpellCheck2 as LucideSpellCheck2,
  Spline as LucideSpline,
  SplinePointer as LucideSplinePointer,
  Split as LucideSplit,
  SquareSplitHorizontal as LucideSplitSquareHorizontal,
  SquareSplitVertical as LucideSplitSquareVertical,
  Spool as LucideSpool,
  Spotlight as LucideSpotlight,
  SprayCan as LucideSprayCan,
  Sprout as LucideSprout,
  Square as LucideSquare,
  SquareActivity as LucideSquareActivity,
  SquareArrowDown as LucideSquareArrowDown,
  SquareArrowDownLeft as LucideSquareArrowDownLeft,
  SquareArrowDownRight as LucideSquareArrowDownRight,
  SquareArrowLeft as LucideSquareArrowLeft,
  SquareArrowOutDownLeft as LucideSquareArrowOutDownLeft,
  SquareArrowOutDownRight as LucideSquareArrowOutDownRight,
  SquareArrowOutUpLeft as LucideSquareArrowOutUpLeft,
  SquareArrowOutUpRight as LucideSquareArrowOutUpRight,
  SquareArrowRight as LucideSquareArrowRight,
  SquareArrowRightEnter as LucideSquareArrowRightEnter,
  SquareArrowRightExit as LucideSquareArrowRightExit,
  SquareArrowUp as LucideSquareArrowUp,
  SquareArrowUpLeft as LucideSquareArrowUpLeft,
  SquareArrowUpRight as LucideSquareArrowUpRight,
  SquareAsterisk as LucideSquareAsterisk,
  SquareBottomDashedScissors as LucideSquareBottomDashedScissors,
  SquareCenterlineDashedHorizontal as LucideSquareCenterlineDashedHorizontal,
  SquareCenterlineDashedVertical as LucideSquareCenterlineDashedVertical,
  SquareChartGantt as LucideSquareChartGantt,
  SquareCheck as LucideSquareCheck,
  SquareCheckBig as LucideSquareCheckBig,
  SquareChevronDown as LucideSquareChevronDown,
  SquareChevronLeft as LucideSquareChevronLeft,
  SquareChevronRight as LucideSquareChevronRight,
  SquareChevronUp as LucideSquareChevronUp,
  SquareCode as LucideSquareCode,
  SquareDashed as LucideSquareDashed,
  SquareDashedBottom as LucideSquareDashedBottom,
  SquareDashedBottomCode as LucideSquareDashedBottomCode,
  SquareDashedKanban as LucideSquareDashedKanban,
  SquareDashedMousePointer as LucideSquareDashedMousePointer,
  SquareDashedTopSolid as LucideSquareDashedTopSolid,
  SquareDivide as LucideSquareDivide,
  SquareDot as LucideSquareDot,
  SquareEqual as LucideSquareEqual,
  SquareFunction as LucideSquareFunction,
  SquareChartGantt as LucideSquareGanttChart,
  SquareKanban as LucideSquareKanban,
  SquareLibrary as LucideSquareLibrary,
  SquareM as LucideSquareM,
  SquareMenu as LucideSquareMenu,
  SquareMinus as LucideSquareMinus,
  SquareMousePointer as LucideSquareMousePointer,
  SquareParking as LucideSquareParking,
  SquareParkingOff as LucideSquareParkingOff,
  SquarePause as LucideSquarePause,
  SquarePen as LucideSquarePen,
  SquarePercent as LucideSquarePercent,
  SquarePi as LucideSquarePi,
  SquarePilcrow as LucideSquarePilcrow,
  SquarePlay as LucideSquarePlay,
  SquarePlus as LucideSquarePlus,
  SquarePower as LucideSquarePower,
  SquareRadical as LucideSquareRadical,
  SquareRoundCorner as LucideSquareRoundCorner,
  SquareScissors as LucideSquareScissors,
  SquareSigma as LucideSquareSigma,
  SquareSlash as LucideSquareSlash,
  SquareSplitHorizontal as LucideSquareSplitHorizontal,
  SquareSplitVertical as LucideSquareSplitVertical,
  SquareSquare as LucideSquareSquare,
  SquareStack as LucideSquareStack,
  SquareStar as LucideSquareStar,
  SquareStop as LucideSquareStop,
  SquareTerminal as LucideSquareTerminal,
  SquareUser as LucideSquareUser,
  SquareUserRound as LucideSquareUserRound,
  SquareX as LucideSquareX,
  SquaresExclude as LucideSquaresExclude,
  SquaresIntersect as LucideSquaresIntersect,
  SquaresSubtract as LucideSquaresSubtract,
  SquaresUnite as LucideSquaresUnite,
  Squircle as LucideSquircle,
  SquircleDashed as LucideSquircleDashed,
  Squirrel as LucideSquirrel,
  Stamp as LucideStamp,
  Star as LucideStar,
  StarHalf as LucideStarHalf,
  StarOff as LucideStarOff,
  Sparkles as LucideStars,
  StepBack as LucideStepBack,
  StepForward as LucideStepForward,
  Stethoscope as LucideStethoscope,
  Sticker as LucideSticker,
  StickyNote as LucideStickyNote,
  Stone as LucideStone,
  CircleStop as LucideStopCircle,
  Store as LucideStore,
  StretchHorizontal as LucideStretchHorizontal,
  StretchVertical as LucideStretchVertical,
  Strikethrough as LucideStrikethrough,
  Subscript as LucideSubscript,
  Captions as LucideSubtitles,
  Sun as LucideSun,
  SunDim as LucideSunDim,
  SunMedium as LucideSunMedium,
  SunMoon as LucideSunMoon,
  SunSnow as LucideSunSnow,
  Sunrise as LucideSunrise,
  Sunset as LucideSunset,
  Superscript as LucideSuperscript,
  SwatchBook as LucideSwatchBook,
  SwissFranc as LucideSwissFranc,
  SwitchCamera as LucideSwitchCamera,
  Sword as LucideSword,
  Swords as LucideSwords,
  Syringe as LucideSyringe,
  Table as LucideTable,
  Table2 as LucideTable2,
  TableCellsMerge as LucideTableCellsMerge,
  TableCellsSplit as LucideTableCellsSplit,
  TableColumnsSplit as LucideTableColumnsSplit,
  Columns3Cog as LucideTableConfig,
  TableOfContents as LucideTableOfContents,
  TableProperties as LucideTableProperties,
  TableRowsSplit as LucideTableRowsSplit,
  Tablet as LucideTablet,
  TabletSmartphone as LucideTabletSmartphone,
  Tablets as LucideTablets,
  Tag as LucideTag,
  Tags as LucideTags,
  Tally1 as LucideTally1,
  Tally2 as LucideTally2,
  Tally3 as LucideTally3,
  Tally4 as LucideTally4,
  Tally5 as LucideTally5,
  Tangent as LucideTangent,
  Target as LucideTarget,
  Telescope as LucideTelescope,
  Tent as LucideTent,
  TentTree as LucideTentTree,
  Terminal as LucideTerminal,
  SquareTerminal as LucideTerminalSquare,
  TestTube as LucideTestTube,
  TestTubeDiagonal as LucideTestTube2,
  TestTubeDiagonal as LucideTestTubeDiagonal,
  TestTubes as LucideTestTubes,
  TextAlignStart as LucideText,
  TextAlignCenter as LucideTextAlignCenter,
  TextAlignEnd as LucideTextAlignEnd,
  TextAlignJustify as LucideTextAlignJustify,
  TextAlignStart as LucideTextAlignStart,
  TextCursor as LucideTextCursor,
  TextCursorInput as LucideTextCursorInput,
  TextInitial as LucideTextInitial,
  TextQuote as LucideTextQuote,
  TextSearch as LucideTextSearch,
  TextSelect as LucideTextSelect,
  TextSelect as LucideTextSelection,
  TextWrap as LucideTextWrap,
  Theater as LucideTheater,
  Thermometer as LucideThermometer,
  ThermometerSnowflake as LucideThermometerSnowflake,
  ThermometerSun as LucideThermometerSun,
  ThumbsDown as LucideThumbsDown,
  ThumbsUp as LucideThumbsUp,
  Ticket as LucideTicket,
  TicketCheck as LucideTicketCheck,
  TicketMinus as LucideTicketMinus,
  TicketPercent as LucideTicketPercent,
  TicketPlus as LucideTicketPlus,
  TicketSlash as LucideTicketSlash,
  TicketX as LucideTicketX,
  Tickets as LucideTickets,
  TicketsPlane as LucideTicketsPlane,
  Timer as LucideTimer,
  TimerOff as LucideTimerOff,
  TimerReset as LucideTimerReset,
  ToggleLeft as LucideToggleLeft,
  ToggleRight as LucideToggleRight,
  Toilet as LucideToilet,
  ToolCase as LucideToolCase,
  Toolbox as LucideToolbox,
  Tornado as LucideTornado,
  Torus as LucideTorus,
  Touchpad as LucideTouchpad,
  TouchpadOff as LucideTouchpadOff,
  TowelRack as LucideTowelRack,
  TowerControl as LucideTowerControl,
  ToyBrick as LucideToyBrick,
  Tractor as LucideTractor,
  TrafficCone as LucideTrafficCone,
  TramFront as LucideTrain,
  TrainFront as LucideTrainFront,
  TrainFrontTunnel as LucideTrainFrontTunnel,
  TrainTrack as LucideTrainTrack,
  TramFront as LucideTramFront,
  Transgender as LucideTransgender,
  Trash as LucideTrash,
  Trash2 as LucideTrash2,
  TreeDeciduous as LucideTreeDeciduous,
  TreePalm as LucideTreePalm,
  TreePine as LucideTreePine,
  Trees as LucideTrees,
  Trello as LucideTrello,
  TrendingDown as LucideTrendingDown,
  TrendingUp as LucideTrendingUp,
  TrendingUpDown as LucideTrendingUpDown,
  Triangle as LucideTriangle,
  TriangleAlert as LucideTriangleAlert,
  TriangleDashed as LucideTriangleDashed,
  TriangleRight as LucideTriangleRight,
  Trophy as LucideTrophy,
  Truck as LucideTruck,
  TruckElectric as LucideTruckElectric,
  TurkishLira as LucideTurkishLira,
  Turntable as LucideTurntable,
  Turtle as LucideTurtle,
  Tv as LucideTv,
  TvMinimal as LucideTv2,
  TvMinimal as LucideTvMinimal,
  TvMinimalPlay as LucideTvMinimalPlay,
  Twitch as LucideTwitch,
  Twitter as LucideTwitter,
  Type as LucideType,
  TypeOutline as LucideTypeOutline,
  Umbrella as LucideUmbrella,
  UmbrellaOff as LucideUmbrellaOff,
  Underline as LucideUnderline,
  Undo as LucideUndo,
  Undo2 as LucideUndo2,
  UndoDot as LucideUndoDot,
  UnfoldHorizontal as LucideUnfoldHorizontal,
  UnfoldVertical as LucideUnfoldVertical,
  Ungroup as LucideUngroup,
  University as LucideUniversity,
  Unlink as LucideUnlink,
  Unlink2 as LucideUnlink2,
  LockOpen as LucideUnlock,
  LockKeyholeOpen as LucideUnlockKeyhole,
  Unplug as LucideUnplug,
  Upload as LucideUpload,
  CloudUpload as LucideUploadCloud,
  Usb as LucideUsb,
  User as LucideUser,
  UserRound as LucideUser2,
  UserCheck as LucideUserCheck,
  UserRoundCheck as LucideUserCheck2,
  CircleUser as LucideUserCircle,
  CircleUserRound as LucideUserCircle2,
  UserCog as LucideUserCog,
  UserRoundCog as LucideUserCog2,
  UserKey as LucideUserKey,
  UserLock as LucideUserLock,
  UserMinus as LucideUserMinus,
  UserRoundMinus as LucideUserMinus2,
  UserPen as LucideUserPen,
  UserPlus as LucideUserPlus,
  UserRoundPlus as LucideUserPlus2,
  UserRound as LucideUserRound,
  UserRoundCheck as LucideUserRoundCheck,
  UserRoundCog as LucideUserRoundCog,
  UserRoundKey as LucideUserRoundKey,
  UserRoundMinus as LucideUserRoundMinus,
  UserRoundPen as LucideUserRoundPen,
  UserRoundPlus as LucideUserRoundPlus,
  UserRoundSearch as LucideUserRoundSearch,
  UserRoundX as LucideUserRoundX,
  UserSearch as LucideUserSearch,
  SquareUser as LucideUserSquare,
  SquareUserRound as LucideUserSquare2,
  UserStar as LucideUserStar,
  UserX as LucideUserX,
  UserRoundX as LucideUserX2,
  Users as LucideUsers,
  UsersRound as LucideUsers2,
  UsersRound as LucideUsersRound,
  Utensils as LucideUtensils,
  UtensilsCrossed as LucideUtensilsCrossed,
  UtilityPole as LucideUtilityPole,
  Van as LucideVan,
  Variable as LucideVariable,
  Vault as LucideVault,
  VectorSquare as LucideVectorSquare,
  Vegan as LucideVegan,
  VenetianMask as LucideVenetianMask,
  Venus as LucideVenus,
  VenusAndMars as LucideVenusAndMars,
  BadgeCheck as LucideVerified,
  Vibrate as LucideVibrate,
  VibrateOff as LucideVibrateOff,
  Video as LucideVideo,
  VideoOff as LucideVideoOff,
  Videotape as LucideVideotape,
  View as LucideView,
  Voicemail as LucideVoicemail,
  Volleyball as LucideVolleyball,
  Volume as LucideVolume,
  Volume1 as LucideVolume1,
  Volume2 as LucideVolume2,
  VolumeOff as LucideVolumeOff,
  VolumeX as LucideVolumeX,
  Vote as LucideVote,
  Wallet as LucideWallet,
  WalletMinimal as LucideWallet2,
  WalletCards as LucideWalletCards,
  WalletMinimal as LucideWalletMinimal,
  Wallpaper as LucideWallpaper,
  Wand as LucideWand,
  WandSparkles as LucideWand2,
  WandSparkles as LucideWandSparkles,
  Warehouse as LucideWarehouse,
  WashingMachine as LucideWashingMachine,
  Watch as LucideWatch,
  Waves as LucideWaves,
  WavesArrowDown as LucideWavesArrowDown,
  WavesArrowUp as LucideWavesArrowUp,
  WavesLadder as LucideWavesLadder,
  Waypoints as LucideWaypoints,
  Webcam as LucideWebcam,
  Webhook as LucideWebhook,
  WebhookOff as LucideWebhookOff,
  Weight as LucideWeight,
  WeightTilde as LucideWeightTilde,
  Wheat as LucideWheat,
  WheatOff as LucideWheatOff,
  WholeWord as LucideWholeWord,
  Wifi as LucideWifi,
  WifiCog as LucideWifiCog,
  WifiHigh as LucideWifiHigh,
  WifiLow as LucideWifiLow,
  WifiOff as LucideWifiOff,
  WifiPen as LucideWifiPen,
  WifiSync as LucideWifiSync,
  WifiZero as LucideWifiZero,
  Wind as LucideWind,
  WindArrowDown as LucideWindArrowDown,
  Wine as LucideWine,
  WineOff as LucideWineOff,
  Workflow as LucideWorkflow,
  Worm as LucideWorm,
  TextWrap as LucideWrapText,
  Wrench as LucideWrench,
  X as LucideX,
  CircleX as LucideXCircle,
  XLineTop as LucideXLineTop,
  OctagonX as LucideXOctagon,
  SquareX as LucideXSquare,
  Youtube as LucideYoutube,
  Zap as LucideZap,
  ZapOff as LucideZapOff,
  ZoomIn as LucideZoomIn,
  ZoomOut as LucideZoomOut,
  Luggage,
  Luggage as LuggageIcon,
  SquareM as MSquare,
  SquareM as MSquareIcon,
  Magnet,
  Magnet as MagnetIcon,
  Mail,
  MailCheck,
  MailCheck as MailCheckIcon,
  Mail as MailIcon,
  MailMinus,
  MailMinus as MailMinusIcon,
  MailOpen,
  MailOpen as MailOpenIcon,
  MailPlus,
  MailPlus as MailPlusIcon,
  MailQuestionMark as MailQuestion,
  MailQuestionMark as MailQuestionIcon,
  MailQuestionMark,
  MailQuestionMark as MailQuestionMarkIcon,
  MailSearch,
  MailSearch as MailSearchIcon,
  MailWarning,
  MailWarning as MailWarningIcon,
  MailX,
  MailX as MailXIcon,
  Mailbox,
  Mailbox as MailboxIcon,
  Mails,
  Mails as MailsIcon,
  Map,
  Map as MapIcon,
  MapMinus,
  MapMinus as MapMinusIcon,
  MapPin,
  MapPinCheck,
  MapPinCheck as MapPinCheckIcon,
  MapPinCheckInside,
  MapPinCheckInside as MapPinCheckInsideIcon,
  MapPinHouse,
  MapPinHouse as MapPinHouseIcon,
  MapPin as MapPinIcon,
  MapPinMinus,
  MapPinMinus as MapPinMinusIcon,
  MapPinMinusInside,
  MapPinMinusInside as MapPinMinusInsideIcon,
  MapPinOff,
  MapPinOff as MapPinOffIcon,
  MapPinPen,
  MapPinPen as MapPinPenIcon,
  MapPinPlus,
  MapPinPlus as MapPinPlusIcon,
  MapPinPlusInside,
  MapPinPlusInside as MapPinPlusInsideIcon,
  MapPinX,
  MapPinX as MapPinXIcon,
  MapPinXInside,
  MapPinXInside as MapPinXInsideIcon,
  MapPinned,
  MapPinned as MapPinnedIcon,
  MapPlus,
  MapPlus as MapPlusIcon,
  Mars,
  Mars as MarsIcon,
  MarsStroke,
  MarsStroke as MarsStrokeIcon,
  Martini,
  Martini as MartiniIcon,
  Maximize,
  Maximize2,
  Maximize2 as Maximize2Icon,
  Maximize as MaximizeIcon,
  Medal,
  Medal as MedalIcon,
  Megaphone,
  Megaphone as MegaphoneIcon,
  MegaphoneOff,
  MegaphoneOff as MegaphoneOffIcon,
  Meh,
  Meh as MehIcon,
  MemoryStick,
  MemoryStick as MemoryStickIcon,
  Menu,
  Menu as MenuIcon,
  SquareMenu as MenuSquare,
  SquareMenu as MenuSquareIcon,
  Merge,
  Merge as MergeIcon,
  MessageCircle,
  MessageCircleCheck,
  MessageCircleCheck as MessageCircleCheckIcon,
  MessageCircleCode,
  MessageCircleCode as MessageCircleCodeIcon,
  MessageCircleDashed,
  MessageCircleDashed as MessageCircleDashedIcon,
  MessageCircleHeart,
  MessageCircleHeart as MessageCircleHeartIcon,
  MessageCircle as MessageCircleIcon,
  MessageCircleMore,
  MessageCircleMore as MessageCircleMoreIcon,
  MessageCircleOff,
  MessageCircleOff as MessageCircleOffIcon,
  MessageCirclePlus,
  MessageCirclePlus as MessageCirclePlusIcon,
  MessageCircleQuestionMark as MessageCircleQuestion,
  MessageCircleQuestionMark as MessageCircleQuestionIcon,
  MessageCircleQuestionMark,
  MessageCircleQuestionMark as MessageCircleQuestionMarkIcon,
  MessageCircleReply,
  MessageCircleReply as MessageCircleReplyIcon,
  MessageCircleWarning,
  MessageCircleWarning as MessageCircleWarningIcon,
  MessageCircleX,
  MessageCircleX as MessageCircleXIcon,
  MessageSquare,
  MessageSquareCheck,
  MessageSquareCheck as MessageSquareCheckIcon,
  MessageSquareCode,
  MessageSquareCode as MessageSquareCodeIcon,
  MessageSquareDashed,
  MessageSquareDashed as MessageSquareDashedIcon,
  MessageSquareDiff,
  MessageSquareDiff as MessageSquareDiffIcon,
  MessageSquareDot,
  MessageSquareDot as MessageSquareDotIcon,
  MessageSquareHeart,
  MessageSquareHeart as MessageSquareHeartIcon,
  MessageSquare as MessageSquareIcon,
  MessageSquareLock,
  MessageSquareLock as MessageSquareLockIcon,
  MessageSquareMore,
  MessageSquareMore as MessageSquareMoreIcon,
  MessageSquareOff,
  MessageSquareOff as MessageSquareOffIcon,
  MessageSquarePlus,
  MessageSquarePlus as MessageSquarePlusIcon,
  MessageSquareQuote,
  MessageSquareQuote as MessageSquareQuoteIcon,
  MessageSquareReply,
  MessageSquareReply as MessageSquareReplyIcon,
  MessageSquareShare,
  MessageSquareShare as MessageSquareShareIcon,
  MessageSquareText,
  MessageSquareText as MessageSquareTextIcon,
  MessageSquareWarning,
  MessageSquareWarning as MessageSquareWarningIcon,
  MessageSquareX,
  MessageSquareX as MessageSquareXIcon,
  MessagesSquare,
  MessagesSquare as MessagesSquareIcon,
  Metronome,
  Metronome as MetronomeIcon,
  Mic,
  MicVocal as Mic2,
  MicVocal as Mic2Icon,
  Mic as MicIcon,
  MicOff,
  MicOff as MicOffIcon,
  MicVocal,
  MicVocal as MicVocalIcon,
  Microchip,
  Microchip as MicrochipIcon,
  Microscope,
  Microscope as MicroscopeIcon,
  Microwave,
  Microwave as MicrowaveIcon,
  Milestone,
  Milestone as MilestoneIcon,
  Milk,
  Milk as MilkIcon,
  MilkOff,
  MilkOff as MilkOffIcon,
  Minimize,
  Minimize2,
  Minimize2 as Minimize2Icon,
  Minimize as MinimizeIcon,
  Minus,
  CircleMinus as MinusCircle,
  CircleMinus as MinusCircleIcon,
  Minus as MinusIcon,
  SquareMinus as MinusSquare,
  SquareMinus as MinusSquareIcon,
  MirrorRectangular,
  MirrorRectangular as MirrorRectangularIcon,
  MirrorRound,
  MirrorRound as MirrorRoundIcon,
  Monitor,
  MonitorCheck,
  MonitorCheck as MonitorCheckIcon,
  MonitorCloud,
  MonitorCloud as MonitorCloudIcon,
  MonitorCog,
  MonitorCog as MonitorCogIcon,
  MonitorDot,
  MonitorDot as MonitorDotIcon,
  MonitorDown,
  MonitorDown as MonitorDownIcon,
  Monitor as MonitorIcon,
  MonitorOff,
  MonitorOff as MonitorOffIcon,
  MonitorPause,
  MonitorPause as MonitorPauseIcon,
  MonitorPlay,
  MonitorPlay as MonitorPlayIcon,
  MonitorSmartphone,
  MonitorSmartphone as MonitorSmartphoneIcon,
  MonitorSpeaker,
  MonitorSpeaker as MonitorSpeakerIcon,
  MonitorStop,
  MonitorStop as MonitorStopIcon,
  MonitorUp,
  MonitorUp as MonitorUpIcon,
  MonitorX,
  MonitorX as MonitorXIcon,
  Moon,
  Moon as MoonIcon,
  MoonStar,
  MoonStar as MoonStarIcon,
  Ellipsis as MoreHorizontal,
  Ellipsis as MoreHorizontalIcon,
  EllipsisVertical as MoreVertical,
  EllipsisVertical as MoreVerticalIcon,
  Motorbike,
  Motorbike as MotorbikeIcon,
  Mountain,
  Mountain as MountainIcon,
  MountainSnow,
  MountainSnow as MountainSnowIcon,
  Mouse,
  Mouse as MouseIcon,
  MouseLeft,
  MouseLeft as MouseLeftIcon,
  MouseOff,
  MouseOff as MouseOffIcon,
  MousePointer,
  MousePointer2,
  MousePointer2 as MousePointer2Icon,
  MousePointer2Off,
  MousePointer2Off as MousePointer2OffIcon,
  MousePointerBan,
  MousePointerBan as MousePointerBanIcon,
  MousePointerClick,
  MousePointerClick as MousePointerClickIcon,
  MousePointer as MousePointerIcon,
  SquareDashedMousePointer as MousePointerSquareDashed,
  SquareDashedMousePointer as MousePointerSquareDashedIcon,
  MouseRight,
  MouseRight as MouseRightIcon,
  Move,
  Move3d as Move3D,
  Move3d as Move3DIcon,
  Move3d,
  Move3d as Move3dIcon,
  MoveDiagonal,
  MoveDiagonal2,
  MoveDiagonal2 as MoveDiagonal2Icon,
  MoveDiagonal as MoveDiagonalIcon,
  MoveDown,
  MoveDown as MoveDownIcon,
  MoveDownLeft,
  MoveDownLeft as MoveDownLeftIcon,
  MoveDownRight,
  MoveDownRight as MoveDownRightIcon,
  MoveHorizontal,
  MoveHorizontal as MoveHorizontalIcon,
  Move as MoveIcon,
  MoveLeft,
  MoveLeft as MoveLeftIcon,
  MoveRight,
  MoveRight as MoveRightIcon,
  MoveUp,
  MoveUp as MoveUpIcon,
  MoveUpLeft,
  MoveUpLeft as MoveUpLeftIcon,
  MoveUpRight,
  MoveUpRight as MoveUpRightIcon,
  MoveVertical,
  MoveVertical as MoveVerticalIcon,
  Music,
  Music2,
  Music2 as Music2Icon,
  Music3,
  Music3 as Music3Icon,
  Music4,
  Music4 as Music4Icon,
  Music as MusicIcon,
  Navigation,
  Navigation2,
  Navigation2 as Navigation2Icon,
  Navigation2Off,
  Navigation2Off as Navigation2OffIcon,
  Navigation as NavigationIcon,
  NavigationOff,
  NavigationOff as NavigationOffIcon,
  Network,
  Network as NetworkIcon,
  Newspaper,
  Newspaper as NewspaperIcon,
  Nfc,
  Nfc as NfcIcon,
  NonBinary,
  NonBinary as NonBinaryIcon,
  Notebook,
  Notebook as NotebookIcon,
  NotebookPen,
  NotebookPen as NotebookPenIcon,
  NotebookTabs,
  NotebookTabs as NotebookTabsIcon,
  NotebookText,
  NotebookText as NotebookTextIcon,
  NotepadText,
  NotepadTextDashed,
  NotepadTextDashed as NotepadTextDashedIcon,
  NotepadText as NotepadTextIcon,
  Nut,
  Nut as NutIcon,
  NutOff,
  NutOff as NutOffIcon,
  Octagon,
  OctagonAlert,
  OctagonAlert as OctagonAlertIcon,
  Octagon as OctagonIcon,
  OctagonMinus,
  OctagonMinus as OctagonMinusIcon,
  OctagonPause,
  OctagonPause as OctagonPauseIcon,
  OctagonX,
  OctagonX as OctagonXIcon,
  Omega,
  Omega as OmegaIcon,
  Option,
  Option as OptionIcon,
  Orbit,
  Orbit as OrbitIcon,
  Origami,
  Origami as OrigamiIcon,
  ListIndentDecrease as Outdent,
  ListIndentDecrease as OutdentIcon,
  Package,
  Package2,
  Package2 as Package2Icon,
  PackageCheck,
  PackageCheck as PackageCheckIcon,
  Package as PackageIcon,
  PackageMinus,
  PackageMinus as PackageMinusIcon,
  PackageOpen,
  PackageOpen as PackageOpenIcon,
  PackagePlus,
  PackagePlus as PackagePlusIcon,
  PackageSearch,
  PackageSearch as PackageSearchIcon,
  PackageX,
  PackageX as PackageXIcon,
  PaintBucket,
  PaintBucket as PaintBucketIcon,
  PaintRoller,
  PaintRoller as PaintRollerIcon,
  Paintbrush,
  PaintbrushVertical as Paintbrush2,
  PaintbrushVertical as Paintbrush2Icon,
  Paintbrush as PaintbrushIcon,
  PaintbrushVertical,
  PaintbrushVertical as PaintbrushVerticalIcon,
  Palette,
  Palette as PaletteIcon,
  TreePalm as Palmtree,
  TreePalm as PalmtreeIcon,
  Panda,
  Panda as PandaIcon,
  PanelBottom,
  PanelBottomClose,
  PanelBottomClose as PanelBottomCloseIcon,
  PanelBottomDashed,
  PanelBottomDashed as PanelBottomDashedIcon,
  PanelBottom as PanelBottomIcon,
  PanelBottomDashed as PanelBottomInactive,
  PanelBottomDashed as PanelBottomInactiveIcon,
  PanelBottomOpen,
  PanelBottomOpen as PanelBottomOpenIcon,
  PanelLeft,
  PanelLeftClose,
  PanelLeftClose as PanelLeftCloseIcon,
  PanelLeftDashed,
  PanelLeftDashed as PanelLeftDashedIcon,
  PanelLeft as PanelLeftIcon,
  PanelLeftDashed as PanelLeftInactive,
  PanelLeftDashed as PanelLeftInactiveIcon,
  PanelLeftOpen,
  PanelLeftOpen as PanelLeftOpenIcon,
  PanelLeftRightDashed,
  PanelLeftRightDashed as PanelLeftRightDashedIcon,
  PanelRight,
  PanelRightClose,
  PanelRightClose as PanelRightCloseIcon,
  PanelRightDashed,
  PanelRightDashed as PanelRightDashedIcon,
  PanelRight as PanelRightIcon,
  PanelRightDashed as PanelRightInactive,
  PanelRightDashed as PanelRightInactiveIcon,
  PanelRightOpen,
  PanelRightOpen as PanelRightOpenIcon,
  PanelTop,
  PanelTopBottomDashed,
  PanelTopBottomDashed as PanelTopBottomDashedIcon,
  PanelTopClose,
  PanelTopClose as PanelTopCloseIcon,
  PanelTopDashed,
  PanelTopDashed as PanelTopDashedIcon,
  PanelTop as PanelTopIcon,
  PanelTopDashed as PanelTopInactive,
  PanelTopDashed as PanelTopInactiveIcon,
  PanelTopOpen,
  PanelTopOpen as PanelTopOpenIcon,
  PanelsLeftBottom,
  PanelsLeftBottom as PanelsLeftBottomIcon,
  Columns3 as PanelsLeftRight,
  Columns3 as PanelsLeftRightIcon,
  PanelsRightBottom,
  PanelsRightBottom as PanelsRightBottomIcon,
  Rows3 as PanelsTopBottom,
  Rows3 as PanelsTopBottomIcon,
  PanelsTopLeft,
  PanelsTopLeft as PanelsTopLeftIcon,
  Paperclip,
  Paperclip as PaperclipIcon,
  Parentheses,
  Parentheses as ParenthesesIcon,
  CircleParking as ParkingCircle,
  CircleParking as ParkingCircleIcon,
  CircleParkingOff as ParkingCircleOff,
  CircleParkingOff as ParkingCircleOffIcon,
  ParkingMeter,
  ParkingMeter as ParkingMeterIcon,
  SquareParking as ParkingSquare,
  SquareParking as ParkingSquareIcon,
  SquareParkingOff as ParkingSquareOff,
  SquareParkingOff as ParkingSquareOffIcon,
  PartyPopper,
  PartyPopper as PartyPopperIcon,
  Pause,
  CirclePause as PauseCircle,
  CirclePause as PauseCircleIcon,
  Pause as PauseIcon,
  OctagonPause as PauseOctagon,
  OctagonPause as PauseOctagonIcon,
  PawPrint,
  PawPrint as PawPrintIcon,
  PcCase,
  PcCase as PcCaseIcon,
  Pen,
  SquarePen as PenBox,
  SquarePen as PenBoxIcon,
  Pen as PenIcon,
  PenLine,
  PenLine as PenLineIcon,
  PenOff,
  PenOff as PenOffIcon,
  SquarePen as PenSquare,
  SquarePen as PenSquareIcon,
  PenTool,
  PenTool as PenToolIcon,
  Pencil,
  Pencil as PencilIcon,
  PencilLine,
  PencilLine as PencilLineIcon,
  PencilOff,
  PencilOff as PencilOffIcon,
  PencilRuler,
  PencilRuler as PencilRulerIcon,
  Pentagon,
  Pentagon as PentagonIcon,
  Percent,
  CirclePercent as PercentCircle,
  CirclePercent as PercentCircleIcon,
  DiamondPercent as PercentDiamond,
  DiamondPercent as PercentDiamondIcon,
  Percent as PercentIcon,
  SquarePercent as PercentSquare,
  SquarePercent as PercentSquareIcon,
  PersonStanding,
  PersonStanding as PersonStandingIcon,
  PhilippinePeso,
  PhilippinePeso as PhilippinePesoIcon,
  Phone,
  PhoneCall,
  PhoneCall as PhoneCallIcon,
  PhoneForwarded,
  PhoneForwarded as PhoneForwardedIcon,
  Phone as PhoneIcon,
  PhoneIncoming,
  PhoneIncoming as PhoneIncomingIcon,
  PhoneMissed,
  PhoneMissed as PhoneMissedIcon,
  PhoneOff,
  PhoneOff as PhoneOffIcon,
  PhoneOutgoing,
  PhoneOutgoing as PhoneOutgoingIcon,
  Pi,
  Pi as PiIcon,
  SquarePi as PiSquare,
  SquarePi as PiSquareIcon,
  Piano,
  Piano as PianoIcon,
  Pickaxe,
  Pickaxe as PickaxeIcon,
  PictureInPicture,
  PictureInPicture2,
  PictureInPicture2 as PictureInPicture2Icon,
  PictureInPicture as PictureInPictureIcon,
  ChartPie as PieChart,
  ChartPie as PieChartIcon,
  PiggyBank,
  PiggyBank as PiggyBankIcon,
  Pilcrow,
  Pilcrow as PilcrowIcon,
  PilcrowLeft,
  PilcrowLeft as PilcrowLeftIcon,
  PilcrowRight,
  PilcrowRight as PilcrowRightIcon,
  SquarePilcrow as PilcrowSquare,
  SquarePilcrow as PilcrowSquareIcon,
  Pill,
  PillBottle,
  PillBottle as PillBottleIcon,
  Pill as PillIcon,
  Pin,
  Pin as PinIcon,
  PinOff,
  PinOff as PinOffIcon,
  Pipette,
  Pipette as PipetteIcon,
  Pizza,
  Pizza as PizzaIcon,
  Plane,
  Plane as PlaneIcon,
  PlaneLanding,
  PlaneLanding as PlaneLandingIcon,
  PlaneTakeoff,
  PlaneTakeoff as PlaneTakeoffIcon,
  Play,
  CirclePlay as PlayCircle,
  CirclePlay as PlayCircleIcon,
  Play as PlayIcon,
  SquarePlay as PlaySquare,
  SquarePlay as PlaySquareIcon,
  Plug,
  Plug2,
  Plug2 as Plug2Icon,
  Plug as PlugIcon,
  PlugZap,
  PlugZap as PlugZap2,
  PlugZap as PlugZap2Icon,
  PlugZap as PlugZapIcon,
  Plus,
  CirclePlus as PlusCircle,
  CirclePlus as PlusCircleIcon,
  Plus as PlusIcon,
  SquarePlus as PlusSquare,
  SquarePlus as PlusSquareIcon,
  Pocket,
  Pocket as PocketIcon,
  PocketKnife,
  PocketKnife as PocketKnifeIcon,
  Podcast,
  Podcast as PodcastIcon,
  Pointer,
  Pointer as PointerIcon,
  PointerOff,
  PointerOff as PointerOffIcon,
  Popcorn,
  Popcorn as PopcornIcon,
  Popsicle,
  Popsicle as PopsicleIcon,
  PoundSterling,
  PoundSterling as PoundSterlingIcon,
  Power,
  CirclePower as PowerCircle,
  CirclePower as PowerCircleIcon,
  Power as PowerIcon,
  PowerOff,
  PowerOff as PowerOffIcon,
  SquarePower as PowerSquare,
  SquarePower as PowerSquareIcon,
  Presentation,
  Presentation as PresentationIcon,
  Printer,
  PrinterCheck,
  PrinterCheck as PrinterCheckIcon,
  Printer as PrinterIcon,
  PrinterX,
  PrinterX as PrinterXIcon,
  Projector,
  Projector as ProjectorIcon,
  Proportions,
  Proportions as ProportionsIcon,
  Puzzle,
  Puzzle as PuzzleIcon,
  Pyramid,
  Pyramid as PyramidIcon,
  QrCode,
  QrCode as QrCodeIcon,
  Quote,
  Quote as QuoteIcon,
  Rabbit,
  Rabbit as RabbitIcon,
  Radar,
  Radar as RadarIcon,
  Radiation,
  Radiation as RadiationIcon,
  Radical,
  Radical as RadicalIcon,
  Radio,
  Radio as RadioIcon,
  RadioReceiver,
  RadioReceiver as RadioReceiverIcon,
  RadioTower,
  RadioTower as RadioTowerIcon,
  Radius,
  Radius as RadiusIcon,
  RailSymbol,
  RailSymbol as RailSymbolIcon,
  Rainbow,
  Rainbow as RainbowIcon,
  Rat,
  Rat as RatIcon,
  Ratio,
  Ratio as RatioIcon,
  Receipt,
  ReceiptCent,
  ReceiptCent as ReceiptCentIcon,
  ReceiptEuro,
  ReceiptEuro as ReceiptEuroIcon,
  Receipt as ReceiptIcon,
  ReceiptIndianRupee,
  ReceiptIndianRupee as ReceiptIndianRupeeIcon,
  ReceiptJapaneseYen,
  ReceiptJapaneseYen as ReceiptJapaneseYenIcon,
  ReceiptPoundSterling,
  ReceiptPoundSterling as ReceiptPoundSterlingIcon,
  ReceiptRussianRuble,
  ReceiptRussianRuble as ReceiptRussianRubleIcon,
  ReceiptSwissFranc,
  ReceiptSwissFranc as ReceiptSwissFrancIcon,
  ReceiptText,
  ReceiptText as ReceiptTextIcon,
  ReceiptTurkishLira,
  ReceiptTurkishLira as ReceiptTurkishLiraIcon,
  RectangleCircle,
  RectangleCircle as RectangleCircleIcon,
  RectangleEllipsis,
  RectangleEllipsis as RectangleEllipsisIcon,
  RectangleGoggles,
  RectangleGoggles as RectangleGogglesIcon,
  RectangleHorizontal,
  RectangleHorizontal as RectangleHorizontalIcon,
  RectangleVertical,
  RectangleVertical as RectangleVerticalIcon,
  Recycle,
  Recycle as RecycleIcon,
  Redo,
  Redo2,
  Redo2 as Redo2Icon,
  RedoDot,
  RedoDot as RedoDotIcon,
  Redo as RedoIcon,
  RefreshCcw,
  RefreshCcwDot,
  RefreshCcwDot as RefreshCcwDotIcon,
  RefreshCcw as RefreshCcwIcon,
  RefreshCw,
  RefreshCw as RefreshCwIcon,
  RefreshCwOff,
  RefreshCwOff as RefreshCwOffIcon,
  Refrigerator,
  Refrigerator as RefrigeratorIcon,
  Regex,
  Regex as RegexIcon,
  RemoveFormatting,
  RemoveFormatting as RemoveFormattingIcon,
  Repeat,
  Repeat1,
  Repeat1 as Repeat1Icon,
  Repeat2,
  Repeat2 as Repeat2Icon,
  Repeat as RepeatIcon,
  Replace,
  ReplaceAll,
  ReplaceAll as ReplaceAllIcon,
  Replace as ReplaceIcon,
  Reply,
  ReplyAll,
  ReplyAll as ReplyAllIcon,
  Reply as ReplyIcon,
  Rewind,
  Rewind as RewindIcon,
  Ribbon,
  Ribbon as RibbonIcon,
  Rocket,
  Rocket as RocketIcon,
  RockingChair,
  RockingChair as RockingChairIcon,
  RollerCoaster,
  RollerCoaster as RollerCoasterIcon,
  Rose,
  Rose as RoseIcon,
  Rotate3d as Rotate3D,
  Rotate3d as Rotate3DIcon,
  Rotate3d,
  Rotate3d as Rotate3dIcon,
  RotateCcw,
  RotateCcw as RotateCcwIcon,
  RotateCcwKey,
  RotateCcwKey as RotateCcwKeyIcon,
  RotateCcwSquare,
  RotateCcwSquare as RotateCcwSquareIcon,
  RotateCw,
  RotateCw as RotateCwIcon,
  RotateCwSquare,
  RotateCwSquare as RotateCwSquareIcon,
  Route,
  Route as RouteIcon,
  RouteOff,
  RouteOff as RouteOffIcon,
  Router,
  Router as RouterIcon,
  Rows2 as Rows,
  Rows2,
  Rows2 as Rows2Icon,
  Rows3,
  Rows3 as Rows3Icon,
  Rows4,
  Rows4 as Rows4Icon,
  Rows2 as RowsIcon,
  Rss,
  Rss as RssIcon,
  Ruler,
  RulerDimensionLine,
  RulerDimensionLine as RulerDimensionLineIcon,
  Ruler as RulerIcon,
  RussianRuble,
  RussianRuble as RussianRubleIcon,
  Sailboat,
  Sailboat as SailboatIcon,
  Salad,
  Salad as SaladIcon,
  Sandwich,
  Sandwich as SandwichIcon,
  Satellite,
  SatelliteDish,
  SatelliteDish as SatelliteDishIcon,
  Satellite as SatelliteIcon,
  SaudiRiyal,
  SaudiRiyal as SaudiRiyalIcon,
  Save,
  SaveAll,
  SaveAll as SaveAllIcon,
  Save as SaveIcon,
  SaveOff,
  SaveOff as SaveOffIcon,
  Scale,
  Scale3d as Scale3D,
  Scale3d as Scale3DIcon,
  Scale3d,
  Scale3d as Scale3dIcon,
  Scale as ScaleIcon,
  Scaling,
  Scaling as ScalingIcon,
  Scan,
  ScanBarcode,
  ScanBarcode as ScanBarcodeIcon,
  ScanEye,
  ScanEye as ScanEyeIcon,
  ScanFace,
  ScanFace as ScanFaceIcon,
  ScanHeart,
  ScanHeart as ScanHeartIcon,
  Scan as ScanIcon,
  ScanLine,
  ScanLine as ScanLineIcon,
  ScanQrCode,
  ScanQrCode as ScanQrCodeIcon,
  ScanSearch,
  ScanSearch as ScanSearchIcon,
  ScanText,
  ScanText as ScanTextIcon,
  ChartScatter as ScatterChart,
  ChartScatter as ScatterChartIcon,
  School,
  University as School2,
  University as School2Icon,
  School as SchoolIcon,
  Scissors,
  Scissors as ScissorsIcon,
  ScissorsLineDashed,
  ScissorsLineDashed as ScissorsLineDashedIcon,
  SquareScissors as ScissorsSquare,
  SquareBottomDashedScissors as ScissorsSquareDashedBottom,
  SquareBottomDashedScissors as ScissorsSquareDashedBottomIcon,
  SquareScissors as ScissorsSquareIcon,
  Scooter,
  Scooter as ScooterIcon,
  ScreenShare,
  ScreenShare as ScreenShareIcon,
  ScreenShareOff,
  ScreenShareOff as ScreenShareOffIcon,
  Scroll,
  Scroll as ScrollIcon,
  ScrollText,
  ScrollText as ScrollTextIcon,
  Search,
  SearchAlert,
  SearchAlert as SearchAlertIcon,
  SearchCheck,
  SearchCheck as SearchCheckIcon,
  SearchCode,
  SearchCode as SearchCodeIcon,
  Search as SearchIcon,
  SearchSlash,
  SearchSlash as SearchSlashIcon,
  SearchX,
  SearchX as SearchXIcon,
  Section,
  Section as SectionIcon,
  Send,
  SendHorizontal as SendHorizonal,
  SendHorizontal as SendHorizonalIcon,
  SendHorizontal,
  SendHorizontal as SendHorizontalIcon,
  Send as SendIcon,
  SendToBack,
  SendToBack as SendToBackIcon,
  SeparatorHorizontal,
  SeparatorHorizontal as SeparatorHorizontalIcon,
  SeparatorVertical,
  SeparatorVertical as SeparatorVerticalIcon,
  Server,
  ServerCog,
  ServerCog as ServerCogIcon,
  ServerCrash,
  ServerCrash as ServerCrashIcon,
  Server as ServerIcon,
  ServerOff,
  ServerOff as ServerOffIcon,
  Settings,
  Settings2,
  Settings2 as Settings2Icon,
  Settings as SettingsIcon,
  Shapes,
  Shapes as ShapesIcon,
  Share,
  Share2,
  Share2 as Share2Icon,
  Share as ShareIcon,
  Sheet,
  Sheet as SheetIcon,
  Shell,
  Shell as ShellIcon,
  ShelvingUnit,
  ShelvingUnit as ShelvingUnitIcon,
  Shield,
  ShieldAlert,
  ShieldAlert as ShieldAlertIcon,
  ShieldBan,
  ShieldBan as ShieldBanIcon,
  ShieldCheck,
  ShieldCheck as ShieldCheckIcon,
  ShieldX as ShieldClose,
  ShieldX as ShieldCloseIcon,
  ShieldEllipsis,
  ShieldEllipsis as ShieldEllipsisIcon,
  ShieldHalf,
  ShieldHalf as ShieldHalfIcon,
  Shield as ShieldIcon,
  ShieldMinus,
  ShieldMinus as ShieldMinusIcon,
  ShieldOff,
  ShieldOff as ShieldOffIcon,
  ShieldPlus,
  ShieldPlus as ShieldPlusIcon,
  ShieldQuestionMark as ShieldQuestion,
  ShieldQuestionMark as ShieldQuestionIcon,
  ShieldQuestionMark,
  ShieldQuestionMark as ShieldQuestionMarkIcon,
  ShieldUser,
  ShieldUser as ShieldUserIcon,
  ShieldX,
  ShieldX as ShieldXIcon,
  Ship,
  Ship as ShipIcon,
  ShipWheel,
  ShipWheel as ShipWheelIcon,
  Shirt,
  Shirt as ShirtIcon,
  ShoppingBag,
  ShoppingBag as ShoppingBagIcon,
  ShoppingBasket,
  ShoppingBasket as ShoppingBasketIcon,
  ShoppingCart,
  ShoppingCart as ShoppingCartIcon,
  Shovel,
  Shovel as ShovelIcon,
  ShowerHead,
  ShowerHead as ShowerHeadIcon,
  Shredder,
  Shredder as ShredderIcon,
  Shrimp,
  Shrimp as ShrimpIcon,
  Shrink,
  Shrink as ShrinkIcon,
  Shrub,
  Shrub as ShrubIcon,
  Shuffle,
  Shuffle as ShuffleIcon,
  PanelLeft as Sidebar,
  PanelLeftClose as SidebarClose,
  PanelLeftClose as SidebarCloseIcon,
  PanelLeft as SidebarIcon,
  PanelLeftOpen as SidebarOpen,
  PanelLeftOpen as SidebarOpenIcon,
  Sigma,
  Sigma as SigmaIcon,
  SquareSigma as SigmaSquare,
  SquareSigma as SigmaSquareIcon,
  Signal,
  SignalHigh,
  SignalHigh as SignalHighIcon,
  Signal as SignalIcon,
  SignalLow,
  SignalLow as SignalLowIcon,
  SignalMedium,
  SignalMedium as SignalMediumIcon,
  SignalZero,
  SignalZero as SignalZeroIcon,
  Signature,
  Signature as SignatureIcon,
  Signpost,
  SignpostBig,
  SignpostBig as SignpostBigIcon,
  Signpost as SignpostIcon,
  Siren,
  Siren as SirenIcon,
  SkipBack,
  SkipBack as SkipBackIcon,
  SkipForward,
  SkipForward as SkipForwardIcon,
  Skull,
  Skull as SkullIcon,
  Slack,
  Slack as SlackIcon,
  Slash,
  Slash as SlashIcon,
  SquareSlash as SlashSquare,
  SquareSlash as SlashSquareIcon,
  Slice,
  Slice as SliceIcon,
  SlidersVertical as Sliders,
  SlidersHorizontal,
  SlidersHorizontal as SlidersHorizontalIcon,
  SlidersVertical as SlidersIcon,
  SlidersVertical,
  SlidersVertical as SlidersVerticalIcon,
  Smartphone,
  SmartphoneCharging,
  SmartphoneCharging as SmartphoneChargingIcon,
  Smartphone as SmartphoneIcon,
  SmartphoneNfc,
  SmartphoneNfc as SmartphoneNfcIcon,
  Smile,
  Smile as SmileIcon,
  SmilePlus,
  SmilePlus as SmilePlusIcon,
  Snail,
  Snail as SnailIcon,
  Snowflake,
  Snowflake as SnowflakeIcon,
  SoapDispenserDroplet,
  SoapDispenserDroplet as SoapDispenserDropletIcon,
  Sofa,
  Sofa as SofaIcon,
  SolarPanel,
  SolarPanel as SolarPanelIcon,
  ArrowUpNarrowWide as SortAsc,
  ArrowUpNarrowWide as SortAscIcon,
  ArrowDownWideNarrow as SortDesc,
  ArrowDownWideNarrow as SortDescIcon,
  Soup,
  Soup as SoupIcon,
  Space,
  Space as SpaceIcon,
  Spade,
  Spade as SpadeIcon,
  Sparkle,
  Sparkle as SparkleIcon,
  Sparkles,
  Sparkles as SparklesIcon,
  Speaker,
  Speaker as SpeakerIcon,
  Speech,
  Speech as SpeechIcon,
  SpellCheck,
  SpellCheck2,
  SpellCheck2 as SpellCheck2Icon,
  SpellCheck as SpellCheckIcon,
  Spline,
  Spline as SplineIcon,
  SplinePointer,
  SplinePointer as SplinePointerIcon,
  Split,
  Split as SplitIcon,
  SquareSplitHorizontal as SplitSquareHorizontal,
  SquareSplitHorizontal as SplitSquareHorizontalIcon,
  SquareSplitVertical as SplitSquareVertical,
  SquareSplitVertical as SplitSquareVerticalIcon,
  Spool,
  Spool as SpoolIcon,
  Spotlight,
  Spotlight as SpotlightIcon,
  SprayCan,
  SprayCan as SprayCanIcon,
  Sprout,
  Sprout as SproutIcon,
  Square,
  SquareActivity,
  SquareActivity as SquareActivityIcon,
  SquareArrowDown,
  SquareArrowDown as SquareArrowDownIcon,
  SquareArrowDownLeft,
  SquareArrowDownLeft as SquareArrowDownLeftIcon,
  SquareArrowDownRight,
  SquareArrowDownRight as SquareArrowDownRightIcon,
  SquareArrowLeft,
  SquareArrowLeft as SquareArrowLeftIcon,
  SquareArrowOutDownLeft,
  SquareArrowOutDownLeft as SquareArrowOutDownLeftIcon,
  SquareArrowOutDownRight,
  SquareArrowOutDownRight as SquareArrowOutDownRightIcon,
  SquareArrowOutUpLeft,
  SquareArrowOutUpLeft as SquareArrowOutUpLeftIcon,
  SquareArrowOutUpRight,
  SquareArrowOutUpRight as SquareArrowOutUpRightIcon,
  SquareArrowRight,
  SquareArrowRightEnter,
  SquareArrowRightEnter as SquareArrowRightEnterIcon,
  SquareArrowRightExit,
  SquareArrowRightExit as SquareArrowRightExitIcon,
  SquareArrowRight as SquareArrowRightIcon,
  SquareArrowUp,
  SquareArrowUp as SquareArrowUpIcon,
  SquareArrowUpLeft,
  SquareArrowUpLeft as SquareArrowUpLeftIcon,
  SquareArrowUpRight,
  SquareArrowUpRight as SquareArrowUpRightIcon,
  SquareAsterisk,
  SquareAsterisk as SquareAsteriskIcon,
  SquareBottomDashedScissors,
  SquareBottomDashedScissors as SquareBottomDashedScissorsIcon,
  SquareCenterlineDashedHorizontal,
  SquareCenterlineDashedHorizontal as SquareCenterlineDashedHorizontalIcon,
  SquareCenterlineDashedVertical,
  SquareCenterlineDashedVertical as SquareCenterlineDashedVerticalIcon,
  SquareChartGantt,
  SquareChartGantt as SquareChartGanttIcon,
  SquareCheck,
  SquareCheckBig,
  SquareCheckBig as SquareCheckBigIcon,
  SquareCheck as SquareCheckIcon,
  SquareChevronDown,
  SquareChevronDown as SquareChevronDownIcon,
  SquareChevronLeft,
  SquareChevronLeft as SquareChevronLeftIcon,
  SquareChevronRight,
  SquareChevronRight as SquareChevronRightIcon,
  SquareChevronUp,
  SquareChevronUp as SquareChevronUpIcon,
  SquareCode,
  SquareCode as SquareCodeIcon,
  SquareDashed,
  SquareDashedBottom,
  SquareDashedBottomCode,
  SquareDashedBottomCode as SquareDashedBottomCodeIcon,
  SquareDashedBottom as SquareDashedBottomIcon,
  SquareDashed as SquareDashedIcon,
  SquareDashedKanban,
  SquareDashedKanban as SquareDashedKanbanIcon,
  SquareDashedMousePointer,
  SquareDashedMousePointer as SquareDashedMousePointerIcon,
  SquareDashedTopSolid,
  SquareDashedTopSolid as SquareDashedTopSolidIcon,
  SquareDivide,
  SquareDivide as SquareDivideIcon,
  SquareDot,
  SquareDot as SquareDotIcon,
  SquareEqual,
  SquareEqual as SquareEqualIcon,
  SquareFunction,
  SquareFunction as SquareFunctionIcon,
  SquareChartGantt as SquareGanttChart,
  SquareChartGantt as SquareGanttChartIcon,
  Square as SquareIcon,
  SquareKanban,
  SquareKanban as SquareKanbanIcon,
  SquareLibrary,
  SquareLibrary as SquareLibraryIcon,
  SquareM,
  SquareM as SquareMIcon,
  SquareMenu,
  SquareMenu as SquareMenuIcon,
  SquareMinus,
  SquareMinus as SquareMinusIcon,
  SquareMousePointer,
  SquareMousePointer as SquareMousePointerIcon,
  SquareParking,
  SquareParking as SquareParkingIcon,
  SquareParkingOff,
  SquareParkingOff as SquareParkingOffIcon,
  SquarePause,
  SquarePause as SquarePauseIcon,
  SquarePen,
  SquarePen as SquarePenIcon,
  SquarePercent,
  SquarePercent as SquarePercentIcon,
  SquarePi,
  SquarePi as SquarePiIcon,
  SquarePilcrow,
  SquarePilcrow as SquarePilcrowIcon,
  SquarePlay,
  SquarePlay as SquarePlayIcon,
  SquarePlus,
  SquarePlus as SquarePlusIcon,
  SquarePower,
  SquarePower as SquarePowerIcon,
  SquareRadical,
  SquareRadical as SquareRadicalIcon,
  SquareRoundCorner,
  SquareRoundCorner as SquareRoundCornerIcon,
  SquareScissors,
  SquareScissors as SquareScissorsIcon,
  SquareSigma,
  SquareSigma as SquareSigmaIcon,
  SquareSlash,
  SquareSlash as SquareSlashIcon,
  SquareSplitHorizontal,
  SquareSplitHorizontal as SquareSplitHorizontalIcon,
  SquareSplitVertical,
  SquareSplitVertical as SquareSplitVerticalIcon,
  SquareSquare,
  SquareSquare as SquareSquareIcon,
  SquareStack,
  SquareStack as SquareStackIcon,
  SquareStar,
  SquareStar as SquareStarIcon,
  SquareStop,
  SquareStop as SquareStopIcon,
  SquareTerminal,
  SquareTerminal as SquareTerminalIcon,
  SquareUser,
  SquareUser as SquareUserIcon,
  SquareUserRound,
  SquareUserRound as SquareUserRoundIcon,
  SquareX,
  SquareX as SquareXIcon,
  SquaresExclude,
  SquaresExclude as SquaresExcludeIcon,
  SquaresIntersect,
  SquaresIntersect as SquaresIntersectIcon,
  SquaresSubtract,
  SquaresSubtract as SquaresSubtractIcon,
  SquaresUnite,
  SquaresUnite as SquaresUniteIcon,
  Squircle,
  SquircleDashed,
  SquircleDashed as SquircleDashedIcon,
  Squircle as SquircleIcon,
  Squirrel,
  Squirrel as SquirrelIcon,
  Stamp,
  Stamp as StampIcon,
  Star,
  StarHalf,
  StarHalf as StarHalfIcon,
  Star as StarIcon,
  StarOff,
  StarOff as StarOffIcon,
  Sparkles as Stars,
  Sparkles as StarsIcon,
  StepBack,
  StepBack as StepBackIcon,
  StepForward,
  StepForward as StepForwardIcon,
  Stethoscope,
  Stethoscope as StethoscopeIcon,
  Sticker,
  Sticker as StickerIcon,
  StickyNote,
  StickyNote as StickyNoteIcon,
  Stone,
  Stone as StoneIcon,
  CircleStop as StopCircle,
  CircleStop as StopCircleIcon,
  Store,
  Store as StoreIcon,
  StretchHorizontal,
  StretchHorizontal as StretchHorizontalIcon,
  StretchVertical,
  StretchVertical as StretchVerticalIcon,
  Strikethrough,
  Strikethrough as StrikethroughIcon,
  Subscript,
  Subscript as SubscriptIcon,
  Captions as Subtitles,
  Captions as SubtitlesIcon,
  Sun,
  SunDim,
  SunDim as SunDimIcon,
  Sun as SunIcon,
  SunMedium,
  SunMedium as SunMediumIcon,
  SunMoon,
  SunMoon as SunMoonIcon,
  SunSnow,
  SunSnow as SunSnowIcon,
  Sunrise,
  Sunrise as SunriseIcon,
  Sunset,
  Sunset as SunsetIcon,
  Superscript,
  Superscript as SuperscriptIcon,
  SwatchBook,
  SwatchBook as SwatchBookIcon,
  SwissFranc,
  SwissFranc as SwissFrancIcon,
  SwitchCamera,
  SwitchCamera as SwitchCameraIcon,
  Sword,
  Sword as SwordIcon,
  Swords,
  Swords as SwordsIcon,
  Syringe,
  Syringe as SyringeIcon,
  Table,
  Table2,
  Table2 as Table2Icon,
  TableCellsMerge,
  TableCellsMerge as TableCellsMergeIcon,
  TableCellsSplit,
  TableCellsSplit as TableCellsSplitIcon,
  TableColumnsSplit,
  TableColumnsSplit as TableColumnsSplitIcon,
  Columns3Cog as TableConfig,
  Columns3Cog as TableConfigIcon,
  Table as TableIcon,
  TableOfContents,
  TableOfContents as TableOfContentsIcon,
  TableProperties,
  TableProperties as TablePropertiesIcon,
  TableRowsSplit,
  TableRowsSplit as TableRowsSplitIcon,
  Tablet,
  Tablet as TabletIcon,
  TabletSmartphone,
  TabletSmartphone as TabletSmartphoneIcon,
  Tablets,
  Tablets as TabletsIcon,
  Tag,
  Tag as TagIcon,
  Tags,
  Tags as TagsIcon,
  Tally1,
  Tally1 as Tally1Icon,
  Tally2,
  Tally2 as Tally2Icon,
  Tally3,
  Tally3 as Tally3Icon,
  Tally4,
  Tally4 as Tally4Icon,
  Tally5,
  Tally5 as Tally5Icon,
  Tangent,
  Tangent as TangentIcon,
  Target,
  Target as TargetIcon,
  Telescope,
  Telescope as TelescopeIcon,
  Tent,
  Tent as TentIcon,
  TentTree,
  TentTree as TentTreeIcon,
  Terminal,
  Terminal as TerminalIcon,
  SquareTerminal as TerminalSquare,
  SquareTerminal as TerminalSquareIcon,
  TestTube,
  TestTubeDiagonal as TestTube2,
  TestTubeDiagonal as TestTube2Icon,
  TestTubeDiagonal,
  TestTubeDiagonal as TestTubeDiagonalIcon,
  TestTube as TestTubeIcon,
  TestTubes,
  TestTubes as TestTubesIcon,
  TextAlignStart as Text,
  TextAlignCenter,
  TextAlignCenter as TextAlignCenterIcon,
  TextAlignEnd,
  TextAlignEnd as TextAlignEndIcon,
  TextAlignJustify,
  TextAlignJustify as TextAlignJustifyIcon,
  TextAlignStart,
  TextAlignStart as TextAlignStartIcon,
  TextCursor,
  TextCursor as TextCursorIcon,
  TextCursorInput,
  TextCursorInput as TextCursorInputIcon,
  TextAlignStart as TextIcon,
  TextInitial,
  TextInitial as TextInitialIcon,
  TextQuote,
  TextQuote as TextQuoteIcon,
  TextSearch,
  TextSearch as TextSearchIcon,
  TextSelect,
  TextSelect as TextSelectIcon,
  TextSelect as TextSelection,
  TextSelect as TextSelectionIcon,
  TextWrap,
  TextWrap as TextWrapIcon,
  Theater,
  Theater as TheaterIcon,
  Thermometer,
  Thermometer as ThermometerIcon,
  ThermometerSnowflake,
  ThermometerSnowflake as ThermometerSnowflakeIcon,
  ThermometerSun,
  ThermometerSun as ThermometerSunIcon,
  ThumbsDown,
  ThumbsDown as ThumbsDownIcon,
  ThumbsUp,
  ThumbsUp as ThumbsUpIcon,
  Ticket,
  TicketCheck,
  TicketCheck as TicketCheckIcon,
  Ticket as TicketIcon,
  TicketMinus,
  TicketMinus as TicketMinusIcon,
  TicketPercent,
  TicketPercent as TicketPercentIcon,
  TicketPlus,
  TicketPlus as TicketPlusIcon,
  TicketSlash,
  TicketSlash as TicketSlashIcon,
  TicketX,
  TicketX as TicketXIcon,
  Tickets,
  Tickets as TicketsIcon,
  TicketsPlane,
  TicketsPlane as TicketsPlaneIcon,
  Timer,
  Timer as TimerIcon,
  TimerOff,
  TimerOff as TimerOffIcon,
  TimerReset,
  TimerReset as TimerResetIcon,
  ToggleLeft,
  ToggleLeft as ToggleLeftIcon,
  ToggleRight,
  ToggleRight as ToggleRightIcon,
  Toilet,
  Toilet as ToiletIcon,
  ToolCase,
  ToolCase as ToolCaseIcon,
  Toolbox,
  Toolbox as ToolboxIcon,
  Tornado,
  Tornado as TornadoIcon,
  Torus,
  Torus as TorusIcon,
  Touchpad,
  Touchpad as TouchpadIcon,
  TouchpadOff,
  TouchpadOff as TouchpadOffIcon,
  TowelRack,
  TowelRack as TowelRackIcon,
  TowerControl,
  TowerControl as TowerControlIcon,
  ToyBrick,
  ToyBrick as ToyBrickIcon,
  Tractor,
  Tractor as TractorIcon,
  TrafficCone,
  TrafficCone as TrafficConeIcon,
  TramFront as Train,
  TrainFront,
  TrainFront as TrainFrontIcon,
  TrainFrontTunnel,
  TrainFrontTunnel as TrainFrontTunnelIcon,
  TramFront as TrainIcon,
  TrainTrack,
  TrainTrack as TrainTrackIcon,
  TramFront,
  TramFront as TramFrontIcon,
  Transgender,
  Transgender as TransgenderIcon,
  Trash,
  Trash2,
  Trash2 as Trash2Icon,
  Trash as TrashIcon,
  TreeDeciduous,
  TreeDeciduous as TreeDeciduousIcon,
  TreePalm,
  TreePalm as TreePalmIcon,
  TreePine,
  TreePine as TreePineIcon,
  Trees,
  Trees as TreesIcon,
  Trello,
  Trello as TrelloIcon,
  TrendingDown,
  TrendingDown as TrendingDownIcon,
  TrendingUp,
  TrendingUpDown,
  TrendingUpDown as TrendingUpDownIcon,
  TrendingUp as TrendingUpIcon,
  Triangle,
  TriangleAlert,
  TriangleAlert as TriangleAlertIcon,
  TriangleDashed,
  TriangleDashed as TriangleDashedIcon,
  Triangle as TriangleIcon,
  TriangleRight,
  TriangleRight as TriangleRightIcon,
  Trophy,
  Trophy as TrophyIcon,
  Truck,
  TruckElectric,
  TruckElectric as TruckElectricIcon,
  Truck as TruckIcon,
  TurkishLira,
  TurkishLira as TurkishLiraIcon,
  Turntable,
  Turntable as TurntableIcon,
  Turtle,
  Turtle as TurtleIcon,
  Tv,
  TvMinimal as Tv2,
  TvMinimal as Tv2Icon,
  Tv as TvIcon,
  TvMinimal,
  TvMinimal as TvMinimalIcon,
  TvMinimalPlay,
  TvMinimalPlay as TvMinimalPlayIcon,
  Twitch,
  Twitch as TwitchIcon,
  Twitter,
  Twitter as TwitterIcon,
  Type,
  Type as TypeIcon,
  TypeOutline,
  TypeOutline as TypeOutlineIcon,
  Umbrella,
  Umbrella as UmbrellaIcon,
  UmbrellaOff,
  UmbrellaOff as UmbrellaOffIcon,
  Underline,
  Underline as UnderlineIcon,
  Undo,
  Undo2,
  Undo2 as Undo2Icon,
  UndoDot,
  UndoDot as UndoDotIcon,
  Undo as UndoIcon,
  UnfoldHorizontal,
  UnfoldHorizontal as UnfoldHorizontalIcon,
  UnfoldVertical,
  UnfoldVertical as UnfoldVerticalIcon,
  Ungroup,
  Ungroup as UngroupIcon,
  University,
  University as UniversityIcon,
  Unlink,
  Unlink2,
  Unlink2 as Unlink2Icon,
  Unlink as UnlinkIcon,
  LockOpen as Unlock,
  LockOpen as UnlockIcon,
  LockKeyholeOpen as UnlockKeyhole,
  LockKeyholeOpen as UnlockKeyholeIcon,
  Unplug,
  Unplug as UnplugIcon,
  Upload,
  CloudUpload as UploadCloud,
  CloudUpload as UploadCloudIcon,
  Upload as UploadIcon,
  Usb,
  Usb as UsbIcon,
  User,
  UserRound as User2,
  UserRound as User2Icon,
  UserCheck,
  UserRoundCheck as UserCheck2,
  UserRoundCheck as UserCheck2Icon,
  UserCheck as UserCheckIcon,
  CircleUser as UserCircle,
  CircleUserRound as UserCircle2,
  CircleUserRound as UserCircle2Icon,
  CircleUser as UserCircleIcon,
  UserCog,
  UserRoundCog as UserCog2,
  UserRoundCog as UserCog2Icon,
  UserCog as UserCogIcon,
  User as UserIcon,
  UserKey,
  UserKey as UserKeyIcon,
  UserLock,
  UserLock as UserLockIcon,
  UserMinus,
  UserRoundMinus as UserMinus2,
  UserRoundMinus as UserMinus2Icon,
  UserMinus as UserMinusIcon,
  UserPen,
  UserPen as UserPenIcon,
  UserPlus,
  UserRoundPlus as UserPlus2,
  UserRoundPlus as UserPlus2Icon,
  UserPlus as UserPlusIcon,
  UserRound,
  UserRoundCheck,
  UserRoundCheck as UserRoundCheckIcon,
  UserRoundCog,
  UserRoundCog as UserRoundCogIcon,
  UserRound as UserRoundIcon,
  UserRoundKey,
  UserRoundKey as UserRoundKeyIcon,
  UserRoundMinus,
  UserRoundMinus as UserRoundMinusIcon,
  UserRoundPen,
  UserRoundPen as UserRoundPenIcon,
  UserRoundPlus,
  UserRoundPlus as UserRoundPlusIcon,
  UserRoundSearch,
  UserRoundSearch as UserRoundSearchIcon,
  UserRoundX,
  UserRoundX as UserRoundXIcon,
  UserSearch,
  UserSearch as UserSearchIcon,
  SquareUser as UserSquare,
  SquareUserRound as UserSquare2,
  SquareUserRound as UserSquare2Icon,
  SquareUser as UserSquareIcon,
  UserStar,
  UserStar as UserStarIcon,
  UserX,
  UserRoundX as UserX2,
  UserRoundX as UserX2Icon,
  UserX as UserXIcon,
  Users,
  UsersRound as Users2,
  UsersRound as Users2Icon,
  Users as UsersIcon,
  UsersRound,
  UsersRound as UsersRoundIcon,
  Utensils,
  UtensilsCrossed,
  UtensilsCrossed as UtensilsCrossedIcon,
  Utensils as UtensilsIcon,
  UtilityPole,
  UtilityPole as UtilityPoleIcon,
  Van,
  Van as VanIcon,
  Variable,
  Variable as VariableIcon,
  Vault,
  Vault as VaultIcon,
  VectorSquare,
  VectorSquare as VectorSquareIcon,
  Vegan,
  Vegan as VeganIcon,
  VenetianMask,
  VenetianMask as VenetianMaskIcon,
  Venus,
  VenusAndMars,
  VenusAndMars as VenusAndMarsIcon,
  Venus as VenusIcon,
  BadgeCheck as Verified,
  BadgeCheck as VerifiedIcon,
  Vibrate,
  Vibrate as VibrateIcon,
  VibrateOff,
  VibrateOff as VibrateOffIcon,
  Video,
  Video as VideoIcon,
  VideoOff,
  VideoOff as VideoOffIcon,
  Videotape,
  Videotape as VideotapeIcon,
  View,
  View as ViewIcon,
  Voicemail,
  Voicemail as VoicemailIcon,
  Volleyball,
  Volleyball as VolleyballIcon,
  Volume,
  Volume1,
  Volume1 as Volume1Icon,
  Volume2,
  Volume2 as Volume2Icon,
  Volume as VolumeIcon,
  VolumeOff,
  VolumeOff as VolumeOffIcon,
  VolumeX,
  VolumeX as VolumeXIcon,
  Vote,
  Vote as VoteIcon,
  Wallet,
  WalletMinimal as Wallet2,
  WalletMinimal as Wallet2Icon,
  WalletCards,
  WalletCards as WalletCardsIcon,
  Wallet as WalletIcon,
  WalletMinimal,
  WalletMinimal as WalletMinimalIcon,
  Wallpaper,
  Wallpaper as WallpaperIcon,
  Wand,
  WandSparkles as Wand2,
  WandSparkles as Wand2Icon,
  Wand as WandIcon,
  WandSparkles,
  WandSparkles as WandSparklesIcon,
  Warehouse,
  Warehouse as WarehouseIcon,
  WashingMachine,
  WashingMachine as WashingMachineIcon,
  Watch,
  Watch as WatchIcon,
  Waves,
  WavesArrowDown,
  WavesArrowDown as WavesArrowDownIcon,
  WavesArrowUp,
  WavesArrowUp as WavesArrowUpIcon,
  Waves as WavesIcon,
  WavesLadder,
  WavesLadder as WavesLadderIcon,
  Waypoints,
  Waypoints as WaypointsIcon,
  Webcam,
  Webcam as WebcamIcon,
  Webhook,
  Webhook as WebhookIcon,
  WebhookOff,
  WebhookOff as WebhookOffIcon,
  Weight,
  Weight as WeightIcon,
  WeightTilde,
  WeightTilde as WeightTildeIcon,
  Wheat,
  Wheat as WheatIcon,
  WheatOff,
  WheatOff as WheatOffIcon,
  WholeWord,
  WholeWord as WholeWordIcon,
  Wifi,
  WifiCog,
  WifiCog as WifiCogIcon,
  WifiHigh,
  WifiHigh as WifiHighIcon,
  Wifi as WifiIcon,
  WifiLow,
  WifiLow as WifiLowIcon,
  WifiOff,
  WifiOff as WifiOffIcon,
  WifiPen,
  WifiPen as WifiPenIcon,
  WifiSync,
  WifiSync as WifiSyncIcon,
  WifiZero,
  WifiZero as WifiZeroIcon,
  Wind,
  WindArrowDown,
  WindArrowDown as WindArrowDownIcon,
  Wind as WindIcon,
  Wine,
  Wine as WineIcon,
  WineOff,
  WineOff as WineOffIcon,
  Workflow,
  Workflow as WorkflowIcon,
  Worm,
  Worm as WormIcon,
  TextWrap as WrapText,
  TextWrap as WrapTextIcon,
  Wrench,
  Wrench as WrenchIcon,
  X,
  CircleX as XCircle,
  CircleX as XCircleIcon,
  X as XIcon,
  XLineTop,
  XLineTop as XLineTopIcon,
  OctagonX as XOctagon,
  OctagonX as XOctagonIcon,
  SquareX as XSquare,
  SquareX as XSquareIcon,
  Youtube,
  Youtube as YoutubeIcon,
  Zap,
  Zap as ZapIcon,
  ZapOff,
  ZapOff as ZapOffIcon,
  ZoomIn,
  ZoomIn as ZoomInIcon,
  ZoomOut,
  ZoomOut as ZoomOutIcon,
  createLucideIcon,
  icons_exports as icons
};
//# sourceMappingURL=lucide-react.js.map
