import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const API_BASE = `${import.meta.env.VITE_API_URL}/v1`;

const initialState = {
  cart: {
    items: [],
    totalPrice: 0,
    totalQuantity: 0,
    isLoading: false,
    error: null,
  },
  wishlist: {
    items: [],
    isLoading: false,
    error: null,
  },
};

const unwrapAxiosError = (error) => {
  const serverMsg = error?.response?.data?.message;
  return serverMsg || error.message || "Request failed";
};

export const fetchCartAction = createAsyncThunk(
  "cart/fetchCart",
  async (_, thunkAPI) => {
    try {
      const response = await axios.get(`${API_BASE}/user/cart`, {
        withCredentials: true,
      });
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(unwrapAxiosError(error));
    }
  }
);

export const addToCartAction = createAsyncThunk(
  "cart/addToCart",
  async ({ productId, variantId, quantity }, thunkAPI) => {
    try {
      const response = await axios.post(
        `${API_BASE}/user/cart`,
        { productId, variantId, quantity },
        {
          withCredentials: true,
        }
      );
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(unwrapAxiosError(error));
    }
  }
);

export const updateCartItemAction = createAsyncThunk(
  "cart/updateCartItem",
  async ({ itemId, quantity }, thunkAPI) => {
    try {
      const response = await axios.patch(
        `${API_BASE}/user/cart/${itemId}`,
        { quantity },
        {
          withCredentials: true,
        }
      );
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(unwrapAxiosError(error));
    }
  }
);

export const removeFromCartAction = createAsyncThunk(
  "cart/removeFromCart",
  async (itemId, thunkAPI) => {
    try {
      const response = await axios.delete(`${API_BASE}/user/cart/${itemId}`, {
        withCredentials: true,
      });
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(unwrapAxiosError(error));
    }
  }
);

export const fetchWishlistAction = createAsyncThunk(
  "cart/fetchWishlist",
  async (_, thunkAPI) => {
    try {
      const response = await axios.get(`${API_BASE}/user/wishlist`, {
        withCredentials: true,
      });
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(unwrapAxiosError(error));
    }
  }
);

export const addToWishlistAction = createAsyncThunk(
  "cart/addToWishlist",
  async ({ productId }, thunkAPI) => {
    try {
      const response = await axios.post(
        `${API_BASE}/user/wishlist`,
        { productId },
        {
          withCredentials: true,
        }
      );
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(unwrapAxiosError(error));
    }
  }
);

export const removeFromWishlistAction = createAsyncThunk(
  "cart/removeFromWishlist",
  async (productId, thunkAPI) => {
    try {
      const response = await axios.delete(
        `${API_BASE}/user/wishlist/${productId}`,
        {
          withCredentials: true,
        }
      );
      return response.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(unwrapAxiosError(error));
    }
  }
);

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchCartAction.pending, (state) => {
        state.cart.isLoading = true;
        state.cart.error = null;
      })
      .addCase(fetchCartAction.fulfilled, (state, action) => {
        state.cart.isLoading = false;
        state.cart.items = action.payload.data.cart || [];
        state.cart.totalQuantity = action.payload.data.totalQuantity || 0;
        state.cart.totalPrice = action.payload.data.totalPrice || 0;
      })
      .addCase(fetchCartAction.rejected, (state, action) => {
        state.cart.isLoading = false;
        state.cart.error = action.payload;
      })
      .addCase(addToCartAction.pending, (state) => {
        state.cart.isLoading = true;
        state.cart.error = null;
      })
      .addCase(addToCartAction.fulfilled, (state, action) => {
        state.cart.isLoading = false;
        state.cart.items = action.payload.data.cart || [];
        state.cart.totalQuantity = action.payload.data.cart.reduce(
          (sum, item) => sum + item.quantity,
          0
        );
        state.cart.totalPrice = action.payload.data.cart.reduce(
          (sum, item) => sum + item.subTotal,
          0
        );
      })
      .addCase(addToCartAction.rejected, (state, action) => {
        state.cart.isLoading = false;
        state.cart.error = action.payload;
      })
      .addCase(updateCartItemAction.pending, (state) => {
        state.cart.isLoading = true;
        state.cart.error = null;
      })
      .addCase(updateCartItemAction.fulfilled, (state, action) => {
        state.cart.isLoading = false;
        state.cart.items = action.payload.data.cart || [];
        state.cart.totalQuantity = action.payload.data.cart.reduce(
          (sum, item) => sum + item.quantity,
          0
        );
        state.cart.totalPrice = action.payload.data.cart.reduce(
          (sum, item) => sum + item.subTotal,
          0
        );
      })
      .addCase(updateCartItemAction.rejected, (state, action) => {
        state.cart.isLoading = false;
        state.cart.error = action.payload;
      })
      .addCase(removeFromCartAction.pending, (state) => {
        state.cart.isLoading = true;
        state.cart.error = null;
      })
      .addCase(removeFromCartAction.fulfilled, (state, action) => {
        state.cart.isLoading = false;
        state.cart.items = action.payload.data.cart || [];
        state.cart.totalQuantity = action.payload.data.cart.reduce(
          (sum, item) => sum + item.quantity,
          0
        );
        state.cart.totalPrice = action.payload.data.cart.reduce(
          (sum, item) => sum + item.subTotal,
          0
        );
      })
      .addCase(removeFromCartAction.rejected, (state, action) => {
        state.cart.isLoading = false;
        state.cart.error = action.payload;
      })
      .addCase(fetchWishlistAction.pending, (state) => {
        state.wishlist.isLoading = true;
        state.wishlist.error = null;
      })
      .addCase(fetchWishlistAction.fulfilled, (state, action) => {
        state.wishlist.isLoading = false;
        state.wishlist.items = action.payload.data.wishlist || [];
      })
      .addCase(fetchWishlistAction.rejected, (state, action) => {
        state.wishlist.isLoading = false;
        state.wishlist.error = action.payload;
      })
      .addCase(addToWishlistAction.pending, (state) => {
        state.wishlist.isLoading = true;
        state.wishlist.error = null;
      })
      .addCase(addToWishlistAction.fulfilled, (state, action) => {
        state.wishlist.isLoading = false;
        state.wishlist.items = action.payload.data.wishlist || state.wishlist.items;
      })
      .addCase(addToWishlistAction.rejected, (state, action) => {
        state.wishlist.isLoading = false;
        state.wishlist.error = action.payload;
      })
      .addCase(removeFromWishlistAction.pending, (state) => {
        state.wishlist.isLoading = true;
        state.wishlist.error = null;
      })
      .addCase(removeFromWishlistAction.fulfilled, (state, action) => {
        state.wishlist.isLoading = false;
        state.wishlist.items = action.payload.data.wishlist || [];
      })
      .addCase(removeFromWishlistAction.rejected, (state, action) => {
        state.wishlist.isLoading = false;
        state.wishlist.error = action.payload;
      });
  },
});

export default cartSlice.reducer;
